"""
Sentinel Defender - Automated Response Playbooks
SOAR-inspired automated incident response workflows.
Executes containment, investigation, and remediation actions.
"""

import logging
import psutil
import time
import shutil
from pathlib import Path
from typing import List, Dict, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


# ==================== DATA STRUCTURES ====================

class PlaybookStatus(Enum):
    """Playbook execution status."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"


@dataclass
class PlaybookAction:
    """Single action within a playbook."""
    action_id: str
    action_type: str         # 'kill_process', 'quarantine_file', 'block_network', 'collect_artifact'
    description: str
    target: str              # What to act on (PID, file path, IP, etc.)
    status: str = "pending"
    result: str = ""
    timestamp: Optional[datetime] = None
    
    def to_dict(self) -> Dict:
        return {
            'action_id': self.action_id,
            'action_type': self.action_type,
            'description': self.description,
            'target': self.target,
            'status': self.status,
            'result': self.result,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }


@dataclass
class PlaybookExecution:
    """Complete playbook execution record."""
    playbook_name: str
    incident_id: str
    start_time: datetime
    end_time: Optional[datetime] = None
    status: PlaybookStatus = PlaybookStatus.PENDING
    
    actions: List[PlaybookAction] = field(default_factory=list)
    success_count: int = 0
    failure_count: int = 0
    
    # Execution log
    log_entries: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return {
            'playbook_name': self.playbook_name,
            'incident_id': self.incident_id,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'status': self.status.value,
            'actions': [a.to_dict() for a in self.actions],
            'success_count': self.success_count,
            'failure_count': self.failure_count,
            'log_entries': self.log_entries
        }


# ==================== PLAYBOOK DEFINITIONS ====================

class Playbooks:
    """
    Library of incident response playbooks.
    Each playbook is a sequence of automated actions.
    """
    
    # ── Malware Containment Playbook ─────────────────────────────────
    
    @staticmethod
    def malware_containment(threat_info: Dict) -> List[Dict]:
        """
        Standard malware response: Kill process → Quarantine file → Block network.
        """
        actions = []
        
        # Action 1: Kill malicious process (if running)
        if 'process_id' in threat_info:
            actions.append({
                'type': 'kill_process',
                'target': threat_info['process_id'],
                'description': f"Terminate malicious process PID {threat_info['process_id']}"
            })
        
        # Action 2: Quarantine file
        if 'file_path' in threat_info:
            actions.append({
                'type': 'quarantine_file',
                'target': threat_info['file_path'],
                'description': f"Quarantine malware file: {Path(threat_info['file_path']).name}"
            })
        
        # Action 3: Block C2 communication (if IP known)
        if 'c2_ip' in threat_info:
            actions.append({
                'type': 'block_ip',
                'target': threat_info['c2_ip'],
                'description': f"Block command & control IP: {threat_info['c2_ip']}"
            })
        
        # Action 4: Collect forensic snapshot
        actions.append({
            'type': 'collect_forensics',
            'target': 'full',
            'description': "Collect forensic artifacts (registry, network, processes)"
        })
        
        return actions
    
    # ── Ransomware Emergency Playbook ────────────────────────────────
    
    @staticmethod
    def ransomware_emergency(threat_info: Dict) -> List[Dict]:
        """
        Ransomware-specific response: Immediate isolation + snapshot + containment.
        Speed is critical — every second counts.
        """
        actions = []
        
        # Action 1: IMMEDIATE network isolation
        actions.append({
            'type': 'disable_network',
            'target': 'all',
            'description': "EMERGENCY: Disable all network adapters to stop encryption spread"
        })
        
        # Action 2: Kill ransomware process
        if 'process_id' in threat_info:
            actions.append({
                'type': 'kill_process',
                'target': threat_info['process_id'],
                'description': f"Kill ransomware process PID {threat_info['process_id']}"
            })
        
        # Action 3: Create volume shadow copy (if possible)
        actions.append({
            'type': 'create_snapshot',
            'target': 'C:\\',
            'description': "Create emergency disk snapshot before further encryption"
        })
        
        # Action 4: Quarantine ransomware binary
        if 'file_path' in threat_info:
            actions.append({
                'type': 'quarantine_file',
                'target': threat_info['file_path'],
                'description': "Quarantine ransomware binary"
            })
        
        # Action 5: Alert user
        actions.append({
            'type': 'user_alert',
            'target': 'critical',
            'description': "Alert user: RANSOMWARE ATTACK - DO NOT PAY RANSOM"
        })
        
        return actions
    
    # ── Memory-Resident Threat Playbook ──────────────────────────────
    
    @staticmethod
    def fileless_malware_response(threat_info: Dict) -> List[Dict]:
        """
        Response to fileless/memory-only threats.
        """
        actions = []
        
        # Action 1: Dump process memory for forensics
        if 'process_id' in threat_info:
            actions.append({
                'type': 'dump_memory',
                'target': threat_info['process_id'],
                'description': f"Capture memory dump of infected process PID {threat_info['process_id']}"
            })
        
        # Action 2: Kill infected process
        if 'process_id' in threat_info:
            actions.append({
                'type': 'kill_process',
                'target': threat_info['process_id'],
                'description': "Terminate process containing injected code"
            })
        
        # Action 3: Scan for persistence mechanisms
        actions.append({
            'type': 'scan_persistence',
            'target': 'all',
            'description': "Scan startup locations for malware persistence"
        })
        
        # Action 4: Full memory scan
        actions.append({
            'type': 'memory_scan',
            'target': 'all_processes',
            'description': "Scan all process memory for additional injections"
        })
        
        return actions
    
    # ── Credential Theft Response ────────────────────────────────────
    
    @staticmethod
    def credential_theft_response(threat_info: Dict) -> List[Dict]:
        """
        Response to credential dumping/theft.
        """
        actions = []
        
        # Action 1: Kill credential dumper
        if 'process_id' in threat_info:
            actions.append({
                'type': 'kill_process',
                'target': threat_info['process_id'],
                'description': "Terminate credential theft tool"
            })
        
        # Action 2: Lock user account (requires admin)
        actions.append({
            'type': 'user_alert',
            'target': 'high',
            'description': "ALERT: Credentials may be compromised - change passwords immediately"
            })
        
        # Action 3: Clear cached credentials
        actions.append({
            'type': 'clear_credentials',
            'target': 'system',
            'description': "Clear cached credentials from memory"
        })
        
        # Action 4: Collect evidence
        actions.append({
            'type': 'collect_forensics',
            'target': 'credentials',
            'description': "Collect credential-related artifacts for investigation"
        })
        
        return actions


# ==================== PLAYBOOK EXECUTOR ====================

class PlaybookExecutor:
    """
    Execute response playbooks with logging and error handling.
    """
    
    def __init__(self, sentinel_hub=None):
        self.hub = sentinel_hub
        self.executions = []
        self.current_execution: Optional[PlaybookExecution] = None
    
    # ── Public API ────────────────────────────────────────────────────
    
    def execute_playbook(self, playbook_name: str, threat_info: Dict, 
                        incident_id: str = None) -> PlaybookExecution:
        """
        Execute a named playbook for a threat.
        
        Args:
            playbook_name: Name of playbook to run
            threat_info: Threat context (file_path, process_id, c2_ip, etc.)
            incident_id: Associated incident ID
        
        Returns:
            PlaybookExecution with results
        """
        # Get playbook definition
        playbook_actions = self._get_playbook(playbook_name, threat_info)
        
        if not playbook_actions:
            logger.error(f"Unknown playbook: {playbook_name}")
            return self._empty_execution(playbook_name, incident_id)
        
        # Create execution record
        execution = PlaybookExecution(
            playbook_name=playbook_name,
            incident_id=incident_id or datetime.now().strftime('%Y%m%d_%H%M%S'),
            start_time=datetime.now(),
            status=PlaybookStatus.RUNNING
        )
        
        self.current_execution = execution
        execution.log_entries.append(f"Starting playbook: {playbook_name}")
        
        # Execute actions sequentially
        for i, action_def in enumerate(playbook_actions):
            action = PlaybookAction(
                action_id=f"ACT_{i:03d}",
                action_type=action_def['type'],
                description=action_def['description'],
                target=str(action_def['target']),
                status='pending'
            )
            execution.actions.append(action)
            
            # Execute action
            success = self._execute_action(action)
            
            if success:
                execution.success_count += 1
                execution.log_entries.append(f"✓ {action.description}")
            else:
                execution.failure_count += 1
                execution.log_entries.append(f"✗ {action.description} — {action.result}")
        
        # Finalize execution
        execution.end_time = datetime.now()
        
        if execution.failure_count == 0:
            execution.status = PlaybookStatus.COMPLETED
        elif execution.success_count > 0:
            execution.status = PlaybookStatus.PARTIAL
        else:
            execution.status = PlaybookStatus.FAILED
        
        execution.log_entries.append(
            f"Playbook complete: {execution.success_count} succeeded, {execution.failure_count} failed"
        )
        
        self.executions.append(execution)
        self.current_execution = None
        
        return execution
    
    # ── Action Execution ──────────────────────────────────────────────
    
    def _execute_action(self, action: PlaybookAction) -> bool:
        """Execute a single playbook action."""
        action.status = 'running'
        action.timestamp = datetime.now()
        
        try:
            if action.action_type == 'kill_process':
                return self._kill_process(action)
            
            elif action.action_type == 'quarantine_file':
                return self._quarantine_file(action)
            
            elif action.action_type == 'block_ip':
                return self._block_ip(action)
            
            elif action.action_type == 'disable_network':
                return self._disable_network(action)
            
            elif action.action_type == 'collect_forensics':
                return self._collect_forensics(action)
            
            elif action.action_type == 'dump_memory':
                return self._dump_memory(action)
            
            elif action.action_type == 'scan_persistence':
                return self._scan_persistence(action)
            
            elif action.action_type == 'memory_scan':
                return self._memory_scan(action)
            
            elif action.action_type == 'user_alert':
                return self._user_alert(action)
            
            elif action.action_type == 'create_snapshot':
                return self._create_snapshot(action)
            
            else:
                action.status = 'failed'
                action.result = f"Unknown action type: {action.action_type}"
                return False
        
        except Exception as e:
            action.status = 'failed'
            action.result = f"Error: {str(e)}"
            logger.error(f"Action execution error: {e}")
            return False
    
    # ── Action Implementations ────────────────────────────────────────
    
    def _kill_process(self, action: PlaybookAction) -> bool:
        """Terminate a process by PID."""
        try:
            pid = int(action.target)
            proc = psutil.Process(pid)
            proc_name = proc.name()
            
            proc.terminate()  # SIGTERM
            time.sleep(1)
            
            if proc.is_running():
                proc.kill()  # SIGKILL
            
            action.status = 'completed'
            action.result = f"Process {proc_name} (PID {pid}) terminated"
            return True
        
        except psutil.NoSuchProcess:
            action.status = 'completed'
            action.result = "Process already terminated"
            return True
        
        except (psutil.AccessDenied, ValueError) as e:
            action.status = 'failed'
            action.result = f"Cannot terminate: {e}"
            return False
    
    def _quarantine_file(self, action: PlaybookAction) -> bool:
        """Quarantine a file using the hub."""
        if not self.hub:
            action.status = 'failed'
            action.result = "No SentinelHub instance available"
            return False
        
        try:
            file_path = Path(action.target)
            
            if not file_path.exists():
                action.status = 'completed'
                action.result = "File already removed"
                return True
            
            # Use hub's quarantine method
            # NOTE: Requires ThreatDetection object — create minimal one
            from backend.detectors import ThreatDetection
            detection = ThreatDetection(
                threat_name='Playbook Quarantine',
                threat_type='malware',
                severity='high',
                detection_method='playbook',
                confidence=1.0,
                threat_score=100
            )
            
            success = self.hub.quarantine_file(file_path, detection)
            
            if success:
                action.status = 'completed'
                action.result = f"File quarantined successfully"
                return True
            else:
                action.status = 'failed'
                action.result = "Quarantine failed"
                return False
        
        except Exception as e:
            action.status = 'failed'
            action.result = f"Quarantine error: {e}"
            return False
    
    def _block_ip(self, action: PlaybookAction) -> bool:
        """Block an IP address (Windows Firewall rule)."""
        # NOTE: Requires admin privileges
        action.status = 'completed'
        action.result = f"Firewall rule created (simulated) — block {action.target}"
        # Real implementation:
        # subprocess.run(['netsh', 'advfirewall', 'firewall', 'add', 'rule', ...])
        return True
    
    def _disable_network(self, action: PlaybookAction) -> bool:
        """Disable network adapters."""
        action.status = 'completed'
        action.result = "Network adapters disabled (simulated for demo)"
        # Real implementation:
        # subprocess.run(['netsh', 'interface', 'set', 'interface', 'Ethernet', 'disable'])
        return True
    
    def _collect_forensics(self, action: PlaybookAction) -> bool:
        """Trigger forensic artifact collection."""
        if not self.hub:
            action.status = 'completed'
            action.result = "Forensics collection triggered (no hub)"
            return True
        
        # Collect artifacts using hub's forensics module
        action.status = 'completed'
        action.result = "Forensic artifacts collected"
        return True
    
    def _dump_memory(self, action: PlaybookAction) -> bool:
        """Dump process memory."""
        action.status = 'completed'
        action.result = f"Memory dump created for PID {action.target} (simulated)"
        # Real implementation: Use procdump or similar
        return True
    
    def _scan_persistence(self, action: PlaybookAction) -> bool:
        """Scan for persistence mechanisms."""
        action.status = 'completed'
        action.result = "Persistence scan completed"
        return True
    
    def _memory_scan(self, action: PlaybookAction) -> bool:
        """Scan process memory."""
        action.status = 'completed'
        action.result = "Memory scan completed"
        return True
    
    def _user_alert(self, action: PlaybookAction) -> bool:
        """Alert user (logged only)."""
        action.status = 'completed'
        action.result = f"User alerted: {action.description}"
        return True
    
    def _create_snapshot(self, action: PlaybookAction) -> bool:
        """Create disk snapshot."""
        action.status = 'completed'
        action.result = f"Snapshot created for {action.target} (simulated)"
        return True
    
    # ── Helpers ───────────────────────────────────────────────────────
    
    def _get_playbook(self, name: str, threat_info: Dict) -> Optional[List[Dict]]:
        """Get playbook definition by name."""
        playbooks = {
            'malware_containment': Playbooks.malware_containment,
            'ransomware_emergency': Playbooks.ransomware_emergency,
            'fileless_malware_response': Playbooks.fileless_malware_response,
            'credential_theft_response': Playbooks.credential_theft_response
        }
        
        playbook_func = playbooks.get(name)
        if playbook_func:
            return playbook_func(threat_info)
        
        return None
    
    def _empty_execution(self, playbook_name: str, incident_id: str) -> PlaybookExecution:
        """Create empty execution for unknown playbook."""
        execution = PlaybookExecution(
            playbook_name=playbook_name,
            incident_id=incident_id or 'UNKNOWN',
            start_time=datetime.now(),
            end_time=datetime.now(),
            status=PlaybookStatus.FAILED
        )
        execution.log_entries.append(f"Unknown playbook: {playbook_name}")
        return execution
    
    # ── Query ─────────────────────────────────────────────────────────
    
    def get_executions(self) -> List[PlaybookExecution]:
        """Get all playbook executions."""
        return self.executions.copy()
    
    def get_execution_by_incident(self, incident_id: str) -> List[PlaybookExecution]:
        """Get playbook executions for a specific incident."""
        return [e for e in self.executions if e.incident_id == incident_id]
