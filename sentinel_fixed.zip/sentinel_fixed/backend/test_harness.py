import time
import collections
from network_engine import AttackDetector, NetworkAlert

# ── Collect alerts instead of printing them ───────────────────────────────────
alerts = []
def collect(alert):
    alerts.append(alert)

# ── Helper: fresh detector for each test ─────────────────────────────────────
def new_det():
    alerts.clear()
    return AttackDetector(alert_callback=collect)

# ── Test runner ───────────────────────────────────────────────────────────────
passed = failed = 0

def check(name, got_alert, expect_alert, expected_category=None):
    global passed, failed
    if expect_alert:
        if got_alert and (expected_category is None or got_alert.category == expected_category):
            print(f"  [PASS] {name} — '{got_alert.category}' ({got_alert.severity})")
            passed += 1
        else:
            cat = got_alert.category if got_alert else "no alert"
            print(f"  [FAIL] {name} — expected '{expected_category}', got '{cat}'")
            failed += 1
    else:
        if not got_alert:
            print(f"  [PASS] {name} — correctly no alert")
            passed += 1
        else:
            print(f"  [FAIL] {name} — unexpected alert: '{got_alert.category}'")
            failed += 1

# ── Fake packet builders (no Scapy/Npcap needed) ─────────────────────────────
# These craft minimal objects that satisfy the detector's .haslayer() checks

try:
    from scapy.all import ARP, IP, TCP, UDP, ICMP, Ether, DNS, DNSRR, DNSQR
    SCAPY = True
except ImportError:
    SCAPY = False
    print("[WARN] Scapy not found — some tests will be skipped\n")


def make_arp(src_ip, src_mac, dst_ip):
    pkt = Ether(src=src_mac, dst="ff:ff:ff:ff:ff:ff")
    pkt /= ARP(op=2, psrc=src_ip, hwsrc=src_mac, pdst=dst_ip)
    return pkt

def make_tcp(src_ip, dst_ip, sport, dport, flags):
    pkt = Ether() / IP(src=src_ip, dst=dst_ip) / TCP(sport=sport, dport=dport, flags=flags)
    return pkt

def make_icmp(src_ip, dst_ip, icmp_type=8, size=64):
    payload = b"X" * max(0, size - 42)
    pkt = Ether() / IP(src=src_ip, dst=dst_ip, len=size) / ICMP(type=icmp_type) / payload
    return pkt

def make_udp(src_ip, dst_ip, sport, dport):
    return Ether() / IP(src=src_ip, dst=dst_ip) / UDP(sport=sport, dport=dport)

def make_dns_reply(src_ip, dst_ip, qname, answer_ip):
    pkt = (Ether() / IP(src=src_ip, dst=dst_ip) /
           UDP(sport=53, dport=1234) /
           DNS(qr=1, qd=DNSQR(qname=qname),
               an=DNSRR(rrname=qname, rdata=answer_ip)))
    return pkt


# ─────────────────────────────────────────────────────────────────────────────
#  TESTS
# ─────────────────────────────────────────────────────────────────────────────

if not SCAPY:
    print("Install Scapy to run these tests: pip install scapy")
    exit(1)

print("\n=== Sentinel Network Threat Detection — Test Harness ===\n")

# ── L2: ARP ──────────────────────────────────────────────────────────────────
print("[ L2 — ARP ]")

det = new_det()
det.process_packet(make_arp("10.0.0.1", "aa:bb:cc:00:00:01", "10.0.0.2"))  # first — benign
det.process_packet(make_arp("10.0.0.1", "aa:bb:cc:00:00:02", "10.0.0.2"))  # second MAC = spoof
alert = alerts[-1] if alerts else None
check("ARP spoofing — two MACs claim same IP", alert, True, "ARP Spoofing")

det = new_det()
det.process_packet(make_arp("172.16.0.50", "de:ad:be:ef:00:01", "172.16.0.1"))
check("ARP — first packet is always clean", alerts[-1] if alerts else None, False)

# ── L3: IP Spoofing ───────────────────────────────────────────────────────────
print("\n[ L3 — IP Spoofing ]")

det = new_det()
det.process_packet(make_tcp("127.0.0.1", "10.0.0.5", 9999, 80, "S"))
check("IP spoof — loopback source", alerts[-1] if alerts else None, True, "IP Spoofing")

det = new_det()
det.process_packet(make_tcp("224.0.0.5", "10.0.0.5", 9999, 80, "S"))
check("IP spoof — multicast source", alerts[-1] if alerts else None, True, "IP Spoofing")

det = new_det()
det.process_packet(make_tcp("192.0.2.50", "10.0.0.5", 9999, 80, "S"))
check("IP spoof — documentation range", alerts[-1] if alerts else None, True, "IP Spoofing")

# ── L3: ICMP ─────────────────────────────────────────────────────────────────
print("\n[ L3 — ICMP ]")

det = new_det()
for _ in range(151):
    det.process_packet(make_icmp("5.5.5.5", "8.8.8.8", icmp_type=8))
check("ICMP flood — 151 echo-requests", alerts[-1] if alerts else None, True, "ICMP Flood")

det = new_det()
det.process_packet(make_icmp("6.6.6.6", "192.168.1.255", icmp_type=8))
check("Smurf attack — echo to broadcast", alerts[-1] if alerts else None, True, "Smurf Attack")

det = new_det()
big = make_icmp("7.7.7.7", "10.0.0.1", icmp_type=8, size=70000)
det.process_packet(big)
check("Ping of Death — 70000 byte packet", alerts[-1] if alerts else None, True, "Ping of Death")

# ── L4: TCP ──────────────────────────────────────────────────────────────────
print("\n[ L4 — TCP ]")

det = new_det()
for i in range(201):
    det.process_packet(make_tcp("1.2.3.4", "10.0.0.5", 40000 + i, 443, "S"))
check("SYN flood — 201 SYNs to port 443", alerts[-1] if alerts else None, True, "SYN Flood")

det = new_det()
for i in range(50):
    det.process_packet(make_tcp("1.2.3.5", "10.0.0.5", 50000 + i, 443, "S"))
check("SYN flood — 50 SYNs (below threshold)", alerts[-1] if alerts else None, False)

det = new_det()
ports = [21,22,23,25,80,135,139,443,445,3389,8080,3306,5432,6379,27017,
         5900,1433,1521,9200,11211]
for p in ports:
    det.process_packet(make_tcp("9.9.9.9", "10.0.0.5", 60000, p, "S"))
check("Port scan — 20 distinct ports", alerts[-1] if alerts else None, True, "Port Scan")

det = new_det()
for i in range(121):
    det.process_packet(make_tcp("11.11.11.11", "10.0.0.5", 54321, 80, "R"))
check("TCP RST injection — 121 RSTs", alerts[-1] if alerts else None, True, "TCP RST Injection")

# ── L4: UDP ──────────────────────────────────────────────────────────────────
print("\n[ L4 — UDP ]")

det = new_det()
for i in range(301):
    det.process_packet(make_udp("4.4.4.4", "10.0.0.5", 54000, 53))
check("UDP flood — 301 packets", alerts[-1] if alerts else None, True, "UDP Flood")

# ── L3: LAND Attack ───────────────────────────────────────────────────────────
print("\n[ L3 — LAND ]")

det = new_det()
pkt = Ether() / IP(src="10.0.0.5", dst="10.0.0.5") / TCP(sport=80, dport=80, flags="S")
det.process_packet(pkt)
check("LAND attack — src == dst IP:port", alerts[-1] if alerts else None, True, "LAND Attack")

# ── L7: DNS ───────────────────────────────────────────────────────────────────
print("\n[ L7 — DNS ]")

det = new_det()
det.process_packet(make_dns_reply("3.3.3.3", "192.168.1.10", "example.com", "1.2.3.4"))
check("DNS spoofing — reply from unknown resolver", alerts[-1] if alerts else None, True, "DNS Spoofing")

# ── Summary ───────────────────────────────────────────────────────────────────
print(f"\n{'='*52}")
print(f"  Results: {passed} passed, {failed} failed out of {passed+failed} tests")
print(f"{'='*52}\n")