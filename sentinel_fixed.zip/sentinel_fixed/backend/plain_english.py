"""
Sentinel Defender - Plain English Translation Layer
====================================================
Converts every technical detection/alert object into language that a
non-technical user can understand and act on immediately.

No jargon. No scores. No MITRE IDs. Just: what happened, why it matters,
and exactly one thing to do about it.

Usage
-----
    from backend.plain_english import (
        translate_threat,
        translate_network_alert,
        translate_investigation_report,
        get_status_summary,
    )

    msg = translate_threat(detection_dict)
    # → PlainEnglishMessage(headline="Suspicious program found",
    #                        body="A file called invoice.exe is trying to...",
    #                        action="Move to quarantine",
    #                        severity_label="Warning",
    #                        emoji="⚠️")
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional


# ── Output data class ─────────────────────────────────────────────────────────

@dataclass
class PlainEnglishMessage:
    headline:       str   # One short sentence — the most important thing
    body:           str   # 1-2 plain sentences explaining what happened
    action:         str   # Exactly one thing to do ("Move to quarantine")
    action_button:  str   # Button label ("Fix it for me" / "Remove now")
    severity_label: str   # "Critical" | "Warning" | "Low risk" | "Safe"
    emoji:          str   # Visual indicator
    color:          str   # Hex colour for UI (#ef4444 red, #f59e0b amber, etc.)
    technical_name: str   # Original technical name (shown in "Details" expander)


# ── Severity mapping ──────────────────────────────────────────────────────────

_SEV_MAP = {
    "critical": ("Critical",  "⛔", "#ef4444"),
    "high":     ("Warning",   "⚠️",  "#f59e0b"),
    "medium":   ("Low risk",  "🟡", "#eab308"),
    "low":      ("Info",      "🔵", "#3b82f6"),
    "clean":    ("Safe",      "✅", "#10b981"),
}


def _sev(raw: str):
    return _SEV_MAP.get((raw or "").lower(), ("Warning", "⚠️", "#f59e0b"))


# ── Threat name → plain-English lookup ───────────────────────────────────────

_THREAT_TRANSLATIONS: Dict[str, Dict] = {
    # Ransomware
    "ransomware": {
        "headline": "File-locking virus detected",
        "body":     "This program encrypts your personal files and demands money to get them back. "
                    "It has not run yet — removing it now keeps your files safe.",
        "action":   "Remove immediately",
        "button":   "Remove now",
    },
    # Trojan / RAT
    "trojan": {
        "headline": "Disguised malicious program found",
        "body":     "This file looks harmless but contains hidden malicious code that could "
                    "give attackers access to your computer.",
        "action":   "Move to quarantine",
        "button":   "Fix it for me",
    },
    "rat": {
        "headline": "Remote access tool found",
        "body":     "This program could let someone else control your computer without your permission, "
                    "access your camera, or steal your passwords.",
        "action":   "Remove immediately",
        "button":   "Remove now",
    },
    "backdoor": {
        "headline": "Hidden access program found",
        "body":     "This file creates a secret entry point into your computer that attackers "
                    "can use to access it remotely.",
        "action":   "Remove immediately",
        "button":   "Remove now",
    },
    # Spyware / Keylogger
    "keylogger": {
        "headline": "Password-stealing program found",
        "body":     "This program secretly records everything you type, including your passwords "
                    "and banking details.",
        "action":   "Remove immediately — change your passwords after",
        "button":   "Remove now",
    },
    "spyware": {
        "headline": "Spyware found",
        "body":     "This program secretly monitors your activity and can steal personal information.",
        "action":   "Remove immediately",
        "button":   "Remove now",
    },
    # Cryptominer
    "miner":  {
        "headline": "Bitcoin miner found",
        "body":     "This program secretly uses your computer's power to generate cryptocurrency "
                    "for someone else, slowing your computer down and increasing your electricity bill.",
        "action":   "Move to quarantine",
        "button":   "Fix it for me",
    },
    "cryptominer": {
        "headline": "Cryptocurrency miner found",
        "body":     "This program is using your computer to generate money for someone else "
                    "without your permission, causing slowdowns.",
        "action":   "Move to quarantine",
        "button":   "Fix it for me",
    },
    # Worm
    "worm": {
        "headline": "Self-spreading virus found",
        "body":     "This program copies itself to other computers on your network, "
                    "potentially infecting your family or colleagues' devices too.",
        "action":   "Remove and disconnect from Wi-Fi until removed",
        "button":   "Remove now",
    },
    # Rootkit
    "rootkit": {
        "headline": "Deep-hiding malware found",
        "body":     "This is one of the most dangerous types of malware. It hides deep inside "
                    "your computer to avoid detection.",
        "action":   "Remove immediately — consider resetting your computer if it persists",
        "button":   "Remove now",
    },
    # Dropper
    "dropper": {
        "headline": "Malware installer found",
        "body":     "This program is designed to download and install other malware onto your computer.",
        "action":   "Move to quarantine",
        "button":   "Fix it for me",
    },
    # Adware
    "adware": {
        "headline": "Unwanted ad program found",
        "body":     "This program shows unwanted pop-up ads and may slow down your browser.",
        "action":   "Remove it",
        "button":   "Remove now",
    },
    # EICAR test
    "eicar": {
        "headline": "Test file detected (not a real threat)",
        "body":     "Sentinel detected a test file used to check if antivirus is working. "
                    "This is not harmful.",
        "action":   "No action needed",
        "button":   "OK",
    },
    # Heuristic / suspicious
    "heuristic": {
        "headline": "Suspicious program found",
        "body":     "This file is behaving like malware, but Sentinel isn't 100% certain. "
                    "It has not been run yet. Moving it to quarantine keeps you safe without deleting it.",
        "action":   "Move to quarantine for safety",
        "button":   "Move to quarantine",
    },
    # Threat Intel hit
    "threat_intel": {
        "headline": "Known malware identified",
        "body":     "This exact file has been confirmed as malware by a global security database. "
                    "It should be removed immediately.",
        "action":   "Remove immediately",
        "button":   "Remove now",
    },
}

_DEFAULT_THREAT = {
    "headline": "Suspicious file found",
    "body":     "Sentinel found a file that may be harmful. It has not been run yet. "
                "Moving it to quarantine isolates it safely without deleting it.",
    "action":   "Move to quarantine",
    "button":   "Fix it for me",
}


def _match_threat_template(threat_name: str, detection_method: str) -> Dict:
    """Find the best-matching plain-English template for a threat."""
    name_lower   = (threat_name or "").lower()
    method_lower = (detection_method or "").lower()

    # Exact / substring match on name
    for key, tmpl in _THREAT_TRANSLATIONS.items():
        if key in name_lower:
            return tmpl

    # Detection-method fallback
    if "threat_intel" in method_lower:
        return _THREAT_TRANSLATIONS["threat_intel"]
    if "heuristic" in method_lower:
        return _THREAT_TRANSLATIONS["heuristic"]

    return _DEFAULT_THREAT


# ── Network alert translations ────────────────────────────────────────────────

_NET_TRANSLATIONS: Dict[str, Dict] = {
    "ARP Spoofing": {
        "headline": "Someone may be intercepting your internet traffic",
        "body":     "A device on your network is pretending to be your router, which could allow "
                    "it to see everything you do online.",
        "action":   "Disconnect from this network and contact your internet provider",
        "button":   "View details",
        "emoji":    "🕵️",
    },
    "C2 Beaconing": {
        "headline": "Your computer may be talking to a hacker",
        "body":     "A program on your computer is regularly contacting a suspicious server. "
                    "This is a sign of malware that has already been installed.",
        "action":   "Run a full scan now",
        "button":   "Scan now",
        "emoji":    "📡",
    },
    "DNS Spoofing": {
        "headline": "Fake website addresses detected",
        "body":     "Something on your network is redirecting website addresses, which could "
                    "send you to fake login pages to steal your passwords.",
        "action":   "Avoid logging into any websites until resolved",
        "button":   "View details",
        "emoji":    "🌐",
    },
    "Brute Force": {
        "headline": "Someone is trying to guess your password",
        "body":     "There have been many failed login attempts from one location. "
                    "This means someone is trying to break into an account.",
        "action":   "Change your passwords and enable two-factor authentication",
        "button":   "View details",
        "emoji":    "🔑",
    },
    "Port Scan": {
        "headline": "Someone is scanning your computer",
        "body":     "A device is probing your computer looking for open doors to exploit. "
                    "This is often the first step before an attack.",
        "action":   "Make sure your firewall is on",
        "button":   "View details",
        "emoji":    "🔍",
    },
    "SMB Exploitation": {
        "headline": "Network file-sharing attack detected",
        "body":     "Someone is trying to exploit a known Windows security weakness to access "
                    "files on your computer or spread a virus across your network.",
        "action":   "Install Windows updates immediately",
        "button":   "View details",
        "emoji":    "💻",
    },
    "Ransomware": {
        "headline": "Ransomware activity on your network",
        "body":     "Signs of a ransomware attack have been detected. Files may be at risk.",
        "action":   "Disconnect from the internet immediately and run a full scan",
        "button":   "Scan now",
        "emoji":    "⛔",
    },
    "Threat Intel: Known Malicious IP": {
        "headline": "Connection to known malicious server",
        "body":     "Your computer tried to connect to an address known to be used by hackers or malware.",
        "action":   "Run a full scan — malware may already be installed",
        "button":   "Scan now",
        "emoji":    "🚨",
    },
    "Threat Intel: Malicious Domain Query": {
        "headline": "Attempt to visit a dangerous website",
        "body":     "Something on your computer tried to look up a website known to spread malware. "
                    "Sentinel blocked the lookup.",
        "action":   "Run a full scan to check for installed malware",
        "button":   "Scan now",
        "emoji":    "🌐",
    },
}

_DEFAULT_NET = {
    "headline": "Suspicious network activity detected",
    "body":     "Sentinel noticed unusual network behaviour that could indicate a security threat.",
    "action":   "Review the Network Monitor tab for details",
    "button":   "View details",
    "emoji":    "🌐",
}


# ── Public API ────────────────────────────────────────────────────────────────

def translate_threat(threat: Dict) -> PlainEnglishMessage:
    """
    Convert a threat dict (from DB or ThreatDetection.to_dict()) into
    a PlainEnglishMessage that any user can understand.
    """
    threat_name      = threat.get("threat_name", "")
    detection_method = threat.get("detection_method", "")
    severity_raw     = threat.get("severity", "medium")
    file_path        = threat.get("file_path") or threat.get("path") or ""
    file_name        = file_path.replace("\\", "/").split("/")[-1] if file_path else "unknown file"

    tmpl = _match_threat_template(threat_name, detection_method)
    sev_label, emoji, color = _sev(severity_raw)

    body = tmpl["body"]
    if file_name and file_name != "unknown file":
        body = f"The file \"{file_name}\" was flagged. " + body

    return PlainEnglishMessage(
        headline       = tmpl["headline"],
        body           = body,
        action         = tmpl["action"],
        action_button  = tmpl["button"],
        severity_label = sev_label,
        emoji          = emoji,
        color          = color,
        technical_name = threat_name,
    )


def translate_network_alert(alert) -> PlainEnglishMessage:
    """
    Convert a NetworkAlert (dataclass or dict) into a PlainEnglishMessage.
    """
    if isinstance(alert, dict):
        category = alert.get("category", "")
        severity = alert.get("severity", "medium")
        src_ip   = alert.get("src_ip", "unknown")
    else:
        category = getattr(alert, "category", "")
        severity = getattr(alert, "severity", "medium")
        src_ip   = getattr(alert, "src_ip", "unknown")

    # Find best template match
    tmpl = None
    for key in _NET_TRANSLATIONS:
        if key.lower() in category.lower() or category.lower() in key.lower():
            tmpl = _NET_TRANSLATIONS[key]
            break
    if tmpl is None:
        tmpl = _DEFAULT_NET

    sev_label, default_emoji, color = _sev(severity.lower())

    return PlainEnglishMessage(
        headline       = tmpl["headline"],
        body           = tmpl["body"],
        action         = tmpl["action"],
        action_button  = tmpl["button"],
        severity_label = sev_label,
        emoji          = tmpl.get("emoji", default_emoji),
        color          = color,
        technical_name = category,
    )


def translate_investigation_report(report) -> str:
    """
    Produce a 3-sentence plain-English summary of an InvestigationReport
    suitable for showing to a non-technical user as the primary view.
    """
    if hasattr(report, "__dataclass_fields__"):
        severity   = report.severity
        risk_score = report.risk_score
        n_threats  = report.threat_count
        actions    = report.recommended_actions
    else:
        severity   = report.get("severity", "CLEAN")
        risk_score = report.get("risk_score", 0)
        n_threats  = report.get("threat_count", 0)
        actions    = report.get("recommended_actions", [])

    if severity == "CLEAN" or n_threats == 0:
        return (
            "✅  Your computer looks safe.\n\n"
            "Sentinel scanned your files and found nothing harmful. "
            "Keep Sentinel running in the background to stay protected."
        )

    sev_words = {
        "CRITICAL": "serious threats",
        "HIGH":     "threats",
        "MEDIUM":   "suspicious files",
        "LOW":      "low-risk items",
    }
    sev_word = sev_words.get(severity, "suspicious items")

    first_action = actions[0] if actions else "Move detected files to quarantine."

    return (
        f"{'⛔' if severity == 'CRITICAL' else '⚠️'}  "
        f"Sentinel found {n_threats} {sev_word} on your computer.\n\n"
        f"These files have not done any damage yet — Sentinel caught them before they could run. "
        f"The most important thing to do right now: {first_action.lower().rstrip('.')}.\n\n"
        f"Use the \"Fix it for me\" button below to let Sentinel handle everything safely."
    )


def get_status_summary(files_scanned: int, threats_found: int,
                        is_scanning: bool, protection_active: bool) -> Dict:
    """
    Return a plain-English status dict for the main dashboard header.
    """
    if is_scanning:
        return {
            "headline": "Scanning your files…",
            "subline":  f"{files_scanned:,} files checked so far",
            "color":    "#3b82f6",
            "emoji":    "🔍",
        }
    if not protection_active:
        return {
            "headline": "Protection is off",
            "subline":  "Turn on Real-time Monitor to stay protected",
            "color":    "#ef4444",
            "emoji":    "🔴",
        }
    if threats_found == 0:
        return {
            "headline": "Your computer is protected",
            "subline":  f"{files_scanned:,} files scanned — nothing harmful found",
            "color":    "#10b981",
            "emoji":    "✅",
        }
    return {
        "headline": f"{threats_found} threat{'s' if threats_found != 1 else ''} found",
        "subline":  "Click 'Fix it for me' to remove them safely",
        "color":    "#ef4444",
        "emoji":    "⚠️",
    }


def plain_english_action(action: Dict) -> str:
    """
    Convert a PlannedAction dict into a single plain sentence for the
    'Fix it for me' progress display.
    e.g. "Moving suspicious file to quarantine…"
    """
    action_type = action.get("action_type", "")
    target      = action.get("target", "")
    fname       = target.replace("\\", "/").split("/")[-1] if "/" in target or "\\" in target else target

    _map = {
        "quarantine":      f"Moving \"{fname}\" to quarantine…",
        "delete":          f"Permanently deleting \"{fname}\"…",
        "network_isolate": "Disconnecting from the internet temporarily…",
        "alert":           "Notifying you of the threat…",
        "report":          "Creating a security report…",
        "rescan":          "Running a follow-up scan to make sure everything is clean…",
    }
    return _map.get(action_type, f"Performing: {action_type}…")