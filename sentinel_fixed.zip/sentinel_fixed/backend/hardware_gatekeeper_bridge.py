"""
Hardware Gatekeeper Bridge
==========================
A lightweight tkinter-friendly wrapper around HardwareGatekeeper.

HardwareGatekeeper was originally written with PyQt6 signals.
This bridge replaces the PyQt6 signal bus with a thread-safe queue
so it integrates cleanly into the Sentinel tkinter GUI without
requiring PyQt6 to be installed.

Usage
-----
    from backend.hardware_gatekeeper_bridge import HardwareGatekeeperBridge

    bridge = HardwareGatekeeperBridge(
        alert_callback=lambda etype, detail: print(etype, detail)
    )
    bridge.start()   # non-blocking, daemon thread
    # ...
    bridge.stop()
"""

from __future__ import annotations

import sys
import time
import queue
import asyncio
import threading
import logging
from typing import Callable, Optional

logger = logging.getLogger(__name__)

# ── Try to import the winrt Radio API (Windows only) ─────────────────────────
try:
    from winrt.windows.devices.radios import Radio, RadioKind, RadioState
    WINRT_AVAILABLE = True
except Exception:
    WINRT_AVAILABLE = False

POLL_INTERVAL_S   = 1.0   # how often we check hardware state
SESSION_TIMEOUT_S = 300   # seconds before auto re-lock


class HardwareGatekeeperBridge:
    """
    Monitors Bluetooth & Wi-Fi hardware state and blocks unauthorised
    activation. Uses a plain callback instead of PyQt6 signals so it
    works in any Python environment.

    Parameters
    ----------
    alert_callback : callable(event_type: str, detail: str)
        Called (on a background thread) when hardware is blocked.
        The GUI wrapper must schedule GUI updates via `after()`.
    password : str
        Password required to authorise hardware use.
    """

    def __init__(
        self,
        alert_callback: Callable[[str, str], None] = None,
        password: str = "SystemAdmin123",
    ):
        self._callback  = alert_callback or (lambda et, d: None)
        self.password   = password
        self._lock      = threading.Lock()
        self._auth      = False
        self._auth_ts   = 0.0
        self._running   = False
        self._thread: Optional[threading.Thread] = None

        self._bt_radio   = None
        self._wifi_radio = None
        self._last_bt    = None
        self._last_wifi  = None

    # ── Public API ────────────────────────────────────────────────────────────

    def start(self) -> bool:
        if not WINRT_AVAILABLE:
            logger.warning("[HWGateway] winrt not available — Hardware Gatekeeper disabled (Windows only).")
            return False
        self._running = True
        self._thread  = threading.Thread(
            target=self._run_loop, daemon=True, name="HWGatekeeper"
        )
        self._thread.start()
        logger.info("[HWGateway] Hardware Gatekeeper started.")
        return True

    def stop(self) -> None:
        self._running = False
        logger.info("[HWGateway] Hardware Gatekeeper stopped.")

    def authenticate(self, provided_password: str) -> bool:
        """Call from GUI thread after user enters password."""
        if provided_password == self.password:
            with self._lock:
                self._auth    = True
                self._auth_ts = time.time()
            logger.info("[HWGateway] Authenticated.")
            return True
        return False

    def revoke(self) -> None:
        with self._lock:
            self._auth    = False
            self._auth_ts = 0.0

    def is_authenticated(self) -> bool:
        with self._lock:
            return self._auth

    def get_stats(self) -> dict:
        return {
            "authenticated": self._auth,
            "bt_state":   self._last_bt   or "unknown",
            "wifi_state": self._last_wifi or "unknown",
        }

    # ── Internal enforcer ────────────────────────────────────────────────────

    def _run_loop(self) -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(self._discover())
        logger.info("[HWGateway] Enforcer started — Bluetooth & Wi-Fi monitored.")

        while self._running:
            if self._bt_radio is None or self._wifi_radio is None:
                loop.run_until_complete(self._discover())

            with self._lock:
                is_auth = self._auth
                auth_ts = self._auth_ts

            # Session timeout
            if is_auth and SESSION_TIMEOUT_S > 0:
                if (time.time() - auth_ts) >= SESSION_TIMEOUT_S:
                    self.revoke()
                    is_auth = False
                    logger.info("[HWGateway] Session expired — re-locked.")

            loop.run_until_complete(self._enforce(self._bt_radio,   "Bluetooth", is_auth))
            loop.run_until_complete(self._enforce(self._wifi_radio, "Wi-Fi",     is_auth))
            time.sleep(POLL_INTERVAL_S)

    async def _discover(self) -> None:
        try:
            radios = await Radio.get_radios_async()
            bt_found = wifi_found = False
            for r in radios:
                if r.kind == RadioKind.BLUETOOTH:
                    self._bt_radio = r
                    bt_found = True
                elif r.kind == RadioKind.WI_FI:
                    self._wifi_radio = r
                    wifi_found = True
            if not bt_found:
                self._bt_radio = None
            if not wifi_found:
                self._wifi_radio = None
        except Exception as e:
            logger.debug("[HWGateway] Radio discovery: %s", e)

    async def _enforce(self, radio, name: str, is_auth: bool) -> None:
        if radio is None:
            return
        try:
            state = radio.state
            state_str = "ON" if state == RadioState.ON else "OFF"

            if name == "Bluetooth":
                self._last_bt = state_str
            else:
                self._last_wifi = state_str

            if state == RadioState.ON and not is_auth:
                logger.warning("[HWGateway] Blocking unauthorised %s activation.", name)
                await radio.set_state_async(RadioState.OFF)
                if name == "Bluetooth":
                    self._last_bt = "OFF"
                else:
                    self._last_wifi = "OFF"
                # Fire alert callback (runs on background thread)
                try:
                    self._callback(
                        name,
                        f"Unauthorised {name} activation was blocked automatically."
                    )
                except Exception as cb_err:
                    logger.error("[HWGateway] Callback error: %s", cb_err)
        except Exception as e:
            # Radio went stale — force re-discovery
            if name == "Bluetooth":
                self._bt_radio = None
            else:
                self._wifi_radio = None
            logger.debug("[HWGateway] Radio error (%s): %s", name, e)
