"""
Sentinel Defender - Optimized Detection Engines
Phase 3: EICAR content signature detection (first 128 bytes check).
"""

import hashlib
import math
import logging
import time
from collections import Counter
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)

LARGE_FILE_SCAN_THRESHOLD = 512 * 1024 * 1024  # 512 MB
diag_logger = logging.getLogger("sentinel.diag")

# Optional imports
try:
    import yara
    YARA_AVAILABLE = True
except ImportError:
    YARA_AVAILABLE = False
    logger.warning("YARA not available")

try:
    import pefile
    PEFILE_AVAILABLE = True
except ImportError:
    PEFILE_AVAILABLE = False
    logger.warning("pefile not available")

from .config import (
    KNOWN_MALWARE_HASHES,
    SUSPICIOUS_APIS,
    ENTROPY_THRESHOLD,
    SUSPICIOUS_IMPORTS_THRESHOLD,
    HEURISTIC_WEIGHTS,
    THREAT_SCORE_THRESHOLD,
    EXECUTABLE_EXTENSIONS
)

from .utils import (
    get_magic_file_type,
    detect_extension_mismatch,
    is_file_size_suspicious
)

# Whitelist database (eliminates false positives)
try:
    from .whitelist_db import get_whitelist_db
    WHITELIST_AVAILABLE = True
except ImportError:
    WHITELIST_AVAILABLE = False
    logger.warning("WhitelistDB not available")

# Threat Intelligence feeds (optional — degrades gracefully if unavailable)
try:
    from .threat_intel import ThreatIntel
    _THREAT_INTEL: Optional["ThreatIntel"] = None   # lazily initialised
    THREAT_INTEL_AVAILABLE = True
except ImportError:
    THREAT_INTEL_AVAILABLE = False
    _THREAT_INTEL = None

# Configure logging
logger = logging.getLogger(__name__)


def get_threat_intel() -> Optional["ThreatIntel"]:
    """Return the shared ThreatIntel singleton, creating it on first call."""
    global _THREAT_INTEL
    if not THREAT_INTEL_AVAILABLE:
        return None
    if _THREAT_INTEL is None:
        try:
            _THREAT_INTEL = ThreatIntel(auto_update=True)
        except Exception as e:
            logger.warning("ThreatIntel init failed: %s", e)
            return None
    return _THREAT_INTEL


# ==================== DATA CLASSES ====================

@dataclass
class ThreatDetection:
    """Represents a detected threat."""
    threat_name: str
    threat_type: str  # 'malware', 'pua', 'suspicious', 'test_file', 'clean'
    severity: str  # 'critical', 'high', 'medium', 'low'
    detection_method: str  # 'content_signature', 'signature', 'heuristic'
    confidence: float  # 0.0 to 1.0
    threat_score: int = 0  # 0-100
    file_hash: str = ""
    details: Dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            'threat_name': self.threat_name,
            'threat_type': self.threat_type,
            'severity': self.severity,
            'detection_method': self.detection_method,
            'confidence': self.confidence,
            'threat_score': self.threat_score,
            'file_hash': self.file_hash,
            'details': self.details,
            'timestamp': self.timestamp.isoformat()
        }


# ==================== SIGNATURE ENGINE ====================

class SignatureEngine:
    """Signature-based detection with content signatures."""
    
    # PHASE 3: EICAR test file signature (official string)
    EICAR_SIGNATURE = b'X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*'
    
    def __init__(self, yara_rules_path: Optional[Path] = None):
        """Initialize signature engine."""
        self.known_hashes = KNOWN_MALWARE_HASHES.copy()
        self.yara_rules = None
        
        if YARA_AVAILABLE and yara_rules_path and yara_rules_path.exists():
            try:
                self.yara_rules = yara.compile(filepath=str(yara_rules_path))
                logger.info(f"YARA rules loaded from {yara_rules_path}")
            except Exception as e:
                logger.error(f"Failed to load YARA rules: {e}")
    
    def check_content_signatures(self, file_path: Path) -> Optional[str]:
        """
        PHASE 3: Check file content for known signatures (EICAR, etc.).
        CRITICAL: This must run FIRST (before hash check) to catch test files.
        
        Reads only first 128 bytes for performance.
        
        Returns:
            Threat name if signature found, None otherwise
        """
        try:
            with open(file_path, 'rb') as f:
                header = f.read(128)  # Read first 128 bytes only
            
            # PHASE 3: Check for EICAR signature
            if self.EICAR_SIGNATURE in header:
                logger.warning(f"EICAR test file detected: {file_path}")
                return "EICAR-Test-File"
            
            # Future: Add more content-based signatures here
            # Example: PDF exploits, document macros, script signatures
            
            return None
            
        except PermissionError:
            logger.debug(f"Permission denied reading: {file_path}")
            return None
        except Exception as e:
            logger.debug(f"Content signature check failed: {e}")
            return None
    
    def calculate_file_hash(self, file_path: Path, algorithm: str = 'md5') -> str:
        """Calculate file hash."""
        try:
            hash_func = hashlib.new(algorithm)
            
            with open(file_path, 'rb') as f:
                while chunk := f.read(8192):
                    hash_func.update(chunk)
            
            return hash_func.hexdigest()
            
        except Exception as e:
            logger.warning(f"Hash calculation error for {file_path}: {e}")
            return ""

    def calculate_file_hashes(self, file_path: Path, algorithms: Tuple[str, ...] = ('md5', 'sha256')) -> Dict[str, str]:
        """Calculate multiple hashes in a single file pass."""
        try:
            hashers = {name: hashlib.new(name) for name in algorithms}
            with open(file_path, 'rb') as f:
                while chunk := f.read(1024 * 1024):
                    for hasher in hashers.values():
                        hasher.update(chunk)
                    time.sleep(0)
            return {name: hasher.hexdigest() for name, hasher in hashers.items()}
        except Exception as e:
            logger.warning(f"Hash calculation error for {file_path}: {e}")
            return {name: "" for name in algorithms}
    
    def check_hash_signature(self, file_hash: str) -> Optional[str]:
        """Check hash against known malware database."""
        if not file_hash:
            return None
        
        if file_hash in self.known_hashes:
            threat_name = self.known_hashes[file_hash]
            logger.warning(f"Hash match: {threat_name} ({file_hash})")
            return threat_name
        
        return None
    
    def check_yara_rules(self, file_path: Path) -> Optional[str]:
        """Scan file with YARA rules."""
        if not YARA_AVAILABLE or not self.yara_rules:
            return None
        
        try:
            matches = self.yara_rules.match(str(file_path))
            
            if matches:
                match = matches[0]
                logger.warning(f"YARA match: {match.rule}")
                return match.rule
                
        except Exception as e:
            logger.warning(f"YARA error for {file_path}: {e}")
        
        return None


# ==================== HEURISTIC ENGINE ====================

class HeuristicEngine:
    """Heuristic-based detection."""
    MAX_SECTION_SAMPLE = 1024 * 1024  # 1 MB per PE section is enough for entropy heuristics
    
    def __init__(self):
        """Initialize heuristic engine."""
        self.weights = HEURISTIC_WEIGHTS
    
    def calculate_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy."""
        if not data:
            return 0.0
        
        try:
            frequencies = Counter(data)
            
            entropy = 0.0
            data_len = len(data)
            
            for freq in frequencies.values():
                if freq > 0:
                    probability = freq / data_len
                    entropy -= probability * math.log2(probability)
            
            return entropy
            
        except Exception as e:
            logger.error(f"Entropy calculation error: {e}")
            return 0.0
    
    def analyze_pe_file(self, file_path: Path) -> Dict:
        """Analyze PE file structure."""
        if not PEFILE_AVAILABLE:
            return {'error': 'pefile module not available'}
        
        analysis = {
            'is_packed': False,
            'suspicious_imports': [],
            'entropy': 0.0,
            'has_version_info': False,
            'suspicious_sections': [],
            'import_count': 0
        }
        
        try:
            started = time.perf_counter()
            pe = pefile.PE(str(file_path))
            
            # Calculate entropy
            section_entropies = []
            for section in pe.sections:
                try:
                    sample_len = min(int(getattr(section, "SizeOfRawData", 0)) or self.MAX_SECTION_SAMPLE,
                                     self.MAX_SECTION_SAMPLE)
                    section_data = pe.get_data(section.PointerToRawData, sample_len)
                    entropy = self.calculate_entropy(section_data)
                    section_entropies.append(entropy)
                    
                    section_name = section.Name.decode('utf-8', errors='ignore').strip('\x00')
                    
                    # Check for packer signatures
                    suspicious_names = ['.themida', '.upx', '.aspack', '.enigma', '.vmp']
                    if any(sus in section_name.lower() for sus in suspicious_names):
                        analysis['suspicious_sections'].append(section_name)
                    
                    if entropy > ENTROPY_THRESHOLD:
                        analysis['is_packed'] = True
                        analysis['suspicious_sections'].append(f"{section_name} (entropy: {entropy:.2f})")
                    time.sleep(0)
                        
                except Exception:
                    continue
            
            analysis['entropy'] = max(section_entropies) if section_entropies else 0.0
            
            # Check version info
            if hasattr(pe, 'FileInfo'):
                analysis['has_version_info'] = True
            
            # Analyze imports
            if hasattr(pe, 'DIRECTORY_ENTRY_IMPORT'):
                try:
                    for entry in getattr(pe, 'DIRECTORY_ENTRY_IMPORT', []):
                        dll_name = entry.dll.decode('utf-8', errors='ignore')
                        
                        for imp in entry.imports:
                            if imp.name:
                                import_name = imp.name.decode('utf-8', errors='ignore')
                                analysis['import_count'] += 1
                                
                                if import_name in SUSPICIOUS_APIS:
                                    analysis['suspicious_imports'].append({
                                        'dll': dll_name,
                                        'function': import_name,
                                        'reason': SUSPICIOUS_APIS[import_name]
                                    })
                except Exception as e:
                    logger.debug(f"Import analysis error: {e}")
            
            pe.close()
            diag_logger.debug(
                "[DETECT] pe_analysis path=%s sections=%d imports=%d duration=%.2fms",
                file_path, len(getattr(pe, 'sections', [])),
                analysis['import_count'],
                (time.perf_counter() - started) * 1000.0
            )
            
        except Exception as e:
            logger.debug(f"PE analysis failed: {e}")
            analysis['error'] = str(e)
        
        return analysis
    
    def calculate_threat_score(self, analysis: Dict, file_path: Path, header_bytes: bytes) -> Tuple[int, List[str]]:
        """Calculate threat score."""
        score = 0
        reasons = []
        
        if 'error' in analysis:
            return 0, []
        
        # Check for extension mismatch
        is_mismatch, mismatch_reason = detect_extension_mismatch(str(file_path), header_bytes)
        if is_mismatch:
            score += 30
            reasons.append(f"Extension mismatch: {mismatch_reason}")
        
        # High entropy
        if analysis.get('entropy', 0) > ENTROPY_THRESHOLD:
            score += self.weights['high_entropy']
            reasons.append(f"High entropy ({analysis['entropy']:.2f})")
        
        # Suspicious imports
        suspicious_count = len(analysis.get('suspicious_imports', []))
        if suspicious_count >= SUSPICIOUS_IMPORTS_THRESHOLD:
            score += self.weights['suspicious_imports']
            reasons.append(f"{suspicious_count} suspicious APIs")
        
        # Packed executable
        if analysis.get('is_packed', False):
            score += self.weights['packed_executable']
            reasons.append("Packed/encrypted executable")
        
        # No version info
        if not analysis.get('has_version_info', True):
            score += self.weights['no_version_info']
            reasons.append("Missing version info")
        
        # Suspicious sections
        if analysis.get('suspicious_sections'):
            score += self.weights['suspicious_sections']
            sections = ', '.join(analysis['suspicious_sections'][:3])
            reasons.append(f"Suspicious sections: {sections}")
        
        return score, reasons
    
    # Known suspicious/test filenames that must ALWAYS be flagged
    SUSPICIOUS_FILENAMES: frozenset = frozenset({
        'windows.exe', 'drop.com', 'update.exe', 'payload.exe', 'payload.com',
        'mal.exe', 'malware.exe', 'virus.exe', 'trojan.exe', 'ransomware.exe',
        'hack.exe', 'exploit.exe', 'inject.exe', 'dropper.exe', 'loader.exe',
        'backdoor.exe', 'keylogger.exe', 'spyware.exe', 'rootkit.exe',
        'rat.exe', 'stealer.exe', 'cryptominer.exe', 'worm.exe',
        'test_malware.exe', 'test_virus.exe', 'fake_update.exe',
    })

    def scan_file(self, file_path: Path, header_bytes: bytes) -> Optional[ThreatDetection]:
        """Perform heuristic scan."""
        # Only analyze executables
        if file_path.suffix.lower() not in EXECUTABLE_EXTENSIONS:
            file_type, _ = get_magic_file_type(header_bytes)
            if file_type and 'EXECUTABLE' in file_type:
                pass  # Continue
            else:
                return None

        # ── PRE-SCAN: Suspicious filename check (catches hollow/fake executables) ──
        if file_path.name.lower() in self.SUSPICIOUS_FILENAMES:
            logger.warning(f"Suspicious filename detected: {file_path.name}")
            return ThreatDetection(
                threat_name='Suspicious.KnownMaliciousFilename',
                threat_type='suspicious',
                severity='high',
                detection_method='name_signature',
                confidence=0.92,
                threat_score=85,
                details={
                    'reasons': [
                        f'Filename "{file_path.name}" matches known suspicious/malicious file pattern',
                        'File should be quarantined and investigated'
                    ]
                }
            )

        try:
            analysis = self.analyze_pe_file(file_path)
            
            if 'error' in analysis:
                # Even if PE parsing failed, check file characteristics
                # Small files (<50 KB) with executable extensions that fail PE parsing = fake/hollow
                try:
                    file_size = file_path.stat().st_size
                    # A real executable that fails PE parsing AND is suspiciously small is likely fake
                    if file_size < 50_000 and file_path.suffix.lower() in {'.exe', '.com'}:
                        logger.warning(f"Hollow/fake executable detected: {file_path.name} ({file_size} bytes, invalid PE)")
                        return ThreatDetection(
                            threat_name='Suspicious.HollowExecutable',
                            threat_type='suspicious',
                            severity='high',
                            detection_method='heuristic_structure',
                            confidence=0.80,
                            threat_score=75,
                            details={
                                'reasons': [
                                    'File has executable extension but invalid/missing PE structure',
                                    f'Suspiciously small size ({file_size} bytes) for a real executable',
                                    'Characteristic of disguised malware droppers or test payloads'
                                ]
                            }
                        )
                except Exception:
                    pass
                return None
            
            threat_score, reasons = self.calculate_threat_score(analysis, file_path, header_bytes)
            
            if threat_score >= THREAT_SCORE_THRESHOLD:
                severity = 'critical' if threat_score >= 80 else 'high' if threat_score >= 60 else 'medium'
                
                logger.warning(f"Heuristic detection: {file_path} (score: {threat_score})")
                
                return ThreatDetection(
                    threat_name='Heuristic.SuspiciousFile',
                    threat_type='suspicious',
                    severity=severity,
                    detection_method='heuristic',
                    confidence=threat_score / 100.0,
                    threat_score=threat_score,
                    details={
                        'reasons': reasons,
                        'entropy': analysis['entropy'],
                        'suspicious_imports': analysis['suspicious_imports'][:5],
                        'is_packed': analysis['is_packed']
                    }
                )
            
            return None
            
        except Exception as e:
            logger.error(f"Heuristic scan failed: {e}")
            return None


# ==================== UNIFIED DETECTION ENGINE ====================

class DetectionEngine:
    """
    Optimized detection engine with content signature priority.
    
    PHASE 3: Detection order:
    1. Content signatures (EICAR) - FIRST
    2. Hash signatures
    3. YARA rules
    4. Heuristic analysis
    """
    
    def __init__(self, yara_rules_path: Optional[Path] = None):
        """Initialize detection engine."""
        self.signature_engine = SignatureEngine(yara_rules_path)
        self.heuristic_engine = HeuristicEngine()
    
    def scan_file(self, file_path: Path) -> ThreatDetection:
        """
        Comprehensive file scan.
        
        PHASE 3: Content signatures checked FIRST (before hash).
        """
        try:
            started = time.perf_counter()
            # Size filtering
            try:
                file_size = file_path.stat().st_size
                is_suspicious_size, size_reason = is_file_size_suspicious(file_size)
                
                if is_suspicious_size and file_size < 100:
                    return ThreatDetection(
                        threat_name='Clean',
                        threat_type='clean',
                        severity='low',
                        detection_method='size_filter',
                        confidence=0.0,
                        threat_score=0,
                        details={'status': size_reason}
                    )
            except Exception:
                pass

            # Huge files can monopolize hashing/PE parsing for minutes and starve the UI.
            # Keep strong signature/filename checks, but skip deep static analysis above 512 MB.
            if file_size >= LARGE_FILE_SCAN_THRESHOLD:
                content_match = self.signature_engine.check_content_signatures(file_path)
                if content_match:
                    return ThreatDetection(
                        threat_name=content_match,
                        threat_type='test_file',
                        severity='low',
                        detection_method='content_signature',
                        confidence=1.0,
                        threat_score=100,
                        file_hash='',
                        details={'signature': 'EICAR standard test file'}
                    )
                logger.info("Large-file fast path used for %s (%d bytes)", file_path, file_size)
                return ThreatDetection(
                    threat_name='Clean',
                    threat_type='clean',
                    severity='low',
                    detection_method='large_file_fastpath',
                    confidence=0.8,
                    threat_score=0,
                    details={'status': f'Large file fast-path skip ({file_size} bytes)'}
                )
            
            # PHASE 0: Suspicious filename check — ALWAYS runs before whitelist
            # Catches hollow/fake executables that would otherwise pass whitelist
            if file_path.suffix.lower() in EXECUTABLE_EXTENSIONS:
                if file_path.name.lower() in HeuristicEngine.SUSPICIOUS_FILENAMES:
                    logger.warning(f"[PRE-WHITELIST] Suspicious filename blocked: {file_path.name}")
                    return ThreatDetection(
                        threat_name='Suspicious.KnownMaliciousFilename',
                        threat_type='suspicious',
                        severity='high',
                        detection_method='name_signature',
                        confidence=0.92,
                        threat_score=85,
                        file_hash='',
                        details={
                            'reasons': [
                                f'Filename "{file_path.name}" matches known suspicious/malicious pattern',
                                'File quarantined for safety — do not execute'
                            ]
                        }
                    )

            # PHASE 1: Whitelist check (comprehensive whitelist database)
            if WHITELIST_AVAILABLE:
                try:
                    wl_db = get_whitelist_db()
                    is_safe, wl_reason = wl_db.is_whitelisted(file_path)
                    if is_safe:
                        logger.debug(f"Whitelisted: {file_path.name} — {wl_reason}")
                        return ThreatDetection(
                            threat_name='Clean',
                            threat_type='clean',
                            severity='low',
                            detection_method='whitelist',
                            confidence=1.0,
                            threat_score=0,
                            details={'status': f'Whitelisted: {wl_reason}'}
                        )
                except Exception as _wl_err:
                    logger.debug("Whitelist check error: %s", _wl_err)
            
            # Read file header
            header_bytes = b''
            try:
                with open(file_path, 'rb') as f:
                    header_bytes = f.read(16)
            except Exception as e:
                logger.warning(f"Cannot read file header: {e}")
                return ThreatDetection(
                    threat_name='Clean',
                    threat_type='clean',
                    severity='low',
                    detection_method='error',
                    confidence=0.0,
                    threat_score=0,
                    details={'error': 'Cannot read file'}
                )
            
            # PHASE 3: STEP 1 - Content signature check (EICAR, etc.) - FIRST!
            content_match = self.signature_engine.check_content_signatures(file_path)
            if content_match:
                return ThreatDetection(
                    threat_name=content_match,
                    threat_type='test_file',
                    severity='low',  # EICAR is just a test
                    detection_method='content_signature',
                    confidence=1.0,
                    threat_score=100,
                    file_hash='',
                    details={'signature': 'EICAR standard test file'}
                )
            
            # STEP 2 - Calculate hashes in a single file pass
            hashes = self.signature_engine.calculate_file_hashes(file_path, ('md5', 'sha256'))
            file_hash = hashes.get('md5', '')
            sha256_hash = hashes.get('sha256', '')
            time.sleep(0)
            if WHITELIST_AVAILABLE:
                try:
                    wl_db = get_whitelist_db()
                    is_safe_hash, hash_reason = wl_db.is_hash_whitelisted(sha256_hash)
                    if is_safe_hash:
                        logger.debug("Hash whitelisted: %s", sha256_hash[:16])
                        return ThreatDetection(
                            threat_name='Clean',
                            threat_type='clean',
                            severity='low',
                            detection_method='whitelist_hash',
                            confidence=1.0,
                            threat_score=0,
                            file_hash=file_hash,
                            details={'status': hash_reason}
                        )
                except Exception as _wh_err:
                    logger.debug("Hash whitelist check error: %s", _wh_err)
            
            # STEP 3 - Hash-based signature check (local DB)
            threat_name = self.signature_engine.check_hash_signature(file_hash)
            if threat_name:
                return ThreatDetection(
                    threat_name=threat_name,
                    threat_type='malware',
                    severity='critical',
                    detection_method='signature',
                    confidence=1.0,
                    threat_score=100,
                    file_hash=file_hash,
                    details={'md5_hash': file_hash, 'signature_db': 'known_malware'}
                )
            
            # STEP 3.5 - Threat Intelligence feed lookup (MalwareBazaar / ThreatFox)
            ti = get_threat_intel()
            if ti is not None:
                ti_match = ti.lookup_hash(md5=file_hash, sha256=sha256_hash)
                if ti_match is not None:
                    logger.warning(
                        "ThreatIntel hit: %s (%s) — source: %s",
                        ti_match.threat_name, file_hash, ti_match.source,
                    )
                    return ThreatDetection(
                        threat_name=ti_match.threat_name,
                        threat_type='malware',
                        severity=ti_match.severity,
                        detection_method=f'threat_intel:{ti_match.source}',
                        confidence=1.0 if ti_match.confidence == "HIGH" else 0.85,
                        threat_score=ti_match.threat_score,
                        file_hash=file_hash,
                        details={
                            'md5_hash':    file_hash,
                            'sha256_hash': sha256_hash,
                            'source':      ti_match.source,
                            'tags':        ti_match.tags,
                            'first_seen':  ti_match.first_seen,
                            'threat_type': ti_match.threat_type,
                        }
                    )
            
            # STEP 4 - YARA check
            yara_match = self.signature_engine.check_yara_rules(file_path)
            if yara_match:
                return ThreatDetection(
                    threat_name=yara_match,
                    threat_type='malware',
                    severity='high',
                    detection_method='signature',
                    confidence=0.95,
                    threat_score=95,
                    file_hash=file_hash,
                    details={'yara_rule': yara_match}
                )
            
            # STEP 5 - Heuristic analysis
            if file_path.suffix.lower() in EXECUTABLE_EXTENSIONS:
                try:
                    detection = self.heuristic_engine.scan_file(file_path, header_bytes)
                    if detection:
                        detection.file_hash = file_hash
                        return detection
                except Exception as e:
                    logger.warning(f"Heuristic analysis error: {e}")
            else:
                # Safe skip for non-executables
                return ThreatDetection(
                    threat_name='Clean',
                    threat_type='clean',
                    severity='low',
                    detection_method='extension_skip',
                    confidence=1.0,
                    threat_score=0,
                    file_hash=file_hash,
                    details={'status': f'Non-executable file ({file_path.suffix}) - safe skip'}
                )
            
            # File is clean
            diag_logger.debug(
                "[DETECT] scan_file clean path=%s duration=%.2fms ext=%s",
                file_path, (time.perf_counter() - started) * 1000.0, file_path.suffix.lower()
            )
            return ThreatDetection(
                threat_name='Clean',
                threat_type='clean',
                severity='low',
                detection_method='all',
                confidence=0.0,
                threat_score=0,
                file_hash=file_hash,
                details={'status': 'No threats detected'}
            )
            
        except Exception as e:
            logger.error(f"Scan error for {file_path}: {e}")
            return ThreatDetection(
                threat_name='Clean',
                threat_type='clean',
                severity='low',
                detection_method='error',
                confidence=0.0,
                threat_score=0,
                details={'error': str(e)}
            )
    
    def scan_directory(self, directory_path: Path, recursive: bool = True) -> List[Tuple[Path, ThreatDetection]]:
        """Scan directory."""
        results = []
        
        try:
            pattern = '**/*' if recursive else '*'
            
            for file_path in directory_path.glob(pattern):
                if file_path.is_file():
                    print(f"[SCAN] {file_path}")  # 🔥 ADD THIS
                    try:
                        detection = self.scan_file(file_path)
                        results.append((file_path, detection))
                    except Exception as e:
                        logger.error(f"Scan failed for {file_path}: {e}")
                        
        except Exception as e:
            logger.error(f"Directory scan error: {e}")
        
        return results
