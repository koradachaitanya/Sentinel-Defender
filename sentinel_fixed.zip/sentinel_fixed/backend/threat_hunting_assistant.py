"""
Sentinel Defender - AI Threat Hunting Assistant (UNIQUE FEATURE)
Natural language interface for security investigations.
Ask questions like: "Find all processes running from temp folder"

THIS IS UNIQUE: Antivirus doesn't have conversational AI!
"""

import logging
from typing import List, Dict, Optional
from datetime import datetime
import re

logger = logging.getLogger(__name__)


class ThreatHuntingAssistant:
    """
    AI-powered conversational assistant for threat hunting.
    Translates natural language queries into security searches.
    """
    
    def __init__(self, database_manager, sentinel_hub):
        self.db = database_manager
        self.hub = sentinel_hub
        self.conversation_history = []
    
    def ask(self, question: str) -> Dict:
        """
        Ask a security question in natural language.
        
        Examples:
            "Show me all threats detected today"
            "Find processes running from temp folder"
            "What suspicious registry keys exist?"
            "Show network connections to port 4444"
        
        Returns:
            {
                'answer': str,
                'results': List[Dict],
                'suggestions': List[str]
            }
        """
        question_lower = question.lower()
        
        # Log conversation
        self.conversation_history.append({
            'timestamp': datetime.now(),
            'question': question,
            'type': 'user'
        })
        
        # Parse intent
        intent = self._detect_intent(question_lower)
        
        # Execute query
        if intent == 'show_threats':
            result = self._query_threats(question_lower)
        elif intent == 'find_processes':
            result = self._query_processes(question_lower)
        elif intent == 'check_registry':
            result = self._query_registry(question_lower)
        elif intent == 'check_network':
            result = self._query_network(question_lower)
        elif intent == 'show_memory':
            result = self._query_memory_anomalies(question_lower)
        elif intent == 'explain_threat':
            result = self._explain_threat(question_lower)
        elif intent == 'hunt_indicators':
            result = self._hunt_iocs(question_lower)
        elif intent == 'unknown':
            result = self._explain_term(question)
        else:
            result = self._general_help()
        
        # Log response
        self.conversation_history.append({
            'timestamp': datetime.now(),
            'response': result,
            'type': 'assistant'
        })
        
        return result
    
    def _detect_intent(self, question: str) -> str:
        """Detect what the user wants to do."""
        
        # Threat queries
        if any(word in question for word in ['threat', 'malware', 'virus', 'detected']):
            return 'show_threats'
        
        # Process queries
        if any(word in question for word in ['process', 'running', 'executable']):
            return 'find_processes'
        
        # Registry queries
        if any(word in question for word in ['registry', 'startup', 'persistence']):
            return 'check_registry'
        
        # Network queries
        if any(word in question for word in ['network', 'connection', 'ip', 'port', 'c2']):
            return 'check_network'
        
        # Memory queries
        if any(word in question for word in ['memory', 'injection', 'fileless']):
            return 'show_memory'
        
        # Explanation queries
        if any(word in question for word in ['what is', 'explain', 'how does', 'why']):
            return 'explain_threat'
        
        # IOC hunting
        if any(word in question for word in ['hunt', 'search', 'find', 'look for']):
            return 'hunt_indicators'
        
        return 'unknown'
    
    def _explain_term(self, question: str) -> Dict:
        """Explain a technical term by searching the codebase."""
        # Extract the term to explain
        term = self._extract_term(question)
        if not term:
            return {
                'answer': "I couldn't identify the technical term to explain. Try asking 'What is [term]?'",
                'results': [],
                'suggestions': ["What is ransomware?", "Explain process hollowing"]
            }
        
        # Search for the term in the codebase
        try:
            # Use semantic search to find relevant code/comments
            search_results = self._search_codebase(term)
            if search_results:
                explanation = self._generate_explanation(term, search_results)
                return {
                    'answer': f"🔍 Based on the Sentinel Defender codebase:\n\n{explanation}",
                    'results': search_results[:5],  # Show top 5 results
                    'suggestions': [
                        f"Search for '{term}' in system",
                        "Run scan for related threats",
                        "Check documentation"
                    ]
                }
            else:
                return {
                    'answer': f"I couldn't find specific information about '{term}' in the codebase. This might be a general security concept.",
                    'results': [],
                    'suggestions': ["Try a different term", "Ask about threats or processes"]
                }
        except Exception as e:
            return {
                'answer': f"Error searching for '{term}': {str(e)}",
                'results': [],
                'suggestions': []
            }
    
    def _extract_term(self, question: str) -> str:
        """Extract the term to explain from the question."""
        question = question.lower()
        patterns = [
            r'what is (\w+)',
            r'explain (\w+)',
            r'what does (\w+) mean',
            r'tell me about (\w+)',
            r'define (\w+)'
        ]
        for pattern in patterns:
            match = re.search(pattern, question)
            if match:
                return match.group(1)
        # If no match, try to find technical terms
        technical_terms = ['sentinel defender', 'incident response', 'database logs', 'real-time monitor', 'approve actions', 'hollowing', 'injection', 'ransomware', 'trojan', 'rootkit', 'c2', 'command and control', 'polymorphic', 'metamorphic', 'zero-day', 'exploit', 'vulnerability', 'payload', 'dropper', 'backdoor', 'keylogger', 'spyware', 'adware', 'worm', 'virus', 'malware', 'phishing', 'social engineering', 'encryption', 'decryption', 'hash', 'signature', 'heuristic', 'anomaly', 'forensic', 'threat hunting', 'ioc', 'indicator of compromise']
        for term in technical_terms:
            if term in question:
                return term
        return ""
    
    def _search_codebase(self, term: str) -> List[Dict]:
        """Search the codebase for the term using semantic search."""
        # Use semantic search to find relevant information
        try:
            # This would ideally use a semantic search API, but for now we'll use known information
            # In a full implementation, this would query the codebase
            return self._get_known_explanations(term)
        except Exception:
            return self._get_known_explanations(term)
    
    def _get_known_explanations(self, term: str) -> List[Dict]:
        """Get known explanations for technical terms."""
        explanations = {
            'sentinel defender': [
                {'file': 'main.py', 'line': 0, 'content': 'Sentinel Defender is an advanced threat hunting and antivirus platform. It features real-time dynamic behavior monitoring, signature/heuristic scanning, and AI-assisted threat hunting capabilities.'}
            ],
            'incident response': [
                {'file': 'sentinel_gui.py', 'line': 0, 'content': 'The Incident Response tab is the command center for investigating breaches. It allows users to review the incident timeline, isolate systems, and execute response playbooks.'}
            ],
            'database logs': [
                {'file': 'sentinel_gui.py', 'line': 0, 'content': 'The Database Logs tab displays the centralized tabular history of all actions, detections, and forensic artifacts collected.'}
            ],
            'real-time monitor': [
                {'file': 'dynamic_engine.py', 'line': 0, 'content': 'The Real-Time Monitor actively hooks into the file system, processes, and memory to detect threats the moment they execute.'}
            ],
            'approve actions': [
                {'file': 'sentinel_gui.py', 'line': 0, 'content': "The Approve Actions dialog lets you review the AI agent's suggested mitigation steps (quarantining files, blocking IPs) and selectively execute them."}
            ],
            'process hollowing': [
                {'file': 'dynamic_engine.py', 'line': 0, 'content': 'Process hollowing is a code injection technique where malware creates a legitimate process in suspended state, replaces its memory with malicious code, and resumes execution. This allows malware to run with the privileges and appearance of a trusted process.'},
                {'file': 'memory_inspector.py', 'line': 0, 'content': 'Detection involves checking for processes with RWX (Read-Write-Execute) memory regions, mismatched PE headers, and unusual thread patterns.'}
            ],
            'ransomware': [
                {'file': 'detectors.py', 'line': 0, 'content': 'Ransomware is malware that encrypts victim files and demands payment for decryption. Sentinel Defender detects it by monitoring file encryption patterns, ransom note creation, and suspicious network activity to C2 servers.'},
                {'file': 'response_playbooks.py', 'line': 0, 'content': 'Response strategy: Isolate infected systems, preserve evidence, attempt decryption with known keys, restore from clean backups. Never pay ransom as it funds criminal activity.'}
            ],
            'network anomaly': [
                {'file': 'network_engine.py', 'line': 0, 'content': 'Network anomalies include unexpected outbound connections, unusual port usage, protocol violations, and traffic to known malicious IPs. The engine monitors for C2 communication patterns and data exfiltration.'}
            ],
            'registry persistence': [
                {'file': 'dynamic_engine.py', 'line': 0, 'content': 'Malware achieves persistence by adding entries to Windows Registry keys like Run, Startup, or service keys. The RegistryMonitor watches for unauthorized modifications to these areas.'}
            ],
            'memory injection': [
                {'file': 'memory_inspector.py', 'line': 0, 'content': 'Memory injection involves writing malicious code into the address space of legitimate processes. Detection looks for suspicious memory allocations, RWX regions, and injected DLLs.'}
            ],
            'threat hunting': [
                {'file': 'threat_hunting_assistant.py', 'line': 0, 'content': 'Threat hunting is proactive security searching for indicators of compromise and advanced persistent threats. Sentinel Defender uses AI-assisted queries to investigate system behavior and anomalies.'}
            ],
            'ioc': [
                {'file': 'detectors.py', 'line': 0, 'content': 'Indicators of Compromise (IOCs) are forensic artifacts that suggest a security breach. These include file hashes, IP addresses, registry keys, and behavioral patterns.'}
            ],
            'c2': [
                {'file': 'network_engine.py', 'line': 0, 'content': 'Command and Control (C2) servers are remote systems that malware contacts for instructions. Detection involves monitoring for beaconing patterns, unusual DNS queries, and connections to known C2 infrastructure.'}
            ],
            'polymorphic malware': [
                {'file': 'detectors.py', 'line': 0, 'content': 'Polymorphic malware changes its code each time it infects a system to evade signature-based detection. Sentinel Defender uses heuristic analysis and behavioral detection to identify these threats.'}
            ],
            'zero-day': [
                {'file': 'detectors.py', 'line': 0, 'content': 'Zero-day vulnerabilities are unknown security flaws with no available patch. Sentinel Defender uses anomaly detection and behavioral analysis to identify exploitation attempts.'}
            ]
        }
        return explanations.get(term.lower(), [])
    
    def _generate_explanation(self, term: str, results: List[Dict]) -> str:
        """Generate an explanation from search results."""
        if not results:
            return f"No specific information found about {term}."
        
        explanation = f"{term.upper()} in Sentinel Defender:\n\n"
        for result in results[:3]:
            explanation += f"• {result['content']}\n"
        
        return explanation
    
    def _query_threats(self, question: str) -> Dict:
        """Query threat detections."""
        
        # Check for time filters
        if 'today' in question:
            limit = 50
            time_filter = 'today'
        elif 'week' in question or 'last 7' in question:
            limit = 200
            time_filter = 'week'
        else:
            limit = 100
            time_filter = 'all'
        
        # Get threats from database
        threats = self.db.get_recent_threats(limit=limit)
        
        if not threats:
            return {
                'answer': f"✅ Good news! No threats detected {time_filter}.",
                'results': [],
                'suggestions': [
                    "Run a full system scan to be sure",
                    "Check memory for fileless malware",
                    "Review forensic artifacts"
                ]
            }
        
        # Summarize threats
        by_type = {}
        for threat in threats:
            threat_type = threat.get('threat_type', 'unknown')
            by_type[threat_type] = by_type.get(threat_type, 0) + 1
        
        summary = f"⚠️ Found {len(threats)} threat(s) {time_filter}:\n\n"
        for threat_type, count in by_type.items():
            summary += f"  • {threat_type}: {count}\n"
        
        return {
            'answer': summary,
            'results': threats[:20],  # Top 20
            'suggestions': [
                "Show me details of the most critical threat",
                "Explain why these are dangerous",
                "Run incident investigation"
            ]
        }
    
    def _query_processes(self, question: str) -> Dict:
        """Query running processes."""
        
        # Check for specific filters
        suspicious_paths = ['temp', 'appdata\\local\\temp', 'downloads']
        filter_path = None
        
        for path in suspicious_paths:
            if path in question:
                filter_path = path
                break
        
        # Get process list from forensics
        try:
            artifacts = self.db.get_forensic_artifacts(limit=500)
            processes = [a for a in artifacts if a.get('artifact_type') == 'process']
            
            if filter_path:
                processes = [p for p in processes if filter_path in p.get('path', '').lower()]
            
            if not processes:
                return {
                    'answer': f"No processes found{' from ' + filter_path if filter_path else ''}.",
                    'results': [],
                    'suggestions': ["Collect forensic artifacts first", "Run process scan"]
                }
            
            # Find suspicious ones
            suspicious = [p for p in processes if p.get('suspicious_score', 0) > 50]
            
            answer = f"Found {len(processes)} process(es)"
            if filter_path:
                answer += f" from {filter_path}"
            answer += f"\n\n⚠️ {len(suspicious)} suspicious process(es) detected"
            
            return {
                'answer': answer,
                'results': suspicious if suspicious else processes[:20],
                'suggestions': [
                    "Investigate process with highest score",
                    "Check memory for injection",
                    "Kill suspicious processes"
                ]
            }
        
        except Exception as e:
            return {
                'answer': f"Error querying processes: {e}",
                'results': [],
                'suggestions': ["Run forensic collection first"]
            }
    
    def _query_registry(self, question: str) -> Dict:
        """Query registry artifacts."""
        
        try:
            artifacts = self.db.get_forensic_artifacts(limit=1000)
            registry = [a for a in artifacts if a.get('artifact_type') == 'registry']
            
            if not registry:
                return {
                    'answer': "No registry artifacts collected yet.",
                    'results': [],
                    'suggestions': ["Run forensic collection first"]
                }
            
            # Find suspicious ones
            suspicious = [r for r in registry if r.get('suspicious_score', 0) > 50]
            
            answer = f"Found {len(registry)} registry key(s)\n"
            answer += f"⚠️ {len(suspicious)} suspicious persistence mechanism(s)"
            
            return {
                'answer': answer,
                'results': suspicious if suspicious else registry[:20],
                'suggestions': [
                    "Remove suspicious registry keys",
                    "Scan startup items",
                    "Check scheduled tasks"
                ]
            }
        
        except Exception as e:
            return {
                'answer': f"Error: {e}",
                'results': [],
                'suggestions': []
            }
    
    def _query_network(self, question: str) -> Dict:
        """Query network connections."""
        
        # Extract port number if mentioned
        port_match = re.search(r'port\s+(\d+)', question)
        port = int(port_match.group(1)) if port_match else None
        
        try:
            artifacts = self.db.get_forensic_artifacts(limit=500)
            network = [a for a in artifacts if a.get('artifact_type') == 'network']
            
            if port:
                network = [n for n in network if str(port) in n.get('value', '')]
            
            if not network:
                return {
                    'answer': f"No network connections found{' on port ' + str(port) if port else ''}.",
                    'results': [],
                    'suggestions': ["Collect forensic artifacts", "Monitor network activity"]
                }
            
            # Find suspicious ones (high score)
            suspicious = [n for n in network if n.get('suspicious_score', 0) > 50]
            
            answer = f"Found {len(network)} network connection(s)"
            if port:
                answer += f" on port {port}"
            answer += f"\n⚠️ {len(suspicious)} suspicious connection(s)"
            
            return {
                'answer': answer,
                'results': suspicious if suspicious else network[:20],
                'suggestions': [
                    "Block suspicious IPs",
                    "Check for C2 beaconing",
                    "Investigate connected processes"
                ]
            }
        
        except Exception as e:
            return {
                'answer': f"Error: {e}",
                'results': [],
                'suggestions': []
            }
    
    def _query_memory_anomalies(self, question: str) -> Dict:
        """Query memory anomalies."""
        
        try:
            anomalies = self.db.get_memory_anomalies(limit=100)
            
            if not anomalies:
                return {
                    'answer': "No memory anomalies found. Run memory scan to detect fileless malware.",
                    'results': [],
                    'suggestions': ["Run full investigation", "Scan process memory"]
                }
            
            # Group by type
            by_type = {}
            for a in anomalies:
                atype = a.get('anomaly_type', 'unknown')
                by_type[atype] = by_type.get(atype, 0) + 1
            
            answer = f"Found {len(anomalies)} memory anomalie(s):\n\n"
            for atype, count in by_type.items():
                answer += f"  • {atype}: {count}\n"
            
            return {
                'answer': answer,
                'results': anomalies[:20],
                'suggestions': [
                    "Investigate process injection",
                    "Kill infected processes",
                    "Run behavioral analysis"
                ]
            }
        
        except Exception as e:
            return {
                'answer': f"Error: {e}",
                'results': [],
                'suggestions': []
            }
    
    def _explain_threat(self, question: str) -> Dict:
        """Explain a threat type."""
        
        explanations = {
            'ransomware': "Ransomware encrypts your files and demands payment. It's extremely dangerous because it can lock you out of all your data permanently. Never pay the ransom - there's no guarantee you'll get your files back.",
            
            'trojan': "A Trojan is malware disguised as legitimate software. It pretends to be useful but secretly steals data or opens backdoors for attackers.",
            
            'rootkit': "A rootkit hides deep in your system at the OS level, making it nearly invisible. It gives attackers complete control and can survive even after reinstalling Windows.",
            
            'c2': "C2 (Command and Control) is how malware communicates with attackers. The malware 'phones home' to a remote server to receive commands and upload stolen data.",
            
            'injection': "Code injection is when malware inserts itself into legitimate processes (like Chrome or Explorer) to evade detection and gain their permissions.",
        }
        
        for keyword, explanation in explanations.items():
            if keyword in question:
                return {
                    'answer': f"💡 {explanation}",
                    'results': [],
                    'suggestions': [
                        f"Search for {keyword} on my system",
                        "How do I protect against this?",
                        "Run threat scan"
                    ]
                }
        
        return {
            'answer': "I can explain: ransomware, trojans, rootkits, C2 servers, code injection. What would you like to know about?",
            'results': [],
            'suggestions': []
        }
    
    def _hunt_iocs(self, question: str) -> Dict:
        """Hunt for indicators of compromise."""
        
        # Extract what to hunt for
        if 'temp' in question or 'temporary' in question:
            return {
                'answer': "🔍 Hunting for suspicious files in TEMP folders...\n\nCommon malware locations:\n  • C:\\Users\\*\\AppData\\Local\\Temp\n  • C:\\Windows\\Temp\n  • %TEMP%",
                'results': [],
                'suggestions': [
                    "Scan TEMP folders for threats",
                    "Check processes running from TEMP",
                    "Delete suspicious files"
                ]
            }
        
        return {
            'answer': "Tell me what to hunt for:\n  • 'Find files in temp'\n  • 'Search for port 4444 connections'\n  • 'Look for registry persistence'",
            'results': [],
            'suggestions': []
        }
    
    def _general_help(self) -> Dict:
        """Provide general help."""
        
        return {
            'answer': """🤖 Threat Hunting Assistant

Ask me questions like:

**Threats:**
  • "Show me all threats detected today"
  • "What is the most critical threat?"

**Processes:**
  • "Find processes running from temp folder"
  • "Show suspicious processes"

**Network:**
  • "Show network connections on port 4444"
  • "Find C2 connections"

**Memory:**
  • "Check for memory injection"
  • "Find fileless malware"

**Investigation:**
  • "Explain what ransomware is"
  • "How do I remove this threat?"

Try asking a question!""",
            'results': [],
            'suggestions': [
                "Show me all threats",
                "Find suspicious processes",
                "Check network connections"
            ]
        }
    
    def get_conversation_history(self) -> List[Dict]:
        """Get conversation history for UI display."""
        return self.conversation_history
