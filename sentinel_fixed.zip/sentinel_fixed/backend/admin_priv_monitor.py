#!/usr/bin/env python3
"""
Sentinel Defender — Admin Privilege Monitor
============================================
Monitors the OS for privilege escalation events in real time:

  Windows  → WMI __InstanceCreationEvent on Win32_Process where elevated token
             + Security Event Log (Event ID 4672: Special privileges assigned)
             + UAC consent.exe spawn detection
  Linux    → inotify watch on /etc/sudoers, /var/log/auth.log tail
             + /proc scan for new processes with UID=0
  macOS    → /var/log/system.log tail for sudo/authd entries

For EVERY detected privilege event an PrivilegeEvent object is emitted and
sent to the registered callback.  The GUI layer then intercepts and demands
password verification before allowing the approval workflow to proceed.

No external pip packages are strictly required — all platform APIs are accessed
via stdlib ctypes / subprocess / threading.  pywin32 improves Windows coverage.
"""

from __future__ import annotations

import os
import re
import sys
import time
import queue
import hashlib
import logging
import platform
import threading
import subprocess
from datetime import datetime
from dataclasses import dataclass, field
from typing import Callable, Optional, List
from enum import Enum

logger = logging.getLogger(__name__)

# ── Platform detection ────────────────────────────────────────────────────────
_OS = platform.system()          # "Windows" | "Linux" | "Darwin"
IS_WINDOWS = _OS == "Windows"
IS_LINUX   = _OS == "Linux"
IS_MACOS   = _OS == "Darwin"

# ── Optional Win32 imports ────────────────────────────────────────────────────
try:
    import ctypes, ctypes.wintypes as wt
    CTYPES_OK = True
except ImportError:
    CTYPES_OK = False

try:
    import win32api, win32security, win32con, win32evtlog, win32evtlogutil
    PYWIN32_OK = True
except (ImportError, ModuleNotFoundError):
    PYWIN32_OK = False


# ─────────────────────────────────────────────────────────────────────────────
#  Data types
# ─────────────────────────────────────────────────────────────────────────────

class PrivilegeLevel(str, Enum):
    SYSTEM          = "SYSTEM"
    ADMINISTRATOR   = "ADMINISTRATOR"
    ELEVATED_USER   = "ELEVATED_USER"
    SUDO            = "SUDO"
    UNKNOWN         = "UNKNOWN"


class EventSeverity(str, Enum):
    CRITICAL = "CRITICAL"    # SYSTEM / kernel-level
    HIGH     = "HIGH"        # Administrator / root escalation
    MEDIUM   = "MEDIUM"      # sudo / UAC elevation
    LOW      = "LOW"         # Info-level privilege change
    INFO     = "INFO"


@dataclass
class PrivilegeEvent:
    event_id:     str               # unique uuid-style id
    timestamp:    str               # ISO 8601
    severity:     EventSeverity
    level:        PrivilegeLevel
    process_name: str               # which process triggered escalation
    process_id:   int
    user:         str               # username attempting escalation
    description:  str               # human-readable summary
    raw_detail:   str               # raw OS log line or WMI data
    source:       str               # "WMI" | "EventLog" | "procfs" | "authlog"
    blocked:      bool = False      # set True if Sentinel denied the request
    approved:     bool = False      # set True after admin password verified


@dataclass
class PrivilegeMonitorStats:
    events_detected:  int = 0
    events_blocked:   int = 0
    events_approved:  int = 0
    monitor_uptime_s: float = 0.0
    last_event_ts:    Optional[str] = None


# ─────────────────────────────────────────────────────────────────────────────
#  Secure password vault (SHA-256, stored in data/admin/vault.dat)
# ─────────────────────────────────────────────────────────────────────────────

VAULT_DIR  = "data" + os.sep + "admin"
VAULT_FILE = os.path.join(VAULT_DIR, "vault.dat")
_SENTINEL  = "SENTINEL_ADMIN_V1"    # file magic


class AdminPasswordVault:
    """
    Stores the Sentinel admin password as a salted SHA-256 hash.
    Never stores plaintext.  Thread-safe.
    """

    def __init__(self):
        os.makedirs(VAULT_DIR, exist_ok=True)
        self._lock = threading.Lock()

    # ── Public API ────────────────────────────────────────────────────────────

    def is_set(self) -> bool:
        """True if a password has already been configured."""
        with self._lock:
            return os.path.exists(VAULT_FILE) and os.path.getsize(VAULT_FILE) > 10

    def set_password(self, new_password: str) -> None:
        """Hash and persist a new password.  Overwrites any existing one."""
        if not new_password:
            raise ValueError("Password must not be empty.")
        blob = self._make_hash(new_password)
        with self._lock:
            with open(VAULT_FILE, "w") as fh:
                fh.write(blob)
        logger.info("[Vault] Admin password updated.")

    def verify(self, candidate: str) -> bool:
        """Return True if `candidate` matches the stored hash."""
        if not self.is_set():
            return False
        with self._lock:
            with open(VAULT_FILE) as fh:
                stored = fh.read().strip()
        return stored == self._make_hash(candidate)

    def clear(self) -> None:
        """Remove the stored password (requires current password check externally)."""
        with self._lock:
            if os.path.exists(VAULT_FILE):
                os.remove(VAULT_FILE)
        logger.info("[Vault] Admin password cleared.")

    # ── Internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _make_hash(password: str) -> str:
        salt = _SENTINEL
        raw  = f"{salt}:{password}:{salt[::-1]}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()


# ─────────────────────────────────────────────────────────────────────────────
#  Windows Privilege Monitor
# ─────────────────────────────────────────────────────────────────────────────

class _WindowsPrivMonitor:
    """
    Deep Windows privilege escalation interceptor.

    Monitors ALL pathways through which a process can gain admin rights:

      1. consent.exe spawn         — Windows UAC dialog appearing
      2. Runas verb on any EXE     — right-click "Run as administrator"
      3. Shell execute runas       — programmatic elevation requests
      4. Explicit cmd/powershell   — cmd.exe / powershell started elevated
      5. Security Event Log 4688   — new elevated process creation
      6. Security Event Log 4672   — special privileges assigned

    For EVERY detected event a PrivilegeEvent is emitted to the queue.
    The GUI layer then shows the Sentinel password challenge and either
    approves or terminates the requesting process.
    """

    # ── Processes that always request admin — intercept each new instance ──
    ADMIN_PROCESS_NAMES = {
        # Shells / interpreters
        "cmd.exe", "powershell.exe", "pwsh.exe", "wscript.exe", "cscript.exe",
        "bash.exe", "wsl.exe",
        # Package / install tools
        "msiexec.exe", "setup.exe", "install.exe", "installer.exe",
        "uninst.exe", "uninstall.exe", "patch.exe", "update.exe",
        # System tools that often run elevated
        "regedit.exe", "regedt32.exe", "gpedit.msc", "secpol.msc",
        "eventvwr.exe", "devmgmt.msc", "diskmgmt.msc", "compmgmt.msc",
        "taskschd.msc", "services.msc", "lusrmgr.msc",
        # Task / process management
        "taskmgr.exe", "procexp.exe", "procexp64.exe", "autoruns.exe",
        # Network tools — netsh and ipconfig run constantly in the background
        # (by Windows itself, antivirus, VPN clients, etc.).  Listing them here
        # caused a popup storm.  They are still caught when they carry an
        # elevated token via _check_token_elevation() in _scan_processes().
        # "netsh.exe", "ipconfig.exe",  ← intentionally removed
        # Privilege escalation tools (hacking / pen-test)
        "psexec.exe", "psexec64.exe", "runas.exe",
    }

    # Windows Security Event IDs
    EID_SPECIAL_PRIV  = 4672   # Special privileges assigned at logon
    EID_PROC_CREATED  = 4688   # New process created
    EID_ELEVATED      = 4698   # Scheduled task created
    EID_UAC_BYPASS    = 4703   # Token right adjusted
    EID_LOGON         = 4624   # Account logon

    # Minimum ms between identical process-name events (debounce)
    DEBOUNCE_MS = 3000

    def __init__(self, event_queue: queue.Queue):
        self._q            = event_queue
        self._running      = False
        self._seen_pids:  set  = set()
        self._last_emit:  dict = {}   # process_name → last emit timestamp (ms)
        self._known_pids: dict = {}   # pid → process_name snapshot at last poll

    def start(self):
        self._running = True
        threads = [
            threading.Thread(target=self._process_poll_loop,
                             daemon=True, name="WinProcPoll"),
            threading.Thread(target=self._eventlog_loop,
                             daemon=True, name="WinEventLog"),
            threading.Thread(target=self._wmi_runas_watch,
                             daemon=True, name="WinWMIRunas"),
        ]
        for t in threads:
            t.start()
        logger.info("[WinPrivMon] Deep interception started (proc-poll + EventLog + WMI).")

    def stop(self):
        self._running = False

    # ── 1. Process polling — catches every admin-capable process ─────────────

    def _process_poll_loop(self):
        """
        Poll running processes every 1.5 s.
        Emit an event for any NEWLY APPEARED process whose name is in
        ADMIN_PROCESS_NAMES OR that is running with an elevated token.
        """
        while self._running:
            try:
                self._scan_processes()
            except Exception as e:
                logger.debug("[WinPrivMon] Poll error: %s", e)
            time.sleep(1.5)

    def _scan_processes(self):
        """
        Use WMIC or tasklist to enumerate running processes.
        For each new PID that matches an admin process name OR has an
        elevated token, fire a PrivilegeEvent.
        """
        try:
            # wmic gives us CommandLine which reveals /runas and similar flags
            out = subprocess.check_output(
                ["wmic", "process", "get",
                 "ProcessId,Name,CommandLine,ExecutablePath",
                 "/FORMAT:CSV"],
                stderr=subprocess.DEVNULL, text=True, timeout=8,
                creationflags=0x08000000
            )
        except Exception:
            # Fallback: plain tasklist
            try:
                out = subprocess.check_output(
                    ["tasklist", "/FO", "CSV", "/NH"],
                    stderr=subprocess.DEVNULL, text=True, timeout=5,
                    creationflags=0x08000000
                )
            except Exception:
                return
            self._parse_tasklist(out)
            return

        self._parse_wmic(out)

    def _parse_wmic(self, csv_text: str):
        now_ms = int(time.time() * 1000)
        for line in csv_text.splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) < 3:
                continue
            # CSV columns: Node, CommandLine, ExecutablePath, Name, ProcessId
            # Find Name and PID — positions vary; search by content
            pname = ""
            pid   = 0
            cmdln = ""
            for i, p in enumerate(parts):
                if p.lower().endswith(".exe") and not pname:
                    pname = p.lower()
                if p.isdigit() and int(p) > 0 and not pid:
                    pid = int(p)
                if p.startswith('"') or "/" in p or os.sep in p:
                    if not cmdln:
                        cmdln = p

            if not pname or not pid:
                continue
            if pid in self._seen_pids:
                continue

            is_admin_proc = pname in self.ADMIN_PROCESS_NAMES
            is_runas      = "runas" in cmdln.lower() or "/runas" in cmdln.lower()
            is_elevated   = self._check_token_elevation(pid)

            # ── FIX: Only show the challenge popup when cmd.exe (Command Prompt)
            # is explicitly launched as Administrator (elevated token or runas).
            # Do NOT fire on every process in ADMIN_PROCESS_NAMES — that causes
            # the popup to appear constantly for normal, non-elevated tools.
            # For all other processes, keep the original broad detection.
            CMD_SHELLS = {"cmd.exe", "powershell.exe", "pwsh.exe"}
            if pname in CMD_SHELLS:
                # For shells: only intercept when actually run as admin
                should_fire = is_runas or is_elevated
            else:
                # For non-shell admin tools: keep existing behaviour
                should_fire = is_admin_proc or is_runas or is_elevated

            if should_fire:
                self._seen_pids.add(pid)
                # Debounce same process name
                last = self._last_emit.get(pname, 0)
                if now_ms - last < self.DEBOUNCE_MS:
                    continue
                self._last_emit[pname] = now_ms

                trigger = "admin process launched"
                if is_runas:      trigger = "Run as Administrator requested"
                elif is_elevated: trigger = "elevated token detected"

                sev = EventSeverity.HIGH
                if pname in ("cmd.exe", "powershell.exe", "pwsh.exe"):
                    sev = EventSeverity.HIGH
                elif pname in ("regedit.exe", "regedt32.exe"):
                    sev = EventSeverity.CRITICAL

                self._emit_event(
                    eid      = f"PROC-{pid}-{now_ms}",
                    sev      = sev,
                    pname    = pname,
                    pid      = pid,
                    user     = os.environ.get("USERNAME", "Unknown"),
                    desc     = (f"Admin-level process detected: {pname} (PID {pid}) — {trigger}"),
                    raw      = f"pid={pid} name={pname} cmd={cmdln[:120]}",
                    src      = "ProcessPoll",
                )

        # Prune stale PIDs
        if len(self._seen_pids) > 1000:
            self._seen_pids.clear()

    def _parse_tasklist(self, csv_text: str):
        """Fallback parser for plain tasklist /FO CSV output."""
        now_ms = int(time.time() * 1000)
        for line in csv_text.splitlines():
            parts = [p.strip('"') for p in line.split('","')]
            if len(parts) < 2:
                continue
            pname = parts[0].lower()
            try:
                pid = int(parts[1])
            except ValueError:
                continue
            if pid in self._seen_pids:
                continue
            # consent.exe = UAC dialog; also catch admin-named processes
            # FIX: For cmd/powershell/pwsh, only fire when actually elevated.
            # For consent.exe (real UAC dialog) and other tools, keep as-is.
            _CMD_SHELLS = {"cmd.exe", "powershell.exe", "pwsh.exe"}
            if pname in _CMD_SHELLS:
                # Only intercept shells when they carry an elevated token
                if not self._check_token_elevation(pid):
                    self._seen_pids.add(pid)   # mark seen so we don't re-check
                    continue
            # For consent.exe and the remaining ADMIN_PROCESS_NAMES keep existing behaviour
            if pname == "consent.exe" or pname in self.ADMIN_PROCESS_NAMES:
                self._seen_pids.add(pid)
                last = self._last_emit.get(pname, 0)
                if now_ms - last < self.DEBOUNCE_MS:
                    continue
                self._last_emit[pname] = now_ms
                self._emit_event(
                    eid   = f"UAC-{pid}-{now_ms}",
                    sev   = EventSeverity.HIGH,
                    pname = pname,
                    pid   = pid,
                    user  = os.environ.get("USERNAME", "Unknown"),
                    desc  = f"Admin elevation requested: {pname} (PID {pid})",
                    raw   = line,
                    src   = "ProcessPoll",
                )

    def _check_token_elevation(self, pid: int) -> bool:
        """
        Use Windows OpenProcessToken + GetTokenInformation to check if PID
        is running with an elevated token.  Returns False on any error
        (non-admin PIDs, access denied, etc.).
        """
        if not CTYPES_OK:
            return False
        try:
            import ctypes
            TOKEN_QUERY       = 0x0008
            TokenElevation    = 20
            PROCESS_QUERY_LIM = 0x1000

            h_proc = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_LIM, False, pid)
            if not h_proc:
                return False
            h_token = ctypes.wintypes.HANDLE()
            ok = ctypes.windll.advapi32.OpenProcessToken(
                h_proc, TOKEN_QUERY, ctypes.byref(h_token))
            ctypes.windll.kernel32.CloseHandle(h_proc)
            if not ok:
                return False

            elevation = ctypes.c_ulong(0)
            ret_len   = ctypes.c_ulong(0)
            ctypes.windll.advapi32.GetTokenInformation(
                h_token, TokenElevation,
                ctypes.byref(elevation), ctypes.sizeof(elevation),
                ctypes.byref(ret_len))
            ctypes.windll.kernel32.CloseHandle(h_token)
            return bool(elevation.value)
        except Exception:
            return False

    # ── 2. Security Event Log ─────────────────────────────────────────────────

    def _eventlog_loop(self):
        if not PYWIN32_OK:
            logger.warning("[WinPrivMon] pywin32 unavailable — EventLog monitoring skipped.")
            return
        try:
            h     = win32evtlog.OpenEventLog(None, "Security")
            flags = (win32evtlog.EVENTLOG_BACKWARDS_READ |
                     win32evtlog.EVENTLOG_SEQUENTIAL_READ)
            while self._running:
                try:
                    records = win32evtlog.ReadEventLog(h, flags, 0)
                    if not records:
                        time.sleep(1.0)
                        continue
                    for r in records:
                        eid = r.EventID & 0xFFFF
                        if eid in (self.EID_SPECIAL_PRIV, self.EID_PROC_CREATED,
                                   self.EID_ELEVATED, self.EID_UAC_BYPASS):
                            self._emit_from_eventlog(r)
                except Exception as inner:
                    logger.debug("[WinPrivMon] EventLog read: %s", inner)
                    time.sleep(2.0)
        except Exception as e:
            logger.error("[WinPrivMon] EventLog open error: %s", e)

    def _emit_from_eventlog(self, record) -> None:
        eid = record.EventID & 0xFFFF
        try:
            strings = record.StringInserts or []
        except Exception:
            strings = []

        user    = strings[1] if len(strings) > 1 else "Unknown"
        process = strings[5] if len(strings) > 5 else "Unknown"
        raw     = " | ".join(str(s) for s in strings)

        sev_map = {
            self.EID_SPECIAL_PRIV: EventSeverity.HIGH,
            self.EID_PROC_CREATED: EventSeverity.MEDIUM,
            self.EID_ELEVATED:     EventSeverity.HIGH,
            self.EID_UAC_BYPASS:   EventSeverity.MEDIUM,
        }
        desc_map = {
            self.EID_SPECIAL_PRIV: f"Special privileges assigned to '{user}'",
            self.EID_PROC_CREATED: f"New elevated process: {process} (user: {user})",
            self.EID_ELEVATED:     f"Scheduled task created by '{user}'",
            self.EID_UAC_BYPASS:   f"Token rights adjusted for '{user}'",
        }

        self._emit_event(
            eid   = f"EVT-{eid}-{int(time.time()*1000)}",
            sev   = sev_map.get(eid, EventSeverity.MEDIUM),
            pname = process,
            pid   = 0,
            user  = user,
            desc  = desc_map.get(eid, f"Security event {eid}"),
            raw   = raw,
            src   = "EventLog",
        )

    # ── 3. WMI __InstanceCreationEvent (catches runas shell verb) ────────────

    def _wmi_runas_watch(self):
        """
        Uses WMI to watch for new Win32_Process instances in real time.
        This catches processes launched via ShellExecute with runas verb
        which may not appear in tasklist before UAC fires.
        Requires WMI (built into Windows Vista+).
        """
        try:
            import subprocess as _sp
            ps_script = r"""
$query = "SELECT * FROM __InstanceCreationEvent WITHIN 1 WHERE TargetInstance ISA 'Win32_Process'"
$watcher = New-Object System.Management.ManagementEventWatcher $query
while ($true) {
    $event = $watcher.WaitForNextEvent()
    $proc  = $event.TargetInstance
    $name  = $proc.Name.ToLower()
    $pid2  = $proc.ProcessId
    $cmd   = $proc.CommandLine
    # FIX: Only intercept shells (cmd/powershell) when explicitly run via runas.
    # Non-shell admin tools (netsh, taskmgr, regedit, etc.) are handled by the
    # process-poll loop when they carry an elevated token — not matched here by
    # name alone, which caused constant false-positive popups.
    $shellNames = @("cmd.exe","powershell.exe","pwsh.exe")
    $isRunas    = ($cmd -and $cmd.ToLower().Contains("runas"))
    if (($shellNames -contains $name -and $isRunas) -or
        ($isRunas -and $name -notin $shellNames)) {
        Write-Output "PRIV_EVENT|$name|$pid2|$cmd"
        [Console]::Out.Flush()
    }
}
"""
            proc = _sp.Popen(
                ["powershell", "-NoProfile", "-NonInteractive",
                 "-ExecutionPolicy", "Bypass", "-Command", ps_script],
                stdout=_sp.PIPE, stderr=_sp.DEVNULL, text=True,
                creationflags=0x08000000
            )
            while self._running:
                line = proc.stdout.readline()
                if not line:
                    time.sleep(0.5)
                    continue
                line = line.strip()
                if line.startswith("PRIV_EVENT|"):
                    parts = line.split("|", 3)
                    if len(parts) >= 3:
                        pname = parts[1].lower()
                        try:
                            pid = int(parts[2])
                        except ValueError:
                            pid = 0
                        cmd = parts[3] if len(parts) > 3 else ""
                        now_ms = int(time.time() * 1000)
                        last   = self._last_emit.get(pname, 0)
                        if now_ms - last >= self.DEBOUNCE_MS:
                            self._last_emit[pname] = now_ms
                            is_runas = "runas" in cmd.lower()
                            self._emit_event(
                                eid   = f"WMI-{pid}-{now_ms}",
                                sev   = EventSeverity.HIGH,
                                pname = pname,
                                pid   = pid,
                                user  = os.environ.get("USERNAME", "Unknown"),
                                desc  = (
                                    f"{'Run as Administrator requested' if is_runas else 'Admin process launched'}: "
                                    f"{pname} (PID {pid})"
                                ),
                                raw   = cmd[:200],
                                src   = "WMI",
                            )
            try:
                proc.terminate()
            except Exception:
                pass
        except Exception as e:
            logger.warning("[WinPrivMon] WMI watcher error: %s — falling back to poll-only mode.", e)

    # ── Shared emitter ────────────────────────────────────────────────────────

    def _emit_event(self, eid, sev, pname, pid, user, desc, raw, src):
        evt = PrivilegeEvent(
            event_id     = eid,
            timestamp    = datetime.now().isoformat(timespec="seconds"),
            severity     = sev,
            level        = PrivilegeLevel.ADMINISTRATOR,
            process_name = pname,
            process_id   = pid,
            user         = user,
            description  = desc,
            raw_detail   = raw[:300],
            source       = src,
        )
        try:
            self._q.put_nowait(evt)
        except queue.Full:
            pass


# ─────────────────────────────────────────────────────────────────────────────
#  Linux Privilege Monitor
# ─────────────────────────────────────────────────────────────────────────────

class _LinuxPrivMonitor:
    """
    Monitors privilege escalation on Linux:
      1. Tails /var/log/auth.log for sudo / su entries.
      2. Polls /proc for processes running as UID 0 that weren't previously seen.
    """

    AUTH_LOG = "/var/log/auth.log"
    ALT_LOG  = "/var/log/secure"      # RHEL/CentOS

    SUDO_RE  = re.compile(r"sudo\s*:\s+(\w+)\s+:.*COMMAND=(.*)")
    SU_RE    = re.compile(r"su\[(\d+)\].*Successful su for (\w+)")
    PKE_RE   = re.compile(r"pkexec.*user=(\w+)")

    def __init__(self, event_queue: queue.Queue):
        self._q       = event_queue
        self._running = False
        self._seen_pids: set = set()

    def start(self):
        self._running = True
        t1 = threading.Thread(target=self._authlog_tail, daemon=True, name="LinuxAuthLog")
        t2 = threading.Thread(target=self._proc_poll,    daemon=True, name="LinuxProcPoll")
        t1.start()
        t2.start()
        logger.info("[LinuxPrivMon] Started.")

    def stop(self):
        self._running = False

    def _authlog_tail(self):
        log_file = self.AUTH_LOG if os.path.exists(self.AUTH_LOG) else self.ALT_LOG
        if not os.path.exists(log_file):
            logger.warning("[LinuxPrivMon] Auth log not found at %s or %s", self.AUTH_LOG, self.ALT_LOG)
            return

        try:
            with open(log_file, "r") as fh:
                fh.seek(0, 2)   # jump to end
                while self._running:
                    line = fh.readline()
                    if not line:
                        time.sleep(0.3)
                        continue
                    self._parse_auth_line(line.strip())
        except PermissionError:
            logger.warning("[LinuxPrivMon] No permission to read %s — run as root for full coverage.", log_file)
        except Exception as e:
            logger.error("[LinuxPrivMon] Auth log error: %s", e)

    def _parse_auth_line(self, line: str):
        m = self.SUDO_RE.search(line)
        if m:
            user, cmd = m.group(1), m.group(2).strip()
            self._emit("SUDO-" + str(int(time.time()*1000)),
                       EventSeverity.HIGH, PrivilegeLevel.SUDO,
                       "sudo", 0, user,
                       f"sudo command by '{user}': {cmd[:80]}",
                       line, "authlog")
            return

        m = self.SU_RE.search(line)
        if m:
            pid, user = m.group(1), m.group(2)
            self._emit("SU-" + pid,
                       EventSeverity.HIGH, PrivilegeLevel.ADMINISTRATOR,
                       "su", int(pid), user,
                       f"'su' root escalation by user '{user}'",
                       line, "authlog")
            return

        m = self.PKE_RE.search(line)
        if m:
            user = m.group(1)
            self._emit("PKE-" + str(int(time.time()*1000)),
                       EventSeverity.MEDIUM, PrivilegeLevel.ELEVATED_USER,
                       "pkexec", 0, user,
                       f"polkit pkexec elevation by '{user}'",
                       line, "authlog")

    def _proc_poll(self):
        while self._running:
            try:
                for entry in os.scandir("/proc"):
                    if not entry.name.isdigit():
                        continue
                    pid = int(entry.name)
                    if pid in self._seen_pids:
                        continue
                    try:
                        status_path = f"/proc/{pid}/status"
                        with open(status_path) as fh:
                            content = fh.read()
                        uid_match = re.search(r"Uid:\s+(\d+)", content)
                        name_match = re.search(r"Name:\s+(\S+)", content)
                        if uid_match and uid_match.group(1) == "0":
                            pname = name_match.group(1) if name_match else "unknown"
                            if pname not in ("kthread", "migration", "ksoftirqd",
                                             "kworker", "idle"):
                                self._seen_pids.add(pid)
                                self._emit(
                                    f"ROOT-{pid}",
                                    EventSeverity.CRITICAL, PrivilegeLevel.SYSTEM,
                                    pname, pid, "root",
                                    f"New root process detected: {pname} (PID {pid})",
                                    f"uid=0 pid={pid} name={pname}", "procfs"
                                )
                    except (FileNotFoundError, PermissionError):
                        self._seen_pids.add(pid)
            except Exception as e:
                logger.debug("[LinuxPrivMon] proc scan: %s", e)
            if len(self._seen_pids) > 2000:
                self._seen_pids.clear()
            time.sleep(2.0)

    def _emit(self, eid, sev, level, pname, pid, user, desc, raw, src):
        evt = PrivilegeEvent(
            event_id=eid, timestamp=datetime.now().isoformat(timespec="seconds"),
            severity=sev, level=level, process_name=pname, process_id=pid,
            user=user, description=desc, raw_detail=raw[:200], source=src,
        )
        try:
            self._q.put_nowait(evt)
        except queue.Full:
            pass


# ─────────────────────────────────────────────────────────────────────────────
#  macOS Privilege Monitor
# ─────────────────────────────────────────────────────────────────────────────

class _MacOSPrivMonitor:
    """
    Tails /var/log/system.log and unified log stream for sudo/authd events.
    """

    def __init__(self, event_queue: queue.Queue):
        self._q       = event_queue
        self._running = False

    def start(self):
        self._running = True
        t = threading.Thread(target=self._log_stream, daemon=True, name="MacOSPrivMon")
        t.start()
        logger.info("[MacOSPrivMon] Started.")

    def stop(self):
        self._running = False

    def _log_stream(self):
        try:
            proc = subprocess.Popen(
                ["log", "stream", "--predicate",
                 'process == "sudo" OR process == "authorizationhost" OR process == "securityd"',
                 "--style", "compact"],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True
            )
            while self._running:
                line = proc.stdout.readline()
                if not line:
                    break
                if any(kw in line for kw in ("COMMAND=", "AUTHENTICATION", "ALLOW", "authorization")):
                    self._emit_from_line(line.strip())
            proc.terminate()
        except FileNotFoundError:
            logger.warning("[MacOSPrivMon] 'log' command not available.")
        except Exception as e:
            logger.error("[MacOSPrivMon] log stream error: %s", e)

    def _emit_from_line(self, line: str):
        user_m = re.search(r"USER=(\w+)", line) or re.search(r"user (\w+)", line)
        user   = user_m.group(1) if user_m else "unknown"
        evt = PrivilegeEvent(
            event_id     = f"MAC-{int(time.time()*1000)}",
            timestamp    = datetime.now().isoformat(timespec="seconds"),
            severity     = EventSeverity.HIGH,
            level        = PrivilegeLevel.ADMINISTRATOR,
            process_name = "authorizationhost",
            process_id   = 0,
            user         = user,
            description  = f"macOS privilege escalation by '{user}'",
            raw_detail   = line[:200],
            source       = "MacOSLog",
        )
        try:
            self._q.put_nowait(evt)
        except queue.Full:
            pass


# ─────────────────────────────────────────────────────────────────────────────
#  Master Admin Privilege Monitor
# ─────────────────────────────────────────────────────────────────────────────

class AdminPrivilegeMonitor:
    """
    Public API — instantiate once, call start() to begin monitoring.

    Parameters
    ----------
    event_callback : callable(PrivilegeEvent)
        Called on the main thread (via after() wrapper if needed) whenever
        a privilege event is detected.
    poll_interval  : float
        How often (seconds) the internal drain loop fires the callback.
    """

    MAX_QUEUE = 200

    def __init__(
        self,
        event_callback: Callable[[PrivilegeEvent], None],
        poll_interval: float = 0.8,
    ):
        self._callback      = event_callback
        self._poll_interval = poll_interval
        self._vault         = AdminPasswordVault()
        self._q: queue.Queue = queue.Queue(maxsize=self.MAX_QUEUE)
        self._running       = False
        self._monitor       = None
        self._drain_thread: Optional[threading.Thread] = None
        self._stats         = PrivilegeMonitorStats()
        self._start_ts      = 0.0
        # Pending events delivered to main thread (avoids "not in main loop" errors)
        self._pending_events: list = []
        self._pending_lock  = threading.Lock()

    # ── Public ────────────────────────────────────────────────────────────────

    def start(self) -> bool:
        if self._running:
            return True
        if IS_WINDOWS:
            self._monitor = _WindowsPrivMonitor(self._q)
        elif IS_LINUX:
            self._monitor = _LinuxPrivMonitor(self._q)
        elif IS_MACOS:
            self._monitor = _MacOSPrivMonitor(self._q)
        else:
            logger.error("[AdminPrivMon] Unsupported OS.")
            return False

        self._running  = True
        self._start_ts = time.time()
        self._monitor.start()
        self._drain_thread = threading.Thread(
            target=self._drain_loop, daemon=True, name="PrivMonDrain"
        )
        self._drain_thread.start()
        logger.info("[AdminPrivMon] Monitoring started on %s.", _OS)
        return True

    def stop(self) -> None:
        self._running = False
        if self._monitor:
            self._monitor.stop()
        logger.info("[AdminPrivMon] Stopped.")

    def get_stats(self) -> PrivilegeMonitorStats:
        self._stats.monitor_uptime_s = round(time.time() - self._start_ts, 1) if self._start_ts else 0.0
        return self._stats

    def has_password(self) -> bool:
        return self._vault.is_set()

    def verify_password(self, candidate: str) -> bool:
        return self._vault.verify(candidate)

    def set_password(self, new_password: str) -> None:
        self._vault.set_password(new_password)

    def clear_password(self) -> None:
        self._vault.clear()

    def inject_test_event(self) -> None:
        """Inject a synthetic event for testing without requiring real OS escalation."""
        evt = PrivilegeEvent(
            event_id     = f"TEST-{int(time.time()*1000)}",
            timestamp    = datetime.now().isoformat(timespec="seconds"),
            severity     = EventSeverity.HIGH,
            level        = PrivilegeLevel.ADMINISTRATOR,
            process_name = "sentinel_test.exe",
            process_id   = os.getpid(),
            user         = os.environ.get("USERNAME", os.environ.get("USER", "testuser")),
            description  = "🧪 TEST: Simulated admin privilege escalation request",
            raw_detail   = "Synthetic event injected by Sentinel test harness",
            source       = "TestHarness",
        )
        try:
            self._q.put_nowait(evt)
        except queue.Full:
            pass

    # ── Internal ──────────────────────────────────────────────────────────────

    def _drain_loop(self) -> None:
        """Drain internal OS event queue into a pending list.

        The callback is NOT fired here — it runs on the main thread via
        drain_pending_callbacks(), which the GUI calls from its heartbeat.
        This eliminates all "main thread is not in main loop" Tkinter errors.
        """
        while self._running:
            try:
                evt = self._q.get(timeout=self._poll_interval)
                self._stats.events_detected += 1
                self._stats.last_event_ts    = evt.timestamp
                # Enqueue for main-thread delivery instead of calling directly
                with self._pending_lock:
                    self._pending_events.append(evt)
            except queue.Empty:
                pass

    def drain_pending_callbacks(self) -> None:
        """Deliver all pending events via the registered callback.

        Call this from the main/UI thread (e.g., inside a Tkinter after() heartbeat).
        It is safe to call even if no events are pending.
        """
        with self._pending_lock:
            events, self._pending_events = self._pending_events[:], []
        for evt in events:
            try:
                self._callback(evt)
            except Exception as e:
                logger.error("[AdminPrivMon] Callback error (main thread): %s", e)
