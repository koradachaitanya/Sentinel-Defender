"""
Hardware Gatekeeper — Optimized & Fixed
========================================
Controls Bluetooth + Wi-Fi hardware access behind a password.

Fixes applied:
  1. PyQt signal bridge  — background thread never touches widgets directly
  2. Session timeout     — authenticated flag auto-resets after N seconds
  3. Manual re-lock      — control panel with explicit lock button
  4. Non-blocking feedback — inline error labels, no QMessageBox in hot path
  5. Radio re-discovery  — re-scans for adapters if one goes stale
  6. app.setQuitOnLastWindowClosed(False) — hiding dialog no longer kills app
  7. Graceful stop()     — clean shutdown on app exit
  8. Status panel        — live hardware state + countdown timer
"""

import sys
import asyncio
import threading
import time

from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QFrame
)
from PyQt6.QtCore import Qt, QObject, QTimer, pyqtSignal
from winrt.windows.devices.radios import Radio, RadioKind, RadioState

# ============================================================
# CONFIGURATION
# ============================================================
SECRET_PASSWORD   = "SystemAdmin123"
SESSION_TIMEOUT_S = 300   # seconds before auto re-lock (0 = never)
POLL_INTERVAL_S   = 0.5   # how often enforcer checks hardware state

# ============================================================
# SIGNAL BUS  — the ONLY safe way to talk from a thread → Qt UI
# ============================================================
class Signals(QObject):
    """
    All emits happen from the background enforcer thread.
    Qt automatically queues them onto the main thread before
    invoking the connected slots — so widgets are always touched
    on the correct thread.
    """
    show_challenge   = pyqtSignal()          # unauthorized activation detected
    bt_state_changed = pyqtSignal(str)       # "ON" | "OFF" | "MISSING"
    wifi_state_changed = pyqtSignal(str)     # "ON" | "OFF" | "MISSING"
    auth_changed     = pyqtSignal(bool)      # authentication state changed
    timer_updated    = pyqtSignal(int)       # session time remaining


# ============================================================
# GATEKEEPER  — pure logic, no Qt widgets
# ============================================================
class HardwareGatekeeper:

    def __init__(self, signals: Signals, password: str = None):
        self.signals     = signals
        self.password    = password or SECRET_PASSWORD
        self._lock       = threading.Lock()
        self._auth       = False
        self._auth_ts    = 0.0
        self._running    = True

        self._bt_radio   = None
        self._wifi_radio = None

        # Cache last emitted states to avoid duplicate signals
        self._last_bt_state   = None
        self._last_wifi_state = None

    # ── Auth API (called from UI thread) ─────────────────────────────────────

    def authenticate(self, provided_password: str = None) -> bool:
        """Authenticate with password. Returns True if successful."""
        password = provided_password or self.password
        # For now, accept any password (will be validated in UI)
        with self._lock:
            was_auth = self._auth
            self._auth    = True
            self._auth_ts = time.time()
            if not was_auth:
                self.signals.auth_changed.emit(True)
        return True

    def revoke(self) -> None:
        with self._lock:
            was_auth = self._auth
            self._auth    = False
            self._auth_ts = 0.0
            if was_auth:
                self.signals.auth_changed.emit(False)

    def is_authenticated(self) -> bool:
        with self._lock:
            return self._auth

    def session_remaining(self) -> int:
        """Seconds remaining in session, or -1 if no timeout configured."""
        if SESSION_TIMEOUT_S <= 0:
            return -1
        with self._lock:
            if not self._auth:
                return 0
            return max(0, SESSION_TIMEOUT_S - int(time.time() - self._auth_ts))

    def stop(self) -> None:
        self._running = False

    # ── Enforcer (runs in daemon thread) ─────────────────────────────────────

    def enforcer_loop(self) -> None:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        # Initial discovery
        loop.run_until_complete(self._discover_radios())
        print("[Gatekeeper] Started — Bluetooth & Wi-Fi under lockdown.")

        while self._running:
            # Re-discover if we lost a radio (e.g. USB dongle unplugged/replugged)
            if self._bt_radio is None or self._wifi_radio is None:
                loop.run_until_complete(self._discover_radios())

            with self._lock:
                is_auth = self._auth
                auth_ts = self._auth_ts

            # ── Session timeout check ────────────────────────────────────────
            if is_auth and SESSION_TIMEOUT_S > 0:
                remaining = SESSION_TIMEOUT_S - int(time.time() - auth_ts)
                self.signals.timer_updated.emit(max(0, remaining))
                if (time.time() - auth_ts) >= SESSION_TIMEOUT_S:
                    print("[Gatekeeper] Session expired — revoking.")
                    self.revoke()
                    is_auth = False
                    # Will fall through to blocking logic below
            elif is_auth:
                self.signals.timer_updated.emit(-1)  # No timeout

            # ── Hardware enforcement ─────────────────────────────────────────
            blocked_something = False

            blocked_something |= loop.run_until_complete(
                self._enforce_radio(self._bt_radio,   "Bluetooth", "_last_bt_state",   is_auth)
            )
            blocked_something |= loop.run_until_complete(
                self._enforce_radio(self._wifi_radio, "Wi-Fi",     "_last_wifi_state", is_auth)
            )

            if blocked_something:
                self.signals.show_challenge.emit()   # prompt password on main thread

            time.sleep(POLL_INTERVAL_S)

    async def _discover_radios(self) -> None:
        try:
            radios = await Radio.get_radios_async()
        except Exception as e:
            print(f"[Gatekeeper] Radio discovery error: {e}")
            return

        bt_found   = False
        wifi_found = False

        for r in radios:
            if r.kind == RadioKind.BLUETOOTH:
                self._bt_radio = r
                bt_found = True
            elif r.kind == RadioKind.WI_FI:
                self._wifi_radio = r
                wifi_found = True

        if not bt_found:
            self._bt_radio = None
        if not wifi_found:
            self._wifi_radio = None

    async def _enforce_radio(
        self, radio, name: str, last_attr: str, is_auth: bool
    ) -> bool:
        """
        Returns True if an unauthorised ON state was found and blocked.
        Also emits state-change signals when the hardware state changes.
        """
        if radio is None:
            self._maybe_emit_state(last_attr, "MISSING",
                                   self.signals.bt_state_changed if name == "Bluetooth"
                                   else self.signals.wifi_state_changed)
            return False

        sig = (self.signals.bt_state_changed
               if name == "Bluetooth" else self.signals.wifi_state_changed)

        try:
            state    = radio.state
            state_str = "ON" if state == RadioState.ON else "OFF"
            self._maybe_emit_state(last_attr, state_str, sig)

            if state == RadioState.ON and not is_auth:
                print(f"[Gatekeeper] BLOCKING unauthorised {name} activation.")
                await radio.set_state_async(RadioState.OFF)
                self._maybe_emit_state(last_attr, "OFF", sig)
                return True

        except Exception as e:
            # Radio object went stale — trigger re-discovery next cycle
            print(f"[Gatekeeper] {name} radio error: {e}")
            if name == "Bluetooth":
                self._bt_radio = None
            else:
                self._wifi_radio = None

        return False

    def _maybe_emit_state(self, attr: str, new_state: str, signal) -> None:
        """Only emit signal when state actually changes to avoid UI spam."""
        if getattr(self, attr) != new_state:
            setattr(self, attr, new_state)
            signal.emit(new_state)


# ============================================================
# PASSWORD DIALOG  — shown only when an intercept fires
# ============================================================
class SecurityChallenge(QWidget):

    def __init__(self, gatekeeper: HardwareGatekeeper):
        super().__init__()
        self.gatekeeper = gatekeeper
        self._build_ui()

    def _build_ui(self):
        self.setWindowTitle("🔒 Network Security Lock")
        self.setFixedSize(420, 240)
        self.setWindowFlags(
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.CustomizeWindowHint  |
            Qt.WindowType.WindowTitleHint
        )
        self.setStyleSheet("""
            QWidget   { background:#0d1117; color:#e6edf3; font-family:'Segoe UI'; }
            QLineEdit {
                background:#161b22; border:1px solid #30363d;
                border-radius:6px; padding:8px 10px; font-size:13px;
            }
            QLineEdit:focus { border-color:#388bfd; }
            QPushButton {
                background:#238636; color:#fff; border:none;
                border-radius:6px; padding:10px; font-size:13px; font-weight:bold;
            }
            QPushButton:hover   { background:#2ea043; }
            QPushButton:pressed { background:#196127; }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 22, 28, 22)
        layout.setSpacing(10)

        title = QLabel("🔐  ACCESS RESTRICTED")
        title.setStyleSheet("font-size:17px; font-weight:bold; color:#f78166;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        sub = QLabel("An unauthorised hardware activation was blocked.\n"
                     "Enter the admin password to unlock Bluetooth & Wi-Fi:")
        sub.setStyleSheet("font-size:12px; color:#8b949e;")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(sub)

        self.pw_input = QLineEdit()
        self.pw_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.pw_input.setPlaceholderText("Admin password…")
        self.pw_input.returnPressed.connect(self._submit)
        layout.addWidget(self.pw_input)

        # Inline error — no blocking QMessageBox
        self.error_lbl = QLabel("")
        self.error_lbl.setStyleSheet("color:#f78166; font-size:11px;")
        self.error_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.error_lbl)

        btn = QPushButton("Authorize Hardware Access")
        btn.clicked.connect(self._submit)
        layout.addWidget(btn)

    def _submit(self):
        if self.pw_input.text() == self.gatekeeper.password:
            self.gatekeeper.authenticate(self.pw_input.text())
            self.pw_input.clear()
            self.error_lbl.setText("")
            self.hide()
        else:
            self.error_lbl.setText("❌  Incorrect password — hardware remains locked.")
            self.pw_input.clear()
            # Brief red border flash
            self.pw_input.setStyleSheet("border:1px solid #f78166;")
            QTimer.singleShot(700, lambda: self.pw_input.setStyleSheet(""))

    # ── Slot — called via Qt signal from enforcer thread ─────────────────────
    def on_show_challenge(self):
        self.pw_input.clear()
        self.error_lbl.setText("")
        self.show()
        self.raise_()
        self.activateWindow()
        self.pw_input.setFocus()


# ============================================================
# CONTROL PANEL  — persistent status + manual re-lock
# ============================================================
class ControlPanel(QWidget):

    def __init__(self, gatekeeper: HardwareGatekeeper, challenge: SecurityChallenge):
        super().__init__()
        self.gatekeeper = gatekeeper
        self.challenge  = challenge
        self._build_ui()
        self._start_refresh_timer()

    def _build_ui(self):
        self.setWindowTitle("Hardware Gatekeeper")
        self.setFixedSize(360, 260)
        self.setWindowFlags(Qt.WindowType.WindowStaysOnTopHint)
        self.setStyleSheet("""
            QWidget     { background:#0d1117; color:#e6edf3; font-family:'Segoe UI'; }
            QLabel      { font-size:13px; }
            QPushButton { border-radius:6px; padding:9px; font-size:12px;
                          font-weight:bold; border:none; color:#fff; }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(8)

        hdr = QLabel("🛡️  Hardware Gatekeeper")
        hdr.setStyleSheet("font-size:16px; font-weight:bold;")
        layout.addWidget(hdr)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet("color:#30363d;")
        layout.addWidget(sep)

        self.bt_lbl     = QLabel("Bluetooth : checking…")
        self.wifi_lbl   = QLabel("Wi-Fi     : checking…")
        self.auth_lbl   = QLabel("Auth      : 🔴 Locked")
        self.timer_lbl  = QLabel("")
        self.timer_lbl.setStyleSheet("font-size:11px; color:#8b949e;")

        for lbl in (self.bt_lbl, self.wifi_lbl, self.auth_lbl, self.timer_lbl):
            layout.addWidget(lbl)

        layout.addSpacing(6)

        btn_row = QHBoxLayout()

        self.lock_btn = QPushButton("🔒  Re-lock Now")
        self.lock_btn.setStyleSheet("background:#da3633;")
        self.lock_btn.clicked.connect(self._manual_relock)
        btn_row.addWidget(self.lock_btn)

        self.unlock_btn = QPushButton("🔑  Unlock")
        self.unlock_btn.setStyleSheet("background:#238636;")
        self.unlock_btn.clicked.connect(self.challenge.on_show_challenge)
        btn_row.addWidget(self.unlock_btn)

        layout.addLayout(btn_row)

    # ── Signal slots (hardware state) ────────────────────────────────────────

    def on_bt_state(self, state: str):
        color, icon = self._state_style(state)
        self.bt_lbl.setText(f"Bluetooth : {icon} {state}")
        self.bt_lbl.setStyleSheet(f"color:{color};")

    def on_wifi_state(self, state: str):
        color, icon = self._state_style(state)
        self.wifi_lbl.setText(f"Wi-Fi     : {icon} {state}")
        self.wifi_lbl.setStyleSheet(f"color:{color};")

    @staticmethod
    def _state_style(state: str):
        return {
            "ON":      ("#3fb950", "🟢"),
            "OFF":     ("#f78166", "🔴"),
            "MISSING": ("#8b949e", "⚠️"),
        }.get(state, ("#8b949e", "❔"))

    # ── 1-second refresh timer (auth status + countdown) ─────────────────────

    def _start_refresh_timer(self):
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh)
        self._timer.start(1000)

    def _refresh(self):
        if self.gatekeeper.is_authenticated():
            self.auth_lbl.setText("Auth : 🟢 Unlocked")
            self.auth_lbl.setStyleSheet("color:#3fb950;")
            rem = self.gatekeeper.session_remaining()
            if rem >= 0:
                m, s = divmod(rem, 60)
                self.timer_lbl.setText(f"⏱  Auto-locks in {m}m {s:02d}s")
            else:
                self.timer_lbl.setText("⏱  No auto-lock")
        else:
            self.auth_lbl.setText("Auth : 🔴 Locked")
            self.auth_lbl.setStyleSheet("color:#f78166;")
            self.timer_lbl.setText("")

    # ── Manual re-lock ────────────────────────────────────────────────────────

    def _manual_relock(self):
        self.gatekeeper.revoke()
        self._refresh()


# ============================================================
# ENTRY POINT
# ============================================================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)   # hiding dialog must NOT kill the app

    signals   = Signals()
    gatekeeper = HardwareGatekeeper(signals)
    challenge  = SecurityChallenge(gatekeeper)
    panel      = ControlPanel(gatekeeper, challenge)

    # Wire signals → slots (Qt handles cross-thread dispatch automatically)
    signals.show_challenge.connect(challenge.on_show_challenge)
    signals.bt_state_changed.connect(panel.on_bt_state)
    signals.wifi_state_changed.connect(panel.on_wifi_state)

    # Clean shutdown — stop enforcer before Qt tears down
    app.aboutToQuit.connect(gatekeeper.stop)

    # Enforcer runs in a daemon thread; has its own asyncio loop
    threading.Thread(target=gatekeeper.enforcer_loop, daemon=True).start()

    panel.show()
    sys.exit(app.exec())
