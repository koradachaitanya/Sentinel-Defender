#!/usr/bin/env python3
"""
Sentinel Defender - Network Detection Engine
============================================
Deep-packet-inspection engine using Scapy + Npcap (Windows) / libpcap (Linux/Mac).

Detects:
  Layer 2  : ARP Spoofing, DHCP Starvation, Rogue DHCP, LLMNR/NBT-NS Poisoning
  Layer 3  : IP Spoofing, ICMP Flood, Ping-of-Death, Smurf Attack
  Layer 4  : SYN Flood, UDP Flood, Port Scanning (SYN/NULL/XMAS/FIN), TCP Session Hijacking
  Layer 7  : DNS Spoofing, DNS Tunneling, HTTP Phishing, SSL Stripping,
             Brute-Force (SSH/FTP/HTTP), C2 Beaconing, SMB Exploitation

Architecture:
  NetworkEngine   — packet capture loop (background thread)
  AttackDetector  — stateful analysis of raw packets → NetworkAlert objects
  NetworkMonitor  — public API used by SentinelHub + GUI
"""

from __future__ import annotations

import time
import math
import socket
import threading
import ipaddress
import logging
import collections
from datetime import datetime
from dataclasses import dataclass, field, asdict
from typing import Optional, Callable, Dict, List, Set
from enum import Enum

logger = logging.getLogger(__name__)

# ── Optional Scapy import ────────────────────────────────────────────────────
try:
    from scapy.all import (
        sniff, ARP, IP, TCP, UDP, ICMP, DNS, DNSQR, DNSRR,
        Ether, get_if_list, conf as scapy_conf, Raw
    )
    from scapy.layers.http import HTTP, HTTPRequest, HTTPResponse
    from scapy.layers.l2 import STP
    SCAPY_AVAILABLE = True
    # Suppress scapy IPv6 warnings
    import logging as _l
    _l.getLogger("scapy.runtime").setLevel(_l.ERROR)
except ImportError:
    SCAPY_AVAILABLE = False
    logger.warning("[NetworkEngine] Scapy not installed — install with: pip install scapy")

# ─────────────────────────────────────────────────────────────────────────────
#  Data classes
# ─────────────────────────────────────────────────────────────────────────────

class AttackCategory(str, Enum):
    ARP_SPOOFING          = "ARP Spoofing"
    DNS_SPOOFING          = "DNS Spoofing"
    DNS_TUNNELING         = "DNS Tunneling"
    IP_SPOOFING           = "IP Spoofing"
    SYN_FLOOD             = "SYN Flood"
    UDP_FLOOD             = "UDP Flood"
    ICMP_FLOOD            = "ICMP Flood"
    PING_OF_DEATH         = "Ping of Death"
    PORT_SCAN             = "Port Scan"
    PHISHING              = "HTTP Phishing"
    SSL_STRIPPING         = "SSL Stripping"
    BRUTE_FORCE           = "Brute Force"
    C2_BEACON             = "C2 Beaconing"
    DHCP_STARVATION       = "DHCP Starvation"
    ROGUE_DHCP            = "Rogue DHCP"
    LLMNR_POISON          = "LLMNR/NBT-NS Poisoning"
    SMB_EXPLOIT           = "SMB Exploitation"
    SMURF                 = "Smurf Attack"
    SESSION_HIJACK        = "TCP Session Hijack"
    # ── New detections ────────────────────────────────────────────────────────
    MAC_FLOOD             = "MAC Flooding"
    STP_ATTACK            = "STP Manipulation"
    ARP_STORM             = "ARP Storm"
    LAND_ATTACK           = "LAND Attack"
    FRAGMENT_ATTACK       = "IP Fragmentation Attack"
    ICMP_REDIRECT         = "ICMP Redirect Abuse"
    TCP_RST_ATTACK        = "TCP RST Injection"
    ACK_FLOOD             = "ACK Flood"
    SLOWLORIS             = "Slowloris"
    SQL_INJECTION         = "SQL Injection"
    XSS_ATTACK            = "Cross-Site Scripting"
    DIRECTORY_ENUMERATION = "Directory Enumeration"
    IPV6_RA_SPOOF         = "IPv6 RA Spoofing"
    UNKNOWN               = "Unknown"


class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"
    INFO     = "INFO"


@dataclass
class NetworkAlert:
    alert_id:     str
    timestamp:    str
    category:     str
    severity:     str
    src_ip:       str
    dst_ip:       str
    src_mac:      str
    dst_mac:      str
    protocol:     str
    src_port:     int
    dst_port:     int
    description:  str
    raw_summary:  str
    packet_count: int  = 1
    mitre_tactic: str  = ""
    recommendation: str = ""
    resolved:     bool = False

    def to_dict(self) -> dict:
        return asdict(self)


# ─────────────────────────────────────────────────────────────────────────────
#  Phishing & C2 Indicators
# ─────────────────────────────────────────────────────────────────────────────

# Known phishing keywords in HTTP Host / URL
PHISHING_KEYWORDS = [
    "paypa1", "paypai", "g00gle", "arnazon", "micros0ft", "secure-login",
    "account-verify", "banking-secure", "update-account", "signin-secure",
    "verify-now", "suspended-account", "unlock-account", "confirm-identity",
    "apple-id-verify", "netflix-billing", "amazon-suspended",
]

# Domains/IPs commonly used by C2 frameworks (sample — expandable)
KNOWN_C2_INDICATORS = {
    "cobalt-strike", "meterpreter", "empire", "covenant",
    "havoc", "sliver", "brute-ratel",
}

# Suspicious high-risk ports
HIGH_RISK_PORTS = {
    4444, 4445, 1337, 31337, 6666, 6667, 8888,  # Common RAT/shell ports
    9090, 9091, 1080,                             # Proxy/SOCKS
    5900, 5901,                                   # VNC
    23,                                           # Telnet
}

# Ports that should NOT have inbound traffic (common scan targets)
SCAN_HONEYPOT_PORTS = {
    1, 7, 9, 13, 17, 19, 21, 22, 23, 25, 53,
    79, 80, 110, 111, 135, 137, 138, 139, 143,
    443, 445, 512, 513, 514, 1433, 1521, 3306,
    3389, 5432, 5900, 6379, 8080, 8443, 27017,
}

# Known legitimate DNS resolvers (Google, Cloudflare, Quad9, OpenDNS, ISP common)
KNOWN_DNS_SERVERS = {
    "8.8.8.8", "8.8.4.4",           # Google
    "1.1.1.1", "1.0.0.1",           # Cloudflare
    "9.9.9.9", "149.112.112.112",   # Quad9
    "208.67.222.222", "208.67.220.220",  # OpenDNS
    "4.2.2.1", "4.2.2.2",           # Level3
    "64.6.64.6", "64.6.65.6",       # Verisign
}

def _get_local_dns_servers() -> set:
    """
    Dynamically resolve the machine's actual configured DNS servers
    (typically the home/office router) so we never flag them as spoofing.
    Works on Windows, Linux, macOS without admin rights.
    """
    servers: set = set()
    # Method 1: socket-based gateway heuristic (router is usually x.x.x.1 or x.x.x.254)
    try:
        import socket, struct
        # Use the local IP to guess the gateway
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
        parts = local_ip.rsplit(".", 1)
        if len(parts) == 2:
            servers.add(parts[0] + ".1")
            servers.add(parts[0] + ".254")
    except Exception:
        pass
    # Method 2: read resolv.conf on Linux/macOS
    try:
        import pathlib
        rc = pathlib.Path("/etc/resolv.conf")
        if rc.exists():
            for line in rc.read_text().splitlines():
                line = line.strip()
                if line.startswith("nameserver"):
                    ip = line.split()[1]
                    servers.add(ip)
    except Exception:
        pass
    # Method 3: Windows DNS via ipconfig output
    try:
        import subprocess, re
        out = subprocess.check_output(["ipconfig", "/all"], timeout=3,
                                      stderr=subprocess.DEVNULL,
                                      creationflags=0x08000000).decode("utf-8", errors="replace")
        for m in re.finditer(r"DNS Servers[^\d]+([\d.]+)", out):
            servers.add(m.group(1).strip())
    except Exception:
        pass
    return servers

# Build the combined set once at import time (fast, no admin needed)
_LOCAL_DNS_SERVERS: set = _get_local_dns_servers()
EFFECTIVE_DNS_SERVERS: set = KNOWN_DNS_SERVERS | _LOCAL_DNS_SERVERS

# ── False-positive whitelist ──────────────────────────────────────────────────
# Destination IPs/ranges that are ALWAYS legitimate — never flag DNS from these
BENIGN_MULTICAST_DESTINATIONS = {
    "224.0.0.251",   # mDNS (Bonjour/Avahi — phones, printers, smart TVs)
    "224.0.0.252",   # LLMNR multicast (Windows name resolution)
    "239.255.255.250",  # SSDP / UPnP (routers, smart devices)
    "224.0.0.1",     # All-hosts multicast
    "224.0.0.2",     # All-routers multicast
    "224.0.0.9",     # RIP multicast
    "224.0.0.13",    # PIM multicast
    "224.0.0.22",    # IGMP multicast
    "255.255.255.255",  # Broadcast
}

# Ports that carry legitimate service-discovery traffic — NOT attacks
BENIGN_SERVICE_PORTS = {
    5353,   # mDNS (Bonjour/Avahi/Android/iOS)
    5355,   # LLMNR (Windows Link-Local Multicast Name Resolution)
    1900,   # SSDP / UPnP discovery
    5350,   # NAT-PMP
    5351,   # NAT-PMP
}

# Domain suffixes that are always local/benign — skip DNS-spoof check
BENIGN_LOCAL_DOMAINS = {
    ".local", ".local.", "local",
    ".arpa", ".arpa.",
    ".lan", ".lan.",
    ".internal", ".internal.",
    ".home", ".home.",
    ".localdomain", ".localdomain.",
}

def _is_benign_mdns_or_service(dst_ip: str, dst_port: int, src_port: int,
                                 qname: str = "") -> bool:
    """
    Returns True if this packet is normal LAN service-discovery traffic
    (mDNS, SSDP, LLMNR, Bonjour) that should NEVER be flagged.
    """
    if dst_ip in BENIGN_MULTICAST_DESTINATIONS:
        return True
    if dst_port in BENIGN_SERVICE_PORTS or src_port in BENIGN_SERVICE_PORTS:
        return True
    if qname:
        q_lower = qname.lower()
        if any(q_lower.endswith(suffix) for suffix in BENIGN_LOCAL_DOMAINS):
            return True
        # Android/iOS service announcements
        if any(tok in q_lower for tok in ("_tcp", "_udp", "android", "apple",
                                           "iphone", "ipad", "_googlecast",
                                           "_airplay", "_raop", "_companion",
                                           "chromecast", "_spotify")):
            return True
    return False


# ─────────────────────────────────────────────────────────────────────────────
#  Attack Detector — stateful per-packet analysis
# ─────────────────────────────────────────────────────────────────────────────

class AttackDetector:
    """
    Maintains sliding-window counters and state tables to detect
    network attacks from raw Scapy packets.
    """

    WINDOW   = 60    # seconds — rolling detection window
    MAX_HIST = 5000  # max entries per counter before purge

    def __init__(self, alert_callback: Callable[[NetworkAlert], None]):
        self._cb         = alert_callback
        self._alert_seq  = 0
        self._lock       = threading.Lock()

        # ARP table: ip → set of MACs seen
        self._arp_table:  Dict[str, Set[str]]       = collections.defaultdict(set)

        # SYN flood: (src_ip, dst_ip, dst_port) → [timestamps]
        self._syn_table:  Dict[tuple, List[float]]  = collections.defaultdict(list)

        # UDP flood: (src_ip, dst_ip) → [timestamps]
        self._udp_table:  Dict[tuple, List[float]]  = collections.defaultdict(list)

        # ICMP flood: src_ip → [timestamps]
        self._icmp_table: Dict[str, List[float]]    = collections.defaultdict(list)

        # Port scan: src_ip → set of (dst_ip, dst_port) tuples
        self._scan_ports: Dict[str, Set[tuple]]     = collections.defaultdict(set)
        self._scan_times: Dict[str, List[float]]    = collections.defaultdict(list)

        # Brute force: (src_ip, dst_ip, dst_port) → [timestamps]
        self._bf_table:   Dict[tuple, List[float]]  = collections.defaultdict(list)

        # DNS: (src_ip → { qname: [timestamps] })
        self._dns_queries: Dict[str, Dict[str, List[float]]] = collections.defaultdict(
            lambda: collections.defaultdict(list)
        )

        # C2 beaconing: (src_ip, dst_ip, dst_port) → [timestamps]
        self._beacon_table: Dict[tuple, List[float]] = collections.defaultdict(list)

        # DHCP MACs seen
        self._dhcp_macs: Set[str] = set()
        self._dhcp_servers: Set[str] = set()

        # Suppression: avoid alerting same attack >1/min
        self._suppress: Dict[str, float] = {}

        # ── New state tables for extended detections ──────────────────────────

        # MAC Flooding: unique src_mac seen within WINDOW
        self._mac_seen: Dict[str, float] = {}          # mac → first_seen_ts

        # STP: (src_mac) → [timestamps of BPDU packets]
        self._stp_table: Dict[str, List[float]] = collections.defaultdict(list)

        # ARP Storm: src_mac → [timestamps of ARP packets]
        self._arp_storm_table: Dict[str, List[float]] = collections.defaultdict(list)

        # IP Fragmentation: src_ip → list of (id, offset, timestamp)
        self._frag_table: Dict[str, List[tuple]] = collections.defaultdict(list)

        # TCP RST Injection: src_ip → [timestamps of RST packets]
        self._rst_table: Dict[str, List[float]] = collections.defaultdict(list)

        # ACK Flood: (src_ip, dst_ip) → [timestamps of ACK-only packets]
        self._ack_table: Dict[tuple, List[float]] = collections.defaultdict(list)

        # Slowloris: dst_ip:dst_port → {src_ip: last_data_ts}
        # tracks half-open HTTP connections with no complete request
        self._slowloris_table: Dict[tuple, Dict[str, float]] = collections.defaultdict(dict)

        # Directory Enumeration (LDAP/Kerberos): (src_ip, dst_port) → [timestamps]
        self._dir_enum_table: Dict[tuple, List[float]] = collections.defaultdict(list)

        # Known gateway IPs — auto-populated from first ICMP redirect seen
        # populated from DHCP server set; pre-seed common defaults
        self._known_gateways: Set[str] = set()

    # ── Public entry point ────────────────────────────────────────────────────

    def process_packet(self, pkt) -> None:
        """Dispatch packet to all relevant detectors."""
        if not SCAPY_AVAILABLE:
            return
        try:
            # ── Layer 2 ──────────────────────────────────────────────────────
            if pkt.haslayer(Ether):
                self._detect_mac_flooding(pkt)

            if pkt.haslayer(ARP):
                self._detect_arp_spoofing(pkt)
                self._detect_arp_storm(pkt)

            # STP (Spanning Tree Protocol BPDU)
            if pkt.haslayer(STP):
                self._detect_stp_attack(pkt)

            # ── Layer 3 / 4 (IPv4) ───────────────────────────────────────────
            if pkt.haslayer(IP):
                ip = pkt[IP]
                self._detect_ip_spoofing(pkt, ip)
                self._detect_land_attack(pkt, ip)
                self._detect_fragment_attack(pkt, ip)

                if pkt.haslayer(ICMP):
                    self._detect_icmp_attacks(pkt, ip)
                    self._detect_icmp_redirect(pkt, ip)

                if pkt.haslayer(TCP):
                    self._detect_tcp_attacks(pkt, ip)
                    self._detect_tcp_rst_injection(pkt, ip)
                    self._detect_ack_flood(pkt, ip)
                    self._detect_slowloris(pkt, ip)

                if pkt.haslayer(UDP):
                    self._detect_udp_attacks(pkt, ip)

                if pkt.haslayer(DNS):
                    self._detect_dns_attacks(pkt, ip)

                if pkt.haslayer(TCP) and pkt[TCP].dport in (80, 8080, 8000):
                    self._detect_http_phishing(pkt, ip)
                    self._detect_http_injection(pkt, ip)

                if pkt.haslayer(TCP) and pkt[TCP].dport == 80:
                    self._detect_ssl_stripping(pkt, ip)

                if pkt.haslayer(TCP) and pkt[TCP].dport == 445:
                    self._detect_smb_exploit(pkt, ip)

                if pkt.haslayer(TCP) and pkt[TCP].dport in (389, 636, 88, 3268, 3269):
                    self._detect_directory_enumeration(pkt, ip)

                self._detect_c2_beaconing(pkt, ip)

            if pkt.haslayer(UDP) and pkt.haslayer(IP):
                self._detect_dhcp(pkt)

            # LLMNR (UDP 5355) / NBT-NS (UDP 137)
            if pkt.haslayer(UDP) and pkt.haslayer(IP):
                udp = pkt[UDP]
                if udp.dport in (5355, 137):
                    self._detect_llmnr_poison(pkt, pkt[IP])

            # ── IPv6 attacks ─────────────────────────────────────────────────
            try:
                from scapy.layers.inet6 import IPv6, ICMPv6ND_RA
                if pkt.haslayer(IPv6) and pkt.haslayer(ICMPv6ND_RA):
                    self._detect_ipv6_ra_spoof(pkt)
            except ImportError:
                pass

        except Exception as e:
            logger.debug("[Detector] Packet processing error: %s", e)

    # ── L2 Detectors ─────────────────────────────────────────────────────────

    def _detect_arp_spoofing(self, pkt) -> None:
        """
        Classic ARP cache poisoning: same IP claimed by 2+ different MACs,
        OR gratuitous ARP from unexpected source.
        """
        arp = pkt[ARP]
        if arp.op not in (1, 2):  # who-has or is-at
            return

        src_ip  = arp.psrc
        src_mac = arp.hwsrc.lower()

        if not src_ip or src_ip in ("0.0.0.0", "255.255.255.255"):
            return

        with self._lock:
            existing_macs = self._arp_table[src_ip]
            if existing_macs and src_mac not in existing_macs:
                # NEW MAC claiming existing IP → ARP Spoofing!
                old_mac = next(iter(existing_macs))
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.ARP_SPOOFING,
                    severity     = Severity.CRITICAL,
                    src_ip       = src_ip,
                    dst_ip       = arp.pdst,
                    src_mac      = src_mac,
                    dst_mac      = arp.hwdst,
                    protocol     = "ARP",
                    src_port     = 0,
                    dst_port     = 0,
                    description  = (
                        f"ARP Spoofing detected! IP {src_ip} previously "
                        f"mapped to {old_mac}, now claimed by {src_mac}. "
                        f"Likely man-in-the-middle attack."
                    ),
                    raw_summary  = pkt.summary(),
                    mitre_tactic = "T1557.002 — ARP Cache Poisoning",
                    recommendation = (
                        "Enable Dynamic ARP Inspection (DAI) on managed switches. "
                        "Use static ARP entries for critical hosts. "
                        "Consider 802.1X port authentication."
                    ),
                ))
            existing_macs.add(src_mac)

    # ── L3 Detectors ─────────────────────────────────────────────────────────

    def _detect_ip_spoofing(self, pkt, ip) -> None:
        """Detect obviously spoofed source IPs (RFC 5735 reserved ranges)."""
        try:
            src = ipaddress.ip_address(ip.src)
        except ValueError:
            return

        spoofed = False
        reason  = ""

        # Loopback from external interface
        if src.is_loopback and not self._is_local_packet(pkt):
            spoofed = True
            reason  = f"Loopback address {ip.src} arriving on external interface"

        # Multicast as source
        if src.is_multicast:
            spoofed = True
            reason  = f"Multicast address {ip.src} used as source (RFC violation)"

        # Reserved/documentation ranges from non-local
        if src in ipaddress.ip_network("192.0.2.0/24"):
            spoofed = True
            reason  = f"Documentation range {ip.src} used as real source"

        if spoofed:
            self._emit(NetworkAlert(
                alert_id     = self._next_id(),
                timestamp    = self._ts(),
                category     = AttackCategory.IP_SPOOFING,
                severity     = Severity.HIGH,
                src_ip       = ip.src,
                dst_ip       = ip.dst,
                src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                dst_mac      = pkt[Ether].dst if pkt.haslayer(Ether) else "",
                protocol     = "IP",
                src_port     = 0,
                dst_port     = 0,
                description  = f"IP Spoofing detected: {reason}",
                raw_summary  = pkt.summary(),
                mitre_tactic = "T1557 — Adversary-in-the-Middle",
                recommendation = (
                    "Enable unicast Reverse Path Forwarding (uRPF) on routers. "
                    "Apply BCP38 ingress filtering. "
                    "Use RPKI for BGP route validation."
                ),
            ))

    def _detect_icmp_attacks(self, pkt, ip) -> None:
        """Detect ICMP Flood, Ping-of-Death, and Smurf Attack."""
        icmp = pkt[ICMP]
        now  = time.time()

        # Ping-of-Death: ICMP packet > 65535 bytes
        try:
            if len(pkt) > 65535:
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.PING_OF_DEATH,
                    severity     = Severity.CRITICAL,
                    src_ip       = ip.src, dst_ip=ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = pkt[Ether].dst if pkt.haslayer(Ether) else "",
                    protocol     = "ICMP",
                    src_port     = 0, dst_port=0,
                    description  = f"Ping of Death! Oversized ICMP packet: {len(pkt)} bytes from {ip.src}",
                    raw_summary  = pkt.summary(),
                    mitre_tactic = "T1498 — Network DoS",
                    recommendation = "Apply ICMP rate limiting. Drop oversized ICMP at perimeter firewall.",
                ))
                return
        except Exception:
            pass

        # Smurf: ICMP echo-request to broadcast
        try:
            dst = ipaddress.ip_address(ip.dst)
            if icmp.type == 8 and (dst.is_multicast or str(dst).endswith(".255")):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.SMURF,
                    severity     = Severity.HIGH,
                    src_ip       = ip.src, dst_ip=ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "ICMP",
                    src_port     = 0, dst_port=0,
                    description  = (
                        f"Smurf Attack: ICMP echo to broadcast {ip.dst} "
                        f"from {ip.src} — will amplify into DoS."
                    ),
                    raw_summary  = pkt.summary(),
                    mitre_tactic = "T1498.001 — Direct Network Flood",
                    recommendation = "Block directed broadcast forwarding on all routers (ip no directed-broadcast).",
                ))
                return
        except Exception:
            pass

        # ICMP Flood: >100 ICMP/min from same src
        if icmp.type == 8:
            key = ip.src
            self._icmp_table[key] = [t for t in self._icmp_table[key] if now - t < self.WINDOW]
            self._icmp_table[key].append(now)
            count = len(self._icmp_table[key])
            if count > 100 and self._should_alert(f"icmp_flood_{key}"):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.ICMP_FLOOD,
                    severity     = Severity.HIGH,
                    src_ip       = ip.src, dst_ip=ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "ICMP",
                    src_port     = 0, dst_port=0,
                    description  = f"ICMP Flood from {ip.src}: {count} echo-requests in {self.WINDOW}s",
                    raw_summary  = pkt.summary(),
                    packet_count = count,
                    mitre_tactic = "T1498.001 — Direct Network Flood",
                    recommendation = "Apply ICMP rate-limiting policy. Consider blocking ICMP echo from untrusted sources.",
                ))

    # ── L4 Detectors ─────────────────────────────────────────────────────────

    def _detect_tcp_attacks(self, pkt, ip) -> None:
        tcp = pkt[TCP]
        now = time.time()

        # ── SYN Flood ────────────────────────────────────────────────────────
        if tcp.flags & 0x02 and not (tcp.flags & 0x10):  # SYN only (no ACK)
            key = (ip.src, ip.dst, tcp.dport)
            self._syn_table[key] = [t for t in self._syn_table[key] if now - t < self.WINDOW]
            self._syn_table[key].append(now)
            count = len(self._syn_table[key])
            if count > 100 and self._should_alert(f"syn_{key}"):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.SYN_FLOOD,
                    severity     = Severity.CRITICAL,
                    src_ip       = ip.src, dst_ip=ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = pkt[Ether].dst if pkt.haslayer(Ether) else "",
                    protocol     = "TCP",
                    src_port     = tcp.sport, dst_port=tcp.dport,
                    description  = (
                        f"SYN Flood: {count} SYN packets from {ip.src} "
                        f"to {ip.dst}:{tcp.dport} in {self.WINDOW}s — "
                        f"half-open connection exhaustion attack."
                    ),
                    raw_summary  = pkt.summary(),
                    packet_count = count,
                    mitre_tactic = "T1498.001 — Direct Network Flood",
                    recommendation = (
                        "Enable SYN cookies on the target server. "
                        "Configure rate limiting per source IP. "
                        "Deploy upstream DDoS mitigation."
                    ),
                ))

        # ── Port Scanning ─────────────────────────────────────────────────────
        # Detect SYN scan (SYN only to many ports), NULL scan (no flags),
        # XMAS scan (FIN+PSH+URG), FIN scan
        flags = int(tcp.flags)
        is_syn_scan  = flags == 0x02
        is_null_scan = flags == 0x00
        is_xmas_scan = flags == 0x29  # FIN+PSH+URG
        is_fin_scan  = flags == 0x01

        if is_syn_scan or is_null_scan or is_xmas_scan or is_fin_scan:
            if tcp.dport in SCAN_HONEYPOT_PORTS:
                key = ip.src
                target = (ip.dst, tcp.dport)
                self._scan_ports[key].add(target)
                self._scan_times[key] = [t for t in self._scan_times[key] if now - t < self.WINDOW]
                self._scan_times[key].append(now)
                unique_ports = len(self._scan_ports[key])

                if unique_ports >= 10 and self._should_alert(f"scan_{key}"):
                    scan_type = (
                        "SYN Scan"  if is_syn_scan  else
                        "NULL Scan" if is_null_scan else
                        "XMAS Scan" if is_xmas_scan else
                        "FIN Scan"
                    )
                    self._emit(NetworkAlert(
                        alert_id     = self._next_id(),
                        timestamp    = self._ts(),
                        category     = AttackCategory.PORT_SCAN,
                        severity     = Severity.HIGH,
                        src_ip       = ip.src, dst_ip=ip.dst,
                        src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                        dst_mac      = "",
                        protocol     = "TCP",
                        src_port     = tcp.sport, dst_port=tcp.dport,
                        description  = (
                            f"{scan_type} detected from {ip.src}: "
                            f"{unique_ports} unique ports probed in {self.WINDOW}s. "
                            f"Reconnaissance in progress."
                        ),
                        raw_summary  = pkt.summary(),
                        packet_count = unique_ports,
                        mitre_tactic = "T1046 — Network Service Discovery",
                        recommendation = (
                            "Block source IP at perimeter firewall. "
                            "Enable port-scan detection on IDS/IPS. "
                            "Configure iptables/pf to rate-limit new connections."
                        ),
                    ))

        # ── Brute Force detection (SSH:22, FTP:21, RDP:3389, HTTP:80/443) ────
        if tcp.dport in (22, 21, 3389, 23) and tcp.flags & 0x02:  # SYN to auth ports
            key = (ip.src, ip.dst, tcp.dport)
            self._bf_table[key] = [t for t in self._bf_table[key] if now - t < self.WINDOW]
            self._bf_table[key].append(now)
            count = len(self._bf_table[key])
            service = {22: "SSH", 21: "FTP", 3389: "RDP", 23: "Telnet"}.get(tcp.dport, str(tcp.dport))
            if count > 30 and self._should_alert(f"bf_{key}"):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.BRUTE_FORCE,
                    severity     = Severity.HIGH,
                    src_ip       = ip.src, dst_ip=ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "TCP",
                    src_port     = tcp.sport, dst_port=tcp.dport,
                    description  = (
                        f"{service} Brute Force from {ip.src}: "
                        f"{count} connection attempts in {self.WINDOW}s to {ip.dst}:{tcp.dport}"
                    ),
                    raw_summary  = pkt.summary(),
                    packet_count = count,
                    mitre_tactic = "T1110 — Brute Force",
                    recommendation = (
                        f"Enable {service} rate limiting / fail2ban. "
                        "Use key-based authentication only. "
                        "Block source IP at firewall after N failures."
                    ),
                ))

        # ── SMB Exploitation (EternalBlue / MS17-010) ────────────────────────
        if tcp.dport == 445 and pkt.haslayer(Raw):
            payload = bytes(pkt[Raw])
            # EternalBlue signature — SMB_COM_TRANSACTION2 with SetupCount anomaly
            if b"\xff\x53\x4d\x42" in payload or b"\xfe\x53\x4d\x42" in payload:
                if len(payload) > 200 and self._should_alert(f"smb_{ip.src}"):
                    self._emit(NetworkAlert(
                        alert_id     = self._next_id(),
                        timestamp    = self._ts(),
                        category     = AttackCategory.SMB_EXPLOIT,
                        severity     = Severity.CRITICAL,
                        src_ip       = ip.src, dst_ip=ip.dst,
                        src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                        dst_mac      = pkt[Ether].dst if pkt.haslayer(Ether) else "",
                        protocol     = "SMB",
                        src_port     = tcp.sport, dst_port=445,
                        description  = (
                            f"Possible SMB Exploitation from {ip.src}! "
                            f"Suspicious SMBv1/v2 payload detected ({len(payload)} bytes). "
                            f"Pattern consistent with EternalBlue/WannaCry attack."
                        ),
                        raw_summary  = pkt.summary(),
                        mitre_tactic = "T1210 — Exploitation of Remote Services",
                        recommendation = (
                            "Disable SMBv1 immediately. "
                            "Apply MS17-010 patch. "
                            "Block port 445 from untrusted networks."
                        ),
                    ))

    def _detect_udp_attacks(self, pkt, ip) -> None:
        """Detect UDP Flood."""
        udp = pkt[UDP]
        now = time.time()

        key = (ip.src, ip.dst)
        self._udp_table[key] = [t for t in self._udp_table[key] if now - t < self.WINDOW]
        self._udp_table[key].append(now)
        count = len(self._udp_table[key])

        if count > 200 and self._should_alert(f"udp_flood_{key}"):
            self._emit(NetworkAlert(
                alert_id     = self._next_id(),
                timestamp    = self._ts(),
                category     = AttackCategory.UDP_FLOOD,
                severity     = Severity.HIGH,
                src_ip       = ip.src, dst_ip=ip.dst,
                src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                dst_mac      = "",
                protocol     = "UDP",
                src_port     = udp.sport, dst_port=udp.dport,
                description  = (
                    f"UDP Flood from {ip.src} → {ip.dst}: "
                    f"{count} UDP datagrams in {self.WINDOW}s. "
                    f"Target service denial likely."
                ),
                raw_summary  = pkt.summary(),
                packet_count = count,
                mitre_tactic = "T1498.001 — Direct Network Flood",
                recommendation = "Apply UDP rate limiting at firewall. Use BCP38 filtering upstream.",
            ))

    # ── L7 Detectors ─────────────────────────────────────────────────────────

    @staticmethod
    def _decode_dns_name(raw) -> str:
        """
        Safely decode a Scapy DNS name field to a clean string.
        Fixes the b'Android.local.' bytes-repr display bug.
        """
        if raw is None:
            return "?"
        if isinstance(raw, bytes):
            try:
                return raw.decode("utf-8", errors="replace").rstrip(".")
            except Exception:
                return str(raw)
        s = str(raw)
        # Strip Python bytes prefix artefacts e.g.  b'example.local.'
        if s.startswith("b'") or s.startswith("b\""):
            s = s[2:].rstrip("'\"")
        return s.rstrip(".")

    def _detect_dns_attacks(self, pkt, ip) -> None:
        """
        Detect DNS Spoofing and DNS Tunneling.
        Skips mDNS, LLMNR, SSDP and other legitimate LAN service-discovery
        traffic to eliminate false positives.
        """
        dns = pkt[DNS]
        now = time.time()
        udp = pkt[UDP] if pkt.haslayer(UDP) else None
        sport = udp.sport if udp else 0
        dport = udp.dport if udp else 0

        # ── Whitelist check — skip ALL benign multicast / service-discovery ──
        # mDNS  (port 5353 / 224.0.0.251)
        # SSDP  (port 1900 / 239.255.255.250)
        # LLMNR (port 5355 / 224.0.0.252)
        raw_qname = dns.qd.qname if dns.qd else None
        qname_str = self._decode_dns_name(raw_qname)

        if _is_benign_mdns_or_service(ip.dst, dport, sport, qname_str):
            return   # ← normal LAN service-discovery, not an attack

        # ── Threat Intelligence: check queried domain against TI feed ─────────
        # This runs on every outbound DNS query — if the destination domain
        # is in the ThreatFox / URLhaus database we fire an alert immediately.
        if dns.qr == 0 and qname_str:   # qr == 0 means it's a query (not a response)
            clean_domain = qname_str.rstrip(".").lower()
            # Check the full domain and the parent domain (e.g. sub.evil.com → evil.com)
            domains_to_check = [clean_domain]
            parts = clean_domain.split(".")
            if len(parts) >= 2:
                domains_to_check.append(".".join(parts[-2:]))
            for dom in domains_to_check:
                if not dom:
                    continue
                try:
                    ti_match = self._ti_lookup_domain(dom)
                    if ti_match and self._should_alert(f"ti_domain_{ip.src}_{dom}"):
                        self._cb(NetworkAlert(
                            alert_id     = self._make_alert_id(),
                            timestamp    = datetime.now().isoformat(timespec="seconds"),
                            category     = "Threat Intel: Malicious Domain Query",
                            severity     = ti_match.severity.upper(),
                            src_ip       = ip.src,
                            dst_ip       = ip.dst,
                            src_mac      = "",
                            dst_mac      = "",
                            protocol     = "DNS",
                            src_port     = sport,
                            dst_port     = dport,
                            description  = (
                                f"DNS query for '{clean_domain}' matched threat intelligence "
                                f"({ti_match.source}). Threat: {ti_match.threat_name} "
                                f"[{ti_match.threat_type}]. "
                                f"Tags: {', '.join(ti_match.tags) if ti_match.tags else 'none'}."
                            ),
                            raw_summary  = f"TI domain hit: {clean_domain} → {ti_match.threat_name}",
                            mitre_tactic = "T1568 — Dynamic Resolution",
                            recommendation = (
                                f"Block DNS resolution for '{clean_domain}' and all subdomains. "
                                f"Isolate the host at {ip.src} for investigation. "
                                f"Source: {ti_match.source}."
                            ),
                        ))
                except Exception:
                    pass

        # ── DNS Spoofing: response from non-authoritative / unexpected source ─
        if dns.qr == 1 and ip.src not in EFFECTIVE_DNS_SERVERS:
            if dns.ancount > 0 and self._should_alert(f"dns_spoof_{ip.src}", cooldown=600.0):
                try:
                    rr    = dns.an
                    rdata = str(rr.rdata) if hasattr(rr, "rdata") else "?"
                    # Use the already-decoded qname (no more b'...' prefix)
                    qname = qname_str or "?"
                    # Extra safety: skip if the answer points to a private/local addr
                    # (routers & DHCP servers legitimately respond to local queries)
                    import ipaddress as _ipa
                    try:
                        answered_ip = _ipa.ip_address(rdata)
                        if answered_ip.is_private or answered_ip.is_loopback:
                            # Only flag if the queried name is not a local domain
                            if _is_benign_mdns_or_service(ip.dst, dport, sport, qname):
                                return
                    except ValueError:
                        pass   # rdata is not an IP — proceed with check

                    self._emit(NetworkAlert(
                        alert_id     = self._next_id(),
                        timestamp    = self._ts(),
                        category     = AttackCategory.DNS_SPOOFING,
                        severity     = Severity.HIGH,
                        src_ip       = ip.src, dst_ip=ip.dst,
                        src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                        dst_mac      = "",
                        protocol     = "DNS",
                        src_port     = sport,
                        dst_port     = dport or 53,
                        description  = (
                            f"DNS Spoofing! Unsolicited DNS response from {ip.src} "
                            f"for '{qname}' → '{rdata}'. "
                            f"Not a known resolver — likely cache poisoning attempt."
                        ),
                        raw_summary  = pkt.summary(),
                        mitre_tactic = "T1557.003 — DNS Spoofing",
                        recommendation = (
                            "Enable DNSSEC on all zones. "
                            "Configure DNS over HTTPS/TLS. "
                            "Use only authorised resolver IPs."
                        ),
                    ))
                except Exception:
                    pass

        # ── DNS Tunneling: very long query names or high query frequency ──────
        if dns.qr == 0 and dns.qd:
            try:
                qname = qname_str.rstrip(".")
                labels = [l for l in qname.split(".") if l]
                avg_label_len = sum(len(l) for l in labels) / max(len(labels), 1)

                tunneling = False
                reason    = ""

                if len(qname) > 100:
                    tunneling = True
                    reason    = f"Suspiciously long DNS query ({len(qname)} chars)"
                elif avg_label_len > 20:
                    tunneling = True
                    reason    = f"DNS labels unusually long (avg {avg_label_len:.0f} chars — encoded data?)"
                else:
                    # High-frequency queries to same domain (>50/min)
                    domain = ".".join(labels[-2:]) if len(labels) >= 2 else qname
                    self._dns_queries[ip.src][domain] = [
                        t for t in self._dns_queries[ip.src][domain] if now - t < self.WINDOW
                    ]
                    self._dns_queries[ip.src][domain].append(now)
                    freq = len(self._dns_queries[ip.src][domain])
                    if freq > 50:
                        tunneling = True
                        reason    = f"High DNS query rate to '{domain}': {freq} queries/min"

                if tunneling and self._should_alert(f"dns_tunnel_{ip.src}_{qname[:30]}"):
                    self._emit(NetworkAlert(
                        alert_id     = self._next_id(),
                        timestamp    = self._ts(),
                        category     = AttackCategory.DNS_TUNNELING,
                        severity     = Severity.HIGH,
                        src_ip       = ip.src, dst_ip=ip.dst,
                        src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                        dst_mac      = "",
                        protocol     = "DNS",
                        src_port     = sport, dst_port=dport or 53,
                        description  = (
                            f"DNS Tunneling detected from {ip.src}: {reason}. "
                            f"Query: {qname[:80]}"
                        ),
                        raw_summary  = pkt.summary(),
                        mitre_tactic = "T1071.004 — DNS Application Layer Protocol",
                        recommendation = (
                            "Deploy DNS firewall / RPZ. "
                            "Limit DNS query rate per client. "
                            "Inspect long subdomains at DNS proxy layer."
                        ),
                    ))
            except Exception:
                pass

    def _detect_http_phishing(self, pkt, ip) -> None:
        """Detect phishing via suspicious HTTP Host headers or URLs."""
        if not pkt.haslayer(Raw):
            return
        try:
            payload = bytes(pkt[Raw]).decode("utf-8", errors="ignore").lower()
            if not payload.startswith(("get ", "post ", "put ", "head ")):
                return

            matched_keywords = [kw for kw in PHISHING_KEYWORDS if kw in payload]
            if matched_keywords and self._should_alert(f"phish_{ip.src}"):
                host_line = ""
                for line in payload.split("\r\n"):
                    if line.lower().startswith("host:"):
                        host_line = line
                        break
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.PHISHING,
                    severity     = Severity.HIGH,
                    src_ip       = ip.src, dst_ip=ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "HTTP",
                    src_port     = pkt[TCP].sport,
                    dst_port     = pkt[TCP].dport,
                    description  = (
                        f"HTTP Phishing traffic from {ip.src}: "
                        f"suspicious keyword(s) {matched_keywords} in HTTP request. "
                        f"{host_line}"
                    ),
                    raw_summary  = pkt.summary(),
                    mitre_tactic = "T1566 — Phishing",
                    recommendation = (
                        "Block domain at DNS/proxy layer. "
                        "Enable browser phishing protection. "
                        "Alert users of active phishing campaign."
                    ),
                ))
        except Exception:
            pass

    def _detect_ssl_stripping(self, pkt, ip) -> None:
        """
        SSL Stripping: HTTP requests to sites that should be HTTPS,
        or HTTP 301/302 redirect downgrades.
        """
        if not pkt.haslayer(Raw):
            return
        try:
            payload = bytes(pkt[Raw]).decode("utf-8", errors="ignore")
            # Look for HTTPS→HTTP redirect or Upgrade-Insecure-Requests manipulation
            if ("location: http://" in payload.lower() and
                    "https" in payload.lower() and
                    self._should_alert(f"ssl_strip_{ip.src}")):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.SSL_STRIPPING,
                    severity     = Severity.HIGH,
                    src_ip       = ip.src, dst_ip=ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "HTTP",
                    src_port     = pkt[TCP].sport, dst_port=80,
                    description  = (
                        f"SSL Stripping detected from {ip.src}: "
                        f"HTTP response downgrades HTTPS to HTTP — "
                        f"credentials may be intercepted in plaintext."
                    ),
                    raw_summary  = pkt.summary(),
                    mitre_tactic = "T1557.001 — LLMNR/NBT-NS Poisoning and SMB Relay",
                    recommendation = (
                        "Enforce HSTS on all HTTPS services. "
                        "Use HSTS Preloading. "
                        "Deploy HTTPS everywhere / force TLS at load balancer."
                    ),
                ))
        except Exception:
            pass

    def _detect_c2_beaconing(self, pkt, ip) -> None:
        """
        C2 Beaconing: regular periodic outbound connections to
        the same dst:port suggest malware phone-home.
        """
        if not pkt.haslayer(TCP):
            return
        tcp = pkt[TCP]
        if not (tcp.flags & 0x02):  # SYN only
            return
        if ip.dst in ("8.8.8.8", "8.8.4.4", "1.1.1.1"):  # ignore common servers
            return

        now = time.time()
        key = (ip.src, ip.dst, tcp.dport)
        self._beacon_table[key] = [t for t in self._beacon_table[key] if now - t < 600]  # 10min window
        self._beacon_table[key].append(now)
        times = self._beacon_table[key]

        # Need ≥5 samples to compute regularity
        if len(times) < 5:
            return

        # Compute intervals between successive connections
        intervals = [times[i+1] - times[i] for i in range(len(times)-1)]
        mean_iv   = sum(intervals) / len(intervals)
        variance  = sum((x - mean_iv)**2 for x in intervals) / len(intervals)
        std_dev   = math.sqrt(variance)
        cv        = std_dev / mean_iv if mean_iv > 0 else 999  # coefficient of variation

        # Suspicious: regular (CV < 0.25) and high-risk dst port
        if cv < 0.25 and tcp.dport in HIGH_RISK_PORTS and self._should_alert(f"beacon_{key}"):
            self._emit(NetworkAlert(
                alert_id     = self._next_id(),
                timestamp    = self._ts(),
                category     = AttackCategory.C2_BEACON,
                severity     = Severity.CRITICAL,
                src_ip       = ip.src, dst_ip=ip.dst,
                src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                dst_mac      = "",
                protocol     = "TCP",
                src_port     = tcp.sport, dst_port=tcp.dport,
                description  = (
                    f"C2 Beaconing from {ip.src} → {ip.dst}:{tcp.dport}! "
                    f"{len(times)} connections, interval={mean_iv:.1f}s "
                    f"(CV={cv:.3f} — highly regular). "
                    f"Possible malware phone-home / RAT callback."
                ),
                raw_summary  = pkt.summary(),
                packet_count = len(times),
                mitre_tactic = "T1071 — Application Layer Protocol C2",
                recommendation = (
                    "Block destination IP/port at egress firewall. "
                    "Isolate the source host. "
                    "Run full malware scan immediately."
                ),
            ))

    def _detect_dhcp(self, pkt) -> None:
        """Detect DHCP Starvation and Rogue DHCP servers."""
        if not pkt.haslayer(UDP):
            return
        udp = pkt[UDP]
        if udp.dport not in (67, 68):
            return

        try:
            from scapy.layers.dhcp import DHCP, BOOTP
            if not pkt.haslayer(DHCP):
                return

            dhcp_options = dict(pkt[DHCP].options) if pkt.haslayer(DHCP) else {}
            msg_type = dhcp_options.get("message-type", 0)
            mac = pkt[Ether].src if pkt.haslayer(Ether) else "?"
            ip  = pkt[IP] if pkt.haslayer(IP) else None

            # DHCP Starvation: many DISCOVER requests from different MACs
            if msg_type == 1:  # DHCPDISCOVER
                self._dhcp_macs.add(mac)
                if len(self._dhcp_macs) > 50 and self._should_alert("dhcp_starv"):
                    self._emit(NetworkAlert(
                        alert_id     = self._next_id(),
                        timestamp    = self._ts(),
                        category     = AttackCategory.DHCP_STARVATION,
                        severity     = Severity.HIGH,
                        src_ip       = ip.src if ip else "?", dst_ip="255.255.255.255",
                        src_mac      = mac, dst_mac="ff:ff:ff:ff:ff:ff",
                        protocol     = "DHCP",
                        src_port     = 68, dst_port=67,
                        description  = (
                            f"DHCP Starvation: {len(self._dhcp_macs)} unique MACs "
                            f"sending DISCOVER requests — address pool exhaustion attack."
                        ),
                        raw_summary  = pkt.summary(),
                        mitre_tactic = "T1498 — Network DoS",
                        recommendation = (
                            "Enable DHCP snooping on switches. "
                            "Rate-limit DHCP requests per port. "
                            "Use port security to limit MACs per switch port."
                        ),
                    ))

            # Rogue DHCP: OFFER from unexpected server
            if msg_type == 2:  # DHCPOFFER
                server_ip = ip.src if ip else "?"
                if server_ip not in self._dhcp_servers:
                    self._dhcp_servers.add(server_ip)
                    if len(self._dhcp_servers) > 1 and self._should_alert(f"rogue_dhcp_{server_ip}"):
                        self._emit(NetworkAlert(
                            alert_id     = self._next_id(),
                            timestamp    = self._ts(),
                            category     = AttackCategory.ROGUE_DHCP,
                            severity     = Severity.CRITICAL,
                            src_ip       = server_ip, dst_ip="255.255.255.255",
                            src_mac      = mac, dst_mac="",
                            protocol     = "DHCP",
                            src_port     = 67, dst_port=68,
                            description  = (
                                f"Rogue DHCP Server detected at {server_ip}! "
                                f"Multiple DHCP servers on network — attacker may "
                                f"redirect client traffic through rogue gateway."
                            ),
                            raw_summary  = pkt.summary(),
                            mitre_tactic = "T1557 — Adversary-in-the-Middle",
                            recommendation = (
                                "Enable DHCP snooping — whitelist only authorised server ports. "
                                "Investigate host at the offending MAC/IP immediately."
                            ),
                        ))
        except ImportError:
            pass


    # ═════════════════════════════════════════════════════════════════════════
    #  NEW DETECTORS — Layer 2
    # ═════════════════════════════════════════════════════════════════════════

    def _detect_mac_flooding(self, pkt) -> None:
        """
        MAC Flooding / CAM Table Overflow.
        Detects excessive unique source MACs on the network within WINDOW.
        Threshold: >200 unique MACs → likely CAM table exhaustion attack.
        MITRE: T1557.002
        """
        src_mac = pkt[Ether].src.lower() if pkt.haslayer(Ether) else None
        if not src_mac or src_mac in ("ff:ff:ff:ff:ff:ff", "00:00:00:00:00:00"):
            return

        now = time.time()
        with self._lock:
            # Expire entries older than WINDOW
            self._mac_seen = {
                m: ts for m, ts in self._mac_seen.items()
                if now - ts < self.WINDOW
            }
            self._mac_seen.setdefault(src_mac, now)
            unique_count = len(self._mac_seen)

        if unique_count > 200 and self._should_alert("mac_flood"):
            src_ip = pkt[IP].src if pkt.haslayer(IP) else "?"
            self._emit(NetworkAlert(
                alert_id     = self._next_id(),
                timestamp    = self._ts(),
                category     = AttackCategory.MAC_FLOOD,
                severity     = Severity.HIGH,
                src_ip       = src_ip,
                dst_ip       = "broadcast",
                src_mac      = src_mac,
                dst_mac      = "ff:ff:ff:ff:ff:ff",
                protocol     = "Ethernet",
                src_port     = 0,
                dst_port     = 0,
                description  = (
                    f"MAC Flooding detected: {unique_count} unique source MAC "
                    f"addresses observed in {self.WINDOW}s. CAM table overflow "
                    f"may force switch into hub mode, exposing all traffic."
                ),
                raw_summary  = pkt.summary(),
                packet_count = unique_count,
                mitre_tactic = "T1557.002 — ARP Cache Poisoning / MAC Flood",
                recommendation = (
                    "Enable port security on managed switches — limit MACs per port. "
                    "Configure storm control. "
                    "Enable 802.1X to authenticate devices before admission."
                ),
            ))

    def _detect_stp_attack(self, pkt) -> None:
        """
        STP Manipulation / Rogue Root Bridge.
        Unexpected BPDU packets arriving at high rate from non-switch hosts
        indicate an attacker attempting to become the STP root bridge and
        intercept all LAN traffic.
        MITRE: T1557 — Adversary-in-the-Middle
        """
        try:
            src_mac = pkt[Ether].src.lower() if pkt.haslayer(Ether) else "?"
            now = time.time()
            key = src_mac

            self._stp_table[key] = [
                t for t in self._stp_table[key] if now - t < self.WINDOW
            ]
            self._stp_table[key].append(now)
            count = len(self._stp_table[key])

            # >5 BPDUs from same host in WINDOW is suspicious (legit switches
            # send 1 BPDU every 2 seconds = ~30 per WINDOW; unknown endpoints
            # sending BPDUs at all is suspicious)
            if count >= 5 and self._should_alert(f"stp_{key}"):
                src_ip = pkt[IP].src if pkt.haslayer(IP) else "N/A"
                stp    = pkt[STP]
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.STP_ATTACK,
                    severity     = Severity.HIGH,
                    src_ip       = src_ip,
                    dst_ip       = "01:80:c2:00:00:00",
                    src_mac      = src_mac,
                    dst_mac      = "01:80:c2:00:00:00",
                    protocol     = "STP",
                    src_port     = 0,
                    dst_port     = 0,
                    description  = (
                        f"STP Manipulation from MAC {src_mac}: "
                        f"{count} BPDU packets in {self.WINDOW}s. "
                        f"Root bridge priority in packet: {getattr(stp, 'rootid', '?')}. "
                        f"Attacker may be attempting to become STP root bridge "
                        f"to intercept all switched LAN traffic."
                    ),
                    raw_summary  = pkt.summary(),
                    packet_count = count,
                    mitre_tactic = "T1557 — Adversary-in-the-Middle via STP Manipulation",
                    recommendation = (
                        "Enable BPDU Guard on all non-trunk switch ports. "
                        "Enable Root Guard on designated root ports. "
                        "Use PortFast only on edge (end-host) ports."
                    ),
                ))
        except Exception:
            pass

    def _detect_arp_storm(self, pkt) -> None:
        """
        ARP Storm / Broadcast ARP Flood.
        Excessive ARP requests from the same source exhaust switch resources
        and generate broadcast storms.
        Threshold: >200 ARP packets from same src_mac per WINDOW.
        MITRE: T1498.001 — Direct Network Flood
        """
        arp = pkt[ARP]
        if arp.op != 1:   # only who-has (request) floods
            return

        src_mac = arp.hwsrc.lower()
        if not src_mac or src_mac in ("ff:ff:ff:ff:ff:ff", "00:00:00:00:00:00"):
            return

        now = time.time()
        key = src_mac
        self._arp_storm_table[key] = [
            t for t in self._arp_storm_table[key] if now - t < self.WINDOW
        ]
        self._arp_storm_table[key].append(now)
        count = len(self._arp_storm_table[key])

        if count > 200 and self._should_alert(f"arp_storm_{key}"):
            self._emit(NetworkAlert(
                alert_id     = self._next_id(),
                timestamp    = self._ts(),
                category     = AttackCategory.ARP_STORM,
                severity     = Severity.HIGH,
                src_ip       = arp.psrc,
                dst_ip       = "255.255.255.255",
                src_mac      = src_mac,
                dst_mac      = "ff:ff:ff:ff:ff:ff",
                protocol     = "ARP",
                src_port     = 0,
                dst_port     = 0,
                description  = (
                    f"ARP Storm from {src_mac} ({arp.psrc}): "
                    f"{count} ARP broadcast requests in {self.WINDOW}s. "
                    f"Excessive broadcast traffic degrading LAN performance."
                ),
                raw_summary  = pkt.summary(),
                packet_count = count,
                mitre_tactic = "T1498.001 — Direct Network Flood",
                recommendation = (
                    "Enable storm control / broadcast suppression on switch ports. "
                    "Investigate source host for misconfiguration or malware. "
                    "Implement rate-limiting for ARP broadcasts per port."
                ),
            ))

    # ═════════════════════════════════════════════════════════════════════════
    #  NEW DETECTORS — Layer 3
    # ═════════════════════════════════════════════════════════════════════════

    def _detect_land_attack(self, pkt, ip) -> None:
        """
        LAND Attack.
        Packet where src_ip == dst_ip AND src_port == dst_port causes the
        target to send replies to itself, consuming CPU and crashing some stacks.
        MITRE: T1498 — Network Denial of Service
        """
        try:
            if not pkt.haslayer(TCP):
                return
            tcp = pkt[TCP]
            if ip.src == ip.dst and tcp.sport == tcp.dport:
                if self._should_alert(f"land_{ip.src}"):
                    self._emit(NetworkAlert(
                        alert_id     = self._next_id(),
                        timestamp    = self._ts(),
                        category     = AttackCategory.LAND_ATTACK,
                        severity     = Severity.CRITICAL,
                        src_ip       = ip.src,
                        dst_ip       = ip.dst,
                        src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                        dst_mac      = pkt[Ether].dst if pkt.haslayer(Ether) else "",
                        protocol     = "TCP",
                        src_port     = tcp.sport,
                        dst_port     = tcp.dport,
                        description  = (
                            f"LAND Attack detected! Packet has identical "
                            f"source and destination: {ip.src}:{tcp.sport}. "
                            f"Target forced to reply to itself — DoS / stack crash."
                        ),
                        raw_summary  = pkt.summary(),
                        mitre_tactic = "T1498 — Network Denial of Service",
                        recommendation = (
                            "Apply ingress filtering — drop packets where src == dst. "
                            "Ensure OS TCP/IP stack is patched against LAND attacks. "
                            "Enable anti-spoofing at firewall/router."
                        ),
                    ))
        except Exception:
            pass

    def _detect_fragment_attack(self, pkt, ip) -> None:
        """
        IP Fragmentation Attack (Teardrop / Overlapping Fragment).
        Detects:
        - Suspicious fragment offsets (offset=0 with MF, tiny payload)
        - >20 fragments from same src within WINDOW
        - Overlapping fragment offsets (Teardrop signature)
        MITRE: T1498 — Network Denial of Service
        """
        try:
            # Only interested in fragmented packets (MF flag set OR non-zero offset)
            frag_offset = ip.frag
            flags_mf    = bool(ip.flags & 0x1)   # More Fragments bit

            if not (flags_mf or frag_offset > 0):
                return

            now = time.time()
            src = ip.src
            pkt_id = ip.id

            # Record (pkt_id, frag_offset, timestamp)
            with self._lock:
                self._frag_table[src] = [
                    entry for entry in self._frag_table[src]
                    if now - entry[2] < self.WINDOW
                ]
                self._frag_table[src].append((pkt_id, frag_offset, now))
                entries = list(self._frag_table[src])

            count = len(entries)

            # Check 1: Too many fragments from same source
            if count > 20 and self._should_alert(f"frag_count_{src}"):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.FRAGMENT_ATTACK,
                    severity     = Severity.HIGH,
                    src_ip       = src,
                    dst_ip       = ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "IP",
                    src_port     = 0,
                    dst_port     = 0,
                    description  = (
                        f"IP Fragmentation Flood from {src}: "
                        f"{count} fragments in {self.WINDOW}s. "
                        f"May exhaust reassembly buffers (Fragment DoS)."
                    ),
                    raw_summary  = pkt.summary(),
                    packet_count = count,
                    mitre_tactic = "T1498 — Network Denial of Service",
                    recommendation = (
                        "Enable fragment reassembly limits on firewall. "
                        "Drop overlapping and tiny fragments at perimeter. "
                        "Apply OS patches for IP fragmentation vulnerabilities."
                    ),
                ))
                return

            # Check 2: Overlapping offsets for same IP ID (Teardrop signature)
            same_id = [(eid, off, ts) for eid, off, ts in entries if eid == pkt_id]
            if len(same_id) >= 2:
                offsets = sorted(set(off for _, off, _ in same_id))
                # Overlapping: a later fragment starts before the previous one ends
                # (offset measured in 8-byte units)
                pkt_len = len(pkt)
                for i in range(1, len(offsets)):
                    prev_off  = offsets[i - 1]
                    cur_off   = offsets[i]
                    # If current offset < previous offset + (fragment_size / 8)
                    # then fragments overlap — Teardrop indicator
                    if cur_off < prev_off + (pkt_len // 8):
                        if self._should_alert(f"frag_overlap_{src}_{pkt_id}"):
                            self._emit(NetworkAlert(
                                alert_id     = self._next_id(),
                                timestamp    = self._ts(),
                                category     = AttackCategory.FRAGMENT_ATTACK,
                                severity     = Severity.HIGH,
                                src_ip       = src,
                                dst_ip       = ip.dst,
                                src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                                dst_mac      = "",
                                protocol     = "IP",
                                src_port     = 0,
                                dst_port     = 0,
                                description  = (
                                    f"Teardrop / Overlapping Fragment Attack from {src}: "
                                    f"IP ID {pkt_id} has overlapping fragment offsets "
                                    f"({prev_off} and {cur_off}). "
                                    f"Targets vulnerable reassembly code — crash/DoS."
                                ),
                                raw_summary  = pkt.summary(),
                                mitre_tactic = "T1498 — Network Denial of Service",
                                recommendation = (
                                    "Drop overlapping fragments at firewall/IPS. "
                                    "Apply OS patches (Teardrop affects older Windows/Linux). "
                                    "Consider blocking IP fragmentation on DMZ interfaces."
                                ),
                            ))
                        break
        except Exception:
            pass

    def _detect_icmp_redirect(self, pkt, ip) -> None:
        """
        ICMP Redirect Abuse.
        ICMP type 5 from a host that is not a known/trusted gateway
        can redirect victim traffic through an attacker-controlled router.
        MITRE: T1557 — Adversary-in-the-Middle
        """
        try:
            icmp = pkt[ICMP]
            if icmp.type != 5:   # type 5 = Redirect
                return

            # Auto-learn known gateways from DHCP servers we have seen
            known_gws = self._known_gateways | self._dhcp_servers

            if ip.src not in known_gws and self._should_alert(f"icmp_redir_{ip.src}"):
                gw_code = {0: "Redirect for Network", 1: "Redirect for Host",
                           2: "Redirect for TOS+Network", 3: "Redirect for TOS+Host"}
                redirect_type = gw_code.get(icmp.code, f"Code {icmp.code}")
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.ICMP_REDIRECT,
                    severity     = Severity.HIGH,
                    src_ip       = ip.src,
                    dst_ip       = ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "ICMP",
                    src_port     = 0,
                    dst_port     = 0,
                    description  = (
                        f"ICMP Redirect from non-gateway {ip.src} ({redirect_type}). "
                        f"Attempting to reroute traffic through attacker-controlled hop. "
                        f"Victim: {ip.dst}."
                    ),
                    raw_summary  = pkt.summary(),
                    mitre_tactic = "T1557 — Adversary-in-the-Middle via ICMP Redirect",
                    recommendation = (
                        "Disable ICMP redirect acceptance on all hosts "
                        "(net.ipv4.conf.all.accept_redirects=0 on Linux). "
                        "Block ICMP type 5 from untrusted sources at perimeter firewall."
                    ),
                ))
        except Exception:
            pass

    # ═════════════════════════════════════════════════════════════════════════
    #  NEW DETECTORS — Layer 4
    # ═════════════════════════════════════════════════════════════════════════

    def _detect_tcp_rst_injection(self, pkt, ip) -> None:
        """
        TCP RST Injection.
        High rate of RST packets from the same source terminates legitimate
        TCP connections — used in censorship, session disruption, DoS.
        Threshold: >100 RST packets per WINDOW.
        MITRE: T1499.002 — Service Exhaustion Flood
        """
        try:
            tcp = pkt[TCP]
            if not (tcp.flags & 0x04):   # RST flag
                return

            now = time.time()
            key = ip.src
            self._rst_table[key] = [
                t for t in self._rst_table[key] if now - t < self.WINDOW
            ]
            self._rst_table[key].append(now)
            count = len(self._rst_table[key])

            if count > 100 and self._should_alert(f"rst_inject_{key}"):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.TCP_RST_ATTACK,
                    severity     = Severity.HIGH,
                    src_ip       = ip.src,
                    dst_ip       = ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "TCP",
                    src_port     = tcp.sport,
                    dst_port     = tcp.dport,
                    description  = (
                        f"TCP RST Injection from {ip.src}: "
                        f"{count} RST packets in {self.WINDOW}s. "
                        f"Active TCP sessions are being forcibly terminated — "
                        f"possible session disruption or censorship attack."
                    ),
                    raw_summary  = pkt.summary(),
                    packet_count = count,
                    mitre_tactic = "T1499.002 — Service Exhaustion / TCP RST Injection",
                    recommendation = (
                        "Enable TCP sequence number validation at firewall. "
                        "Use encrypted transport (TLS) to make RST injection harder. "
                        "Investigate source host — may be rogue middlebox or malware."
                    ),
                ))
        except Exception:
            pass

    # Known CDN / cloud service IP prefixes — these send high ACK rates
    # legitimately (Telegram, WhatsApp, Google, Cloudflare, etc.).
    # ACK flood from these sources is almost always a false positive.
    ACK_FLOOD_WHITELIST_PREFIXES = (
        "91.108.",    # Telegram servers
        "149.154.",   # Telegram servers
        "74.125.",    # Google
        "172.217.",   # Google
        "142.250.",   # Google
        "104.16.",    # Cloudflare
        "104.17.",    # Cloudflare
        "104.18.",    # Cloudflare
        "104.19.",    # Cloudflare
        "104.20.",    # Cloudflare
        "104.21.",    # Cloudflare
        "157.240.",   # Meta (WhatsApp/Facebook)
        "31.13.",     # Meta
        "52.",        # AWS
        "54.",        # AWS
        "13.",        # AWS
        "20.",        # Azure
        "40.",        # Azure
        "52.114.",    # Microsoft Teams
        "13.107.",    # Microsoft 365
    )

    def _detect_ack_flood(self, pkt, ip) -> None:
        """
        ACK Flood.
        High rate of ACK-only packets (no SYN/FIN/RST/PSH/URG) from same src.
        Exhausts server CPU processing unexpected ACKs for non-existent sessions.
        Threshold: >200 ACK-only packets per WINDOW.
        MITRE: T1498.001 — Direct Network Flood
        """
        try:
            tcp = pkt[TCP]
            flags = int(tcp.flags)
            # ACK-only: ACK set, SYN/FIN/RST/PSH/URG all clear
            if flags != 0x10:
                return

            # FIX: Skip known CDN/cloud IPs — they generate high ACK rates
            # legitimately. Telegram (91.108.x.x, 149.154.x.x), Google,
            # Cloudflare, Meta, AWS, Azure all trigger false positives here.
            src = ip.src
            if any(src.startswith(pfx) for pfx in self.ACK_FLOOD_WHITELIST_PREFIXES):
                return

            now = time.time()
            key = (ip.src, ip.dst)
            self._ack_table[key] = [
                t for t in self._ack_table[key] if now - t < self.WINDOW
            ]
            self._ack_table[key].append(now)
            count = len(self._ack_table[key])

            # Threshold: 500 ACK-only packets per 60s window.
            # Cooldown: 30 min between popups for the same src→dst pair.
            if count > 500 and self._should_alert(f"ack_flood_{key}", cooldown=1800.0):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.ACK_FLOOD,
                    severity     = Severity.HIGH,
                    src_ip       = ip.src,
                    dst_ip       = ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "TCP",
                    src_port     = tcp.sport,
                    dst_port     = tcp.dport,
                    description  = (
                        f"ACK Flood from {ip.src} → {ip.dst}: "
                        f"{count} ACK-only packets in {self.WINDOW}s. "
                        f"Server processing spurious ACKs — CPU exhaustion DoS."
                    ),
                    raw_summary  = pkt.summary(),
                    packet_count = count,
                    mitre_tactic = "T1498.001 — Direct Network Flood",
                    recommendation = (
                        "Apply stateful firewall rules — drop ACKs for unknown sessions. "
                        "Enable SYN cookies to prevent state exhaustion. "
                        "Deploy upstream DDoS scrubbing service."
                    ),
                ))
        except Exception:
            pass

    def _detect_slowloris(self, pkt, ip) -> None:
        """
        Slowloris HTTP DoS.
        Tracks TCP connections to HTTP ports that send partial request headers
        without completing them, holding server threads open indefinitely.
        Threshold: >50 incomplete connections per WINDOW.
        MITRE: T1499.002 — Service Exhaustion Flood
        """
        try:
            tcp = pkt[TCP]
            if tcp.dport not in (80, 8080, 8000, 443):
                return

            now = time.time()
            conn_key = (ip.dst, tcp.dport)   # keyed on server endpoint

            # A SYN packet = new connection attempt
            if tcp.flags & 0x02 and not (tcp.flags & 0x10):
                self._slowloris_table[conn_key][ip.src] = now
                return

            # If connection has data (PSH set) → mark as completed
            if tcp.flags & 0x08 and pkt.haslayer(Raw):
                payload = bytes(pkt[Raw]).decode("utf-8", errors="ignore")
                if "\r\n\r\n" in payload:   # complete HTTP header block
                    self._slowloris_table[conn_key].pop(ip.src, None)
                    return

            # Expire stale incomplete connections (older than WINDOW)
            self._slowloris_table[conn_key] = {
                src: ts for src, ts in self._slowloris_table[conn_key].items()
                if now - ts < self.WINDOW
            }

            incomplete = len(self._slowloris_table[conn_key])
            if incomplete > 50 and self._should_alert(f"slowloris_{conn_key}"):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.SLOWLORIS,
                    severity     = Severity.HIGH,
                    src_ip       = ip.src,
                    dst_ip       = ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "HTTP",
                    src_port     = tcp.sport,
                    dst_port     = tcp.dport,
                    description  = (
                        f"Slowloris attack on {ip.dst}:{tcp.dport}: "
                        f"{incomplete} incomplete HTTP connections held open "
                        f"within {self.WINDOW}s — server thread pool exhaustion."
                    ),
                    raw_summary  = pkt.summary(),
                    packet_count = incomplete,
                    mitre_tactic = "T1499.002 — Service Exhaustion Flood / Slowloris",
                    recommendation = (
                        "Set server timeout for incomplete request headers (e.g. 10s). "
                        "Limit simultaneous connections per IP. "
                        "Deploy reverse proxy (Nginx) in front of Apache — "
                        "Nginx is not vulnerable to Slowloris."
                    ),
                ))
        except Exception:
            pass

    # ═════════════════════════════════════════════════════════════════════════
    #  NEW DETECTORS — Layer 7
    # ═════════════════════════════════════════════════════════════════════════

    def _detect_http_injection(self, pkt, ip) -> None:
        """
        SQL Injection and Cross-Site Scripting (XSS) in HTTP payloads.
        Inspects raw HTTP request payloads for common injection patterns.
        MITRE: T1190 — Exploit Public-Facing Application
        """
        if not pkt.haslayer(Raw):
            return
        try:
            tcp = pkt[TCP]
            raw = bytes(pkt[Raw]).decode("utf-8", errors="ignore")

            if not raw.lstrip().upper().startswith(("GET ", "POST ", "PUT ", "PATCH ")):
                return

            payload_lower = raw.lower()

            # ── SQL Injection patterns ────────────────────────────────────────
            SQL_PATTERNS = [
                "' or 1=1",   "' or '1'='1",   "or 1=1--",
                "union select", "union all select",
                "sleep(",      "benchmark(",
                "information_schema",
                "drop table",  "insert into",    "update set",
                "xp_cmdshell", "exec(",          "execute(",
                "char(",       "concat(",        "load_file(",
            ]
            sql_matches = [p for p in SQL_PATTERNS if p in payload_lower]
            if sql_matches and self._should_alert(f"sqli_{ip.src}"):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.SQL_INJECTION,
                    severity     = Severity.HIGH,
                    src_ip       = ip.src,
                    dst_ip       = ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "HTTP",
                    src_port     = tcp.sport,
                    dst_port     = tcp.dport,
                    description  = (
                        f"SQL Injection attempt from {ip.src}: "
                        f"patterns detected in HTTP payload: {sql_matches[:5]}. "
                        f"Attacker may be attempting database extraction or command execution."
                    ),
                    raw_summary  = pkt.summary(),
                    mitre_tactic = "T1190 — Exploit Public-Facing Application / SQLi",
                    recommendation = (
                        "Use parameterised queries / prepared statements exclusively. "
                        "Deploy WAF with SQLi ruleset (ModSecurity / AWS WAF). "
                        "Enable database activity monitoring. "
                        "Rotate database credentials immediately if exfiltration suspected."
                    ),
                ))

            # ── XSS patterns ─────────────────────────────────────────────────
            XSS_PATTERNS = [
                "<script",      "javascript:",   "onerror=",
                "onload=",      "onclick=",      "alert(",
                "document.cookie", "document.write", "eval(",
                "fromcharcode", "expression(",   "vbscript:",
                "data:text/html",
            ]
            xss_matches = [p for p in XSS_PATTERNS if p in payload_lower]
            if xss_matches and self._should_alert(f"xss_{ip.src}"):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.XSS_ATTACK,
                    severity     = Severity.MEDIUM,
                    src_ip       = ip.src,
                    dst_ip       = ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "HTTP",
                    src_port     = tcp.sport,
                    dst_port     = tcp.dport,
                    description  = (
                        f"Cross-Site Scripting (XSS) attempt from {ip.src}: "
                        f"patterns in HTTP payload: {xss_matches[:5]}. "
                        f"Attacker may inject scripts to steal session cookies or credentials."
                    ),
                    raw_summary  = pkt.summary(),
                    mitre_tactic = "T1059.007 — JavaScript / XSS",
                    recommendation = (
                        "Implement strict Content Security Policy (CSP) headers. "
                        "Enable HttpOnly and Secure flags on all session cookies. "
                        "Use output encoding / HTML escaping on all user-supplied data. "
                        "Deploy WAF with XSS ruleset."
                    ),
                ))
        except Exception:
            pass

    def _detect_directory_enumeration(self, pkt, ip) -> None:
        """
        LDAP / Kerberos Directory Enumeration.
        High-volume traffic on LDAP (389, 636, 3268, 3269) or Kerberos (88)
        from a single source indicates automated AD/LDAP reconnaissance.
        Threshold: >100 packets per WINDOW.
        MITRE: T1087.002 — Account Discovery: Domain Account
        """
        try:
            tcp = pkt[TCP]
            port = tcp.dport
            if port not in (389, 636, 88, 3268, 3269):
                return

            now = time.time()
            key = (ip.src, port)
            self._dir_enum_table[key] = [
                t for t in self._dir_enum_table[key] if now - t < self.WINDOW
            ]
            self._dir_enum_table[key].append(now)
            count = len(self._dir_enum_table[key])

            service_map = {
                389: "LDAP", 636: "LDAPS", 88: "Kerberos",
                3268: "Global Catalog LDAP", 3269: "Global Catalog LDAPS",
            }
            service = service_map.get(port, str(port))

            if count > 100 and self._should_alert(f"dir_enum_{key}"):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.DIRECTORY_ENUMERATION,
                    severity     = Severity.MEDIUM,
                    src_ip       = ip.src,
                    dst_ip       = ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = service,
                    src_port     = tcp.sport,
                    dst_port     = port,
                    description  = (
                        f"{service} Enumeration from {ip.src}: "
                        f"{count} requests to {ip.dst}:{port} in {self.WINDOW}s. "
                        f"Automated AD/LDAP user and group enumeration in progress."
                    ),
                    raw_summary  = pkt.summary(),
                    packet_count = count,
                    mitre_tactic = "T1087.002 — Account Discovery: Domain Account",
                    recommendation = (
                        "Enable LDAP signing and channel binding (KB4520412). "
                        "Restrict anonymous LDAP bind. "
                        "Monitor and alert on high-volume LDAP/Kerberos queries. "
                        "Review AD tiering — limit LDAP access from workstation tier."
                    ),
                ))
        except Exception:
            pass

    # ═════════════════════════════════════════════════════════════════════════
    #  NEW DETECTORS — IPv6
    # ═════════════════════════════════════════════════════════════════════════

    def _detect_ipv6_ra_spoof(self, pkt) -> None:
        """
        IPv6 Router Advertisement Spoofing.
        ICMPv6 type 134 (Router Advertisement) from a non-router MAC
        can redirect all IPv6 traffic through an attacker-controlled gateway.
        MITRE: T1557 — Adversary-in-the-Middle via IPv6 RA Spoofing
        """
        try:
            from scapy.layers.inet6 import IPv6, ICMPv6ND_RA
            if not (pkt.haslayer(IPv6) and pkt.haslayer(ICMPv6ND_RA)):
                return

            ipv6 = pkt[IPv6]
            src_mac = pkt[Ether].src.lower() if pkt.haslayer(Ether) else "?"

            # Legitimate RA packets come from link-local addresses (fe80::/10)
            # and should have a router MAC known to the network.
            # Flag any RA from a non-link-local source OR unusual MAC patterns.
            is_link_local = str(ipv6.src).lower().startswith("fe80:")

            # Known OUI prefixes for common router vendors (Cisco, Juniper, etc.)
            ROUTER_OUI_PREFIXES = {
                "00:00:0c", "00:1b:0d", "f4:6d:04", "00:18:74",  # Cisco
                "2c:6b:f5", "00:05:85",                           # Juniper
                "00:26:18", "b4:fb:e4",                           # Arista
                "dc:9f:db", "00:24:b2",                           # Ubiquiti
            }
            oui = ":".join(src_mac.split(":")[:3])
            is_known_router_oui = oui in ROUTER_OUI_PREFIXES

            # FIX: Only fire when the source is genuinely non-link-local (truly
            # suspicious) OR when it IS link-local but from a completely unrecognised
            # vendor OUI AND we haven't seen this MAC before.
            # Using OR here was wrong — fe80::1 is always link-local so
            # is_link_local=True, but nearly every home router has a MAC that
            # isn't in our small ROUTER_OUI_PREFIXES list, causing an alert on
            # every RA from the legitimate gateway every 60 s.
            # Also raise the cooldown to 10 min — one alert per gateway per session.
            # FIX: Persist accepted router MACs to a file so app restarts
            # don't re-alert for the home router every single time.
            # Also fix the logic: first-time link-local = alert ONCE, then
            # add to seen set so it is never alerted again (even after restart).
            _ra_cache_file = os.path.join("data", "ra_seen_macs.txt")
            if not hasattr(self, '_seen_ra_macs'):
                self._seen_ra_macs = set()
                try:
                    if os.path.exists(_ra_cache_file):
                        with open(_ra_cache_file) as _rf:
                            for _line in _rf:
                                _m = _line.strip()
                                if _m: self._seen_ra_macs.add(_m)
                except Exception: pass

            if is_link_local:
                if src_mac in self._seen_ra_macs:
                    _truly_suspicious = False   # known router — never alert again
                elif is_known_router_oui:
                    # Recognised vendor — silently accept, never alert
                    self._seen_ra_macs.add(src_mac)
                    try:
                        with open(_ra_cache_file, "a") as _rf: _rf.write(src_mac + "\n")
                    except Exception: pass
                    _truly_suspicious = False
                else:
                    # Unknown vendor, first time — alert once, then accept
                    _truly_suspicious = True
                    self._seen_ra_macs.add(src_mac)
                    try:
                        with open(_ra_cache_file, "a") as _rf: _rf.write(src_mac + "\n")
                    except Exception: pass
            else:
                _truly_suspicious = True   # non-link-local RA is always suspicious
            if _truly_suspicious and self._should_alert(f"ipv6_ra_{src_mac}", cooldown=3600.0):
                    self._emit(NetworkAlert(
                        alert_id     = self._next_id(),
                        timestamp    = self._ts(),
                        category     = AttackCategory.IPV6_RA_SPOOF,
                        severity     = Severity.HIGH,
                        src_ip       = str(ipv6.src),
                        dst_ip       = str(ipv6.dst),
                        src_mac      = src_mac,
                        dst_mac      = pkt[Ether].dst if pkt.haslayer(Ether) else "",
                        protocol     = "ICMPv6",
                        src_port     = 0,
                        dst_port     = 0,
                        description  = (
                            f"IPv6 Router Advertisement from unexpected host {src_mac} "
                            f"(src: {ipv6.src}). "
                            f"{'Non-link-local source. ' if not is_link_local else ''}"
                            f"Attacker may be hijacking IPv6 default gateway — "
                            f"all IPv6 traffic at risk of interception."
                        ),
                        raw_summary  = pkt.summary(),
                        mitre_tactic = "T1557 — Adversary-in-the-Middle via IPv6 RA Spoofing",
                        recommendation = (
                            "Enable RA Guard on all access switch ports (RFC 6105). "
                            "Use IPv6 First-Hop Security (FHS) on managed switches. "
                            "Deploy DHCPv6 Guard. "
                            "Disable IPv6 on segments where it is not required."
                        ),
                    ))
        except Exception:
            pass

    def _detect_llmnr_poison(self, pkt, ip) -> None:
        """
        Detect LLMNR / NBT-NS poisoning (Responder-style attacks).
        Only flags LLMNR *response* packets (QR bit = 1) — NOT normal queries.
        Normal Windows LLMNR queries (dport 5355 to 224.0.0.252) are benign.
        """
        udp = pkt[UDP]
        if not pkt.haslayer(Raw):
            return
        try:
            raw_data = bytes(pkt[Raw])
            # LLMNR header: byte 2-3 are flags; QR bit is bit15 of flags word
            # If QR=0 it's a query (normal) — only flag QR=1 (response/poisoning)
            if len(raw_data) < 4:
                return
            flags = (raw_data[2] << 8) | raw_data[3]
            is_response = bool(flags & 0x8000)

            # Also skip if destination is the legitimate LLMNR multicast addr
            # (genuine Responder attacks target unicast, not the multicast group)
            if ip.dst == "224.0.0.252" and not is_response:
                return   # Normal LLMNR query broadcast — benign

            if udp.dport == 5355 and is_response and self._should_alert(f"llmnr_{ip.src}"):
                self._emit(NetworkAlert(
                    alert_id     = self._next_id(),
                    timestamp    = self._ts(),
                    category     = AttackCategory.LLMNR_POISON,
                    severity     = Severity.HIGH,
                    src_ip       = ip.src, dst_ip=ip.dst,
                    src_mac      = pkt[Ether].src if pkt.haslayer(Ether) else "",
                    dst_mac      = "",
                    protocol     = "LLMNR",
                    src_port     = udp.sport, dst_port=5355,
                    description  = (
                        f"LLMNR Poisoning detected from {ip.src}: "
                        f"Unsolicited LLMNR response — tool like Responder "
                        f"may be stealing NTLM hashes."
                    ),
                    raw_summary  = pkt.summary(),
                    mitre_tactic = "T1557.001 — LLMNR/NBT-NS Poisoning",
                    recommendation = (
                        "Disable LLMNR and NBT-NS via Group Policy. "
                        "Enable SMB signing to prevent relay attacks. "
                        "Investigate host at {ip.src} immediately."
                    ),
                ))
        except Exception:
            pass

    def _detect_smb_exploit(self, pkt, ip) -> None:
        """Already handled inside _detect_tcp_attacks."""
        pass

    # ── Threat Intel helper ───────────────────────────────────────────────────

    def _ti_lookup_domain(self, domain: str):
        """Proxy to the NetworkMonitor's TI instance (set after construction)."""
        ti = getattr(self, "_ti_ref", None)
        if ti is None:
            return None
        try:
            return ti.lookup_domain(domain)
        except Exception:
            return None

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _next_id(self) -> str:
        with self._lock:
            self._alert_seq += 1
            return f"NET-{datetime.now().strftime('%Y%m%d%H%M%S')}-{self._alert_seq:05d}"

    def _ts(self) -> str:
        return datetime.now().isoformat(timespec="seconds")

    def _is_local_packet(self, pkt) -> bool:
        try:
            return pkt[Ether].src == pkt[Ether].dst if pkt.haslayer(Ether) else False
        except Exception:
            return False

    def _should_alert(self, key: str, cooldown: float = 60.0) -> bool:
        """Rate-limit repeated alerts for the same event."""
        now = time.time()
        last = self._suppress.get(key, 0)
        if now - last >= cooldown:
            self._suppress[key] = now
            return True
        return False

    def _emit(self, alert: NetworkAlert) -> None:
        logger.warning("[NetworkAlert] %s | %s | %s → %s",
                       alert.severity, alert.category, alert.src_ip, alert.dst_ip)
        try:
            self._cb(alert)
        except Exception as e:
            logger.error("[NetworkEngine] Callback error: %s", e)


# ─────────────────────────────────────────────────────────────────────────────
#  NetworkMonitor — public API
# ─────────────────────────────────────────────────────────────────────────────

class NetworkMonitor:
    """
    High-level API.  Used by SentinelHub and the GUI.

    Usage:
        monitor = NetworkMonitor(alert_callback=my_fn)
        monitor.start(interface="Ethernet")
        ...
        monitor.stop()
        alerts = monitor.get_alerts()
    """

    def __init__(self, alert_callback: Optional[Callable[[NetworkAlert], None]] = None):
        self._alert_cb    = alert_callback or (lambda a: None)
        self._alerts:     List[NetworkAlert] = []
        self._lock        = threading.Lock()
        self._running     = False
        self._thread:     Optional[threading.Thread] = None
        self._detector    = AttackDetector(self._on_alert)
        self._packet_count = 0
        self._start_time: Optional[float] = None

        # Threat intelligence integration
        self._ti = None
        try:
            from .threat_intel import ThreatIntel
            self._ti = ThreatIntel(auto_update=True)
            logger.info("[NetworkMonitor] ThreatIntel feeds active")
        except Exception as _te:
            logger.debug("[NetworkMonitor] ThreatIntel not available: %s", _te)

        # Share TI reference with the AttackDetector so domain checks work in DNS handler
        self._detector._ti_ref = self._ti

        # Cache of IPs already checked this session to avoid duplicate alerts
        self._ti_checked_ips: set = set()

    # ── Start / Stop ──────────────────────────────────────────────────────────

    def start(self, interface: Optional[str] = None, packet_limit: int = 0) -> bool:
        """Start packet capture in background thread. Returns True if started."""
        if not SCAPY_AVAILABLE:
            logger.error("[NetworkMonitor] Cannot start — Scapy not installed.")
            return False
        if self._running:
            return True

        self._running    = True
        self._start_time = time.time()
        self._thread     = threading.Thread(
            target=self._capture_loop,
            args=(interface, packet_limit),
            daemon=True,
            name="SentinelNetworkCapture",
        )
        self._thread.start()
        logger.info("[NetworkMonitor] Capture started on interface: %s", interface or "default")
        return True

    def stop(self) -> None:
        """Stop packet capture."""
        self._running = False
        logger.info("[NetworkMonitor] Capture stopped.")

    # ── Public API ────────────────────────────────────────────────────────────

    def get_alerts(self, limit: int = 200) -> List[NetworkAlert]:
        with self._lock:
            return list(self._alerts[-limit:])

    def get_alerts_by_severity(self, severity: str) -> List[NetworkAlert]:
        with self._lock:
            return [a for a in self._alerts if a.severity == severity]

    def get_stats(self) -> dict:
        with self._lock:
            by_cat  = collections.Counter(a.category for a in self._alerts)
            by_sev  = collections.Counter(a.severity for a in self._alerts)
            elapsed = time.time() - self._start_time if self._start_time else 0
            return {
                "packets_captured": self._packet_count,
                "total_alerts":     len(self._alerts),
                "elapsed_seconds":  int(elapsed),
                "alerts_by_severity": dict(by_sev),
                "alerts_by_category": dict(by_cat),
                "is_running":       self._running,
            }

    def clear_alerts(self) -> None:
        with self._lock:
            self._alerts.clear()

    @staticmethod
    def list_interfaces() -> List[str]:
        """Return available network interfaces."""
        if not SCAPY_AVAILABLE:
            return []
        try:
            return get_if_list()
        except Exception:
            return []

    # ── Internal ──────────────────────────────────────────────────────────────

    def _capture_loop(self, interface: Optional[str], packet_limit: int) -> None:
        """Main packet capture loop."""
        try:
            sniff(
                iface     = interface,
                prn       = self._process_packet,
                store     = False,
                stop_filter = lambda p: not self._running,
                count     = packet_limit or 0,
            )
        except PermissionError:
            logger.error(
                "[NetworkMonitor] Permission denied — run as Administrator/root for packet capture."
            )
        except Exception as e:
            logger.error("[NetworkMonitor] Capture error: %s", e)

    def _process_packet(self, pkt) -> None:
        self._packet_count += 1
        self._detector.process_packet(pkt)

        # ── Threat Intelligence: check src/dst IPs against live feed ──────────
        if self._ti is None or not SCAPY_AVAILABLE:
            return
        try:
            if not pkt.haslayer("IP"):
                return
            ip_layer = pkt["IP"]
            for ip_addr in (ip_layer.src, ip_layer.dst):
                if ip_addr in self._ti_checked_ips:
                    continue
                # Skip private / loopback / multicast
                if (ip_addr.startswith(("10.", "192.168.", "127.", "169.254.", "224.", "255."))
                        or ip_addr.startswith("172.") and 16 <= int(ip_addr.split(".")[1]) <= 31):
                    continue
                self._ti_checked_ips.add(ip_addr)

                match = self._ti.lookup_ip(ip_addr)
                if match:
                    alert = NetworkAlert(
                        alert_id     = f"TI-IP-{ip_addr.replace('.', '-')}-{int(time.time())}",
                        timestamp    = datetime.now().isoformat(timespec="seconds"),
                        category     = "Threat Intel: Known Malicious IP",
                        severity     = match.severity.upper(),
                        src_ip       = ip_layer.src,
                        dst_ip       = ip_layer.dst,
                        src_mac      = "",
                        dst_mac      = "",
                        protocol     = "IP",
                        src_port     = 0,
                        dst_port     = 0,
                        description  = (
                            f"IP {ip_addr} matched threat intelligence feed ({match.source}). "
                            f"Threat: {match.threat_name} [{match.threat_type}]. "
                            f"First seen: {match.first_seen}. "
                            f"Tags: {', '.join(match.tags) if match.tags else 'none'}."
                        ),
                        raw_summary  = f"TI hit: {ip_addr} → {match.threat_name}",
                        mitre_tactic = "T1071 — Application Layer Protocol C2",
                        recommendation = (
                            f"Block {ip_addr} at the perimeter firewall immediately. "
                            f"This IP is associated with {match.threat_name} "
                            f"({match.threat_type}) according to {match.source}."
                        ),
                    )
                    self._on_alert(alert)
        except Exception as _e:
            logger.debug("[NetworkMonitor] TI packet check error: %s", _e)

    def _on_alert(self, alert: NetworkAlert) -> None:
        with self._lock:
            self._alerts.append(alert)
            if len(self._alerts) > 10000:  # cap memory
                self._alerts = self._alerts[-5000:]
        try:
            self._alert_cb(alert)
        except Exception as e:
            logger.error("[NetworkMonitor] Alert callback error: %s", e)