"""
Sentinel Defender - Memory Inspector Module
Scans running process memory for injected code, shellcode patterns, and anomalies.
Detects fileless malware that resides only in RAM.
"""

import logging
import psutil
import ctypes
import struct
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime

logger = logging.getLogger(__name__)

# ==================== WINDOWS API (via ctypes) ====================

try:
    kernel32 = ctypes.windll.kernel32
    PROCESS_VM_READ = 0x0010
    PROCESS_QUERY_INFORMATION = 0x0400
    MEM_COMMIT = 0x1000
    PAGE_EXECUTE = 0x10
    PAGE_EXECUTE_READ = 0x20
    PAGE_EXECUTE_READWRITE = 0x40
    PAGE_EXECUTE_WRITECOPY = 0x80
    WINDOWS_API_AVAILABLE = True
except Exception:
    WINDOWS_API_AVAILABLE = False
    logger.warning("Windows API not available - memory inspection limited")


# ==================== DATA STRUCTURES ====================

@dataclass
class MemoryAnomaly:
    """Represents a suspicious pattern found in process memory."""
    process_name: str
    process_id: int
    anomaly_type: str      # 'shellcode', 'injected_dll', 'suspicious_string', 'rwx_region'
    severity: str          # 'critical', 'high', 'medium', 'low'
    description: str
    memory_address: int
    memory_size: int
    evidence: str          # hex dump or pattern match
    confidence: float      # 0.0 to 1.0
    timestamp: datetime
    mitre_technique: str   # e.g., "T1055 - Process Injection"

    def to_dict(self) -> Dict:
        return {
            'process_name': self.process_name,
            'process_id': self.process_id,
            'anomaly_type': self.anomaly_type,
            'severity': self.severity,
            'description': self.description,
            'memory_address': hex(self.memory_address),
            'memory_size': self.memory_size,
            'evidence': self.evidence[:200],  # Truncate
            'confidence': self.confidence,
            'timestamp': self.timestamp.isoformat(),
            'mitre_technique': self.mitre_technique
        }


# ==================== SHELLCODE SIGNATURES ====================

class ShellcodeDetector:
    """Detect common shellcode patterns in memory."""
    
    # Common x86/x64 shellcode opcodes
    SHELLCODE_PATTERNS = {
        # Metasploit common stubs
        b'\xfc\xe8\x82\x00\x00\x00': 'Metasploit reverse_tcp shellcode',
        b'\xfc\x48\x83\xe4\xf0': 'Metasploit windows/x64 shellcode',
        b'\x31\xc9\x64\x8b\x71\x30': 'Win32 PEB access (find kernel32.dll)',
        b'\x64\xa1\x30\x00\x00\x00': 'PEB access x86',
        b'\x65\x48\x8b\x04\x25\x60\x00': 'PEB access x64',
        
        # Common NOP sleds
        b'\x90' * 20: 'NOP sled (potential exploit)',
        
        # GetProcAddress / LoadLibrary patterns
        b'GetProcAddress': 'Dynamic API resolution',
        b'LoadLibraryA': 'DLL loading in memory',
        b'VirtualAlloc': 'Memory allocation (shellcode prep)',
        b'CreateRemoteThread': 'Thread injection API',
        
        # Suspicious strings
        b'cmd.exe': 'Command execution',
        b'powershell': 'PowerShell execution',
        b'mshta.exe': 'MSHTA execution (LOLBin)',
    }
    
    @staticmethod
    def scan_for_shellcode(memory_data: bytes) -> List[Tuple[int, str, float]]:
        """
        Scan memory block for shellcode patterns.
        Returns: [(offset, pattern_name, confidence), ...]
        """
        findings = []
        
        for pattern, name in ShellcodeDetector.SHELLCODE_PATTERNS.items():
            offset = 0
            while True:
                offset = memory_data.find(pattern, offset)
                if offset == -1:
                    break
                
                # Calculate confidence based on pattern specificity
                confidence = 0.7 if len(pattern) > 10 else 0.5
                if b'Metasploit' in name.encode():
                    confidence = 0.95
                
                findings.append((offset, name, confidence))
                offset += len(pattern)
        
        return findings


# ==================== MEMORY INSPECTOR ====================

class MemoryInspector:
    """
    Scan running process memory for threats.
    Focuses on executable regions (RWX) and known malicious patterns.
    """
    
    def __init__(self):
        self.shellcode_detector = ShellcodeDetector()
        self.scanned_processes = set()
        self.anomalies_found = []
    
    # ── Public API ────────────────────────────────────────────────────
    
    def scan_all_processes(self, include_system: bool = False) -> List[MemoryAnomaly]:
        """
        Scan memory of all accessible processes.
        Returns list of anomalies found.
        """
        self.anomalies_found.clear()
        
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                # Skip system/kernel processes unless explicitly requested
                if not include_system and proc.info['name'] in ['System', 'Registry', 'svchost.exe']:
                    continue
                
                anomalies = self.scan_process(proc.info['pid'], proc.info['name'])
                self.anomalies_found.extend(anomalies)
                
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        return self.anomalies_found
    
    def scan_process(self, pid: int, process_name: str = None) -> List[MemoryAnomaly]:
        """
        Scan a single process memory.
        Returns anomalies found in this process.
        """
        if not WINDOWS_API_AVAILABLE:
            return self._scan_process_psutil_fallback(pid, process_name)
        
        anomalies = []
        
        try:
            # Open process handle
            h_process = kernel32.OpenProcess(
                PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, False, pid
            )
            if not h_process:
                return []
            
            # Enumerate memory regions
            regions = self._enumerate_memory_regions(h_process, pid)
            
            for region in regions:
                # Focus on executable regions (RWX, RX)
                if region['protection'] & (PAGE_EXECUTE | PAGE_EXECUTE_READ | 
                                          PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY):
                    
                    # Read memory
                    memory_data = self._read_memory(h_process, region['address'], region['size'])
                    if not memory_data:
                        continue
                    
                    # Scan for threats
                    findings = self.shellcode_detector.scan_for_shellcode(memory_data)
                    
                    for offset, pattern_name, confidence in findings:
                        anomaly = MemoryAnomaly(
                            process_name=process_name or f"PID_{pid}",
                            process_id=pid,
                            anomaly_type='shellcode' if 'shellcode' in pattern_name.lower() else 'suspicious_string',
                            severity='critical' if confidence > 0.8 else 'high',
                            description=f"Detected: {pattern_name}",
                            memory_address=region['address'] + offset,
                            memory_size=len(memory_data),
                            evidence=memory_data[offset:offset+64].hex(),
                            confidence=confidence,
                            timestamp=datetime.now(),
                            mitre_technique=self._map_to_mitre(pattern_name)
                        )
                        anomalies.append(anomaly)
                    
                    # Check for RWX (Read-Write-Execute) regions — suspicious!
                    if region['protection'] & PAGE_EXECUTE_READWRITE:
                        anomaly = MemoryAnomaly(
                            process_name=process_name or f"PID_{pid}",
                            process_id=pid,
                            anomaly_type='rwx_region',
                            severity='high',
                            description=f"RWX memory region at {hex(region['address'])} — possible code injection",
                            memory_address=region['address'],
                            memory_size=region['size'],
                            evidence=f"Protection: RWX | Size: {region['size']} bytes",
                            confidence=0.75,
                            timestamp=datetime.now(),
                            mitre_technique='T1055 - Process Injection'
                        )
                        anomalies.append(anomaly)
            
            kernel32.CloseHandle(h_process)
            
        except Exception as e:
            logger.error(f"Memory scan error for PID {pid}: {e}")
        
        return anomalies
    
    # ── Memory Reading (Windows API) ──────────────────────────────────
    
    def _enumerate_memory_regions(self, h_process, pid: int) -> List[Dict]:
        """Enumerate all committed memory regions in a process."""
        regions = []
        address = 0
        
        class MEMORY_BASIC_INFORMATION(ctypes.Structure):
            _fields_ = [
                ("BaseAddress", ctypes.c_void_p),
                ("AllocationBase", ctypes.c_void_p),
                ("AllocationProtect", ctypes.c_ulong),
                ("RegionSize", ctypes.c_size_t),
                ("State", ctypes.c_ulong),
                ("Protect", ctypes.c_ulong),
                ("Type", ctypes.c_ulong),
            ]
        
        mbi = MEMORY_BASIC_INFORMATION()
        
        while address < 0x7FFFFFFF0000:  # Max user-mode address
            result = kernel32.VirtualQueryEx(
                h_process, ctypes.c_void_p(address), ctypes.byref(mbi), ctypes.sizeof(mbi)
            )
            
            if not result:
                break
            
            if mbi.State == MEM_COMMIT:
                regions.append({
                    'address': mbi.BaseAddress,
                    'size': mbi.RegionSize,
                    'protection': mbi.Protect
                })
            
            address = mbi.BaseAddress + mbi.RegionSize
            
            # Safety limit: max 1000 regions
            if len(regions) > 1000:
                break
        
        return regions
    
    def _read_memory(self, h_process, address: int, size: int) -> Optional[bytes]:
        """Read memory from process. Returns None on failure."""
        # Limit read size to 1 MB per region
        size = min(size, 1024 * 1024)
        
        buffer = ctypes.create_string_buffer(size)
        bytes_read = ctypes.c_size_t()
        
        result = kernel32.ReadProcessMemory(
            h_process, ctypes.c_void_p(address), buffer, size, ctypes.byref(bytes_read)
        )
        
        if result:
            return buffer.raw[:bytes_read.value]
        return None
    
    # ── Fallback for non-Windows ──────────────────────────────────────
    
    def _scan_process_psutil_fallback(self, pid: int, process_name: str) -> List[MemoryAnomaly]:
        """
        Limited scan using psutil (cross-platform).
        Only checks for suspicious process names / command lines.
        """
        anomalies = []
        try:
            proc = psutil.Process(pid)
            cmdline = ' '.join(proc.cmdline())
            
            # Check for suspicious patterns in command line
            suspicious_patterns = [
                ('powershell -e', 'Base64-encoded PowerShell command'),
                ('cmd /c echo', 'Suspicious command execution'),
                ('mshta http', 'MSHTA remote execution'),
                ('regsvr32 /s /u /i:http', 'Regsvr32 remote execution'),
            ]
            
            for pattern, desc in suspicious_patterns:
                if pattern in cmdline.lower():
                    anomaly = MemoryAnomaly(
                        process_name=process_name or proc.name(),
                        process_id=pid,
                        anomaly_type='suspicious_cmdline',
                        severity='high',
                        description=desc,
                        memory_address=0,
                        memory_size=0,
                        evidence=cmdline[:200],
                        confidence=0.8,
                        timestamp=datetime.now(),
                        mitre_technique='T1059 - Command and Scripting Interpreter'
                    )
                    anomalies.append(anomaly)
        
        except Exception:
            pass
        
        return anomalies
    
    # ── MITRE ATT&CK Mapping ──────────────────────────────────────────
    
    @staticmethod
    def _map_to_mitre(pattern_name: str) -> str:
        """Map detected pattern to MITRE ATT&CK technique."""
        mitre_map = {
            'shellcode': 'T1055 - Process Injection',
            'PEB access': 'T1055 - Process Injection',
            'GetProcAddress': 'T1106 - Native API',
            'CreateRemoteThread': 'T1055.001 - Dynamic-link Library Injection',
            'VirtualAlloc': 'T1055 - Process Injection',
            'cmd.exe': 'T1059.003 - Windows Command Shell',
            'powershell': 'T1059.001 - PowerShell',
            'mshta': 'T1218.005 - Mshta',
        }
        
        for key, technique in mitre_map.items():
            if key.lower() in pattern_name.lower():
                return technique
        
        return 'Unknown Technique'
    
    # ── Summary ───────────────────────────────────────────────────────
    
    def get_summary(self) -> Dict:
        """Return summary statistics of last scan."""
        if not self.anomalies_found:
            return {'total': 0, 'by_severity': {}, 'by_type': {}}
        
        by_severity = {}
        by_type = {}
        
        for anomaly in self.anomalies_found:
            by_severity[anomaly.severity] = by_severity.get(anomaly.severity, 0) + 1
            by_type[anomaly.anomaly_type] = by_type.get(anomaly.anomaly_type, 0) + 1
        
        return {
            'total': len(self.anomalies_found),
            'by_severity': by_severity,
            'by_type': by_type,
            'processes_scanned': len(self.scanned_processes)
        }
