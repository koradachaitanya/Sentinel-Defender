"""
Sentinel Defender - Process Behavior Engine
Real-time process monitoring and behavioral anomaly detection.
"""

import logging
from typing import List, Dict, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

# Optional import with graceful fallback
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    logging.warning("psutil not available. Install with: pip install psutil")

from .config import (
    is_whitelisted_process,
    get_suspicious_relationship,
    HEURISTIC_WEIGHTS
)

# Configure logging
logger = logging.getLogger(__name__)


# ==================== DATA CLASSES ====================

@dataclass
class ProcessInfo:
    """Detailed information about a running process."""
    pid: int
    name: str
    exe_path: str
    cmdline: List[str]
    parent_pid: int
    parent_name: str
    username: str
    cpu_percent: float
    memory_percent: float
    create_time: datetime
    connections: List[Dict] = field(default_factory=list)
    open_files: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization."""
        return {
            'pid': self.pid,
            'name': self.name,
            'exe_path': self.exe_path,
            'cmdline': self.cmdline,
            'parent_pid': self.parent_pid,
            'parent_name': self.parent_name,
            'username': self.username,
            'cpu_percent': self.cpu_percent,
            'memory_percent': self.memory_percent,
            'create_time': self.create_time.isoformat(),
            'connections': self.connections,
            'open_files': self.open_files
        }


@dataclass
class ProcessAlert:
    """Represents a behavioral anomaly detected in a process."""
    alert_id: str
    process_name: str
    process_id: int
    parent_process: str
    alert_type: str
    severity: str  # 'critical', 'high', 'medium', 'low'
    confidence: float
    description: str
    threat_score: int = 0
    details: Dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    recommended_action: str = "monitor"
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization."""
        return {
            'alert_id': self.alert_id,
            'process_name': self.process_name,
            'process_id': self.process_id,
            'parent_process': self.parent_process,
            'alert_type': self.alert_type,
            'severity': self.severity,
            'confidence': self.confidence,
            'description': self.description,
            'threat_score': self.threat_score,
            'details': self.details,
            'timestamp': self.timestamp.isoformat(),
            'recommended_action': self.recommended_action
        }


# ==================== PROCESS BEHAVIOR ENGINE ====================

class ProcessBehaviorEngine:
    """
    Monitors running processes and detects suspicious behavioral patterns.
    """
    
    def __init__(self):
        """Initialize process behavior engine."""
        if not PSUTIL_AVAILABLE:
            logger.error("psutil is required for process monitoring")
            raise ImportError("psutil module is required. Install with: pip install psutil")
        
        self.monitored_processes: Dict[int, ProcessInfo] = {}
        self.alert_history: List[ProcessAlert] = []
        self.suspicious_behaviors: Set[str] = set()
    
    def get_process_info(self, pid: int) -> Optional[ProcessInfo]:
        """
        Gather detailed information about a process.
        
        Args:
            pid: Process ID
        
        Returns:
            ProcessInfo object or None if process not found
        """
        try:
            proc = psutil.Process(pid)
            
            # Get parent process information
            try:
                parent = proc.parent()
                parent_pid = parent.pid if parent else 0
                parent_name = parent.name() if parent else "Unknown"
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                parent_pid = 0
                parent_name = "Unknown"
            
            # Get process details with error handling
            try:
                exe_path = proc.exe()
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                exe_path = "Access Denied"
            
            try:
                cmdline = proc.cmdline()
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                cmdline = []
            
            try:
                username = proc.username()
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                username = "Unknown"
            
            # Get network connections
            connections = []
            try:
                for conn in proc.connections(kind='inet'):
                    connections.append({
                        'local_addr': f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else None,
                        'remote_addr': f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else None,
                        'status': conn.status
                    })
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                pass
            
            # Get open files
            open_files = []
            try:
                for file in proc.open_files():
                    open_files.append(file.path)
            except (psutil.AccessDenied, psutil.NoSuchProcess):
                pass
            
            process_info = ProcessInfo(
                pid=pid,
                name=proc.name(),
                exe_path=exe_path,
                cmdline=cmdline,
                parent_pid=parent_pid,
                parent_name=parent_name,
                username=username,
                cpu_percent=proc.cpu_percent(interval=0.1),
                memory_percent=proc.memory_percent(),
                create_time=datetime.fromtimestamp(proc.create_time()),
                connections=connections[:10],  # Limit to first 10 connections
                open_files=open_files[:10]  # Limit to first 10 files
            )
            
            return process_info
            
        except psutil.NoSuchProcess:
            logger.debug(f"Process {pid} no longer exists")
            return None
        except Exception as e:
            logger.error(f"Error getting process info for PID {pid}: {e}")
            return None
    
    def analyze_parent_child_relationship(self, child_info: ProcessInfo) -> Optional[ProcessAlert]:
        """
        Analyze parent-child process relationships for anomalies.
        
        Args:
            child_info: Information about the child process
        
        Returns:
            ProcessAlert if suspicious relationship detected, None otherwise
        """
        # Skip if whitelisted
        if is_whitelisted_process(child_info.name, child_info.exe_path):
            return None
        
        # Check for suspicious parent-child combinations
        relationship = get_suspicious_relationship(
            child_info.parent_name,
            child_info.name
        )
        
        if relationship:
            alert_id = f"PC-{child_info.pid}-{datetime.now().timestamp()}"
            
            severity = relationship.get('severity', 'medium')
            reason = relationship.get('reason', 'Suspicious process relationship')
            
            # Calculate threat score
            threat_score = HEURISTIC_WEIGHTS.get('parent_child_anomaly', 50)
            if severity == 'high':
                threat_score += 30
            elif severity == 'critical':
                threat_score += 50
            
            confidence = 0.9 if severity == 'high' else 0.7
            
            logger.warning(
                f"Suspicious parent-child relationship detected: "
                f"{child_info.parent_name} -> {child_info.name} (PID: {child_info.pid})"
            )
            
            return ProcessAlert(
                alert_id=alert_id,
                process_name=child_info.name,
                process_id=child_info.pid,
                parent_process=child_info.parent_name,
                alert_type='parent_child_anomaly',
                severity=severity,
                confidence=confidence,
                description=f"{child_info.parent_name} spawned {child_info.name}: {reason}",
                threat_score=threat_score,
                details={
                    'parent_pid': child_info.parent_pid,
                    'child_cmdline': ' '.join(child_info.cmdline),
                    'relationship_reason': reason
                },
                recommended_action='quarantine' if severity == 'high' else 'alert'
            )
        
        return None
    
    def detect_suspicious_cmdline(self, process_info: ProcessInfo) -> Optional[ProcessAlert]:
        """
        Detect suspicious command-line patterns.
        
        Args:
            process_info: Process information
        
        Returns:
            ProcessAlert if suspicious command detected, None otherwise
        """
        cmdline = ' '.join(process_info.cmdline).lower()
        
        # Suspicious PowerShell patterns
        powershell_patterns = [
            ('downloadstring', 'Web download in PowerShell'),
            ('invoke-expression', 'Code execution via Invoke-Expression'),
            ('bypass', 'Execution policy bypass'),
            ('-encodedcommand', 'Encoded PowerShell command'),
            ('hidden', 'Hidden window execution'),
            ('webclient', 'Web client usage'),
        ]
        
        # Suspicious command patterns
        command_patterns = [
            ('reg add', 'Registry modification'),
            ('schtasks', 'Scheduled task creation'),
            ('netsh', 'Network configuration change'),
            ('bcdedit', 'Boot configuration modification'),
            ('vssadmin delete', 'Shadow copy deletion (ransomware indicator)'),
            ('wmic', 'WMI command execution'),
        ]
        
        for pattern, description in powershell_patterns:
            if pattern in cmdline and 'powershell' in process_info.name.lower():
                alert_id = f"CMD-PS-{process_info.pid}-{datetime.now().timestamp()}"
                
                logger.warning(f"Suspicious PowerShell command detected: PID {process_info.pid}")
                
                return ProcessAlert(
                    alert_id=alert_id,
                    process_name=process_info.name,
                    process_id=process_info.pid,
                    parent_process=process_info.parent_name,
                    alert_type='suspicious_cmdline',
                    severity='high',
                    confidence=0.85,
                    description=f"Suspicious PowerShell pattern: {description}",
                    threat_score=70,
                    details={
                        'pattern_matched': pattern,
                        'full_cmdline': ' '.join(process_info.cmdline)
                    },
                    recommended_action='alert'
                )
        
        for pattern, description in command_patterns:
            if pattern in cmdline:
                alert_id = f"CMD-{process_info.pid}-{datetime.now().timestamp()}"
                
                logger.warning(f"Suspicious command detected: PID {process_info.pid}")
                
                return ProcessAlert(
                    alert_id=alert_id,
                    process_name=process_info.name,
                    process_id=process_info.pid,
                    parent_process=process_info.parent_name,
                    alert_type='suspicious_cmdline',
                    severity='medium',
                    confidence=0.7,
                    description=f"Suspicious command pattern: {description}",
                    threat_score=55,
                    details={
                        'pattern_matched': pattern,
                        'full_cmdline': ' '.join(process_info.cmdline)
                    },
                    recommended_action='monitor'
                )
        
        return None
    
    def detect_unusual_network_activity(self, process_info: ProcessInfo) -> Optional[ProcessAlert]:
        """
        Detect processes with unusual network connections.
        
        Args:
            process_info: Process information
        
        Returns:
            ProcessAlert if unusual activity detected, None otherwise
        """
        # Processes that normally shouldn't have network connections
        non_network_processes = [
            'notepad.exe', 'calc.exe', 'mspaint.exe', 'wordpad.exe'
        ]
        
        if process_info.name.lower() in non_network_processes and process_info.connections:
            alert_id = f"NET-{process_info.pid}-{datetime.now().timestamp()}"
            
            logger.warning(
                f"Unusual network activity detected: {process_info.name} (PID: {process_info.pid})"
            )
            
            return ProcessAlert(
                alert_id=alert_id,
                process_name=process_info.name,
                process_id=process_info.pid,
                parent_process=process_info.parent_name,
                alert_type='unusual_network_activity',
                severity='medium',
                confidence=0.75,
                description=f"{process_info.name} has unexpected network connections",
                threat_score=60,
                details={
                    'connection_count': len(process_info.connections),
                    'connections': process_info.connections[:5]
                },
                recommended_action='alert'
            )
        
        return None
    
    def detect_resource_anomalies(self, process_info: ProcessInfo) -> Optional[ProcessAlert]:
        """
        Detect processes consuming unusual amounts of resources.
        
        Args:
            process_info: Process information
        
        Returns:
            ProcessAlert if anomaly detected, None otherwise
        """
        # Very high CPU usage (potential cryptominer)
        if process_info.cpu_percent > 80:
            alert_id = f"CPU-{process_info.pid}-{datetime.now().timestamp()}"
            
            logger.warning(
                f"High CPU usage detected: {process_info.name} "
                f"(PID: {process_info.pid}, CPU: {process_info.cpu_percent}%)"
            )
            
            return ProcessAlert(
                alert_id=alert_id,
                process_name=process_info.name,
                process_id=process_info.pid,
                parent_process=process_info.parent_name,
                alert_type='high_cpu_usage',
                severity='low',
                confidence=0.5,
                description=f"Process consuming {process_info.cpu_percent:.1f}% CPU (possible cryptominer)",
                threat_score=40,
                details={
                    'cpu_percent': process_info.cpu_percent,
                    'memory_percent': process_info.memory_percent
                },
                recommended_action='monitor'
            )
        
        return None
    
    def scan_process(self, pid: int) -> List[ProcessAlert]:
        """
        Perform comprehensive behavioral analysis on a process.
        
        Args:
            pid: Process ID to scan
        
        Returns:
            List of ProcessAlert objects (empty if no anomalies)
        """
        alerts = []
        
        process_info = self.get_process_info(pid)
        if not process_info:
            return alerts
        
        # Store process info
        self.monitored_processes[pid] = process_info
        
        # Run all detection methods
        detection_methods = [
            self.analyze_parent_child_relationship,
            self.detect_suspicious_cmdline,
            self.detect_unusual_network_activity,
            self.detect_resource_anomalies
        ]
        
        for method in detection_methods:
            try:
                alert = method(process_info)
                if alert:
                    alerts.append(alert)
                    self.alert_history.append(alert)
            except Exception as e:
                logger.error(f"Detection method {method.__name__} failed for PID {pid}: {e}")
        
        return alerts
    
    def scan_all_processes(self) -> List[ProcessAlert]:
        """
        Scan all running processes for behavioral anomalies.
        
        Returns:
            List of all ProcessAlert objects detected
        """
        all_alerts = []
        
        for proc in psutil.process_iter(['pid']):
            try:
                alerts = self.scan_process(proc.info['pid'])
                all_alerts.extend(alerts)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        logger.info(f"Process scan complete. {len(all_alerts)} alerts generated.")
        return all_alerts
    
    def get_running_processes(self) -> List[Dict]:
        """
        Get list of all running processes with basic information.
        
        Returns:
            List of process dictionaries
        """
        processes = []
        
        for proc in psutil.process_iter(['pid', 'name', 'username', 'cpu_percent', 'memory_percent']):
            try:
                processes.append({
                    'pid': proc.info['pid'],
                    'name': proc.info['name'],
                    'username': proc.info['username'],
                    'cpu_percent': proc.info['cpu_percent'],
                    'memory_percent': proc.info['memory_percent']
                })
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        return processes
    
    def kill_process(self, pid: int) -> bool:
        """
        Terminate a process.
        
        Args:
            pid: Process ID to terminate
        
        Returns:
            True if successful, False otherwise
        """
        try:
            proc = psutil.Process(pid)
            proc.terminate()
            
            # Wait for graceful termination
            proc.wait(timeout=5)
            
            logger.warning(f"Process terminated: PID {pid}")
            return True
            
        except psutil.TimeoutExpired:
            # Force kill if graceful termination fails
            try:
                proc.kill()
                logger.warning(f"Process force-killed: PID {pid}")
                return True
            except Exception as e:
                logger.error(f"Failed to kill process {pid}: {e}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to terminate process {pid}: {e}")
            return False


# ==================== CONVENIENCE FUNCTIONS ====================

def get_process_engine() -> ProcessBehaviorEngine:
    """Get singleton process engine instance."""
    if not hasattr(get_process_engine, "_instance"):
        get_process_engine._instance = ProcessBehaviorEngine()
    return get_process_engine._instance
