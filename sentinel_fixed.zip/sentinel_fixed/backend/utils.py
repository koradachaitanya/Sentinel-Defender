"""
Sentinel Defender - Utility Functions
XOR encryption for quarantine and magic bytes detection for file type validation.
"""

import logging
from typing import Optional, Tuple

# Configure logging
logger = logging.getLogger(__name__)

# XOR encryption key for quarantine (4-byte repeating key)
QUARANTINE_XOR_KEY = b'\xDE\xAD\xBE\xEF'

# Magic bytes for file type detection
MAGIC_BYTES_SIGNATURES = {
    # Executables
    b'MZ': ('PE_EXECUTABLE', 'Windows executable (PE)'),
    b'\x7fELF': ('ELF_EXECUTABLE', 'Linux/Unix executable (ELF)'),
    b'\xCA\xFE\xBA\xBE': ('MACH_O', 'macOS executable (Mach-O)'),
    
    # Archives
    b'PK\x03\x04': ('ZIP', 'ZIP archive (or DOCX/JAR)'),
    b'PK\x05\x06': ('ZIP_EMPTY', 'Empty ZIP archive'),
    b'Rar!\x1A\x07': ('RAR', 'RAR archive'),
    b'\x1f\x8b': ('GZIP', 'GZIP compressed'),
    b'BZh': ('BZIP2', 'BZIP2 compressed'),
    b'7z\xbc\xaf\x27\x1c': ('7ZIP', '7-Zip archive'),
    
    # Documents
    b'%PDF': ('PDF', 'PDF document'),
    b'\xd0\xcf\x11\xe0': ('OLE', 'Microsoft Office (old format)'),
    
    # Images
    b'\xff\xd8\xff': ('JPEG', 'JPEG image'),
    b'\x89PNG\r\n\x1a\n': ('PNG', 'PNG image'),
    b'GIF87a': ('GIF', 'GIF image (87a)'),
    b'GIF89a': ('GIF', 'GIF image (89a)'),
    b'BM': ('BMP', 'Bitmap image'),
    
    # Media
    b'\x00\x00\x00\x18ftypmp4': ('MP4', 'MP4 video'),
    b'\x00\x00\x00\x20ftypiso': ('MP4', 'MP4 video (isom)'),
    b'RIFF': ('RIFF', 'RIFF container (AVI/WAV)'),
    
    # Scripts
    b'#!/bin/bash': ('BASH_SCRIPT', 'Bash shell script'),
    b'#!/bin/sh': ('SHELL_SCRIPT', 'Shell script'),
    b'#!/usr/bin/env python': ('PYTHON_SCRIPT', 'Python script'),
}


def xor_encrypt_decrypt(data: bytes, key: bytes = QUARANTINE_XOR_KEY) -> bytes:
    """
    XOR encrypt/decrypt data with a repeating key.
    Since XOR is its own inverse, same function works for both encryption and decryption.
    
    Args:
        data: Bytes to encrypt/decrypt
        key: XOR key (default: QUARANTINE_XOR_KEY)
    
    Returns:
        Encrypted/decrypted bytes
    
    Example:
        encrypted = xor_encrypt_decrypt(b"Hello")
        decrypted = xor_encrypt_decrypt(encrypted)  # Back to b"Hello"
    """
    if not data:
        return b''
    
    if not key:
        raise ValueError("XOR key cannot be empty")
    
    key_len = len(key)
    
    # XOR each byte with corresponding key byte (cycling through key)
    result = bytearray(len(data))
    for i in range(len(data)):
        result[i] = data[i] ^ key[i % key_len]
    
    return bytes(result)


def get_magic_file_type(header_bytes: bytes) -> Tuple[Optional[str], Optional[str]]:
    """
    Detect actual file type from magic bytes (file header).
    This prevents extension-based evasion (e.g., malware.exe renamed to malware.jpg).
    
    Args:
        header_bytes: First 16 bytes of file (enough for most signatures)
    
    Returns:
        Tuple of (file_type, description) or (None, None) if unknown
    
    Example:
        >>> get_magic_file_type(b'MZ\x90\x00\x03\x00')
        ('PE_EXECUTABLE', 'Windows executable (PE)')
        
        >>> get_magic_file_type(b'\xff\xd8\xff\xe0')
        ('JPEG', 'JPEG image')
    """
    if not header_bytes:
        return None, None
    
    # Try to match magic bytes (check longest signatures first)
    sorted_signatures = sorted(
        MAGIC_BYTES_SIGNATURES.items(),
        key=lambda x: len(x[0]),
        reverse=True
    )
    
    for magic, (file_type, description) in sorted_signatures:
        if header_bytes.startswith(magic):
            return file_type, description
    
    # Unknown file type
    return None, None


def detect_extension_mismatch(file_path: str, header_bytes: bytes) -> Tuple[bool, str]:
    """
    Detect if file extension doesn't match actual file type (possible evasion).
    
    Args:
        file_path: Path to file (for extension check)
        header_bytes: First 16 bytes of file
    
    Returns:
        Tuple of (is_mismatch, explanation)
    
    Example:
        >>> detect_extension_mismatch("image.jpg", b'MZ\x90\x00')
        (True, "File claims to be .jpg but is actually PE_EXECUTABLE")
    """
    from pathlib import Path
    
    # Get claimed extension
    claimed_ext = Path(file_path).suffix.lower()
    
    # Get actual file type from magic bytes
    actual_type, description = get_magic_file_type(header_bytes)
    
    if not actual_type:
        return False, "Unknown file type"
    
    # Define expected file types for extensions
    extension_map = {
        '.exe': ['PE_EXECUTABLE'],
        '.dll': ['PE_EXECUTABLE'],
        '.sys': ['PE_EXECUTABLE'],
        '.scr': ['PE_EXECUTABLE'],
        '.com': ['PE_EXECUTABLE'],
        '.jpg': ['JPEG'],
        '.jpeg': ['JPEG'],
        '.png': ['PNG'],
        '.gif': ['GIF'],
        '.pdf': ['PDF'],
        '.zip': ['ZIP', 'ZIP_EMPTY'],
        '.rar': ['RAR'],
        '.7z': ['7ZIP'],
        '.gz': ['GZIP'],
        '.bz2': ['BZIP2'],
        '.mp4': ['MP4'],
        '.avi': ['RIFF'],
        '.wav': ['RIFF'],
    }
    
    expected_types = extension_map.get(claimed_ext, [])
    
    # Check for mismatch
    if expected_types and actual_type not in expected_types:
        explanation = f"File claims to be {claimed_ext} but is actually {actual_type}"
        return True, explanation
    
    return False, "File type matches extension"


def is_file_size_suspicious(file_size: int) -> Tuple[bool, str]:
    """
    Check if file size is suspicious (too small or too large for malware).
    
    Args:
        file_size: File size in bytes
    
    Returns:
        Tuple of (is_suspicious, reason)
    """
    MIN_EXECUTABLE_SIZE = 100  # Bytes (below this can't be valid executable)
    MAX_PRACTICAL_MALWARE = 100_000_000  # 100 MB (above this is impractical)
    
    if file_size < MIN_EXECUTABLE_SIZE:
        return True, f"File too small ({file_size} bytes) to be valid executable"
    
    if file_size > MAX_PRACTICAL_MALWARE:
        return True, f"File too large ({file_size / 1_000_000:.1f} MB) for practical malware"
    
    return False, "File size normal"


def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename for safe storage (remove path traversal attempts).
    
    Args:
        filename: Original filename
    
    Returns:
        Sanitized filename
    
    Example:
        >>> sanitize_filename("../../../etc/passwd")
        "passwd"
        
        >>> sanitize_filename("malware<>.exe")
        "malware.exe"
    """
    import re
    from pathlib import Path
    
    # Get just the filename (remove any path components)
    filename = Path(filename).name
    
    # Remove dangerous characters
    # Keep: alphanumeric, dash, underscore, dot
    filename = re.sub(r'[^\w\-.]', '_', filename)
    
    # Remove leading/trailing dots and spaces
    filename = filename.strip('. ')
    
    # Ensure filename is not empty
    if not filename:
        filename = "unnamed_file"
    
    return filename


def format_size(self, size_bytes):
    # SAFETY CHECK: If size is None (from DB), treat it as 0
    if size_bytes is None:
        size_bytes = 0
        
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} PB"


# ==================== TESTING FUNCTIONS ====================

def test_xor_encryption():
    """Test XOR encryption is reversible."""
    original = b"This is secret malware data"
    encrypted = xor_encrypt_decrypt(original)
    decrypted = xor_encrypt_decrypt(encrypted)
    
    assert decrypted == original, "XOR encryption is not reversible!"
    assert encrypted != original, "XOR encryption did nothing!"
    print("✓ XOR encryption test passed")


def test_magic_bytes():
    """Test magic bytes detection."""
    test_cases = [
        (b'MZ\x90\x00\x03', 'PE_EXECUTABLE'),
        (b'\x7fELF\x01\x01', 'ELF_EXECUTABLE'),
        (b'%PDF-1.4', 'PDF'),
        (b'\xff\xd8\xff\xe0', 'JPEG'),
        (b'PK\x03\x04', 'ZIP'),
        (b'unknown', None),
    ]
    
    for header, expected_type in test_cases:
        detected_type, _ = get_magic_file_type(header)
        assert detected_type == expected_type, f"Failed for {header}: got {detected_type}, expected {expected_type}"
    
    print("✓ Magic bytes detection test passed")


if __name__ == "__main__":
    print("Running utility tests...")
    test_xor_encryption()
    test_magic_bytes()
    print("All tests passed!")
