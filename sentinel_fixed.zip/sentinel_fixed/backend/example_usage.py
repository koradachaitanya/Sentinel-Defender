#!/usr/bin/env python3
"""
Sentinel Defender - Example Usage Script
Demonstrates the SentinelHub orchestrator with all features.

Run with: python example_usage.py
"""

import time
import sys
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from backend.main import SentinelHub, ScanType
from backend.database import DatabaseManager


# ==================== CALLBACK FUNCTIONS ====================

def on_progress(file_path: str, files_scanned: int):
    """Called for each file scanned."""
    print(f"  [{files_scanned}] Scanning: {file_path}")


def on_threat(detection, file_path: str):
    """Called when a threat is detected."""
    print(f"\n🚨 THREAT DETECTED!")
    print(f"  File: {file_path}")
    print(f"  Threat: {detection.threat_name}")
    print(f"  Type: {detection.threat_type}")
    print(f"  Severity: {detection.severity}")
    print(f"  Score: {detection.threat_score}/100")
    print(f"  Method: {detection.detection_method}")
    print(f"  Confidence: {detection.confidence:.2%}")
    print("-" * 60)


def on_alert(alert):
    """Called when a process alert is generated."""
    print(f"\n⚠️  PROCESS ALERT!")
    print(f"  Process: {alert.process_name} (PID: {alert.process_id})")
    print(f"  Parent: {alert.parent_process}")
    print(f"  Type: {alert.alert_type}")
    print(f"  Severity: {alert.severity}")
    print(f"  Description: {alert.description}")
    print(f"  Action: {alert.recommended_action}")
    print("-" * 60)


# ==================== MAIN DEMONSTRATION ====================

def main():
    """Main demonstration of SentinelHub capabilities."""
    
    print("=" * 60)
    print("SENTINEL DEFENDER - Orchestrator Demonstration")
    print("=" * 60)
    print()
    
    # Initialize SentinelHub with callbacks
    print("Initializing SentinelHub...")
    hub = SentinelHub(
        progress_callback=on_progress,
        threat_callback=on_threat,
        alert_callback=on_alert
    )
    print("✓ Hub initialized\n")
    
    # ==================== PROCESS MONITORING ====================
    
    print("Starting process monitoring...")
    hub.start_process_monitoring()
    print("✓ Process monitoring active (background thread)\n")
    
    time.sleep(2)  # Let monitor run briefly
    
    # ==================== FILE SCANNING ====================
    
    # Get a directory to scan
    print("Select scan target:")
    print("  1. Current directory")
    print("  2. Custom path")
    choice = input("Choice (1-2): ").strip()
    
    if choice == "2":
        target_path = input("Enter path to scan: ").strip()
        target = Path(target_path)
    else:
        target = Path.cwd()
    
    if not target.exists():
        print(f"Error: Path does not exist: {target}")
        hub.shutdown()
        return
    
    print(f"\nStarting scan of: {target}")
    print("Scan type: CUSTOM (all scannable files)")
    print("-" * 60)
    
    # Start the scan
    success = hub.start_scan(
        target_path=target,
        scan_type=ScanType.CUSTOM,
        recursive=True
    )
    
    if not success:
        print("Failed to start scan!")
        hub.shutdown()
        return
    
    # Monitor scan progress
    last_status = None
    while True:
        status = hub.get_scan_status()
        
        # Only print if status changed
        if status != last_status:
            print(f"\nStatus: {status['status'].upper()}")
            print(f"  Files scanned: {status['files_scanned']}")
            print(f"  Threats found: {status['threats_found']}")
            print(f"  Files quarantined: {status['files_quarantined']}")
            print(f"  Queue remaining: {status['queue_size']}")
            last_status = status
        
        # Check if scan is complete
        if status['status'] in ['completed', 'stopped', 'error']:
            break
        
        time.sleep(1)
    
    print("\n" + "=" * 60)
    print("SCAN COMPLETE")
    print("=" * 60)
    
    # ==================== SCAN RESULTS ====================
    
    final_status = hub.get_scan_status()
    print(f"\nFinal Statistics:")
    print(f"  Total files scanned: {final_status['files_scanned']}")
    print(f"  Threats detected: {final_status['threats_found']}")
    print(f"  Files quarantined: {final_status['files_quarantined']}")
    
    # ==================== DATABASE QUERIES ====================
    
    print("\n" + "-" * 60)
    print("DATABASE ANALYSIS")
    print("-" * 60)
    
    db = DatabaseManager()
    
    # Get threat statistics
    stats = db.get_threat_statistics()
    print(f"\nThreat Statistics:")
    print(f"  Total scans: {stats['total_scans']}")
    print(f"  Threats detected: {stats['threats_detected']}")
    print(f"  Clean files: {stats['clean_files']}")
    
    if stats.get('threats_by_type'):
        print(f"\n  Threats by type:")
        for threat_type, count in stats['threats_by_type'].items():
            print(f"    - {threat_type}: {count}")
    
    if stats.get('detection_methods'):
        print(f"\n  Detection methods:")
        for method, count in stats['detection_methods'].items():
            print(f"    - {method}: {count}")
    
    # Get recent threats
    recent_threats = db.get_scan_history(limit=10, threat_only=True)
    if recent_threats:
        print(f"\nRecent Threats (last 10):")
        for threat in recent_threats:
            print(f"  • {threat['threat_name']} - {threat['path']}")
    
    # Get quarantine records
    quarantined = db.get_quarantine_records(status='quarantined')
    if quarantined:
        print(f"\nQuarantined Files ({len(quarantined)}):")
        for record in quarantined:
            print(f"  • {record['threat_name']}")
            print(f"    Original: {record['original_path']}")
            print(f"    Vault: {record['vault_path']}")
    
    # Get process alerts
    alerts = db.get_process_alerts(limit=5)
    if alerts:
        print(f"\nRecent Process Alerts ({len(alerts)}):")
        for alert in alerts[:5]:
            print(f"  • {alert['process_name']} (PID: {alert['process_id']})")
            print(f"    {alert['description']}")
    
    # ==================== REPORT GENERATION ====================
    
    print("\n" + "-" * 60)
    print("REPORT GENERATION")
    print("-" * 60)
    
    generate = input("\nGenerate forensic PDF report? (y/n): ").strip().lower()
    
    if generate == 'y':
        print("Generating report...")
        report_path = hub.generate_report()
        
        if report_path:
            print(f"✓ Report saved to: {report_path}")
        else:
            print("✗ Report generation failed")
    
    # ==================== CLEANUP ====================
    
    print("\n" + "-" * 60)
    print("CLEANUP")
    print("-" * 60)
    
    print("Stopping process monitoring...")
    hub.stop_process_monitoring()
    
    print("Shutting down Sentinel Hub...")
    hub.shutdown()
    
    print("\n✓ Demonstration complete!")
    print("=" * 60)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nInterrupted by user. Exiting...")
        sys.exit(0)
    except Exception as e:
        print(f"\n\nError: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
