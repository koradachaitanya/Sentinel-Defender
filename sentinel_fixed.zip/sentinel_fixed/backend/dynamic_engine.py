"""
Sentinel Defender - Dynamic Real-Time Detection Engine
=======================================================
Provides three independent real-time monitors that feed alerts back to
SentinelHub via a thread-safe callback queue — no direct GUI calls, no
Tkinter deadlocks.

Components
----------
FilesystemMonitor   — watches directories for new/modified files using
                      watchdog (inotify on Linux, FSEvents on macOS,
                      ReadDirectoryChangesW on Windows). Detected files
                      are immediately sent through the DetectionEngine.

ProcessMonitor      — polls psutil every N seconds for new processes,
                      parent-child anomalies, suspicious command lines,
                      unexpected network connections, and injection
                      indicators (hollowed memory, unsigned DLLs).

MemoryScanner       — on-demand + periodic scan of running process memory
                      regions for shellcode heuristics, RWX pages, and
                      known bad byte patterns.

RegistryMonitor     — Windows only; polls HKLM/HKCU Run keys, Startup
                      folders, scheduled tasks, and service keys for
                      unexpected entries. Falls back gracefully on Linux/macOS.

DynamicEngine       — umbrella class that owns all four monitors, starts
                      and stops them together, and feeds a unified
                      DynamicAlert stream.

Architecture notes
------------------
- Every alert is produced on a worker thread and placed on a thread-safe
  queue.Queue. The GUI polls this queue on its mainloop timer — it never
  blocks or calls back into Tkinter from a background thread.
- All monitors are daemon threads so they die cleanly when the process exits.
- Detection callbacks from FilesystemMonitor pass through the existing
  DetectionEngine so all existing signature + heuristic logic is reused.
- ProcessMonitor keeps a 'seen_pids' set to avoid re-alerting on the same
  process between polls.
"""

from __future__ import annotations

import os 
import sys
import time
import queue
import hashlib
import logging
import threading
import subprocess
import collections
from pathlib import Path
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional, Callable, Dict, List, Set, Any

logger = logging.getLogger(__name__)

# ── Optional dependency guards ───────────────────────────────────────────────
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    logger.warning("[DynamicEngine] psutil not installed — ProcessMonitor disabled")

try:
    from watchdog.observers import Observer
    from watchdog.events import (
        FileSystemEventHandler,
        FileCreatedEvent,
        FileModifiedEvent,
        FileMovedEvent,
    )
    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False
    logger.warning("[DynamicEngine] watchdog not installed — FilesystemMonitor disabled. "
                   "Install with: pip install watchdog")

WINDOWS = sys.platform == "win32"
if WINDOWS:
    try:
        import winreg
        WINREG_AVAILABLE = True
    except ImportError:
        WINREG_AVAILABLE = False
else:
    WINREG_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
#  Alert dataclass
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class DynamicAlert:
    """
    Unified alert produced by any dynamic monitor.
    Designed to be JSON-serialisable and GUI-displayable.
    """
    alert_id:        str
    timestamp:       str
    source:          str          # 'filesystem' | 'process' | 'memory' | 'registry'
    severity:        str          # 'critical' | 'high' | 'medium' | 'low' | 'info'
    alert_type:      str          # human-readable category
    title:           str          # short one-line summary
    description:     str          # full detail
    recommendation:  str = ""
    confidence:      float = 0.0  # 0.0–1.0
    threat_score:    int = 0      # 0–100
    details:         Dict = field(default_factory=dict)
    resolved:        bool = False

    def to_dict(self) -> dict:
        return asdict(self)


# ─────────────────────────────────────────────────────────────────────────────
#  Shared helpers
# ─────────────────────────────────────────────────────────────────────────────

_seq_lock = threading.Lock()
_seq_counter = 0


def _next_id(prefix: str = "DYN") -> str:
    global _seq_counter
    with _seq_lock:
        _seq_counter += 1
        return f"{prefix}-{datetime.now().strftime('%Y%m%d%H%M%S')}-{_seq_counter:05d}"


def _ts() -> str:
    return datetime.now().isoformat(timespec="seconds")


# ─────────────────────────────────────────────────────────────────────────────
#  1. Filesystem Monitor
# ─────────────────────────────────────────────────────────────────────────────

# Extensions considered immediately dangerous when written to disk
_HIGH_RISK_EXTS = {
    ".exe", ".dll", ".sys", ".drv",             # Windows PE
    ".ps1", ".psm1", ".psd1",                   # PowerShell
    ".vbs", ".vbe", ".js", ".jse", ".wsf",      # Script engines
    ".bat", ".cmd",                              # Batch
    ".hta",                                      # HTML Application
    ".scr",                                      # Screensaver (PE + autorun)
    ".pif",                                      # Program Information File
    ".jar",                                      # Java
    ".sh", ".bash", ".zsh",                      # Unix shell
    ".elf",                                      # Linux executable
    ".dylib", ".so",                             # Shared libraries
    ".reg",                                      # Registry import
    ".lnk",                                      # Shortcut (spawn chain abuse)
    ".doc", ".docx", ".docm",                    # Office macro docs
    ".xls", ".xlsx", ".xlsm",
    ".ppt", ".pptx", ".pptm",
    ".pdf",                                      # PDF exploits
    ".iso", ".img", ".vhd", ".vmdk",            # Disk images (mount-and-run)
    ".zip", ".rar", ".7z", ".tar", ".gz",        # Archives (payload delivery)
}

# Directories to ignore — scanning these causes noise and slowdowns
_IGNORE_DIRS = {
    "__pycache__", ".git", ".svn", "node_modules",
    "System Volume Information", "$Recycle.Bin",
    "Windows\\WinSxS", "Windows\\assembly",
}

# Rapid-write detection: if the same file is written N times in T seconds
# it might be ransomware encrypting in place
_RAPID_WRITE_THRESHOLD = 5      # writes
_RAPID_WRITE_WINDOW    = 10.0   # seconds


class _FSEventHandler(FileSystemEventHandler if WATCHDOG_AVAILABLE else object):
    """
    Watchdog event handler.  Filters low-interest events and forwards
    suspicious ones to the FilesystemMonitor for scanning.
    """

    def __init__(self, monitor: "FilesystemMonitor"):
        if WATCHDOG_AVAILABLE:
            super().__init__()
        self._monitor = monitor

    def on_created(self, event):
        if not event.is_directory:
            self._monitor._queue_path(event.src_path, "created")

    def on_modified(self, event):
        if not event.is_directory:
            self._monitor._queue_path(event.src_path, "modified")

    def on_moved(self, event):
        # File rename — destination is the interesting path
        if not event.is_directory:
            self._monitor._queue_path(event.dest_path, "renamed")


class FilesystemMonitor:
    """
    Real-time filesystem watcher.

    On Windows: uses ReadDirectoryChangesW via watchdog.
    On Linux:   uses inotify via watchdog.
    On macOS:   uses FSEvents via watchdog.

    Falls back to a polling watcher if the native backend fails.

    All detected file events are:
      1. Filtered by extension and directory
      2. Checked for rapid-write patterns (ransomware indicator)
      3. Sent through the full DetectionEngine (signature + heuristic)
      4. Emitted as DynamicAlert objects on the shared queue
    """

    def __init__(
        self,
        alert_queue:       queue.Queue,
        detection_engine,                   # DetectionEngine instance from detectors.py
        watch_paths:       List[str],
        recursive:         bool = True,
        scan_all_exts:     bool = False,    # True = scan every file, False = high-risk only
    ):
        self._q             = alert_queue
        self._det           = detection_engine
        self._paths         = [Path(p) for p in watch_paths]
        self._recursive     = recursive
        self._scan_all      = scan_all_exts
        self._running       = False
        self._observer      = None

        # Rapid-write tracker: path → deque of timestamps
        self._write_times:  Dict[str, collections.deque] = collections.defaultdict(
            lambda: collections.deque(maxlen=50)
        )
        self._rw_lock       = threading.Lock()
        self._alerted_rw:   Set[str] = set()     # paths already alerted for rapid-write

        # Deduplicate scan queue so the same file isn't scanned 10× in a burst
        self._pending:      Set[str] = set()
        self._pend_lock     = threading.Lock()

        # Worker thread processes the scan queue
        self._scan_queue    = queue.Queue(maxsize=1000)
        self._scan_thread:  Optional[threading.Thread] = None

    # ── Public control ────────────────────────────────────────────────────────

    def start(self) -> bool:
        if not WATCHDOG_AVAILABLE:
            logger.error("[FilesystemMonitor] watchdog not installed.")
            return False
        if self._running:
            return True

        self._running = True

        # Start the watchdog observer
        try:
            self._observer = Observer()
            handler = _FSEventHandler(self)
            for path in self._paths:
                if path.exists():
                    self._observer.schedule(handler, str(path),
                                            recursive=self._recursive)
                    logger.info("[FilesystemMonitor] Watching: %s", path)
                else:
                    logger.warning("[FilesystemMonitor] Path does not exist: %s", path)
            self._observer.start()
        except Exception as exc:
            logger.error("[FilesystemMonitor] Observer failed to start: %s", exc)
            self._running = False
            return False

        # Start the scan worker thread
        self._scan_thread = threading.Thread(
            target=self._scan_worker,
            name="FS-ScanWorker",
            daemon=True,
        )
        self._scan_thread.start()
        logger.info("[FilesystemMonitor] Started (%d path(s))", len(self._paths))
        return True

    def stop(self) -> None:
        self._running = False
        if self._observer:
            try:
                self._observer.stop()
                self._observer.join(timeout=3)
            except Exception:
                pass
        # Unblock scan worker
        try:
            self._scan_queue.put_nowait(None)
        except queue.Full:
            pass
        logger.info("[FilesystemMonitor] Stopped.")

    def add_watch_path(self, path: str) -> None:
        """Dynamically add a new path to watch at runtime."""
        if not WATCHDOG_AVAILABLE or not self._observer or not self._running:
            return
        p = Path(path)
        if p.exists():
            handler = _FSEventHandler(self)
            self._observer.schedule(handler, str(p), recursive=self._recursive)
            self._paths.append(p)
            logger.info("[FilesystemMonitor] Added watch: %s", path)

    # ── Internal ──────────────────────────────────────────────────────────────

    def _queue_path(self, raw_path: str, event_type: str) -> None:
        """Called by watchdog event handler — filters then enqueues."""
        path = Path(raw_path)

        # Skip directories and ignored names
        if any(part in _IGNORE_DIRS for part in path.parts):
            return
        if path.is_dir():
            return

        # Extension filter
        ext = path.suffix.lower()
        if not self._scan_all and ext not in _HIGH_RISK_EXTS:
            return

        # Rapid-write detection (before dedup — we want all write events)
        self._check_rapid_write(raw_path, event_type)

        # Dedup: skip if already queued/scanning
        with self._pend_lock:
            if raw_path in self._pending:
                return
            self._pending.add(raw_path)

        try:
            self._scan_queue.put_nowait((raw_path, event_type))
        except queue.Full:
            with self._pend_lock:
                self._pending.discard(raw_path)

    def _check_rapid_write(self, raw_path: str, event_type: str) -> None:
        """
        Detect ransomware-style rapid writes: same file modified many times
        in a short window — typical of in-place encryption.
        """
        if event_type not in ("modified", "created"):
            return
        now = time.time()
        with self._rw_lock:
            dq = self._write_times[raw_path]
            dq.append(now)
            # Count writes within the window
            recent = sum(1 for t in dq if now - t < _RAPID_WRITE_WINDOW)
            if recent >= _RAPID_WRITE_THRESHOLD and raw_path not in self._alerted_rw:
                self._alerted_rw.add(raw_path)
                self._emit(DynamicAlert(
                    alert_id    = _next_id("FS"),
                    timestamp   = _ts(),
                    source      = "filesystem",
                    severity    = "high",
                    alert_type  = "rapid_write",
                    title       = f"Rapid file modification: {Path(raw_path).name}",
                    description = (
                        f"File '{raw_path}' was written {recent} times "
                        f"in {_RAPID_WRITE_WINDOW:.0f}s — possible ransomware "
                        f"encryption in progress."
                    ),
                    recommendation = (
                        "Immediately isolate the writing process. "
                        "Check process handle list for this file path. "
                        "Verify backup integrity."
                    ),
                    confidence  = 0.80,
                    threat_score = 75,
                    details     = {
                        "path": raw_path,
                        "writes_in_window": recent,
                        "window_seconds": _RAPID_WRITE_WINDOW,
                    },
                ))

    def _scan_worker(self) -> None:
        """Background thread: dequeues file paths and runs DetectionEngine."""
        while self._running:
            try:
                item = self._scan_queue.get(timeout=1.0)
                if item is None:
                    break
                raw_path, event_type = item
            except queue.Empty:
                continue
            finally:
                pass  # do not break here

            try:
                path = Path(raw_path)
                if not path.exists() or not path.is_file():
                    continue

                # Short delay to let the write finish before scanning
                time.sleep(0.3)

                detection = self._det.scan_file(path)
                is_threat = (
                    detection.threat_type in ("malware", "suspicious", "test_file")
                    or detection.threat_score >= 60
                )

                if is_threat:
                    sev = (
                        "critical" if detection.severity in ("critical",) else
                        "high"     if detection.severity in ("high",)     else
                        "medium"
                    )
                    self._emit(DynamicAlert(
                        alert_id     = _next_id("FS"),
                        timestamp    = _ts(),
                        source       = "filesystem",
                        severity     = sev,
                        alert_type   = "file_threat",
                        title        = f"{detection.threat_name} — {path.name}",
                        description  = (
                            f"Threat detected in {event_type} file: {raw_path}\n"
                            f"Threat: {detection.threat_name} "
                            f"(score={detection.threat_score}, "
                            f"method={detection.detection_method})"
                        ),
                        recommendation = (
                            "Quarantine the file immediately. "
                            "Identify the process that created it. "
                            "Check for lateral movement from same process."
                        ),
                        confidence   = detection.confidence,
                        threat_score = detection.threat_score,
                        details      = {
                            "path":             raw_path,
                            "event":            event_type,
                            "threat_name":      detection.threat_name,
                            "threat_type":      detection.threat_type,
                            "detection_method": detection.detection_method,
                            "file_hash":        detection.file_hash,
                        },
                    ))
                    logger.warning("[FilesystemMonitor] Threat: %s (%s, score=%d)",
                                   path.name, detection.threat_name, detection.threat_score)
            except Exception as exc:
                logger.debug("[FilesystemMonitor] Scan error for %s: %s", raw_path, exc)
            finally:
                with self._pend_lock:
                    self._pending.discard(raw_path)

    def _emit(self, alert: DynamicAlert) -> None:
        try:
            self._q.put_nowait(alert)
        except queue.Full:
            logger.warning("[FilesystemMonitor] Alert queue full — alert dropped")


# ─────────────────────────────────────────────────────────────────────────────
#  2. Process Monitor
# ─────────────────────────────────────────────────────────────────────────────

# Processes that should never spawn shells or interpreters
_SUSPICIOUS_PARENT_CHILD = {
    # Office apps spawning shells
    ("winword.exe",    "cmd.exe"):        ("high",    "Word spawning command shell"),
    ("winword.exe",    "powershell.exe"): ("critical","Word spawning PowerShell"),
    ("excel.exe",      "cmd.exe"):        ("high",    "Excel spawning command shell"),
    ("excel.exe",      "powershell.exe"): ("critical","Excel spawning PowerShell"),
    ("outlook.exe",    "cmd.exe"):        ("high",    "Outlook spawning command shell"),
    ("outlook.exe",    "powershell.exe"): ("critical","Outlook spawning PowerShell"),
    ("acrobat.exe",    "cmd.exe"):        ("high",    "Acrobat spawning command shell"),
    ("acrord32.exe",   "cmd.exe"):        ("high",    "Acrobat Reader spawning shell"),
    # Browsers dropping executables
    ("chrome.exe",     "cmd.exe"):        ("medium",  "Chrome spawning shell"),
    ("firefox.exe",    "cmd.exe"):        ("medium",  "Firefox spawning shell"),
    ("msedge.exe",     "cmd.exe"):        ("medium",  "Edge spawning shell"),
    # Script engines spawning further processes
    ("wscript.exe",    "cmd.exe"):        ("high",    "WSH spawning command shell"),
    ("cscript.exe",    "cmd.exe"):        ("high",    "CScript spawning command shell"),
    ("mshta.exe",      "powershell.exe"): ("critical","HTA spawning PowerShell"),
    ("mshta.exe",      "cmd.exe"):        ("critical","HTA spawning shell"),
    # System processes that should never spawn user tools
    ("svchost.exe",    "powershell.exe"): ("critical","svchost spawning PowerShell"),
    ("lsass.exe",      "cmd.exe"):        ("critical","LSASS spawning shell (LSASS hijack?)"),
    ("services.exe",   "powershell.exe"): ("critical","services.exe spawning PowerShell"),
}

# Command-line patterns and their descriptions
_CMDLINE_PATTERNS = [
    # PowerShell
    ("-encodedcommand",   "critical", "Base64-encoded PowerShell command (obfuscation)"),
    ("downloadstring(",   "high",     "PowerShell web download via DownloadString"),
    ("invoke-expression", "high",     "PowerShell IEX code execution"),
    ("-noprofile -",      "medium",   "PowerShell with suppressed profile (stealth)"),
    ("bypass",            "medium",   "PowerShell execution policy bypass"),
    ("hidden",            "medium",   "Hidden window PowerShell execution"),
    ("webclient",         "medium",   "PowerShell WebClient usage"),
    ("frombase64string",  "high",     "PowerShell Base64 decode (payload staging)"),
    ("reflectiveloader",  "critical", "Reflective DLL injection pattern in cmdline"),
    # CMD / shell
    ("vssadmin delete",   "critical", "VSS shadow copy deletion (ransomware indicator)"),
    ("bcdedit /set",      "high",     "Boot config modification (anti-recovery)"),
    ("wbadmin delete",    "critical", "Windows backup deletion"),
    ("schtasks /create",  "medium",   "Scheduled task creation (persistence)"),
    ("reg add hklm",      "high",     "HKLM registry modification (persistence)"),
    ("reg add hkcu",      "medium",   "HKCU registry modification (persistence)"),
    ("netsh advfirewall", "high",     "Firewall rule modification"),
    ("net user /add",     "high",     "New user account creation"),
    ("net localgroup",    "high",     "Local group membership change"),
    ("certutil -decode",  "high",     "Certutil used to decode payload (LOLBin)"),
    ("certutil -urlcache","high",     "Certutil used to download file (LOLBin)"),
    ("msiexec /i http",   "high",     "MSI install from remote URL"),
    ("regsvr32 /s /u /i:","high",     "Squiblydoo COM scriptlet execution"),
    ("rundll32",          "medium",   "rundll32 execution (verify DLL path)"),
    ("mshta ",            "high",     "mshta HTA execution (LOLBin)"),
]

# Processes that should NEVER have outbound network connections
_NON_NETWORK_PROCS = {
    "notepad.exe", "calc.exe", "mspaint.exe", "wordpad.exe",
    "explorer.exe",  # explorer outbound is suspicious (not inbound)
    "taskmgr.exe", "regedit.exe", "mmc.exe",
}

# CPU threshold for cryptominer detection (%)
_CRYPTO_CPU_THRESHOLD = 85.0

# How often to poll for new processes (seconds)
_PROC_POLL_INTERVAL = 3.0

# Memory-mapped region flags (Windows VirtualQuery)
MEM_COMMIT  = 0x1000
PAGE_EXECUTE_READWRITE = 0x40
PAGE_EXECUTE_WRITECOPY = 0x80


class ProcessMonitor:
    """
    Continuous process monitor.

    Polls psutil every _PROC_POLL_INTERVAL seconds for:
    - New processes not seen before
    - Parent-child relationship anomalies
    - Suspicious command-line patterns
    - Unexpected network connections on non-network processes
    - High CPU usage (cryptominer indicator)
    - Process hollowing / memory anomalies (Windows only, best-effort)
    - Unsigned or unusual executable paths
    """

    def __init__(self, alert_queue: queue.Queue):
        self._q          = alert_queue
        self._running    = False
        self._thread:    Optional[threading.Thread] = None
        self._seen_pids: Dict[int, str] = {}       # pid → proc.name()
        self._lock       = threading.Lock()
        # Track alerted pids per alert type to suppress repeats
        self._alerted:   Dict[str, Set[int]] = collections.defaultdict(set)

    # ── Public control ────────────────────────────────────────────────────────

    def start(self) -> bool:
        if not PSUTIL_AVAILABLE:
            logger.error("[ProcessMonitor] psutil not available.")
            return False
        if self._running:
            return True
        self._running = True

        # Seed seen_pids with currently running processes so we don't
        # alert on every process at startup
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                self._seen_pids[proc.info["pid"]] = (proc.info["name"] or "").lower()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        self._thread = threading.Thread(
            target=self._poll_loop,
            name="ProcessMonitor",
            daemon=True,
        )
        self._thread.start()
        logger.info("[ProcessMonitor] Started (poll interval=%.1fs)", _PROC_POLL_INTERVAL)
        return True

    def stop(self) -> None:
        self._running = False
        logger.info("[ProcessMonitor] Stopped.")

    def scan_now(self) -> List[DynamicAlert]:
        """Force an immediate scan and return alerts synchronously."""
        return self._scan_processes()

    # ── Internal ──────────────────────────────────────────────────────────────

    def _poll_loop(self) -> None:
        while self._running:
            try:
                self._scan_processes()
            except Exception as exc:
                logger.error("[ProcessMonitor] Poll error: %s", exc)
            # Sleep in small increments so stop() is responsive
            for _ in range(int(_PROC_POLL_INTERVAL / 0.2)):
                if not self._running:
                    return
                time.sleep(0.2)

    def _scan_processes(self) -> List[DynamicAlert]:
        alerts: List[DynamicAlert] = []
        if not PSUTIL_AVAILABLE:
            return alerts

        current_pids: Set[int] = set()

        for proc in psutil.process_iter(
            ["pid", "name", "exe", "cmdline", "ppid",
             "cpu_percent", "memory_percent", "username",
             "status"]
        ):
            try:
                pid  = proc.info["pid"]
                name = (proc.info["name"] or "").lower()
                current_pids.add(pid)

                is_new = pid not in self._seen_pids
                with self._lock:
                    self._seen_pids[pid] = name

                if not is_new:
                    # Still check CPU and network on known processes
                    self._check_cpu(proc, alerts)
                    self._check_network(proc, alerts)
                    continue

                # ── New process — full analysis ───────────────────────────────
                self._check_parent_child(proc, alerts)
                self._check_cmdline(proc, alerts)
                self._check_network(proc, alerts)
                self._check_exe_path(proc, alerts)
                self._check_cpu(proc, alerts)

            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
            except Exception as exc:
                logger.debug("[ProcessMonitor] Error on pid %s: %s",
                             getattr(proc, "pid", "?"), exc)

        # Clean up dead PIDs from state
        with self._lock:
            dead = set(self._seen_pids.keys()) - current_pids
            for pid in dead:
                self._seen_pids.pop(pid, None)
                for s in self._alerted.values():
                    s.discard(pid)

        for a in alerts:
            self._emit(a)
        return alerts

    def _check_parent_child(self, proc, alerts: list) -> None:
        try:
            name   = proc.info["name"].lower() if proc.info["name"] else ""
            ppid   = proc.info["ppid"]
            if ppid is None or ppid == 0:
                return
            parent = psutil.Process(ppid)
            pname  = parent.name().lower()
            key    = (pname, name)
            if key in _SUSPICIOUS_PARENT_CHILD:
                if proc.info["pid"] not in self._alerted["parent_child"]:
                    self._alerted["parent_child"].add(proc.info["pid"])
                    severity, reason = _SUSPICIOUS_PARENT_CHILD[key]
                    alerts.append(DynamicAlert(
                        alert_id     = _next_id("PROC"),
                        timestamp    = _ts(),
                        source       = "process",
                        severity     = severity,
                        alert_type   = "parent_child_anomaly",
                        title        = f"{pname} → {name}",
                        description  = (
                            f"{reason}.\n"
                            f"Parent: {pname} (PID {ppid})\n"
                            f"Child:  {name}  (PID {proc.info['pid']})\n"
                            f"Cmdline: {' '.join(proc.info.get('cmdline') or [])}"
                        ),
                        recommendation = (
                            "Investigate immediately — this parent→child chain "
                            "is a known malware indicator. "
                            "Terminate both processes if exploitation is confirmed. "
                            "Check for lateral movement."
                        ),
                        confidence   = 0.90,
                        threat_score = 80 if severity == "critical" else 65,
                        details      = {
                            "parent_name": pname,
                            "parent_pid":  ppid,
                            "child_name":  name,
                            "child_pid":   proc.info["pid"],
                            "cmdline":     " ".join(proc.info.get("cmdline") or []),
                        },
                    ))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    def _check_cmdline(self, proc, alerts: list) -> None:
        try:
            cmdline = " ".join(proc.info.get("cmdline") or []).lower()
            if not cmdline:
                return
            pid = proc.info["pid"]

            for pattern, severity, description in _CMDLINE_PATTERNS:
                if pattern in cmdline:
                    akey = f"cmd_{pattern}"
                    if pid not in self._alerted[akey]:
                        self._alerted[akey].add(pid)
                        alerts.append(DynamicAlert(
                            alert_id     = _next_id("PROC"),
                            timestamp    = _ts(),
                            source       = "process",
                            severity     = severity,
                            alert_type   = "suspicious_cmdline",
                            title        = f"Suspicious cmdline: {description[:60]}",
                            description  = (
                                f"{description}\n"
                                f"Process: {proc.info.get('name','')} (PID {pid})\n"
                                f"Cmdline: {cmdline[:500]}"
                            ),
                            recommendation = (
                                "Review the full command line. "
                                "Correlate with the parent process and user account. "
                                "Block execution if no legitimate business justification."
                            ),
                            confidence   = 0.85,
                            threat_score = 80 if severity == "critical" else
                                           65 if severity == "high"     else 45,
                            details      = {
                                "pid":     pid,
                                "name":    proc.info.get("name", ""),
                                "pattern": pattern,
                                "cmdline": cmdline[:500],
                            },
                        ))
                    break   # one alert per process per scan
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    def _check_network(self, proc, alerts: list) -> None:
        try:
            name = (proc.info.get("name") or "").lower()
            if name not in _NON_NETWORK_PROCS:
                return
            pid = proc.info["pid"]
            if pid in self._alerted["network"]:
                return

            conns = proc.connections()
            # Filter to ESTABLISHED connections only
            active = [c for c in conns
                      if hasattr(c, "status") and c.status == "ESTABLISHED"]
            if active:
                self._alerted["network"].add(pid)
                conn_strs = [
                    f"{c.laddr.ip}:{c.laddr.port} → {c.raddr.ip}:{c.raddr.port}"
                    for c in active if c.raddr
                ]
                alerts.append(DynamicAlert(
                    alert_id     = _next_id("PROC"),
                    timestamp    = _ts(),
                    source       = "process",
                    severity     = "medium",
                    alert_type   = "unexpected_network",
                    title        = f"{name} has unexpected network connections",
                    description  = (
                        f"{name} (PID {pid}) should not have network connections "
                        f"but has {len(active)} ESTABLISHED connection(s):\n"
                        + "\n".join(conn_strs[:5])
                    ),
                    recommendation = (
                        "Investigate whether this process has been trojanised "
                        "or replaced by a malicious binary. "
                        "Verify file hash against known-good copy."
                    ),
                    confidence   = 0.75,
                    threat_score = 60,
                    details      = {
                        "pid":         pid,
                        "name":        name,
                        "connections": conn_strs[:10],
                    },
                ))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    def _check_exe_path(self, proc, alerts: list) -> None:
        """
        Flag executables running from suspicious locations:
        %TEMP%, AppData\\Local\\Temp, Downloads, recycle bin,
        or any path containing 'tmp' / 'temp'.
        """
        try:
            exe  = proc.info.get("exe") or ""
            pid  = proc.info["pid"]
            name = (proc.info.get("name") or "").lower()
            if not exe:
                return

            exe_lower = exe.lower()
            suspicious_dirs = [
                "\\temp\\", "/tmp/", "\\appdata\\local\\temp\\",
                "\\downloads\\", "\\recycle", "%temp%",
                "\\windows\\temp\\",
            ]
            reason = next(
                (d for d in suspicious_dirs if d in exe_lower), None
            )
            if reason and pid not in self._alerted["exe_path"]:
                self._alerted["exe_path"].add(pid)
                alerts.append(DynamicAlert(
                    alert_id     = _next_id("PROC"),
                    timestamp    = _ts(),
                    source       = "process",
                    severity     = "high",
                    alert_type   = "suspicious_exe_path",
                    title        = f"{name} running from temp/suspicious location",
                    description  = (
                        f"Process '{name}' (PID {pid}) is executing from "
                        f"a suspicious path: {exe}\n"
                        f"Legitimate software rarely runs from temp directories."
                    ),
                    recommendation = (
                        "Check file hash and verify it is a known application. "
                        "Terminate and quarantine if unrecognised. "
                        "Check for dropper that placed it there."
                    ),
                    confidence   = 0.80,
                    threat_score = 70,
                    details={"pid": pid, "name": name, "exe": exe},
                ))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    def _check_cpu(self, proc, alerts: list) -> None:
        try:
            cpu = proc.info.get("cpu_percent") or 0.0
            pid = proc.info["pid"]
            if cpu >= _CRYPTO_CPU_THRESHOLD and pid not in self._alerted["high_cpu"]:
                self._alerted["high_cpu"].add(pid)
                name = proc.info.get("name", "unknown")
                alerts.append(DynamicAlert(
                    alert_id     = _next_id("PROC"),
                    timestamp    = _ts(),
                    source       = "process",
                    severity     = "medium",
                    alert_type   = "high_cpu_usage",
                    title        = f"High CPU: {name} ({cpu:.0f}%)",
                    description  = (
                        f"Process '{name}' (PID {pid}) is consuming "
                        f"{cpu:.1f}% CPU — possible cryptominer or runaway malware."
                    ),
                    recommendation = (
                        "Investigate whether this is a known CPU-intensive task. "
                        "Check network connections for mining pool addresses. "
                        "Compare exe path and hash against known-good."
                    ),
                    confidence   = 0.55,
                    threat_score = 45,
                    details={"pid": pid, "name": name, "cpu_percent": cpu},
                ))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    def _emit(self, alert: DynamicAlert) -> None:
        try:
            self._q.put_nowait(alert)
        except queue.Full:
            logger.warning("[ProcessMonitor] Alert queue full — alert dropped")


# ─────────────────────────────────────────────────────────────────────────────
#  3. Memory Scanner
# ─────────────────────────────────────────────────────────────────────────────

# Shellcode / malware byte patterns (common stagers & loaders)
_BAD_BYTE_PATTERNS: List[bytes] = [
    # Metasploit/meterpreter x86 stager prologue
    b"\xfc\xe8\x89\x00\x00\x00",
    # Common XOR decoder stub
    b"\xeb\x10\x5a\x4a\x33\xc9",
    # Cobalt Strike default beacon XOR key artefact
    b"\x69\x68\x69\x68\x69\x6a\x69\x68",
    # Null pointer sled (heap spray)
    b"\x00" * 32,
    # EICAR prefix (test)
    b"X5O!P%@AP[4\\PZX54",
    # PowerShell AMSI bypass magic
    b"amsiScanBuffer",
    b"AmsiScanBuffer",
]

# How many processes to scan per memory scan pass (limits overhead)
_MEM_SCAN_BATCH     = 20
_MEM_SCAN_INTERVAL  = 60.0      # seconds between auto-scan passes
_MIN_REGION_SIZE    = 4096      # skip regions smaller than one page
_MAX_REGION_SAMPLE  = 65536     # bytes to sample per region


class MemoryScanner:
    """
    Lightweight in-process memory scanner.

    Uses /proc/<pid>/maps + /proc/<pid>/mem on Linux.
    Uses process_memory_maps() from psutil on all platforms.

    Checks for:
    - RWX (read-write-execute) memory regions — classic shellcode indicator
    - Known bad byte patterns in sampled regions
    - Anomalously large anonymous executable regions (heap shellcode)
    """

    def __init__(self, alert_queue: queue.Queue):
        self._q         = alert_queue
        self._running   = False
        self._thread:   Optional[threading.Thread] = None
        self._alerted:  Set[str] = set()    # "pid:region_addr" already alerted

    # ── Public control ────────────────────────────────────────────────────────

    def start(self) -> bool:
        if not PSUTIL_AVAILABLE:
            logger.error("[MemoryScanner] psutil not available.")
            return False
        if self._running:
            return True
        self._running = True
        self._thread = threading.Thread(
            target=self._auto_scan_loop,
            name="MemoryScanner",
            daemon=True,
        )
        self._thread.start()
        logger.info("[MemoryScanner] Started (interval=%.0fs)", _MEM_SCAN_INTERVAL)
        return True

    def stop(self) -> None:
        self._running = False
        logger.info("[MemoryScanner] Stopped.")

    def scan_pid(self, pid: int) -> List[DynamicAlert]:
        """Scan a single PID immediately and return alerts."""
        return self._scan_pid(pid)

    # ── Internal ──────────────────────────────────────────────────────────────

    def _auto_scan_loop(self) -> None:
        while self._running:
            try:
                self._scan_batch()
            except Exception as exc:
                logger.error("[MemoryScanner] Scan loop error: %s", exc)
            for _ in range(int(_MEM_SCAN_INTERVAL / 0.5)):
                if not self._running:
                    return
                time.sleep(0.5)

    def _scan_batch(self) -> None:
        """Scan a rotating batch of processes."""
        try:
            all_procs = [p for p in psutil.process_iter(["pid", "name", "exe"])
                         if p.info["pid"] not in (0, 4)]   # skip Idle + System
        except Exception:
            return

        # Rotate through processes across scan cycles to spread load
        batch = all_procs[:_MEM_SCAN_BATCH]
        for proc in batch:
            if not self._running:
                return
            alerts = self._scan_pid(proc.info["pid"])
            for a in alerts:
                self._emit(a)

    def _scan_pid(self, pid: int) -> List[DynamicAlert]:
        alerts: List[DynamicAlert] = []
        if not PSUTIL_AVAILABLE:
            return alerts

        try:
            proc = psutil.Process(pid)
            name = proc.name()

            # Use psutil memory_maps (portable, no raw /proc access needed)
            try:
                maps = proc.memory_maps(grouped=False)
            except (psutil.AccessDenied, psutil.NoSuchProcess, AttributeError):
                return alerts

            for m in maps:
                perms = getattr(m, "perms", "") or ""
                addr  = getattr(m, "addr", "?")  or "?"
                size  = getattr(m, "size", 0)    or 0
                path  = getattr(m, "path", "")   or ""

                # RWX region check
                if "r" in perms and "w" in perms and "x" in perms:
                    key = f"{pid}:{addr}"
                    if key not in self._alerted and size >= _MIN_REGION_SIZE:
                        self._alerted.add(key)
                        is_anon = not path or path in ("[heap]", "[stack]", "")
                        severity = "high" if is_anon else "medium"
                        alerts.append(DynamicAlert(
                            alert_id     = _next_id("MEM"),
                            timestamp    = _ts(),
                            source       = "memory",
                            severity     = severity,
                            alert_type   = "rwx_memory_region",
                            title        = f"RWX region in {name} (PID {pid})",
                            description  = (
                                f"Process '{name}' (PID {pid}) has a read-write-execute "
                                f"memory region at {addr} ({size:,} bytes). "
                                + (f"Anonymous region — classic shellcode injection pattern."
                                   if is_anon else
                                   f"Mapped file: {path}")
                            ),
                            recommendation = (
                                "RWX regions in anonymous memory are a strong shellcode "
                                "indicator. Capture a memory dump and analyse with "
                                "volatility/malfind. Terminate process if confirmed."
                            ),
                            confidence   = 0.70 if is_anon else 0.40,
                            threat_score = 65 if is_anon else 40,
                            details={
                                "pid": pid, "name": name,
                                "addr": addr, "size": size,
                                "perms": perms, "path": path,
                            },
                        ))

        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
        except Exception as exc:
            logger.debug("[MemoryScanner] scan_pid(%d) error: %s", pid, exc)

        return alerts

    def _emit(self, alert: DynamicAlert) -> None:
        try:
            self._q.put_nowait(alert)
        except queue.Full:
            logger.warning("[MemoryScanner] Alert queue full — alert dropped")


# ─────────────────────────────────────────────────────────────────────────────
#  4. Registry Monitor (Windows only)
# ─────────────────────────────────────────────────────────────────────────────

# Registry run/persistence keys to watch
_REG_PERSISTENCE_KEYS = [
    (winreg.HKEY_LOCAL_MACHINE,
     r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"),
    (winreg.HKEY_LOCAL_MACHINE,
     r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"),
    (winreg.HKEY_CURRENT_USER,
     r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"),
    (winreg.HKEY_CURRENT_USER,
     r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"),
    (winreg.HKEY_LOCAL_MACHINE,
     r"SYSTEM\CurrentControlSet\Services"),
    (winreg.HKEY_LOCAL_MACHINE,
     r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"),
] if WINREG_AVAILABLE else []

_REG_POLL_INTERVAL = 30.0   # seconds between registry polls


class RegistryMonitor:
    """
    Windows registry persistence monitor.

    Polls known autostart locations and compares against a baseline
    captured at startup. New entries trigger alerts.

    On Linux/macOS this class starts and immediately returns False —
    no polling thread is created.
    """

    def __init__(self, alert_queue: queue.Queue):
        self._q        = alert_queue
        self._running  = False
        self._thread:  Optional[threading.Thread] = None
        self._baseline: Dict[str, Dict[str, str]] = {}   # key_path → {name: data}

    def start(self) -> bool:
        if not WINREG_AVAILABLE:
            logger.info("[RegistryMonitor] Not available on this platform.")
            return False
        if self._running:
            return True

        self._baseline = self._snapshot_all()
        self._running  = True
        self._thread = threading.Thread(
            target=self._poll_loop,
            name="RegistryMonitor",
            daemon=True,
        )
        self._thread.start()
        logger.info("[RegistryMonitor] Started (%d key(s) watched)",
                    len(_REG_PERSISTENCE_KEYS))
        return True

    def stop(self) -> None:
        self._running = False
        logger.info("[RegistryMonitor] Stopped.")

    def _poll_loop(self) -> None:
        while self._running:
            try:
                self._check_changes()
            except Exception as exc:
                logger.error("[RegistryMonitor] Poll error: %s", exc)
            for _ in range(int(_REG_POLL_INTERVAL / 0.5)):
                if not self._running:
                    return
                time.sleep(0.5)

    def _snapshot_all(self) -> Dict[str, Dict[str, str]]:
        snapshot = {}
        for hive, subkey in _REG_PERSISTENCE_KEYS:
            key_path = f"{hive}\\{subkey}"
            snapshot[key_path] = self._read_key(hive, subkey)
        return snapshot

    def _read_key(self, hive, subkey: str) -> Dict[str, str]:
        values = {}
        try:
            with winreg.OpenKey(hive, subkey, 0,
                                winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
                i = 0
                while True:
                    try:
                        name, data, _ = winreg.EnumValue(key, i)
                        values[name] = str(data)
                        i += 1
                    except OSError:
                        break
        except (FileNotFoundError, PermissionError, OSError):
            pass
        return values

    def _check_changes(self) -> None:
        current = self._snapshot_all()
        for key_path, cur_vals in current.items():
            base_vals = self._baseline.get(key_path, {})
            # New or changed values
            for name, data in cur_vals.items():
                if name not in base_vals:
                    self._emit(DynamicAlert(
                        alert_id     = _next_id("REG"),
                        timestamp    = _ts(),
                        source       = "registry",
                        severity     = "high",
                        alert_type   = "new_autorun_entry",
                        title        = f"New registry autorun: {name}",
                        description  = (
                            f"New autorun entry detected in {key_path}\n"
                            f"Name:  {name}\n"
                            f"Value: {data[:200]}"
                        ),
                        recommendation = (
                            "Verify this entry was added by a legitimate installer. "
                            "Delete it and trace the creating process if unknown. "
                            "Common malware persistence mechanism."
                        ),
                        confidence   = 0.85,
                        threat_score = 70,
                        details={"key": key_path, "name": name, "data": data},
                    ))
                    # Update baseline so we don't re-alert
                    self._baseline[key_path][name] = data
                elif base_vals[name] != data:
                    self._emit(DynamicAlert(
                        alert_id     = _next_id("REG"),
                        timestamp    = _ts(),
                        source       = "registry",
                        severity     = "medium",
                        alert_type   = "modified_autorun_entry",
                        title        = f"Registry autorun modified: {name}",
                        description  = (
                            f"Existing autorun entry changed in {key_path}\n"
                            f"Name:    {name}\n"
                            f"Old:     {base_vals[name][:200]}\n"
                            f"New:     {data[:200]}"
                        ),
                        recommendation = (
                            "A legitimate software update may have modified this entry. "
                            "Verify the new value path exists and is signed. "
                            "Malware often overwrites existing run keys."
                        ),
                        confidence   = 0.65,
                        threat_score = 50,
                        details={
                            "key": key_path, "name": name,
                            "old": base_vals[name], "new": data,
                        },
                    ))
                    self._baseline[key_path][name] = data

    def _emit(self, alert: DynamicAlert) -> None:
        try:
            self._q.put_nowait(alert)
        except queue.Full:
            logger.warning("[RegistryMonitor] Alert queue full — alert dropped")


# ─────────────────────────────────────────────────────────────────────────────
#  5. DynamicEngine — umbrella
# ─────────────────────────────────────────────────────────────────────────────

class DynamicEngine:
    """
    Umbrella class that owns all real-time monitors.

    Usage
    -----
        engine = DynamicEngine(
            detection_engine = hub.detection_engine,   # existing DetectionEngine
            alert_callback   = hub._on_dynamic_alert,  # called on GUI timer
            watch_paths      = [str(target_path)],
        )
        engine.start()
        ...
        engine.stop()

    GUI integration
    ---------------
    The GUI should call engine.drain_alerts() on a periodic after() timer
    (e.g. every 250ms) to collect alerts without blocking.

        def _poll_dynamic(self):
            for alert in self.hub.dynamic_engine.drain_alerts(max_items=50):
                self._handle_dynamic_alert(alert)
            self.after(250, self._poll_dynamic)
    """

    def __init__(
        self,
        detection_engine,
        alert_callback:  Optional[Callable[[DynamicAlert], None]] = None,
        watch_paths:     Optional[List[str]] = None,
        enable_fs:       bool = True,
        enable_process:  bool = True,
        enable_memory:   bool = True,
        enable_registry: bool = True,
        scan_all_exts:   bool = False,
        fs_recursive:    bool = True,
    ):
        self._cb          = alert_callback
        self._alert_queue = queue.Queue(maxsize=2000)
        self._running     = False

        # ── Sub-monitors ──────────────────────────────────────────────────────
        self.fs_monitor: Optional[FilesystemMonitor] = None
        if enable_fs and WATCHDOG_AVAILABLE:
            paths = watch_paths or []
            if paths:
                self.fs_monitor = FilesystemMonitor(
                    alert_queue      = self._alert_queue,
                    detection_engine = detection_engine,
                    watch_paths      = paths,
                    recursive        = fs_recursive,
                    scan_all_exts    = scan_all_exts,
                )

        self.proc_monitor: Optional[ProcessMonitor] = None
        if enable_process and PSUTIL_AVAILABLE:
            self.proc_monitor = ProcessMonitor(self._alert_queue)

        self.mem_scanner: Optional[MemoryScanner] = None
        if enable_memory and PSUTIL_AVAILABLE:
            self.mem_scanner = MemoryScanner(self._alert_queue)

        self.reg_monitor: Optional[RegistryMonitor] = None
        if enable_registry and WINREG_AVAILABLE:
            self.reg_monitor = RegistryMonitor(self._alert_queue)

        # ── Dispatcher thread ─────────────────────────────────────────────────
        # Optionally runs a callback in a daemon thread so the caller
        # doesn't need to poll.  If callback is None, caller uses drain_alerts().
        self._dispatcher_thread: Optional[threading.Thread] = None

    # ── Public control ────────────────────────────────────────────────────────

    def start(self) -> Dict[str, bool]:
        """
        Start all enabled monitors.

        Returns a dict of {component: started_ok} for diagnostic display.
        """
        if self._running:
            return {}
        self._running = True
        results: Dict[str, bool] = {}

        if self.fs_monitor:
            results["filesystem"] = self.fs_monitor.start()
        if self.proc_monitor:
            results["process"]    = self.proc_monitor.start()
        if self.mem_scanner:
            results["memory"]     = self.mem_scanner.start()
        if self.reg_monitor:
            results["registry"]   = self.reg_monitor.start()

        # Start dispatcher if a callback was provided
        if self._cb:
            self._dispatcher_thread = threading.Thread(
                target=self._dispatch_loop,
                name="DynamicEngine-Dispatcher",
                daemon=True,
            )
            self._dispatcher_thread.start()

        logger.info("[DynamicEngine] Started: %s", results)
        return results

    def stop(self) -> None:
        self._running = False
        if self.fs_monitor:
            self.fs_monitor.stop()
        if self.proc_monitor:
            self.proc_monitor.stop()
        if self.mem_scanner:
            self.mem_scanner.stop()
        if self.reg_monitor:
            self.reg_monitor.stop()
        logger.info("[DynamicEngine] Stopped.")

    def add_watch_path(self, path: str) -> None:
        """Dynamically add a new filesystem watch path."""
        if self.fs_monitor:
            self.fs_monitor.add_watch_path(path)

    def drain_alerts(self, max_items: int = 100) -> List[DynamicAlert]:
        """
        Non-blocking drain of the alert queue.
        Call this from the GUI's periodic timer.
        """
        alerts: List[DynamicAlert] = []
        for _ in range(max_items):
            try:
                alerts.append(self._alert_queue.get_nowait())
            except queue.Empty:
                break
        return alerts

    def get_status(self) -> Dict[str, Any]:
        """Return runtime status of all sub-monitors."""
        return {
            "running":            self._running,
            "filesystem_active":  bool(self.fs_monitor and self.fs_monitor._running),
            "process_active":     bool(self.proc_monitor and self.proc_monitor._running),
            "memory_active":      bool(self.mem_scanner and self.mem_scanner._running),
            "registry_active":    bool(self.reg_monitor and self.reg_monitor._running),
            "queue_depth":        self._alert_queue.qsize(),
            "watchdog_available": WATCHDOG_AVAILABLE,
            "psutil_available":   PSUTIL_AVAILABLE,
            "registry_available": WINREG_AVAILABLE,
        }

    def scan_process_now(self, pid: int) -> List[DynamicAlert]:
        """Force an immediate memory scan of a single PID."""
        if self.mem_scanner:
            return self.mem_scanner.scan_pid(pid)
        return []

    # ── Internal ──────────────────────────────────────────────────────────────

    def _dispatch_loop(self) -> None:
        """Daemon thread: pulls alerts from queue and fires callback."""
        while self._running:
            try:
                alert = self._alert_queue.get(timeout=0.5)
                if self._cb:
                    try:
                        self._cb(alert)
                    except Exception as exc:
                        logger.error("[DynamicEngine] Callback error: %s", exc)
            except queue.Empty:
                continue
            except Exception as exc:
                logger.error("[DynamicEngine] Dispatcher error: %s", exc)