"""
Sentinel Defender - Configuration Module
Centralized configuration for paths, thresholds, and whitelists.
"""

import json
from pathlib import Path

# ==================== DIRECTORY CONFIGURATION ====================
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
QUARANTINE_DIR = DATA_DIR / "quarantine"
LOG_DIR = DATA_DIR / "logs"

# Ensure directories exist
DATA_DIR.mkdir(exist_ok=True)
QUARANTINE_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)

# ==================== FILE PATHS ====================
LOG_FILE = LOG_DIR / "sentinel.log"
DB_PATH = DATA_DIR / "sentinel.db"
WHITELIST_FILE = DATA_DIR / "whitelist.json"
SIGNATURE_DB = DATA_DIR / "signatures.db"

# ==================== DETECTION THRESHOLDS ====================
ENTROPY_THRESHOLD = 7.2  # High entropy suggests encryption/packing
SUSPICIOUS_IMPORTS_THRESHOLD = 3  # Number of dangerous imports to flag
HASH_SCAN_TIMEOUT = 30  # Seconds before hash scan times out

# ==================== HEURISTIC WEIGHTS ====================
HEURISTIC_WEIGHTS = {
    "high_entropy": 40,
    "suspicious_imports": 30,
    "packed_executable": 25,
    "no_version_info": 10,
    "suspicious_sections": 20,
    "parent_child_anomaly": 50,
}

THREAT_SCORE_THRESHOLD = 60  # Score >= 60 = Malicious

# ==================== SUSPICIOUS API IMPORTS ====================
SUSPICIOUS_APIS = {
    # Process Manipulation
    "CreateRemoteThread": "Process Injection",
    "WriteProcessMemory": "Memory Manipulation",
    "VirtualAllocEx": "Remote Memory Allocation",
    "SetWindowsHookEx": "Keylogging/Hooking",
    
    # Network Activity
    "InternetOpen": "Network Connection",
    "URLDownloadToFile": "File Download",
    "WinHttpOpen": "HTTP Activity",
    
    # Registry Manipulation
    "RegSetValueEx": "Registry Modification",
    "RegCreateKeyEx": "Registry Key Creation",
    
    # File Operations
    "CreateFile": "File Access",
    "DeleteFile": "File Deletion",
    "MoveFile": "File Movement",
    
    # Crypto/Obfuscation
    "CryptEncrypt": "Encryption",
    "CryptDecrypt": "Decryption",
}

# ==================== PROCESS WHITELIST ====================
DEFAULT_WHITELIST = {
    "version": "1.0",
    "last_updated": "2026-02-14",
    "safe_processes": [
        # Windows System Processes
        {"name": "System", "path": "System", "reason": "Windows Kernel"},
        {"name": "smss.exe", "path": "\\System32\\smss.exe", "reason": "Session Manager"},
        {"name": "csrss.exe", "path": "\\System32\\csrss.exe", "reason": "Client/Server Runtime"},
        {"name": "wininit.exe", "path": "\\System32\\wininit.exe", "reason": "Windows Initialization"},
        {"name": "services.exe", "path": "\\System32\\services.exe", "reason": "Service Control Manager"},
        {"name": "lsass.exe", "path": "\\System32\\lsass.exe", "reason": "Local Security Authority"},
        {"name": "svchost.exe", "path": "\\System32\\svchost.exe", "reason": "Service Host"},
        {"name": "explorer.exe", "path": "\\explorer.exe", "reason": "Windows Explorer"},
        {"name": "winlogon.exe", "path": "\\System32\\winlogon.exe", "reason": "Windows Logon"},
        
        # Linux System Processes
        {"name": "systemd", "path": "/usr/lib/systemd/systemd", "reason": "System and Service Manager"},
        {"name": "init", "path": "/sbin/init", "reason": "Init Process"},
        {"name": "kthreadd", "path": "[kthreadd]", "reason": "Kernel Thread Daemon"},
        
        # Common Applications
        {"name": "chrome.exe", "path": "Google\\Chrome\\Application\\chrome.exe", "reason": "Google Chrome"},
        {"name": "firefox.exe", "path": "Mozilla Firefox\\firefox.exe", "reason": "Mozilla Firefox"},
        {"name": "code.exe", "path": "Microsoft VS Code\\Code.exe", "reason": "Visual Studio Code"},
    ],
    
    "safe_parent_child_relationships": [
        {"parent": "explorer.exe", "child": "chrome.exe", "reason": "User launching browser"},
        {"parent": "explorer.exe", "child": "firefox.exe", "reason": "User launching browser"},
        {"parent": "services.exe", "child": "svchost.exe", "reason": "Service spawning"},
        {"parent": "chrome.exe", "child": "chrome.exe", "reason": "Browser multi-process"},
        {"parent": "code.exe", "child": "node.exe", "reason": "VS Code extensions"},
    ],
    
    "suspicious_parent_child_relationships": [
        {"parent": "winword.exe", "child": "powershell.exe", "severity": "high", "reason": "Macro-based attack vector"},
        {"parent": "excel.exe", "child": "cmd.exe", "severity": "high", "reason": "Macro-based attack vector"},
        {"parent": "outlook.exe", "child": "wscript.exe", "severity": "high", "reason": "Script execution from email"},
        {"parent": "acrobat.exe", "child": "powershell.exe", "severity": "high", "reason": "PDF exploit vector"},
        {"parent": "svchost.exe", "child": "powershell.exe", "severity": "medium", "reason": "Unusual service behavior"},
        {"parent": "notepad.exe", "child": "cmd.exe", "severity": "medium", "reason": "Text editor spawning shell"},
    ]
}

# ==================== KNOWN MALWARE HASHES (MD5) ====================
# In production, this would be a separate database file
KNOWN_MALWARE_HASHES = {
    # EICAR Test File
    "44d88612fea8a8f36de82e1278abb02f": "EICAR-Test-File",
    
    # Example malware families (educational purposes - not real hashes)
    # Real implementation would use threat intelligence feeds
}

# ==================== FILE TYPE FILTERS ====================
SCANNABLE_EXTENSIONS = {
    # Executables & scripts
    ".exe", ".dll", ".sys", ".scr", ".com", ".bat",
    ".cmd", ".ps1", ".vbs", ".js", ".jar", ".msi",
    # Python & data files
    ".py", ".pyw", ".pyc", ".json", ".xml", ".yaml", ".yml",
    # Documents
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    # Images (can carry embedded payloads / stego)
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp",
    # Text / logs
    ".txt", ".csv", ".log", ".ini", ".cfg",
}

EXECUTABLE_EXTENSIONS = {
    ".exe", ".dll", ".sys", ".scr", ".com"
}

# ==================== HELPER FUNCTIONS ====================
def load_whitelist():
    """Load whitelist from JSON file or create default."""
    if WHITELIST_FILE.exists():
        try:
            with open(WHITELIST_FILE, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError:
            print(f"[WARNING] Corrupted whitelist file. Using defaults.")
            return DEFAULT_WHITELIST
    else:
        save_whitelist(DEFAULT_WHITELIST)
        return DEFAULT_WHITELIST

def save_whitelist(whitelist_data):
    """Save whitelist to JSON file."""
    with open(WHITELIST_FILE, 'w') as f:
        json.dump(whitelist_data, f, indent=4)

def is_whitelisted_process(process_name, process_path):
    """Check if a process is in the whitelist."""
    whitelist = load_whitelist()
    for safe_process in whitelist.get("safe_processes", []):
        if process_name.lower() == safe_process["name"].lower():
            if safe_process["path"].lower() in process_path.lower():
                return True
    return False

def get_suspicious_relationship(parent_name, child_name):
    """Check if parent-child relationship is suspicious."""
    whitelist = load_whitelist()
    for rel in whitelist.get("suspicious_parent_child_relationships", []):
        if (parent_name.lower() == rel["parent"].lower() and 
            child_name.lower() == rel["child"].lower()):
            return rel
    return None

# ==================== LOGGING CONFIGURATION ====================
LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "detailed": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        },
        "simple": {
            "format": "%(levelname)s - %(message)s"
        }
    },
    "handlers": {
        "file": {
            "class": "logging.FileHandler",
            "filename": str(LOG_FILE),
            "formatter": "detailed",
            "level": "INFO"
        },
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "simple",
            "level": "WARNING"
        }
    },
    "root": {
        "level": "INFO",
        "handlers": ["file", "console"]
    }
}
