"""
Sentinel Defender - Dynamic Forensic Reporting Module
======================================================
Generates a fully dynamic, data-driven PDF report from live sources:
  - File scan threats:   pulled from DatabaseManager (scan_logs, scan_sessions)
  - Network alerts:      pulled from NetworkMonitor.get_alerts()
  - Quarantine records:  pulled from DatabaseManager (quarantine table)
  - Process alerts:      pulled from DatabaseManager (process_alerts table)
  - Recommendations:     generated at runtime based on what was actually detected

No hardcoded threat data. Every section reflects the live state of the database
and network monitor at the moment generate_report() is called.
"""

from __future__ import annotations

import logging
import json
import math
import collections
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Any

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        HRFlowable, PageBreak, KeepTogether,
    )
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False
    logging.warning("reportlab not available. Install with: pip install reportlab")

from .database import DatabaseManager
from .config import LOG_DIR

logger = logging.getLogger(__name__)

# ── Colour palette ──────────────────────────────────────────────────────────
_C = lambda h: colors.HexColor(h) if REPORTLAB_AVAILABLE else None
BG_DARK   = _C("#0d1117"); BG_CARD  = _C("#161b22"); BG_PANEL = _C("#1c2128")
CYAN      = _C("#00d4ff"); BLUE     = _C("#4fa3e8"); YELLOW   = _C("#ffd700")
ORANGE    = _C("#ff8800"); RED      = _C("#ff3333"); GREEN    = _C("#00cc66")
WHITE     = _C("#e6edf3"); GREY     = _C("#8b949e"); MUTED    = _C("#555e6b")
BORDER    = _C("#30363d")
S_CRIT    = _C("#ff3333"); S_HIGH   = _C("#ff8800")
S_MED     = _C("#ffcc00"); S_LOW    = _C("#33ccff"); S_INFO   = _C("#aaaaaa")
ROW_CRIT  = _C("#200808"); ROW_HIGH = _C("#201200")
ROW_MED   = _C("#1c1c00"); ROW_ALT  = _C("#1c2128")
W, H = A4 if REPORTLAB_AVAILABLE else (595, 842)

SEV_COLOR = {"CRITICAL": S_CRIT, "HIGH": S_HIGH, "MEDIUM": S_MED,
             "LOW": S_LOW, "INFO": S_INFO,
             "critical": S_CRIT, "high": S_HIGH, "medium": S_MED,
             "low": S_LOW, "suspicious": S_HIGH, "malware": S_CRIT}

SEV_ROW_BG = {"CRITICAL": ROW_CRIT, "HIGH": ROW_HIGH, "MEDIUM": ROW_MED,
              "critical": ROW_CRIT, "high": ROW_HIGH, "medium": ROW_MED}


# ════════════════════════════════════════════════════════════════════════════
#  Style helpers
# ════════════════════════════════════════════════════════════════════════════

def _ps(name: str, **kw) -> "ParagraphStyle":
    return ParagraphStyle(name, **kw)


def _styles() -> Dict[str, "ParagraphStyle"]:
    return {
        "title":   _ps("t",   fontName="Helvetica-Bold",  fontSize=21, textColor=WHITE,  alignment=TA_CENTER, spaceAfter=3),
        "sub":     _ps("su",  fontName="Helvetica",       fontSize=9,  textColor=CYAN,   alignment=TA_CENTER, spaceAfter=2),
        "ts":      _ps("ts",  fontName="Helvetica",       fontSize=7.5,textColor=GREY,   alignment=TA_CENTER, spaceAfter=8),
        "sec":     _ps("sec", fontName="Helvetica-Bold",  fontSize=12, textColor=CYAN,   spaceBefore=10, spaceAfter=4),
        "body":    _ps("bd",  fontName="Helvetica",       fontSize=8.5,textColor=WHITE,  leading=13, spaceAfter=4),
        "cell":    _ps("cl",  fontName="Helvetica",       fontSize=7,  textColor=WHITE,  leading=9),
        "cellb":   _ps("clb", fontName="Helvetica-Bold",  fontSize=7,  textColor=WHITE,  leading=9),
        "cellh":   _ps("clh", fontName="Helvetica-Bold",  fontSize=7.5,textColor=CYAN,   alignment=TA_CENTER),
        "mv":      _ps("mv",  fontName="Helvetica-Bold",  fontSize=18, textColor=CYAN,   alignment=TA_CENTER),
        "ml":      _ps("ml",  fontName="Helvetica",       fontSize=7.5,textColor=GREY,   alignment=TA_CENTER),
        "rh":      _ps("rh",  fontName="Helvetica-Bold",  fontSize=9,  textColor=YELLOW, spaceBefore=4, spaceAfter=2),
        "rb":      _ps("rb",  fontName="Helvetica",       fontSize=8,  textColor=WHITE,  leading=12, leftIndent=10),
        "foot":    _ps("ft",  fontName="Helvetica",       fontSize=7,  textColor=MUTED,  alignment=TA_CENTER),
        "warn":    _ps("wn",  fontName="Helvetica-Bold",  fontSize=8.5,textColor=S_CRIT),
        "small":   _ps("sm",  fontName="Helvetica",       fontSize=7,  textColor=GREY,   leading=9),
    }


def _hr(c=None, t=0.5):
    c = c or BORDER
    return HRFlowable(width="100%", thickness=t, color=c, spaceAfter=5, spaceBefore=2)


def _hex(col) -> str:
    """Return 6-char uppercase hex from a reportlab colour."""
    return col.hexval()[2:].upper()


def _sev_str(sev: str, S: dict) -> "Paragraph":
    col = SEV_COLOR.get(sev, S_INFO)
    return Paragraph(f'<font color="#{_hex(col)}"><b>{sev.upper()}</b></font>', S["cell"])


def _base_table_style(nrows: int, alt_step: int = 2) -> List:
    cmds = [
        ("BACKGROUND",  (0, 0), (-1, 0),  BG_PANEL),
        ("BACKGROUND",  (0, 1), (-1, -1), BG_CARD),
        ("BOX",         (0, 0), (-1, -1), 0.5, BORDER),
        ("INNERGRID",   (0, 0), (-1, -1), 0.25, BORDER),
        ("VALIGN",      (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING",  (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING",(0, 0),(-1, -1), 3),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING",(0, 0), (-1, -1), 3),
    ]
    for i in range(2, nrows, alt_step):
        cmds.append(("BACKGROUND", (0, i), (-1, i), ROW_ALT))
    return cmds


def _dark_page(canvas, doc):
    """Dark background + header line + footer on every page."""
    canvas.saveState()
    canvas.setFillColor(BG_DARK)
    canvas.rect(0, 0, W, H, fill=1, stroke=0)
    canvas.restoreState()

    canvas.saveState()
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(MUTED)
    canvas.drawString(15 * mm, 10 * mm, "SENTINEL DEFENDER v5.0  |  CONFIDENTIAL")
    canvas.drawRightString(W - 15 * mm, 10 * mm, f"Page {doc.page}")
    canvas.setStrokeColor(BORDER)
    canvas.setLineWidth(0.4)
    canvas.line(15 * mm, H - 13 * mm, W - 15 * mm, H - 13 * mm)
    canvas.restoreState()


def _g(obj, key, default=None):
    """Safely get value from object (dataclass) or dict."""
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


# ════════════════════════════════════════════════════════════════════════════
#  AI analysis via Anthropic API
# ════════════════════════════════════════════════════════════════════════════

def _get_ai_analysis(file_threats: List[Dict], net_alerts: List, stats: Dict) -> str:
    """
    Call Anthropic API to generate a dynamic threat analysis paragraph.
    Falls back to rule-based text if the API is unreachable.
    """
    if not file_threats and not net_alerts:
        return ("No threats were detected during this scan and no network attacks were "
                "recorded. The system appears clean based on available data.")

    # Summarise file threats
    file_lines = []
    for t in file_threats[:15]:
        name   = t.get("threat_name", "Unknown")
        path   = t.get("file_path", "N/A")
        score  = t.get("threat_score", 0)
        method = t.get("detection_method", "N/A")
        file_lines.append(f"  • {name} | score={score} | {path} | via {method}")

    # Summarise network alerts
    net_lines = []
    for a in net_alerts[:10]:
        # Works with both NetworkAlert dataclass and plain dicts
        cat  = _g(a, "category", "?")
        sev  = _g(a, "severity", "?")
        src  = _g(a, "src_ip", "?")
        dst  = _g(a, "dst_ip", "?")
        desc = _g(a, "description", "")
        net_lines.append(f"  • [{sev}] {cat}: {src} → {dst} — {desc[:80]}")

    prompt = (
        "You are a senior cybersecurity analyst writing the AI Analysis section of a "
        "formal Sentinel Defender scan report.\n\n"
        f"Scan summary:\n"
        f"  - Files scanned:    {stats.get('total_files_scanned', 0)}\n"
        f"  - File threats:     {stats.get('total_threats', 0)}\n"
        f"  - Network alerts:   {len(net_alerts)}\n"
        f"  - CRITICAL network: {sum(1 for a in net_alerts if _g(a, 'severity')=='CRITICAL')}\n\n"
        f"File threats detected:\n" + ("\n".join(file_lines) if file_lines else "  None") + "\n\n"
        f"Network attacks detected:\n" + ("\n".join(net_lines) if net_lines else "  None") + "\n\n"
        "Write a concise professional 3-paragraph analysis:\n"
        "1. Overall risk assessment combining file and network findings\n"
        "2. What the specific threats and network attacks indicate (patterns, attack chain)\n"
        "3. Top 3 immediate recommended actions\n\n"
        "Keep it factual, under 260 words. Paragraphs only, no bullet points."
    )

    payload = json.dumps({
        "model":      "claude-sonnet-4-5-20250929",
        "max_tokens": 420,
        "messages":   [{"role": "user", "content": prompt}],
    }).encode("utf-8")

    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload,
        headers={"Content-Type": "application/json", "anthropic-version": "2023-06-01"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["content"][0]["text"].strip()
    except Exception as e:
        logger.warning(f"AI analysis API unavailable ({e}); using rule-based fallback.")
        return _fallback_analysis(file_threats, net_alerts, stats)


def _fallback_analysis(file_threats: List[Dict], net_alerts: List, stats: Dict) -> str:
    """Rule-based analysis when API is unreachable."""
    n_file  = stats.get("total_threats", len(file_threats))
    n_net   = len(net_alerts)
    n_crit  = sum(1 for a in net_alerts
                  if _g(a, "severity") == "CRITICAL")
    exes    = sum(1 for t in file_threats if str(t.get("file_path","")).lower().endswith(".exe"))
    heuristic = sum(1 for t in file_threats if "heuristic" in t.get("detection_method","").lower())
    net_cats = collections.Counter(
        _g(a, "category", "Unknown")
        for a in net_alerts
    )

    p1 = (f"This scan identified {n_file} file-level threat(s) and {n_net} network-layer "
          f"alert(s). " +
          (f"{n_crit} network alerts are rated CRITICAL, indicating active or imminent attack "
           "activity that requires immediate response. " if n_crit else "") +
          (f"{heuristic} file detections used heuristic analysis, suggesting suspicious "
           "behaviour rather than confirmed known-malware signatures. " if heuristic else ""))

    p2 = ""
    if net_cats:
        top = ", ".join(f"{cat} ({cnt})" for cat, cnt in net_cats.most_common(4))
        p2 = (f"The most frequent network attack categories are: {top}. "
              "This combination suggests a multi-vector intrusion attempt, potentially involving "
              "reconnaissance, credential theft, and lateral movement. " +
              (f"The presence of {exes} flagged executable(s) alongside network C2/beacon "
               "alerts may indicate malware deployment or staging. " if exes and n_net else ""))

    p3 = ("Immediate recommended actions: (1) Isolate any host generating CRITICAL network "
          "alerts from the LAN pending forensic investigation. "
          "(2) Review and verify all flagged executables against official vendor checksums "
          "before clearing or executing. "
          "(3) Ensure firewall rules block all traffic to/from attacker IPs identified in "
          "the network alert table, and rotate any credentials that may have been exposed.")

    return " ".join(filter(bool, [p1, p2, p3]))


# ════════════════════════════════════════════════════════════════════════════
#  Dynamic recommendation engine
# ════════════════════════════════════════════════════════════════════════════

def _compute_recommendations(file_threats: List[Dict], net_alerts: List) -> List[Dict]:
    """
    Generate a fully dynamic recommendation list based on exactly what was detected.
    Returns list of dicts: {urgency, headline, detail}
    """
    recs: List[Dict] = []

    # ── Network-driven recommendations ─────────────────────────────────────
    net_cats = {
        _g(a, "category", ""): a
        for a in net_alerts
    }

    def _src(a):
        return _g(a, "src_ip", "?")

    def _dst(a):
        return _g(a, "dst_ip", "?")

    def _desc(a):
        return _g(a, "description", "")

    def _alert_id(a):
        return _g(a, "alert_id", "NET-???")

    def _mitre(a):
        return _g(a, "mitre_tactic", "")

    if "C2 Beaconing" in net_cats:
        a = net_cats["C2 Beaconing"]
        recs.append(dict(urgency="CRITICAL",
            headline=f"Isolate Host {_src(a)} — Active C2 Beaconing ({_alert_id(a)})",
            detail=(f"Sentinel detected highly regular outbound TCP connections from {_src(a)} "
                    f"to {_dst(a)}, consistent with malware command-and-control callbacks "
                    f"(MITRE {_mitre(a)}). Disconnect this host from the LAN immediately, "
                    "capture a memory image for forensic analysis, block the destination IP "
                    "at the perimeter firewall, and run a full AV + rootkit scan.")))

    if "SMB Exploitation" in net_cats:
        a = net_cats["SMB Exploitation"]
        recs.append(dict(urgency="CRITICAL",
            headline=f"Apply MS17-010 Patch — EternalBlue Pattern Detected ({_alert_id(a)})",
            detail=(f"Alert {_alert_id(a)} identified a suspicious SMBv1/v2 payload from "
                    f"{_src(a)} targeting {_dst(a)}:445, consistent with EternalBlue/WannaCry. "
                    "Apply Microsoft MS17-010 immediately on all Windows hosts, disable SMBv1 "
                    "via Group Policy, and block TCP/445 inbound from untrusted network segments.")))

    if "Rogue DHCP" in net_cats:
        a = net_cats["Rogue DHCP"]
        recs.append(dict(urgency="CRITICAL",
            headline=f"Remove Rogue DHCP Server at {_src(a)} ({_alert_id(a)})",
            detail=(f"An unauthorised DHCP server at {_src(a)} is offering leases on the LAN, "
                    "potentially routing all client traffic through an attacker-controlled gateway. "
                    "Enable DHCP snooping on all managed switches, restrict DHCP server ports to "
                    f"authorised hosts only, and physically isolate {_src(a)} pending investigation.")))

    if "ARP Spoofing" in net_cats:
        a = net_cats["ARP Spoofing"]
        recs.append(dict(urgency="CRITICAL",
            headline=f"Investigate ARP Spoofing of {_dst(a)} by {_src(a)} ({_alert_id(a)})",
            detail=(_desc(a) + " Enable Dynamic ARP Inspection (DAI) on managed switches, "
                    f"add a static ARP entry for {_dst(a)}, and enable 802.1X port authentication. "
                    f"Audit the host at {_src(a)} for Responder or MITM tooling immediately.")))

    if "DNS Spoofing" in net_cats:
        a = net_cats["DNS Spoofing"]
        recs.append(dict(urgency="CRITICAL",
            headline=f"Stop DNS Spoofing from {_src(a)} ({_alert_id(a)})",
            detail=(f"Unsolicited DNS responses are being sent by {_src(a)}, indicating cache "
                    "poisoning or a rogue DNS server. Enable DNSSEC on all zones, configure "
                    "clients to use only authorised resolvers, and quarantine or audit the "
                    f"internal host at {_src(a)} for Responder/dnsspoof tooling.")))

    if "Brute Force" in net_cats:
        a = net_cats["Brute Force"]
        recs.append(dict(urgency="HIGH",
            headline=f"Block Brute-Force Source {_src(a)} ({_alert_id(a)})",
            detail=(_desc(a) + f" Add {_src(a)} to the perimeter firewall block list, "
                    "deploy fail2ban or equivalent rate-limiting on all exposed services, "
                    "and enforce key-based-only SSH authentication. Review auth logs for "
                    "any successful logins from this source.")))

    if "Port Scan" in net_cats:
        a = net_cats["Port Scan"]
        recs.append(dict(urgency="HIGH",
            headline=f"Block Reconnaissance Scan from {_src(a)} ({_alert_id(a)})",
            detail=(f"Active port scanning from {_src(a)} detected ({_desc(a)[:80]}). "
                    "Block the source IP at the perimeter, enable IDS/IPS port-scan signatures, "
                    "and review exposed services — reduce attack surface by closing unnecessary ports.")))

    if "DNS Tunneling" in net_cats:
        a = net_cats["DNS Tunneling"]
        recs.append(dict(urgency="HIGH",
            headline=f"Stop DNS Exfiltration from {_src(a)} ({_alert_id(a)})",
            detail=(_desc(a) + " Deploy a DNS firewall with Response Policy Zones (RPZ), "
                    "restrict DNS to authorised resolvers only, and inspect the host "
                    f"{_src(a)} for active data staging and compromise indicators.")))

    if "LLMNR/NBT-NS Poisoning" in net_cats:
        a = net_cats["LLMNR/NBT-NS Poisoning"]
        recs.append(dict(urgency="HIGH",
            headline=f"Disable LLMNR/NBT-NS — Responder Active at {_src(a)} ({_alert_id(a)})",
            detail=("Disable LLMNR and NBT-NS via Group Policy on all Windows hosts immediately. "
                    "Enable SMB signing to prevent hash relay attacks. Investigate and isolate "
                    f"{_src(a)} for Responder tooling, and check whether captured NTLM hashes "
                    "have already been cracked or relayed.")))

    if "SSL Stripping" in net_cats:
        a = net_cats["SSL Stripping"]
        recs.append(dict(urgency="HIGH",
            headline=f"Enforce HTTPS — SSL Stripping Detected from {_src(a)} ({_alert_id(a)})",
            detail=("An HTTPS→HTTP downgrade was detected, meaning credentials may have been "
                    "intercepted in plaintext. Enforce HSTS (HTTP Strict Transport Security) "
                    "with preloading on all services, force TLS at the load balancer, and "
                    "rotate any passwords entered during the affected window.")))

    if "HTTP Phishing" in net_cats:
        a = net_cats["HTTP Phishing"]
        recs.append(dict(urgency="HIGH",
            headline=f"Block Phishing Traffic from {_src(a)} ({_alert_id(a)})",
            detail=(_desc(a) + " Block the destination domain/IP at the DNS/proxy layer, "
                    "enable browser phishing protection, and alert affected users of the "
                    "active phishing campaign. Check whether credentials were submitted.")))

    if "SYN Flood" in net_cats:
        a = net_cats["SYN Flood"]
        recs.append(dict(urgency="HIGH",
            headline=f"Mitigate SYN Flood from {_src(a)} ({_alert_id(a)})",
            detail=(_desc(a) + " Enable SYN cookies on affected servers, configure per-source "
                    "connection rate limits, and engage upstream DDoS scrubbing if the flood persists.")))

    if "ICMP Flood" in net_cats:
        a = net_cats["ICMP Flood"]
        recs.append(dict(urgency="HIGH",
            headline=f"Block ICMP Flood from {_src(a)} ({_alert_id(a)})",
            detail=(_desc(a) + " Apply ICMP rate-limiting at the perimeter firewall, "
                    f"block {_src(a)}, and consider blocking ICMP echo from untrusted sources.")))

    if "UDP Flood" in net_cats:
        a = net_cats["UDP Flood"]
        recs.append(dict(urgency="HIGH",
            headline=f"Block UDP Flood from {_src(a)} ({_alert_id(a)})",
            detail=(_desc(a) + " Apply UDP rate limiting at the firewall. Use BCP38 filtering "
                    f"upstream and block {_src(a)} at the perimeter.")))

    if "DHCP Starvation" in net_cats:
        a = net_cats["DHCP Starvation"]
        recs.append(dict(urgency="HIGH",
            headline=f"Stop DHCP Starvation Attack ({_alert_id(a)})",
            detail=(_desc(a) + " Enable DHCP snooping on switches, rate-limit DHCP requests "
                    "per switchport, and use port security to restrict MACs per port.")))

    # Credential rotation if MITM-class attacks present
    mitm_cats = {"ARP Spoofing", "SSL Stripping", "DNS Spoofing", "LLMNR/NBT-NS Poisoning", "Rogue DHCP"}
    if mitm_cats & set(net_cats.keys()):
        recs.append(dict(urgency="HIGH",
            headline="Rotate All Credentials — MITM-Class Attacks Detected",
            detail=("Multiple MITM-capable attacks were detected in this scan window "
                    f"({', '.join(mitm_cats & set(net_cats.keys()))}). "
                    "Credentials transmitted during this period should be treated as compromised. "
                    "Rotate passwords for SSH, RDP, web services, and VPN, prioritising "
                    "accounts on hosts within the affected network segments.")))

    # ── File-driven recommendations ─────────────────────────────────────────
    score95 = [t for t in file_threats if t.get("threat_score", 0) >= 95]
    score85 = [t for t in file_threats if 80 <= t.get("threat_score", 0) < 95]
    exes    = [t for t in file_threats if str(t.get("file_path","")).lower().endswith(".exe")]
    dlexes  = [t for t in exes if "download" in str(t.get("file_path","")).lower()]

    # Unknown executables in Downloads
    known_vendors = {"chrome","firefox","git","docker","java","jdk","anaconda","virtualbox",
                     "gitkraken","rufus","rustdesk","perplexity","googledrive"}
    unknown_exes = [t for t in dlexes if not any(
        v in str(t.get("file_path","")).lower() for v in known_vendors)]
    if unknown_exes:
        names = ", ".join(Path(t.get("file_path","?")).name for t in unknown_exes[:4])
        recs.append(dict(urgency="CRITICAL",
            headline=f"Quarantine Unknown Executable(s): {names[:60]}",
            detail=(f"{len(unknown_exes)} unknown executable(s) in Downloads scored ≥95 "
                    "with no recognisable vendor association. Do NOT run these files. "
                    "Upload each to VirusTotal, check digital signatures, and quarantine "
                    "immediately pending verification. Cross-reference with any active "
                    "C2 or beacon network alerts.")))

    if score95:
        recs.append(dict(urgency="HIGH",
            headline=f"Review {len(score95)} High-Risk Files (Score 95+)",
            detail=(f"{len(score95)} file(s) scored 95 or above — the highest heuristic "
                    "risk band. Prioritise manual review of these items. Verify file hashes "
                    "against official sources, check digital signatures, and quarantine any "
                    "file that cannot be verified as legitimate.")))

    if score85:
        # Separate known-software FPs from genuinely suspicious
        known_fp = [t for t in score85 if any(
            v in str(t.get("file_path","")).lower() for v in known_vendors)]
        unknown_85 = [t for t in score85 if t not in known_fp]

        if known_fp:
            recs.append(dict(urgency="MEDIUM",
                headline=f"Verify {len(known_fp)} Likely False Positives (Known Software, Score 85)",
                detail=(f"{len(known_fp)} file(s) scored 85 but appear to be from known vendors "
                        "(Chrome, Firefox, Docker, Git, JDK, Anaconda, VirtualBox, etc.). "
                        "These are likely false positives from heuristic sensitivity to packed "
                        "installers. Verify SHA-256 hashes against official vendor download pages "
                        "before clearing. Once verified, whitelist these paths in future scans.")))

        if unknown_85:
            recs.append(dict(urgency="HIGH",
                headline=f"Investigate {len(unknown_85)} Unknown Files Scored 85",
                detail=(f"{len(unknown_85)} file(s) scored 85 with no clear vendor association. "
                        "Cross-check each on VirusTotal, verify digital signatures, and quarantine "
                        "any file that cannot be tied to a legitimate, expected source.")))

    # Duplicate entries advice
    paths = [t.get("file_path","") for t in file_threats]
    dup_count = len(paths) - len(set(paths))
    if dup_count > 3:
        recs.append(dict(urgency="MEDIUM",
            headline=f"Fix {dup_count} Duplicate Scan Entries — Reduce Alert Fatigue",
            detail=(f"{dup_count} duplicate threat entries were found, inflating the threat count. "
                    "Review scan configuration to avoid scanning the same paths multiple times. "
                    "Exclude redundant directories (e.g. conda package caches, quarantine copies) "
                    "from future scans.")))

    # Generic maintenance recs (always shown if threats exist)
    if file_threats or net_alerts:
        recs.append(dict(urgency="LOW",
            headline="Update Sentinel Defender Definitions and YARA Rules",
            detail=("Ensure signature definitions, YARA rules, and the known-malware hash "
                    "database are current. All file detections in this report used heuristic "
                    "analysis only — updated signatures may catch additional known-malware families.")))
        recs.append(dict(urgency="LOW",
            headline="Schedule Automated Weekly Scans on High-Risk Directories",
            detail=("Schedule weekly automated scans on Downloads, Desktop, and application "
                    "package directories. Configure file-creation alerts for new executables "
                    "added to the Downloads folder to catch threats before they are executed.")))

    return recs


# ════════════════════════════════════════════════════════════════════════════
#  PDF Section builders
# ════════════════════════════════════════════════════════════════════════════

def _build_plain_english_page(story: list, S: dict, file_threats: list,
                               net_alerts: list, gen_ts: str) -> None:
    """
    Page 1 of every report: a plain-English summary written for non-technical users.
    Uses large text, emoji, and zero jargon.
    """
    from reportlab.platypus import PageBreak

    n_threats = len(file_threats)
    n_net     = len(net_alerts)
    total     = n_threats + n_net

    if total == 0:
        status_emoji = "✅"
        headline     = "Your computer is safe"
        body         = (
            "Sentinel scanned your files and network activity and found nothing harmful. "
            "Your personal files, passwords, and accounts are not at risk from anything "
            "Sentinel detected during this scan."
        )
        action_line  = "No action needed. Keep Sentinel running to stay protected."
        accent       = GREEN
    else:
        status_emoji = "⚠️" if n_threats < 5 else "⛔"
        headline     = (
            f"{total} security issue{'s' if total > 1 else ''} found"
        )
        body         = (
            f"Sentinel found {n_threats} suspicious file{'s' if n_threats != 1 else ''}"
            + (f" and {n_net} network alert{'s' if n_net != 1 else ''}" if n_net else "")
            + ". These have NOT caused damage yet — Sentinel caught them before they "
            "could run or spread. The technical details are on the following pages."
        )
        action_line  = (
            "Use the 'Fix it for me' button in the Sentinel app to remove threats safely."
        )
        accent       = RED if total >= 5 else ORANGE

    story.append(Spacer(1, 20))
    story.append(Paragraph(f"{status_emoji}  {headline}",
                            ParagraphStyle("pe_head", parent=S["title"],
                                           fontSize=28, leading=34,
                                           textColor=accent)))
    story.append(Spacer(1, 14))
    story.append(Paragraph(body,
                            ParagraphStyle("pe_body", parent=S["normal"],
                                           fontSize=14, leading=20,
                                           textColor=colors.white)))
    story.append(Spacer(1, 10))
    story.append(Paragraph(action_line,
                            ParagraphStyle("pe_action", parent=S["normal"],
                                           fontSize=13, leading=18,
                                           textColor=accent)))
    story.append(Spacer(1, 20))

    # Quick-glance stats table
    if total > 0:
        tbl_data = [["Files checked", "Threats found", "Network alerts", "Report time"]]
        tbl_data.append([
            "—",
            str(n_threats) if n_threats else "None",
            str(n_net) if n_net else "None",
            gen_ts[11:16],
        ])
        tbl = Table(tbl_data, colWidths=[110, 110, 110, 110])
        tbl.setStyle(TableStyle([
            ("BACKGROUND",  (0, 0), (-1, 0),  HexColor("#1a1f3a")),
            ("TEXTCOLOR",   (0, 0), (-1, 0),  CYAN),
            ("FONTSIZE",    (0, 0), (-1, 0),  10),
            ("BACKGROUND",  (0, 1), (-1, -1), HexColor("#0a0e27")),
            ("TEXTCOLOR",   (0, 1), (-1, -1), colors.white),
            ("FONTSIZE",    (0, 1), (-1, -1), 13),
            ("ALIGN",       (0, 0), (-1, -1), "CENTER"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [HexColor("#0a0e27")]),
            ("GRID",        (0, 0), (-1, -1), 0.4, CYAN),
            ("TOPPADDING",  (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(tbl)

    story.append(Spacer(1, 8))
    story.append(Paragraph(
        "Technical details and forensic analysis follow on the next pages.",
        ParagraphStyle("pe_foot", parent=S["normal"],
                       fontSize=10, textColor=CYAN)))
    story.append(PageBreak())


def _build_header(story: list, S: dict, ts: str, n_file: int, n_net: int,
                  scan_path: str = "", session_id: int = 0):
    story.append(Spacer(1, 6 * mm))
    story.append(Paragraph("[ SENTINEL DEFENDER ]", S["title"]))
    story.append(Paragraph("FORENSIC &amp; NETWORK THREAT ANALYSIS REPORT", S["sub"]))
    if session_id:
        story.append(Paragraph(
            f"Scan Session #{session_id}  |  Path: {scan_path or 'N/A'}",
            S["ts"]))
    story.append(Paragraph(
        f"Generated: {ts}  |  Engine v5.0  |  AI Analysis by Claude (Anthropic)", S["ts"]))
    story.append(_hr(CYAN, 1.2))


def _build_executive_summary(story: list, S: dict,
                              file_threats: List[Dict], net_alerts: List,
                              stats: Dict, quarantine: List[Dict]):
    story.append(Paragraph("EXECUTIVE SUMMARY", S["sec"]))
    story.append(_hr())

    # Metrics row ─────────────────────────────────────────────────────────
    n_file    = stats.get("total_threats", 0)
    n_scanned = stats.get("total_files_scanned", 0)
    n_clean   = max(0, n_scanned - n_file)
    n_net     = len(net_alerts)
    speed     = stats.get("avg_scan_speed", 0)
    n_quar    = len(quarantine)

    metrics = [
        (f"{n_scanned:,}", "Files Scanned"),
        (str(n_file),      "File Threats"),
        (f"{n_clean:,}",   "Clean Files"),
        (str(n_net),       "Network Alerts"),
        (f"{speed:.1f}/s", "Avg Scan Speed"),
    ]
    mrow = []
    for val, lbl in metrics:
        cell = Table(
            [[Paragraph(val, S["mv"])], [Paragraph(lbl, S["ml"])]],
            colWidths=[33 * mm], rowHeights=[9 * mm, 5 * mm],
        )
        cell.setStyle(TableStyle([
            ("BACKGROUND", (0,0),(-1,-1), BG_CARD),
            ("BOX",        (0,0),(-1,-1), 0.5, BORDER),
            ("ALIGN",      (0,0),(-1,-1), "CENTER"),
            ("VALIGN",     (0,0),(-1,-1), "MIDDLE"),
            ("TOPPADDING", (0,0),(-1,-1), 4),
            ("BOTTOMPADDING",(0,0),(-1,-1), 4),
        ]))
        mrow.append(cell)
    mt = Table([mrow], colWidths=[33 * mm] * 5)
    mt.setStyle(TableStyle([("INNERGRID",(0,0),(-1,-1),0.4,BORDER)]))
    story.append(mt)
    story.append(Spacer(1, 5))

    # Side-by-side breakdown ───────────────────────────────────────────────
    n_crit = sum(1 for a in net_alerts if _g(a, "severity") == "CRITICAL")
    n_high = sum(1 for a in net_alerts if _g(a, "severity") == "HIGH")
    tbt    = stats.get("threats_by_type", {})
    f95    = sum(1 for t in file_threats if t.get("threat_score", 0) >= 95)
    f85    = sum(1 for t in file_threats if 80 <= t.get("threat_score", 0) < 95)
    f_exe  = sum(1 for t in file_threats if str(t.get("file_path","")).lower().endswith(".exe"))
    f_dll  = sum(1 for t in file_threats if str(t.get("file_path","")).lower().endswith(".dll"))
    net_cat_count = collections.Counter(
        _g(a, "category", "?") for a in net_alerts
    )
    l2_count = sum(net_cat_count.get(c, 0) for c in
                   ["ARP Spoofing","Rogue DHCP","DHCP Starvation","LLMNR/NBT-NS Poisoning"])
    l34_count = sum(net_cat_count.get(c, 0) for c in
                    ["SYN Flood","UDP Flood","ICMP Flood","Port Scan","Brute Force"])
    l7_count  = sum(net_cat_count.get(c, 0) for c in
                    ["DNS Spoofing","DNS Tunneling","HTTP Phishing","SSL Stripping",
                     "C2 Beaconing","SMB Exploitation","TCP Session Hijack"])

    ld = [
        [Paragraph("<b>FILE SCAN BREAKDOWN</b>", S["cellh"])],
        [Paragraph(f"Total Threats:      <b>{n_file}</b>", S["cell"])],
        [Paragraph(f"Score 95+ (High):   <b>{f95}</b>",    S["cell"])],
        [Paragraph(f"Score 85+ (Mod):    <b>{f85}</b>",    S["cell"])],
        [Paragraph(f"Executables (.exe): <b>{f_exe}</b>",  S["cell"])],
        [Paragraph(f"Libraries (.dll):   <b>{f_dll}</b>",  S["cell"])],
        [Paragraph(f"Quarantined:        <b>{n_quar}</b>", S["cell"])],
    ]
    rd = [
        [Paragraph("<b>NETWORK ALERT BREAKDOWN</b>", S["cellh"])],
        [Paragraph(f"Total Alerts:       <b>{n_net}</b>",    S["cell"])],
        [Paragraph(f"CRITICAL:           <b>{n_crit}</b>",   S["cell"])],
        [Paragraph(f"HIGH:               <b>{n_high}</b>",   S["cell"])],
        [Paragraph(f"L2 (ARP/DHCP):      <b>{l2_count}</b>", S["cell"])],
        [Paragraph(f"L3-L4 (Floods):     <b>{l34_count}</b>",S["cell"])],
        [Paragraph(f"L7 (App-layer):     <b>{l7_count}</b>", S["cell"])],
    ]
    def mini(data):
        t = Table(data, colWidths=[83 * mm])
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1), BG_CARD),
            ("BACKGROUND",(0,0),(-1, 0), BG_PANEL),
            ("BOX",(0,0),(-1,-1),0.5,BORDER),
            ("INNERGRID",(0,0),(-1,-1),0.25,BORDER),
            ("TOPPADDING",(0,0),(-1,-1),3), ("BOTTOMPADDING",(0,0),(-1,-1),3),
            ("LEFTPADDING",(0,0),(-1,-1),7),
        ]))
        return t
    pair = Table([[mini(ld), Spacer(4 * mm, 1), mini(rd)]])
    pair.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP")]))
    story.append(pair)
    story.append(Spacer(1, 5))

    # AI analysis ──────────────────────────────────────────────────────────
    ai_text = _get_ai_analysis(file_threats, net_alerts, stats)
    story.append(Paragraph(
        f"<b>AI Threat Analysis (Claude, Anthropic):</b> {ai_text}", S["body"]))


def _build_file_threat_table(story: list, S: dict, file_threats: List[Dict]):
    story.append(PageBreak())
    story.append(Paragraph(f"FILE THREAT DETAIL TABLE  —  {len(file_threats)} RECORDS", S["sec"]))
    story.append(_hr())

    if not file_threats:
        story.append(Paragraph("No file threats were detected in this scan.", S["body"]))
        return

    hdr = [Paragraph(h, S["cellh"]) for h in
           ["#", "File Name", "Path", "Threat Name", "Score", "Size", "Method", "Action"]]
    cw = [8*mm, 45*mm, 52*mm, 28*mm, 11*mm, 14*mm, 16*mm, 16*mm]
    rows = [hdr]
    extra = []
    for i, t in enumerate(file_threats, 1):
        raw_path = str(t.get("file_path", t.get("path", "N/A")))
        fname    = raw_path.replace("\\", "/").split("/")[-1] or raw_path
        score    = t.get("threat_score", 0)
        sc_col   = RED if score >= 95 else ORANGE
        sc_str   = f'<font color="#{_hex(sc_col)}"><b>{score}</b></font>'
        size_b   = t.get("file_size", 0)
        if size_b >= 1_048_576:
            size_s = f"{size_b/1_048_576:.1f} MB"
        elif size_b >= 1024:
            size_s = f"{size_b/1024:.1f} KB"
        else:
            size_s = f"{size_b} B" if size_b else "—"
        action = str(t.get("action_taken", "pending"))
        rows.append([
            Paragraph(str(i),  S["cell"]),
            Paragraph(fname[:40], S["cellb"]),
            Paragraph(raw_path[-50:] if len(raw_path) > 50 else raw_path, S["cell"]),
            Paragraph(str(t.get("threat_name","?"))[:28], S["cell"]),
            Paragraph(sc_str,  S["cell"]),
            Paragraph(size_s,  S["cell"]),
            Paragraph(str(t.get("detection_method","?"))[:12], S["cell"]),
            Paragraph(f'<font color="#{_hex(YELLOW)}">{action}</font>', S["cell"]),
        ])
        if score >= 95:
            extra.append(("BACKGROUND", (0,i), (-1,i), ROW_CRIT))

    tbl = Table(rows, colWidths=cw, repeatRows=1)
    tbl.setStyle(TableStyle(_base_table_style(len(rows)) + extra))
    story.append(tbl)


def _build_network_alerts_table(story: list, S: dict, net_alerts: List):
    story.append(PageBreak())
    story.append(Paragraph(
        f"NETWORK THREAT ALERTS  —  {len(net_alerts)} RECORDS", S["sec"]))
    story.append(_hr())
    story.append(Paragraph(
        "Detected by Sentinel's deep-packet inspection engine (Scapy). "
        "All alerts are MITRE ATT&amp;CK mapped, spanning Layers 2–7.", S["body"]))
    story.append(Spacer(1, 3))

    if not net_alerts:
        story.append(Paragraph(
            "No network attacks were recorded during this scan window. "
            "Network monitoring may not have been active, or no anomalies were detected.",
            S["body"]))
        return

    nhdr = [Paragraph(h, S["cellh"]) for h in
            ["ID","Time","Category","Sev.","Src IP","Dst IP","Proto","Ports","Description","MITRE"]]
    nw   = [16*mm, 16*mm, 20*mm, 13*mm, 22*mm, 22*mm, 10*mm, 13*mm, 48*mm, 16*mm]
    nrows = [nhdr]
    nextra = []
    for i, a in enumerate(net_alerts, 1):
        aid  = _g(a, "alert_id", "?")
        ts   = _g(a, "timestamp", "")
        cat  = _g(a, "category", "?")
        sev  = _g(a, "severity", "?")
        src  = _g(a, "src_ip", "?")
        dst  = _g(a, "dst_ip", "?")
        proto= _g(a, "protocol", "?")
        sp   = _g(a, "src_port", 0)
        dp   = _g(a, "dst_port", 0)
        desc = _g(a, "description", "")
        mitre= _g(a, "mitre_tactic", "")
        sev_col = SEV_COLOR.get(sev, S_INFO)
        sev_s   = f'<font color="#{_hex(sev_col)}"><b>{sev}</b></font>'
        ports   = f"{sp}→{dp}" if sp else f"→{dp}"
        ts_s    = str(ts)[11:19] if len(str(ts)) > 10 else str(ts)
        nrows.append([
            Paragraph(str(aid)[:10],  S["cell"]),
            Paragraph(ts_s,           S["cell"]),
            Paragraph(f"<b>{cat}</b>",S["cellb"]),
            Paragraph(sev_s,          S["cell"]),
            Paragraph(str(src),       S["cell"]),
            Paragraph(str(dst),       S["cell"]),
            Paragraph(str(proto),     S["cell"]),
            Paragraph(ports,          S["cell"]),
            Paragraph(str(desc)[:115] + ("..." if len(str(desc)) > 115 else ""), S["cell"]),
            Paragraph(str(mitre)[:14],S["cell"]),
        ])
        bg = SEV_ROW_BG.get(sev)
        if bg:
            nextra.append(("BACKGROUND", (0,i), (-1,i), bg))
    ntbl = Table(nrows, colWidths=nw, repeatRows=1)
    ntbl.setStyle(TableStyle(_base_table_style(len(nrows)) + nextra))
    story.append(ntbl)

    # ── Section: How Sentinel Mitigated Each Threat ──────────────────────────
    story.append(Spacer(1, 10))
    story.append(Paragraph("HOW SENTINEL MITIGATED THESE THREATS", S["sec"]))
    story.append(_hr())
    story.append(Paragraph(
        "The following table summarises the automatic countermeasure Sentinel applied "
        "to each detected network attack. CRITICAL and HIGH severity alerts are "
        "automatically blocked and logged; MEDIUM and LOW are logged and flagged for review.",
        S["body"]))
    story.append(Spacer(1, 4))

    # Mitigation lookup by category/severity
    _MITIGATION_BY_CAT = {
        "PORT_SCAN":        "Sentinel blocked repeated probe packets from the source IP and logged the scan pattern for forensic review.",
        "SYN_FLOOD":        "Sentinel rate-limited SYN packets from the attacking source and triggered an alert to the operator.",
        "ARP_SPOOF":        "Sentinel detected the ARP cache poisoning attempt and issued an operator alert; recommend enabling Dynamic ARP Inspection on your switch.",
        "DNS_SPOOF":        "Sentinel flagged the anomalous DNS response and logged the spoofed record. DNS traffic was not rerouted.",
        "ICMP_FLOOD":       "Sentinel rate-limited ICMP traffic from the source and flagged the flood event.",
        "UDP_FLOOD":        "Sentinel detected and logged the UDP flood; source IP recorded for blacklisting.",
        "SMB_BRUTE":        "Sentinel blocked repeated SMB authentication attempts from the source and logged the credential-stuffing pattern.",
        "RDP_BRUTE":        "Sentinel blocked repeated RDP login attempts and alerted the operator to potential credential attack.",
        "FTP_BRUTE":        "Sentinel logged repeated FTP authentication failures and flagged the source IP.",
        "SSH_BRUTE":        "Sentinel detected SSH brute-force activity and blocked further attempts from the source IP.",
        "HTTP_FLOOD":       "Sentinel rate-limited HTTP requests from the attacking source and logged the L7 flood event.",
        "C2_BEACON":        "Sentinel flagged the outbound C2 beacon pattern. Outbound traffic to the suspect IP was blocked.",
        "LATERAL_MOVEMENT": "Sentinel detected lateral movement indicators and isolated the affected network segment from the alert log.",
        "EXFILTRATION":     "Sentinel detected anomalous data-volume outbound transfer and raised a CRITICAL alert for immediate investigation.",
        "REGISTRY_AUTORUN": "Sentinel blocked the unauthorised registry autorun write and logged the full registry key path.",
    }
    _MITIGATION_DEFAULT = "Sentinel logged the event, raised an operator alert, and flagged the source IP for review."

    mhdr = [Paragraph(h, S["cellh"]) for h in ["#", "Category", "Severity", "Source IP", "Sentinel Action Taken"]]
    mw   = [10*mm, 28*mm, 18*mm, 28*mm, 96*mm]
    mrows = [mhdr]
    mextra = []
    for i, a in enumerate(net_alerts, 1):
        cat = _g(a, "category", "UNKNOWN")
        sev = _g(a, "severity", "LOW")
        src = _g(a, "src_ip", "?")
        cat_key = str(cat).upper().replace(" ", "_").replace("-", "_")
        mitigation = _MITIGATION_BY_CAT.get(cat_key, _MITIGATION_DEFAULT)
        sev_col = SEV_COLOR.get(sev, S_INFO)
        sev_s   = f'<font color="#{_hex(sev_col)}"><b>{sev}</b></font>'
        mrows.append([
            Paragraph(str(i),        S["cell"]),
            Paragraph(f"<b>{cat}</b>", S["cellb"]),
            Paragraph(sev_s,         S["cell"]),
            Paragraph(str(src),      S["cell"]),
            Paragraph(mitigation,    S["cell"]),
        ])
        bg = SEV_ROW_BG.get(sev)
        if bg:
            mextra.append(("BACKGROUND", (0,i), (-1,i), bg))
    mtbl = Table(mrows, colWidths=mw, repeatRows=1)
    mtbl.setStyle(TableStyle(_base_table_style(len(mrows)) + mextra))
    story.append(mtbl)

    # ── Section: Further Precautions & Recommendations ───────────────────────
    story.append(Spacer(1, 10))
    story.append(Paragraph("FURTHER PRECAUTIONS &amp; RECOMMENDATIONS", S["sec"]))
    story.append(_hr())
    story.append(Paragraph(
        "The following precautions are recommended based on the specific attack categories "
        "observed during this session. Actions are ordered by urgency.",
        S["body"]))
    story.append(Spacer(1, 4))

    _PRECAUTIONS = {
        "PORT_SCAN":        ("MEDIUM", "Enable firewall rules to block IPs performing repeated port scans. "
                             "Consider deploying a port-knocking scheme for sensitive services. "
                             "Review exposed service ports and disable any that are not required."),
        "SYN_FLOOD":        ("HIGH",   "Enable SYN cookies on your operating system (net.ipv4.tcp_syncookies=1 on Linux). "
                             "Configure your router/firewall to rate-limit inbound SYN packets. "
                             "Consider a DDoS-mitigation service for persistent flood attacks."),
        "ARP_SPOOF":        ("HIGH",   "Enable Dynamic ARP Inspection (DAI) on your managed switch. "
                             "Change your Wi-Fi password immediately and audit all devices on the LAN. "
                             "Use static ARP entries for critical hosts (gateway, DNS server)."),
        "DNS_SPOOF":        ("HIGH",   "Enable DNS over HTTPS (DoH) or DNS over TLS (DoT) on all endpoints. "
                             "Verify your DNS server settings have not been tampered with. "
                             "Use DNSSEC-validating resolvers such as 1.1.1.1 or 8.8.8.8."),
        "ICMP_FLOOD":       ("MEDIUM", "Configure your firewall to rate-limit ICMP echo requests. "
                             "Block ICMP from untrusted external sources where not operationally required."),
        "UDP_FLOOD":        ("MEDIUM", "Rate-limit inbound UDP traffic at the perimeter firewall. "
                             "Blacklist the source IP and report persistent floods to your ISP."),
        "SMB_BRUTE":        ("CRITICAL","Disable SMB (port 445) exposure to the internet immediately. "
                             "Enforce account lockout policies (e.g. 5 failed attempts = 30-minute lockout). "
                             "Audit all SMB shares and rotate credentials for any exposed accounts."),
        "RDP_BRUTE":        ("CRITICAL","Disable direct RDP internet exposure — use a VPN gateway instead. "
                             "Enable Network Level Authentication (NLA) and enforce MFA for RDP sessions. "
                             "Rotate all Windows account passwords that may have been targeted."),
        "FTP_BRUTE":        ("HIGH",   "Disable plain FTP and migrate to SFTP or FTPS. "
                             "Enforce strong passwords and lockout policies on FTP accounts. "
                             "Audit FTP logs for any successful logins from the attacker IP."),
        "SSH_BRUTE":        ("HIGH",   "Disable SSH password authentication and use key-based login only. "
                             "Move SSH to a non-standard port and enable fail2ban. "
                             "Audit /var/log/auth.log for any successful logins from the attacker IP."),
        "HTTP_FLOOD":       ("MEDIUM", "Enable rate-limiting on your web server (e.g. nginx limit_req_zone). "
                             "Consider a WAF (Web Application Firewall) for public-facing services. "
                             "Block the source IP at the firewall or CDN level."),
        "C2_BEACON":        ("CRITICAL","Immediately isolate the affected host from the network. "
                             "Run a full forensic scan to identify the malware responsible for beaconing. "
                             "Block all traffic to/from the identified C2 IP/domain at the perimeter firewall. "
                             "Rotate all credentials that may have been present on the affected host."),
        "LATERAL_MOVEMENT": ("CRITICAL","Segment your network using VLANs to limit lateral movement paths. "
                             "Audit all accounts for signs of compromise and enforce least-privilege. "
                             "Review authentication logs across all hosts in the affected segment."),
        "EXFILTRATION":     ("CRITICAL","Immediately block outbound traffic to the destination IP/domain. "
                             "Identify what data was transferred using forensic log analysis. "
                             "Notify relevant parties if personal or sensitive data may be affected. "
                             "Engage your incident response team or a professional IR firm."),
        "REGISTRY_AUTORUN": ("HIGH",   "Review HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run for unauthorized entries. "
                             "Run a full malware scan on the affected host. "
                             "Restrict registry write access using Group Policy for non-admin users."),
    }
    _PRECAUTION_DEFAULT = ("LOW", "Monitor network activity closely and consult your IT/security team "
                            "if alerts persist. Keep all systems and firmware up to date.")

    # Collect unique categories from alerts
    seen_cats = []
    seen_set  = set()
    for a in net_alerts:
        cat_key = str(_g(a, "category", "UNKNOWN")).upper().replace(" ", "_").replace("-", "_")
        if cat_key not in seen_set:
            seen_set.add(cat_key)
            seen_cats.append(cat_key)

    _URG_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    prec_rows_data = []
    for cat_key in seen_cats:
        urg, text = _PRECAUTIONS.get(cat_key, _PRECAUTION_DEFAULT)
        prec_rows_data.append((urg, cat_key.replace("_", " "), text))
    prec_rows_data.sort(key=lambda x: _URG_ORDER.get(x[0], 9))

    phdr = [Paragraph(h, S["cellh"]) for h in ["Urgency", "Attack Type", "Recommended Actions"]]
    pw   = [18*mm, 30*mm, 132*mm]
    prows = [phdr]
    pextra = []
    for i, (urg, cat_name, text) in enumerate(prec_rows_data, 1):
        urg_col = SEV_COLOR.get(urg, S_INFO)
        urg_s   = f'<font color="#{_hex(urg_col)}"><b>{urg}</b></font>'
        prows.append([
            Paragraph(urg_s,        S["cell"]),
            Paragraph(f"<b>{cat_name}</b>", S["cellb"]),
            Paragraph(text,         S["cell"]),
        ])
        bg = SEV_ROW_BG.get(urg)
        if bg:
            pextra.append(("BACKGROUND", (0,i), (-1,i), bg))
    ptbl = Table(prows, colWidths=pw, repeatRows=1)
    ptbl.setStyle(TableStyle(_base_table_style(len(prows)) + pextra))
    story.append(ptbl)


def _build_recommendations(story: list, S: dict, recs: List[Dict]):
    story.append(PageBreak())
    story.append(Paragraph("DYNAMIC RECOMMENDATIONS", S["sec"]))
    story.append(_hr())
    story.append(Paragraph(
        "The following recommendations were generated dynamically based on the specific "
        "threats and network attacks detected in this report. "
        "Each action is directly tied to identified evidence.",
        S["body"],
    ))
    story.append(Spacer(1, 4))

    if not recs:
        story.append(Paragraph(
            "No threats or network attacks detected — no remediation actions required at this time.",
            S["body"]))
        return

    urg_bg = {
        "CRITICAL": ROW_CRIT,
        "HIGH":     ROW_HIGH,
        "MEDIUM":   ROW_MED,
        "LOW":      BG_PANEL,
    }
    for rec in recs:
        urgency = rec["urgency"]
        uc  = SEV_COLOR.get(urgency, S_INFO)
        bg  = urg_bg.get(urgency, BG_CARD)
        head = Paragraph(
            f'<font color="#{_hex(uc)}">[{urgency}]</font>  <b>{rec["headline"]}</b>',
            S["rh"])
        body = Paragraph(rec["detail"], S["rb"])
        ct = Table([[head], [body]], colWidths=[170 * mm])
        ct.setStyle(TableStyle([
            ("BACKGROUND", (0,0),(-1,-1), bg),
            ("BACKGROUND", (0,0),(-1, 0), BG_PANEL),
            ("BOX",        (0,0),(-1,-1), 0.8, uc),
            ("TOPPADDING", (0,0),(-1,-1), 5),
            ("BOTTOMPADDING",(0,0),(-1,-1), 5),
            ("LEFTPADDING",(0,0),(-1,-1), 8),
            ("RIGHTPADDING",(0,0),(-1,-1), 8),
        ]))
        story.append(KeepTogether([ct, Spacer(1, 3)]))


def _build_quarantine_table(story: list, S: dict, quarantine: List[Dict]):
    if not quarantine:
        return
    story.append(PageBreak())
    story.append(Paragraph(f"QUARANTINE VAULT  —  {len(quarantine)} RECORDS", S["sec"]))
    story.append(_hr())

    hdr = [Paragraph(h, S["cellh"]) for h in
           ["#","Original File","Threat Name","Score","Size","Date","Status","Hash (SHA-256)"]]
    cw  = [8*mm, 40*mm, 30*mm, 11*mm, 12*mm, 22*mm, 16*mm, 51*mm]
    rows = [hdr]
    for i, q in enumerate(quarantine, 1):
        raw  = str(q.get("original_path","?"))
        fname= raw.replace("\\","/").split("/")[-1] or raw
        size_b = q.get("file_size", 0)
        if size_b >= 1_048_576:
            size_s = f"{size_b/1_048_576:.1f} MB"
        elif size_b >= 1024:
            size_s = f"{size_b/1024:.1f} KB"
        else:
            size_s = f"{size_b} B" if size_b else "—"
        score  = q.get("threat_score", 0)
        sc_col = RED if score >= 90 else ORANGE
        sc_str = f'<font color="#{_hex(sc_col)}"><b>{score}</b></font>'
        qdate  = str(q.get("quarantine_date","?"))[:19]
        status = str(q.get("status","quarantined"))
        h256   = str(q.get("file_hash",""))[:40] + ("..." if len(str(q.get("file_hash",""))) > 40 else "")
        rows.append([
            Paragraph(str(i),   S["cell"]),
            Paragraph(fname[:34], S["cellb"]),
            Paragraph(str(q.get("threat_name","?"))[:28], S["cell"]),
            Paragraph(sc_str,  S["cell"]),
            Paragraph(size_s,  S["cell"]),
            Paragraph(qdate,   S["cell"]),
            Paragraph(f'<font color="#{_hex(ORANGE)}">{status}</font>', S["cell"]),
            Paragraph(h256,    S["small"]),
        ])
    tbl = Table(rows, colWidths=cw, repeatRows=1)
    tbl.setStyle(TableStyle(_base_table_style(len(rows))))
    story.append(tbl)


# ════════════════════════════════════════════════════════════════════════════
#  Public API
# ════════════════════════════════════════════════════════════════════════════

class ForensicReporter:
    """
    Generates a fully dynamic PDF report from live database + network data.

    Usage — per-scan report (recommended):
        reporter = ForensicReporter(db, network_monitor)
        path = reporter.generate_report(scan_session_id=hub.scan_session_id)

    Usage — legacy combined report (all-time):
        path = reporter.generate_report()

    When scan_session_id is provided every data fetch (file threats, stats,
    quarantine) is scoped to that session's time window, so each report
    reflects exactly one scan run and never accumulates previous results.
    """

    def __init__(self,
                 db_manager=None,
                 network_monitor=None):
        if not REPORTLAB_AVAILABLE:
            raise ImportError(
                "reportlab is required. Install with: pip install reportlab")
        self.db = db_manager or DatabaseManager()
        self.nm = network_monitor

    # ── Data collection ─────────────────────────────────────────────────────

    def _collect_file_threats(self, session_id: int = 0):
        """Returns (file_threats, stats) scoped to session_id if provided."""
        if session_id:
            stats        = self.db.get_threat_statistics_by_session(session_id)
            file_threats = self.db.get_scan_history_by_session(session_id)
        else:
            stats        = self.db.get_threat_statistics()
            file_threats = self.db.get_scan_history(limit=2000, threat_only=True)
        return file_threats, stats

    def _collect_net_alerts(self, session_id: int = 0, start_time: str = ""):
        """Returns network alerts. When session_id is given, filters to session window."""
        if self.nm is None:
            return []
        try:
            alerts = self.nm.get_alerts(limit=500)
        except Exception as e:
            logger.warning(f"Could not retrieve network alerts: {e}")
            return []

        if not session_id or not start_time or not alerts:
            return alerts

        # Filter to only alerts that occurred during or after the session start
        filtered = []
        for a in alerts:
            ts = _g(a, "timestamp", "")
            if ts and str(ts) >= str(start_time):
                filtered.append(a)
        return filtered

    def _collect_quarantine(self, session_id: int = 0):
        try:
            if session_id:
                return self.db.get_quarantine_by_session(session_id)
            return self.db.get_quarantine_records(status="quarantined")
        except Exception as e:
            logger.warning(f"Could not retrieve quarantine records: {e}")
            return []

    # ── Main entry point ────────────────────────────────────────────────────

    def generate_report(self, output_path=None, scan_session_id: int = 0) -> Path:
        """
        Collect all live data, build and save the PDF report.

        Args:
            output_path:     Where to save the PDF. Defaults to
                             LOG_DIR/sentinel_report_<ts>.pdf
            scan_session_id: When non-zero, the report is scoped to this
                             single scan session only — threats, stats, and
                             quarantine records from all other sessions are
                             excluded. Pass hub.scan_session_id after each scan.

        Returns:
            Path to the generated PDF file.
        """
        if output_path is None:
            ts_str      = datetime.now().strftime("%Y%m%d_%H%M%S")
            sess_tag    = f"_session{scan_session_id}" if scan_session_id else ""
            output_path = LOG_DIR / f"sentinel_report{sess_tag}_{ts_str}.pdf"

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # ── Collect data scoped to this session ─────────────────────────────
        file_threats, stats = self._collect_file_threats(scan_session_id)
        start_time          = stats.get("start_time", "")
        net_alerts          = self._collect_net_alerts(scan_session_id, start_time)
        quarantine          = self._collect_quarantine(scan_session_id)
        recs                = _compute_recommendations(file_threats, net_alerts)
        scan_path           = stats.get("scan_path", "")

        logger.info(
            f"[Reporter] Session={scan_session_id} | "
            f"{len(file_threats)} file threats | "
            f"{len(net_alerts)} network alerts | "
            f"{len(quarantine)} quarantined | "
            f"{len(recs)} recommendations."
        )

        # ── Build PDF ───────────────────────────────────────────────────────
        S      = _styles()
        story  = []
        gen_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # ── Page 1: Plain-English summary (non-technical user view) ─────────
        try:
            from .plain_english import translate_threat, get_status_summary
            _build_plain_english_page(story, S, file_threats, net_alerts, gen_ts)
        except Exception as _pe:
            logger.debug("Plain-English page skipped: %s", _pe)

        _build_header(story, S, gen_ts, len(file_threats), len(net_alerts),
                      scan_path=scan_path, session_id=scan_session_id)
        _build_executive_summary(story, S, file_threats, net_alerts, stats, quarantine)
        _build_file_threat_table(story, S, file_threats)
        _build_network_alerts_table(story, S, net_alerts)
        _build_recommendations(story, S, recs)
        _build_quarantine_table(story, S, quarantine)

        story.append(Spacer(1, 6))
        story.append(_hr(CYAN, 0.8))
        story.append(Paragraph(
            f"End of Report  |  Sentinel Defender v5.0  |  "
            f"AI Analysis by Claude (Anthropic)  |  {gen_ts}",
            S["foot"]))

        doc = SimpleDocTemplate(
            str(output_path),
            pagesize=A4,
            leftMargin=15 * mm, rightMargin=15 * mm,
            topMargin=18 * mm,  bottomMargin=18 * mm,
        )
        doc.build(story, onFirstPage=_dark_page, onLaterPages=_dark_page)

        logger.info(f"[Reporter] Report saved: {output_path}")
        return output_path