#!/usr/bin/env python3
"""
Sentinel Defender - Action Agent
Executes remediation actions ONE AT A TIME, only after explicit human approval.
Never executes any action autonomously.
"""

import logging
import threading
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, asdict
from enum import Enum
from typing import Callable, Optional, List

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
#  Enums & data classes
# ─────────────────────────────────────────────

class ActionStatus(str, Enum):
    PENDING   = "PENDING"
    APPROVED  = "APPROVED"
    DENIED    = "DENIED"
    RUNNING   = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED    = "FAILED"
    SKIPPED   = "SKIPPED"


@dataclass
class ActionResult:
    action_id: str
    action_type: str
    target: str
    status: str
    executed_at: str
    message: str
    error: Optional[str] = None


# ─────────────────────────────────────────────
#  Agent
# ─────────────────────────────────────────────

class ActionAgent:
    """
    Executes approved remediation actions.

    Workflow per action:
    1.  Present action details to user via approval_callback.
    2.  Wait for human decision (approve / deny / skip).
    3.  Execute only if approved.
    4.  Report result via result_callback.

    Approval callback signature:
        approval_callback(action: dict) -> bool   (True = approved)

    Result callback signature:
        result_callback(result: ActionResult) -> None
    """

    def __init__(
        self,
        hub=None,
        approval_callback: Optional[Callable] = None,
        result_callback: Optional[Callable]   = None,
    ):
        self.hub = hub
        self.approval_callback = approval_callback
        self.result_callback   = result_callback
        self.results: List[ActionResult] = []
        self._stop_flag = False

    # ── Public API ────────────────────────────────────────────────────────────

    def execute_plan(self, plan, scan_path: Optional[str] = None):
        """
        Run all actions in a RemediationPlan (dataclass or dict) in a
        background thread, pausing for human approval at each step.
        """
        if hasattr(plan, "__dataclass_fields__"):
            actions = plan.actions
        else:
            actions = plan.get("actions", [])

        self._stop_flag = False
        thread = threading.Thread(
            target=self._run_actions,
            args=(actions, scan_path),
            daemon=True,
        )
        thread.start()
        return thread

    def execute_single(self, action: dict, scan_path: Optional[str] = None) -> ActionResult:
        """Execute one action synchronously (after approval)."""
        return self._execute_action(action, scan_path)

    def stop(self):
        """Signal the running plan to halt after the current action."""
        self._stop_flag = True

    # ── Internal orchestration ────────────────────────────────────────────────

    def _run_actions(self, actions: List[dict], scan_path: Optional[str]):
        for action in actions:
            if self._stop_flag:
                logger.info("[ActionAgent] Plan execution halted by user.")
                break

            approved = self._request_approval(action)

            if approved:
                result = self._execute_action(action, scan_path)
            else:
                result = ActionResult(
                    action_id   = action.get("action_id", "?"),
                    action_type = action.get("action_type", "?"),
                    target      = action.get("target", "?"),
                    status      = ActionStatus.DENIED,
                    executed_at = datetime.now().isoformat(timespec="seconds"),
                    message     = "Action denied by user — skipped.",
                )
                logger.info("[ActionAgent] Action %s denied.", result.action_id)

            self.results.append(result)
            if self.result_callback:
                self.result_callback(result)

    def _request_approval(self, action: dict) -> bool:
        """Block until user approves or denies the action."""
        if self.approval_callback is None:
            # No callback = auto-deny (safe default)
            return False
        try:
            return bool(self.approval_callback(action))
        except Exception as e:
            logger.error("[ActionAgent] Approval callback error: %s", e)
            return False

    def _execute_action(self, action: dict, scan_path: Optional[str]) -> ActionResult:
        action_type = action.get("action_type", "unknown")
        target      = action.get("target", "")
        action_id   = action.get("action_id", "?")

        logger.info("[ActionAgent] Executing %s on '%s'", action_type, target)

        dispatch = {
            "quarantine":      self._do_quarantine,
            "delete":          self._do_delete,
            "network_isolate": self._do_network_isolate,
            "alert":           self._do_alert,
            "report":          self._do_report,
            "rescan":          self._do_rescan,
        }

        handler = dispatch.get(action_type, self._do_unknown)
        try:
            message = handler(target, scan_path, action)
            status  = ActionStatus.COMPLETED
            error   = None
        except PermissionError as e:
            message = f"Permission denied: {e}"
            status  = ActionStatus.FAILED
            error   = str(e)
            logger.error("[ActionAgent] Permission error on %s: %s", action_id, e)
        except FileNotFoundError as e:
            message = f"File not found: {e}"
            status  = ActionStatus.FAILED
            error   = str(e)
            logger.error("[ActionAgent] File not found on %s: %s", action_id, e)
        except Exception as e:
            message = f"Unexpected error: {e}"
            status  = ActionStatus.FAILED
            error   = str(e)
            logger.error("[ActionAgent] Error on %s: %s", action_id, e)

        result = ActionResult(
            action_id   = action_id,
            action_type = action_type,
            target      = target,
            status      = status,
            executed_at = datetime.now().isoformat(timespec="seconds"),
            message     = message,
            error       = error,
        )
        return result

    # ── Action handlers ───────────────────────────────────────────────────────

    def _do_quarantine(self, target: str, scan_path, action: dict) -> str:
        """Move a file to the quarantine vault via SentinelHub."""
        if self.hub is None:
            return f"[SIMULATED] Would quarantine: {target}"

        # Try to quarantine via hub
        try:
            # hub.quarantine_file expects a Path
            result = self.hub.quarantine_file(Path(target))
            if result:
                return f"Successfully quarantined: {target}"
            else:
                return f"Quarantine returned no confirmation for: {target} (may already be quarantined)"
        except AttributeError:
            return f"[SIMULATED] Hub quarantine API not available — would quarantine: {target}"

    def _do_delete(self, target: str, scan_path, action: dict) -> str:
        """Permanently delete a quarantined file."""
        p = Path(target)
        if p.exists():
            p.unlink()
            return f"Permanently deleted: {target}"
        # Try via hub quarantine DB
        if self.hub is not None:
            try:
                qid = action.get("quarantine_id")
                if qid:
                    self.hub.delete_quarantined_file(qid)
                    return f"Deleted quarantine record {qid}"
            except Exception:
                pass
        return f"File '{target}' not found on disk — may already be removed."

    def _do_network_isolate(self, target: str, scan_path, action: dict) -> str:
        """
        Attempt to disable network interfaces.
        Requires elevated privileges on most platforms.
        """
        import subprocess, sys

        if sys.platform == "win32":
            cmd = ["netsh", "interface", "set", "interface", "Wi-Fi", "admin=disable"]
        elif sys.platform.startswith("linux"):
            cmd = ["nmcli", "networking", "off"]
        elif sys.platform == "darwin":
            cmd = ["networksetup", "-setairportpower", "en0", "off"]
        else:
            return "[SIMULATED] Network isolation not supported on this platform."

        try:
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if proc.returncode == 0:
                return "Network interfaces disabled successfully."
            else:
                return f"Network isolation command returned code {proc.returncode}: {proc.stderr.strip()}"
        except FileNotFoundError:
            return f"[SIMULATED] Network isolation command not available — would run: {' '.join(cmd)}"
        except PermissionError:
            return "Insufficient privileges to disable network — run Sentinel as Administrator/root."

    def _do_alert(self, target: str, scan_path, action: dict) -> str:
        """Log an alert (GUI displays it via result_callback)."""
        msg = "⚠️  THREAT ALERT: Remediation actions are in progress. Review the Action Agent tab."
        logger.warning("[ActionAgent] ALERT: %s", msg)
        return msg

    def _do_report(self, target: str, scan_path, action: dict) -> str:
        """Trigger PDF report generation via hub."""
        if self.hub is None:
            return "[SIMULATED] Would generate PDF forensic report."
        try:
            report_path = self.hub.generate_report()
            return f"PDF report generated: {report_path}"
        except AttributeError:
            return "[SIMULATED] Hub report API not available — would generate PDF."
        except Exception as e:
            return f"Report generation failed: {e}"

    def _do_rescan(self, target: str, scan_path, action: dict) -> str:
        """Re-trigger a scan on the original scan path."""
        path = scan_path or target
        if not path or path == "original_scan_path":
            return "[SIMULATED] No scan path available — start a new scan manually."
        if self.hub is None:
            return f"[SIMULATED] Would rescan: {path}"
        try:
            from backend.main import ScanType
            self.hub.start_scan(target_path=Path(path), scan_type=ScanType.FULL, recursive=True)
            return f"Re-scan started on: {path}"
        except Exception as e:
            return f"Could not start re-scan: {e}"

    def _do_unknown(self, target: str, scan_path, action: dict) -> str:
        return f"[SIMULATED] Unknown action type — would perform: {action.get('action_type')} on {target}"

    # ── Utility ───────────────────────────────────────────────────────────────

    def get_results_summary(self) -> dict:
        completed = sum(1 for r in self.results if r.status == ActionStatus.COMPLETED)
        failed    = sum(1 for r in self.results if r.status == ActionStatus.FAILED)
        denied    = sum(1 for r in self.results if r.status == ActionStatus.DENIED)
        return {
            "total":     len(self.results),
            "completed": completed,
            "failed":    failed,
            "denied":    denied,
        }
