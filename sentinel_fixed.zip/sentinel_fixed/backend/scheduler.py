"""
Sentinel Defender - Scheduled Scan Engine
==========================================
Runs nightly background scans on user-chosen folders automatically,
without requiring the main window to be open.

Usage
-----
    from backend.scheduler import ScanScheduler

    scheduler = ScanScheduler(hub, prefs)
    scheduler.start()   # starts daemon thread
    scheduler.stop()
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, List, Optional

logger = logging.getLogger(__name__)


class ScanScheduler:
    """
    Daemon thread that wakes up once per minute, checks if it is time
    for a scheduled scan, and triggers one via SentinelHub if so.

    The scan time and target paths come from UserPreferences and are
    re-read each check, so changes the user makes in the GUI take effect
    without a restart.
    """

    def __init__(self, hub, prefs, on_scan_started: Optional[Callable] = None):
        """
        hub   — SentinelHub instance
        prefs — UserPreferences instance
        on_scan_started — optional GUI callback called when a scheduled scan fires
        """
        self._hub             = hub
        self._prefs           = prefs
        self._on_scan_started = on_scan_started
        self._thread: Optional[threading.Thread] = None
        self._stop_event      = threading.Event()
        self._last_scan_date: Optional[str] = None   # "YYYY-MM-DD" of last fired scan

    # ── Public API ────────────────────────────────────────────────────────────

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop,
            name="SentinelScheduler",
            daemon=True,
        )
        self._thread.start()
        logger.info("[Scheduler] Started — checking every 60 s")

    def stop(self) -> None:
        self._stop_event.set()
        logger.info("[Scheduler] Stopped")

    @property
    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    # ── Internal ──────────────────────────────────────────────────────────────

    def _loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                self._check_and_fire()
            except Exception as e:
                logger.error("[Scheduler] Error in loop: %s", e)
            # Sleep 60 s in 5-second increments so stop() is responsive
            for _ in range(12):
                if self._stop_event.is_set():
                    return
                time.sleep(5)

    def _check_and_fire(self) -> None:
        if not self._prefs.scheduled_scans_enabled:
            return

        now        = datetime.now()
        today_str  = now.strftime("%Y-%m-%d")
        now_hhmm   = now.strftime("%H:%M")
        target_hhmm = self._prefs.scheduled_scan_time  # e.g. "02:00"

        # Fire if the clock matches the target time and we haven't scanned today
        if now_hhmm == target_hhmm and self._last_scan_date != today_str:
            self._last_scan_date = today_str
            paths = self._prefs.scheduled_scan_paths
            if not paths:
                # Fallback: scan Downloads + Desktop + Documents
                home = Path.home()
                paths = [
                    str(home / "Downloads"),
                    str(home / "Desktop"),
                    str(home / "Documents"),
                ]
            self._fire_scan(paths)

    def _fire_scan(self, paths: List[str]) -> None:
        logger.info("[Scheduler] Firing nightly scan on %d path(s)", len(paths))
        if self._on_scan_started:
            try:
                self._on_scan_started(paths)
            except Exception as e:
                logger.warning("[Scheduler] on_scan_started callback error: %s", e)

        for path_str in paths:
            p = Path(path_str)
            if not p.exists():
                logger.warning("[Scheduler] Path does not exist, skipping: %s", path_str)
                continue
            try:
                from .main import ScanType
                self._hub.start_scan(
                    target_path=p,
                    scan_type=ScanType.QUICK,
                    recursive=True,
                )
                logger.info("[Scheduler] Scan started on: %s", path_str)
                # Wait for this scan to finish before starting the next
                self._wait_for_scan()
            except Exception as e:
                logger.error("[Scheduler] Failed to start scan on %s: %s", path_str, e)

    def _wait_for_scan(self, timeout: int = 3600) -> None:
        """Block until SentinelHub reports scan is no longer running."""
        waited = 0
        while waited < timeout:
            try:
                status = self._hub.get_scan_status()
                if status.get("status") in ("completed", "idle", "stopped"):
                    return
            except Exception:
                pass
            time.sleep(5)
            waited += 5