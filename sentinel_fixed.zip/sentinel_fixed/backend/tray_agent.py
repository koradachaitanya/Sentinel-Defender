"""
Sentinel Defender - System Tray Agent
======================================
Keeps Sentinel running silently in the background when the main window is
closed or minimised. Shows a tray icon whose colour reflects the system's
current protection status.

Requires:  pystray   (pip install pystray)
           Pillow    (pip install Pillow)      ← needed to draw the icon
Both are optional — if missing, tray support is gracefully skipped.

Usage
-----
    from backend.tray_agent import TrayAgent

    tray = TrayAgent(
        show_window_callback  = app.deiconify,
        quit_callback         = app.on_closing,
        get_status_callback   = lambda: hub.get_scan_status(),
    )
    tray.start()     # starts the tray icon in a daemon thread
    tray.notify("Threat found", "invoice.exe was quarantined")
    tray.set_status("threat")   # "safe" | "threat" | "scanning" | "off"
    tray.stop()
"""

from __future__ import annotations

import logging
import threading
from typing import Callable, Optional

logger = logging.getLogger(__name__)

# ── Optional imports ──────────────────────────────────────────────────────────

try:
    import pystray
    from pystray import MenuItem as Item, Menu
    PYSTRAY_AVAILABLE = True
except ImportError:
    PYSTRAY_AVAILABLE = False
    logger.info("[TrayAgent] pystray not installed — tray icon disabled")

try:
    from PIL import Image, ImageDraw
    PILLOW_AVAILABLE = True
except ImportError:
    PILLOW_AVAILABLE = False
    logger.info("[TrayAgent] Pillow not installed — tray icon disabled")

TRAY_AVAILABLE = PYSTRAY_AVAILABLE and PILLOW_AVAILABLE

# ── Icon drawing ──────────────────────────────────────────────────────────────

_STATUS_COLORS = {
    "safe":     "#10b981",   # green
    "threat":   "#ef4444",   # red
    "scanning": "#3b82f6",   # blue
    "off":      "#6b7280",   # grey
}


def _draw_icon(status: str = "safe") -> "Image.Image":
    """Draw a 64×64 shield icon in the given status colour."""
    size   = 64
    color  = _STATUS_COLORS.get(status, "#10b981")
    bg     = (0, 0, 0, 0)         # transparent background

    img  = Image.new("RGBA", (size, size), bg)
    draw = ImageDraw.Draw(img)

    # Shield outline (filled polygon)
    shield = [
        (32, 4),
        (56, 14),
        (56, 36),
        (32, 60),
        (8,  36),
        (8,  14),
    ]
    draw.polygon(shield, fill=color)

    # "S" letter in white — simple cross strokes
    cx, cy = 32, 32
    draw.rectangle([cx - 8, cy - 14, cx + 8, cy - 8],  fill="white")
    draw.rectangle([cx - 8, cy - 8,  cx + 2, cy - 2],  fill="white")
    draw.rectangle([cx - 8, cy - 2,  cx + 8, cy + 4],  fill="white")
    draw.rectangle([cx - 2, cy + 4,  cx + 8, cy + 10], fill="white")
    draw.rectangle([cx - 8, cy + 10, cx + 8, cy + 16], fill="white")

    return img


# ── TrayAgent ─────────────────────────────────────────────────────────────────

class TrayAgent:
    """
    Manages a system-tray icon for Sentinel Defender.

    If pystray / Pillow are not installed, all methods become no-ops so
    the rest of the application continues to work without modification.
    """

    def __init__(
        self,
        show_window_callback:  Optional[Callable] = None,
        quit_callback:         Optional[Callable] = None,
        get_status_callback:   Optional[Callable] = None,
    ):
        self._show_window  = show_window_callback  or (lambda: None)
        self._quit         = quit_callback         or (lambda: None)
        self._get_status   = get_status_callback   or (lambda: {})
        self._icon: Optional["pystray.Icon"] = None
        self._status       = "safe"
        self._thread: Optional[threading.Thread] = None

    # ── Public API ────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Start the tray icon in a background daemon thread."""
        if not TRAY_AVAILABLE:
            return
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._run,
            name="SentinelTray",
            daemon=True,
        )
        self._thread.start()
        logger.info("[TrayAgent] Tray icon started")

    def stop(self) -> None:
        """Remove the tray icon."""
        if self._icon:
            try:
                self._icon.stop()
            except Exception:
                pass
        logger.info("[TrayAgent] Tray icon stopped")

    def set_status(self, status: str) -> None:
        """
        Update the icon colour.
        status: "safe" | "threat" | "scanning" | "off"
        """
        if not TRAY_AVAILABLE or self._icon is None:
            return
        self._status = status
        try:
            self._icon.icon = _draw_icon(status)
            tooltip_map = {
                "safe":     "Sentinel Defender — Protected",
                "threat":   "Sentinel Defender — Threat detected!",
                "scanning": "Sentinel Defender — Scanning…",
                "off":      "Sentinel Defender — Protection off",
            }
            self._icon.title = tooltip_map.get(status, "Sentinel Defender")
        except Exception as e:
            logger.debug("[TrayAgent] set_status error: %s", e)

    def notify(self, title: str, message: str) -> None:
        """
        Show a system notification balloon / toast.
        Falls back silently if not supported by the platform.
        """
        if not TRAY_AVAILABLE or self._icon is None:
            return
        try:
            self._icon.notify(message, title)
        except Exception as e:
            logger.debug("[TrayAgent] notify error: %s", e)

    # ── Internal ──────────────────────────────────────────────────────────────

    def _run(self) -> None:
        menu = Menu(
            Item("Open Sentinel",    self._on_open,  default=True),
            Item("Protection: ON",   self._on_toggle_protection),
            Menu.SEPARATOR,
            Item("Quit",             self._on_quit),
        )
        self._icon = pystray.Icon(
            name="SentinelDefender",
            icon=_draw_icon(self._status),
            title="Sentinel Defender — Protected",
            menu=menu,
        )
        try:
            self._icon.run()
        except Exception as e:
            logger.warning("[TrayAgent] Icon run error: %s", e)

    def _on_open(self, icon=None, item=None) -> None:
        try:
            self._show_window()
        except Exception as e:
            logger.debug("[TrayAgent] show_window error: %s", e)

    def _on_toggle_protection(self, icon=None, item=None) -> None:
        # Simple placeholder — full integration via show_window_callback
        self._on_open()

    def _on_quit(self, icon=None, item=None) -> None:
        self.stop()
        try:
            self._quit()
        except Exception as e:
            logger.debug("[TrayAgent] quit error: %s", e)