"""
Sentinel Defender - Optimized Orchestrator Hub
STABILITY PATCH: Engine throttling for GIL release and smooth GUI.
"""

import queue
import threading
import logging
import time
import shutil
import hashlib
from pathlib import Path
from typing import Callable, Optional, Generator, Dict, Any, List
from datetime import datetime
from enum import Enum
from collections import deque

from .utils import sanitize_filename, xor_encrypt_decrypt
from .database import DatabaseManager, QUARANTINE_DIR
from .config import SCANNABLE_EXTENSIONS
from .detectors import DetectionEngine, ThreatDetection
from .process_engine import ProcessBehaviorEngine, ProcessAlert
from .reporting import ForensicReporter
try:
    from .network_engine import NetworkMonitor
    NETWORK_ENGINE_AVAILABLE = True
except ImportError:
    NETWORK_ENGINE_AVAILABLE = False
try:
    from .dynamic_engine import DynamicEngine, DynamicAlert
    DYNAMIC_ENGINE_AVAILABLE = True
except ImportError:
    DYNAMIC_ENGINE_AVAILABLE = False
    logger = logging.getLogger(__name__)
    logger.warning("DynamicEngine not available")
from .threat_hunting_assistant import ThreatHuntingAssistant

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
diag_logger = logging.getLogger("sentinel.diag")


# ==================== CIRCULAR LOG BUFFER ====================

class CircularLogBuffer:
    """
    Lock-free circular buffer for high-speed log accumulation.
    Clean files stored here (memory only), threats go to database.
    """
    def __init__(self, maxsize: int = 1000):
        """Initialize circular buffer."""
        self.buffer = [''] * maxsize
        self.write_index = 0
        self.maxsize = maxsize
        self.total_written = 0
        self._lock = threading.Lock()
    
    def append(self, log_entry: str):
        """O(1) append - overwrites oldest entry when full."""
        with self._lock:
            self.buffer[self.write_index] = log_entry
            self.write_index = (self.write_index + 1) % self.maxsize
            self.total_written += 1
    
    def get_recent(self, count: int = 50) -> List[str]:
        """Get last N entries without removing them."""
        with self._lock:
            if self.write_index >= count:
                return self.buffer[self.write_index - count:self.write_index]
            else:
                # Wrapped around
                return (self.buffer[self.maxsize - (count - self.write_index):] + 
                       self.buffer[:self.write_index])

    def get_since(self, last_seen: int, count: int = 50) -> tuple[List[str], int]:
        """Return up to `count` new entries since `last_seen`, plus the new cursor."""
        with self._lock:
            current_total = self.total_written
            earliest_available = max(0, current_total - self.maxsize)
            cursor = max(last_seen, earliest_available)
            available = current_total - cursor
            take = min(count, available)
            if take <= 0:
                return [], current_total

            start = (self.write_index - take) % self.maxsize
            if start + take <= self.maxsize:
                items = self.buffer[start:start + take]
            else:
                split = self.maxsize - start
                items = self.buffer[start:] + self.buffer[:take - split]
            return items, current_total
    
    def get_all(self) -> List[str]:
        """Get all entries in order."""
        with self._lock:
            return self.buffer[self.write_index:] + self.buffer[:self.write_index]
    
    def clear(self):
        """Clear buffer."""
        with self._lock:
            self.buffer = [''] * self.maxsize
            self.write_index = 0
            self.total_written = 0


# ==================== ASYNC THREAT DATABASE WRITER ====================

class ThreatDatabaseWriter:
    """
    Asynchronous database writer for threats only.
    Batches writes to reduce database locking.
    """
    def __init__(self, db: DatabaseManager):
        """Initialize threat writer."""
        self.db = db
        self.threat_queue = queue.Queue(maxsize=500)
        self.batch_size = 100
        self.flush_interval = 5.0  # seconds
        self.shutdown_event = threading.Event()
        
        # Start writer daemon
        self.writer_thread = threading.Thread(
            target=self._writer_daemon,
            name="ThreatDBWriter",
            daemon=True
        )
        self.writer_thread.start()
        logger.info("Threat database writer started")
    
    def queue_threat(self, threat_record: Dict[str, Any]):
        """Queue a threat for database writing."""
        try:
            self.threat_queue.put_nowait(threat_record)
        except queue.Full:
            logger.warning("Threat queue full")
    
    def _writer_daemon(self):
        """Background thread that batches database writes."""
        batch = []
        last_flush = time.time()
        
        while not self.shutdown_event.is_set():
            try:
                try:
                    threat = self.threat_queue.get(timeout=0.5)
                    batch.append(threat)
                except queue.Empty:
                    threat = None
                
                # Flush conditions
                current_time = time.time()
                should_flush = (
                    len(batch) >= self.batch_size or
                    (batch and (current_time - last_flush) >= self.flush_interval) or
                    self.shutdown_event.is_set()
                )
                
                if should_flush and batch:
                    self.db.batch_insert_threats(batch)
                    batch.clear()
                    last_flush = current_time
                    
            except Exception as e:
                logger.error(f"Threat writer error: {e}")
                batch.clear()
                time.sleep(0.1)
        
        # Final flush
        if batch:
            self.db.batch_insert_threats(batch)
        
        logger.info("Threat database writer stopped")
    
    def shutdown(self):
        """Shutdown writer daemon."""
        self.shutdown_event.set()
        if self.writer_thread.is_alive():
            self.writer_thread.join(timeout=5.0)


# ==================== ENUMS ====================

class ScanType(Enum):
    """Types of scans available."""
    QUICK = "quick"
    FULL = "full"
    CUSTOM = "custom"


class ScanStatus(Enum):
    """Scan operation status."""
    IDLE = "idle"
    SCANNING = "scanning"
    PAUSED = "paused"
    COMPLETED = "completed"
    STOPPED = "stopped"
    ERROR = "error"


# ==================== SENTINEL HUB ====================

class SentinelHub:
    """
    Optimized orchestrator with stability patch.
    
    STABILITY PATCH: Engine throttling for GIL release.
    """
    
    def __init__(self, progress_callback: Optional[Callable] = None,
                 threat_callback: Optional[Callable] = None,
                 alert_callback: Optional[Callable] = None):
        """Initialize Sentinel Hub."""
        # Core components
        self.db = DatabaseManager()
        self.detection_engine = DetectionEngine()
        self.process_engine = ProcessBehaviorEngine()

        # Network monitor — captures live packet-level alerts
        self.network_monitor = None
        if NETWORK_ENGINE_AVAILABLE:
            try:
                self.network_monitor = NetworkMonitor(alert_callback=self._on_network_alert)
            except Exception as _ne:
                logger.warning(f"NetworkMonitor could not be initialised: {_ne}")

        # Reporter receives both DB and network monitor so reports are fully dynamic
        self.reporter = ForensicReporter(self.db, network_monitor=self.network_monitor)
        
        # ── Dynamic real-time engine ──────────────────────────────────────────
        # Owns FilesystemMonitor + ProcessMonitor + MemoryScanner + RegistryMonitor.
        # Alerts are produced on worker threads and queued; GUI drains via
        # get_dynamic_alerts() on its heartbeat timer — zero Tkinter callbacks
        # from background threads, so no deadlocks possible.
        self.dynamic_engine: Optional["DynamicEngine"] = None
        if DYNAMIC_ENGINE_AVAILABLE:
            try:
                self.dynamic_engine = DynamicEngine(
                    detection_engine = self.detection_engine,
                    alert_callback   = None,   # GUI polls via drain; no push callback
                    watch_paths      = [],     # paths added when protection starts
                    enable_fs        = True,
                    enable_process   = True,
                    enable_memory    = True,
                    enable_registry  = True,
                )
            except Exception as _de:
                logger.warning("DynamicEngine could not be initialised: %s", _de)
        
        # Threat Hunting Assistant
        self.threat_assistant = ThreatHuntingAssistant(self.db, self)
        
        # Threat Intelligence (Spool up auto-updater background thread)
        from .detectors import get_threat_intel
        self.threat_intel = get_threat_intel()
        
        self._dynamic_protection_active = False
        
        # Circular log buffer (in-memory)
        self.log_buffer = CircularLogBuffer(maxsize=1000)
        
        # Async threat writer (disk)
        self.threat_writer = ThreatDatabaseWriter(self.db)
        
        # Callbacks
        self.progress_callback = progress_callback
        self.threat_callback = threat_callback
        self.alert_callback = alert_callback
        
        # Scanning state
        self.scan_status = ScanStatus.IDLE
        self.scan_thread: Optional[threading.Thread] = None
        self.scan_stop_event = threading.Event()
        self.file_generator: Optional[Generator] = None
        
        # Performance tracking
        self.scan_start_time = None
        self.scan_session_id = 0
        self.files_per_second_history = deque(maxlen=60)
        self.threats_per_second_history = deque(maxlen=60)
        self.last_performance_update = time.time()
        
        # Process monitoring
        self.monitor_thread: Optional[threading.Thread] = None
        self.monitor_stop_event = threading.Event()
        self.monitoring_active = False
        
        # Thread-safe statistics
        self.stats_lock = threading.Lock()
        self.current_scan_stats = {
            'files_scanned': 0,
            'threats_found': 0,
            'files_quarantined': 0,
            'scan_start_time': None,
            'scan_end_time': None,
            'files_per_sec': 0.0,
            'current_file': '',
            'last_progress_ts': 0.0,
        }
        
        logger.info("Sentinel Hub initialized (Stability Patch Active)")
    
    # ==================== FILE GENERATION ====================
    
    def _generate_files(self, target_path: Path, recursive: bool) -> Generator[Path, None, None]:
        """Generator with extension filtering."""
        try:
            if not target_path.exists():
                logger.error(f"Path does not exist: {target_path}")
                return
            
            if target_path.is_file():
                if target_path.suffix.lower() in SCANNABLE_EXTENSIONS:
                    yield target_path
                return
            
            if target_path.is_dir():
                pattern = '**/*' if recursive else '*'
                
                for file_path in target_path.glob(pattern):
                    if self.scan_stop_event.is_set():
                        return
                    
                    if file_path.is_file():
                        # Skip hidden/system files
                        if file_path.name.startswith('.'):
                            continue
                        if file_path.name in {'thumbs.db', 'desktop.ini', '.DS_Store'}:
                            continue
                        
                        # Only scan relevant files
                        if file_path.suffix.lower() in SCANNABLE_EXTENSIONS:
                            yield file_path
                            
        except Exception as e:
            logger.error(f"File generator error: {e}")
    
    # ==================== SCANNING WORKER (STABILITY PATCH) ====================
    
    def _scan_worker(self):
        """
        Worker thread that processes files.
        
        STABILITY PATCH: Releases GIL every 10 files to allow GUI to run.
        """
        logger.info("Scan worker started (Throttled Mode)")
        
        files_processed = 0  # STABILITY PATCH: Counter for throttling
        
        try:
            for file_path in self.file_generator:
                if self.scan_stop_event.is_set():
                    break
                with self.stats_lock:
                    self.current_scan_stats['current_file'] = str(file_path)
                    self.current_scan_stats['last_progress_ts'] = time.time()
                if files_processed < 25 or files_processed % 50 == 0:
                    logger.info("Scan worker processing file #%d: %s", files_processed + 1, file_path)
                    diag_logger.debug("[SCAN] file start #%d path=%s", files_processed + 1, file_path)
                self._scan_single_file(file_path)
                files_processed += 1
                if files_processed <= 25 or files_processed % 50 == 0:
                    diag_logger.debug("[SCAN] file end #%d queue=%d", files_processed, self.threat_writer.threat_queue.qsize())
                # ENGINE THROTTLE: sleep every 3 files, 15ms
                # GUI gets ~83ms of breathing room per second at 13 files/sec
                time.sleep(0.001 if files_processed % 3 else 0.015)
            
            self._complete_scan()
            
        except Exception as e:
            logger.error(f"Scan worker error: {e}")
            self.scan_status = ScanStatus.ERROR
        
        logger.info("Scan worker stopped")
    
    def _scan_single_file(self, file_path: Path):
        """Scan single file."""
        scan_start = time.time()
        
        try:
            # Update statistics
            with self.stats_lock:
                self.current_scan_stats['files_scanned'] += 1
                files_scanned = self.current_scan_stats['files_scanned']
                self.current_scan_stats['current_file'] = str(file_path)
                self.current_scan_stats['last_progress_ts'] = time.time()
            
            # Update performance metrics
            self._update_performance_metrics()
            
            # Perform detection
            detect_started = time.perf_counter()
            detection = self.detection_engine.scan_file(file_path)
            logger.info(
                "Detection result: path=%s type=%s severity=%s score=%s",
                file_path, detection.threat_type, detection.severity, detection.threat_score
            )
            diag_logger.debug(
                "[SCAN] detection done path=%s duration=%.2fms type=%s score=%s",
                file_path, (time.perf_counter() - detect_started) * 1000.0,
                detection.threat_type, detection.threat_score
            )
            
            scan_duration_ms = int((time.time() - scan_start) * 1000)
            
            # Determine if threat
            is_threat = (
                detection.threat_type in ['malware', 'suspicious', 'test_file']
                or detection.threat_score >= 60
            )
            
            # Log to buffer (all files, memory only)
            # EMERGENCY FIX: Add [THREAT] marker so threats show RED in live logs
            if is_threat:
                log_entry = f"[THREAT] [{files_scanned}] {file_path.name} - {detection.threat_name} (Score: {detection.threat_score})"
            else:
                log_entry = f"[CLEAN] [{files_scanned}] {file_path.name} - {detection.threat_name}"
            self.log_buffer.append(log_entry)
            
            # Callback for GUI
            if self.progress_callback:
                try:
                    self.progress_callback(str(file_path), files_scanned)
                except Exception as e:
                    logger.error(f"Progress callback error: {e}")
            
            # Only threats go to database
            if is_threat:
                with self.stats_lock:
                    self.current_scan_stats['threats_found'] += 1
                
                logger.warning(f"Threat detected: {file_path}")
                
                # Queue threat for async database write
                try:
                    file_size = file_path.stat().st_size
                except:
                    file_size = 0
                
                threat_record = {
                    'timestamp': datetime.now(),
                    'file_path': str(file_path),
                    'file_size': file_size,
                    'scan_status': 'threat',
                    'threat_name': detection.threat_name,
                    'threat_type': detection.threat_type,
                    'threat_score': detection.threat_score,
                    'detection_method': detection.detection_method,
                    'action_taken': 'pending',
                    'scan_duration_ms': scan_duration_ms
                }
                
                self.threat_writer.queue_threat(threat_record)
                diag_logger.debug("[QUEUE] threat_writer size=%d", self.threat_writer.threat_queue.qsize())
                
                # Notify callback
                if self.threat_callback:
                    try:
                        self.threat_callback(detection, str(file_path))
                    except Exception as e:
                        logger.error(f"Threat callback error: {e}")
                
                # Auto-quarantine: critical/high severity OR any suspicious/malware/test file
                should_quarantine = (
                    detection.severity in ['critical', 'high']
                    or detection.threat_type in ['suspicious', 'malware', 'test_file']
                    or detection.threat_score >= 60
                )
                if should_quarantine:
                    logger.warning("Auto-quarantine triggered for %s", file_path)
                    self.quarantine_file(file_path, detection)
                    
        except Exception as e:
            logger.error(f"Error scanning {file_path}: {e}")
    
    # ==================== PERFORMANCE TRACKING ====================
    
    def _update_performance_metrics(self):
        """Update performance metrics for graphs."""
        current_time = time.time()
        
        # Update every second
        if current_time - self.last_performance_update >= 1.0:
            with self.stats_lock:
                if self.scan_start_time:
                    elapsed = current_time - self.scan_start_time
                    if elapsed > 0:
                        files_per_sec = self.current_scan_stats['files_scanned'] / elapsed
                        self.current_scan_stats['files_per_sec'] = files_per_sec
                        
                        self.files_per_second_history.append(files_per_sec)
                        self.threats_per_second_history.append(
                            self.current_scan_stats['threats_found']
                        )
            
            self.last_performance_update = current_time
    
    def get_performance_history(self) -> Dict[str, List]:
        """Get performance history for graphs."""
        return {
            'files_per_sec': list(self.files_per_second_history),
            'threats_count': list(self.threats_per_second_history)
        }
    
    # ==================== SCAN CONTROL ====================
    
    def start_scan(self, target_path: Path, scan_type: ScanType = ScanType.CUSTOM,
                   recursive: bool = True) -> bool:
        """Start new scan."""
        if self.scan_status == ScanStatus.SCANNING:
            logger.warning("Scan already in progress")
            return False
        
        # Reset state
        self.scan_stop_event.clear()
        self.scan_status = ScanStatus.SCANNING
        
        # Reset statistics
        with self.stats_lock:
            self.current_scan_stats = {
                'files_scanned': 0,
                'threats_found': 0,
                'files_quarantined': 0,
                'scan_start_time': datetime.now(),
                'scan_end_time': None,
                'files_per_sec': 0.0,
                'current_file': '',
                'last_progress_ts': time.time(),
            }
        
        # Track scan session
        self.scan_start_time = time.time()
        self.scan_session_id = self.db.add_scan_session(
            start_time=self.current_scan_stats['scan_start_time'],
            scan_path=str(target_path)
        )
        
        # Clear performance history
        self.files_per_second_history.clear()
        self.threats_per_second_history.clear()
        
        # Create generator
        self.file_generator = self._generate_files(target_path, recursive)
        
        # Start worker
        self.scan_thread = threading.Thread(
            target=self._scan_worker,
            name="ScanWorker",
            daemon=True
        )
        self.scan_thread.start()
        
        logger.info(f"Scan started on {target_path}")
        return True
    
    def _complete_scan(self):
        """Mark scan as completed."""
        self.scan_status = ScanStatus.COMPLETED
        
        with self.stats_lock:
            self.current_scan_stats['scan_end_time'] = datetime.now()
            self.current_scan_stats['current_file'] = ''
            self.current_scan_stats['last_progress_ts'] = time.time()
            
            if self.scan_start_time:
                elapsed = time.time() - self.scan_start_time
                avg_files_per_sec = self.current_scan_stats['files_scanned'] / elapsed if elapsed > 0 else 0
                
                self.db.update_scan_session(
                    self.scan_session_id,
                    end_time=self.current_scan_stats['scan_end_time'],
                    total_files=self.current_scan_stats['files_scanned'],
                    threats_found=self.current_scan_stats['threats_found'],
                    files_quarantined=self.current_scan_stats['files_quarantined'],
                    avg_files_per_sec=avg_files_per_sec
                )
        
        logger.info("Scan completed")
    
    def stop_scan(self) -> bool:
        """Stop current scan."""
        if self.scan_status != ScanStatus.SCANNING:
            return False
        
        self.scan_stop_event.set()
        self.scan_status = ScanStatus.STOPPED
        
        if self.scan_thread and self.scan_thread.is_alive():
            self.scan_thread.join(timeout=2.0)
        
        logger.info("Scan stopped")
        return True
    
    def get_scan_status(self) -> Dict[str, Any]:
        """Get current scan status."""
        with self.stats_lock:
            return {
                'status': self.scan_status.value,
                'files_scanned': self.current_scan_stats['files_scanned'],
                'threats_found': self.current_scan_stats['threats_found'],
                'files_quarantined': self.current_scan_stats['files_quarantined'],
                'files_per_sec': self.current_scan_stats['files_per_sec'],
                'current_file': self.current_scan_stats.get('current_file', ''),
                'last_progress_ts': self.current_scan_stats.get('last_progress_ts', 0.0),
            }
    
    def get_log_buffer_contents(self, count: int = 50) -> List[str]:
        """Get recent logs from buffer."""
        return self.log_buffer.get_recent(count)

    def get_log_buffer_since(self, last_seen: int, count: int = 50) -> tuple[List[str], int]:
        """Get only new log entries since the provided cursor."""
        return self.log_buffer.get_since(last_seen, count)
    
    # ==================== QUARANTINE ====================
    
    def quarantine_file(self, file_path: Path, detection: ThreatDetection) -> bool:
        """Quarantine file with XOR encryption to AppData/Local/SentinelDefender/quarantine."""
        tmp_vault_path = None
        try:
            if not file_path.exists():
                logger.warning(f"Quarantine skipped — file no longer exists: {file_path}")
                return False

            # Ensure quarantine directory exists (defensive — it should already be created)
            QUARANTINE_DIR.mkdir(parents=True, exist_ok=True)
            logger.info("Quarantine started: source=%s", file_path)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            try:
                sanitized_name = sanitize_filename(file_path.name)
            except Exception:
                sanitized_name = Path(file_path.name).name.replace(" ", "_")
            vault_filename = f"{timestamp}_{sanitized_name}.quar"
            vault_path = QUARANTINE_DIR / vault_filename
            tmp_vault_path = vault_path.with_suffix(vault_path.suffix + ".tmp")

            hasher = hashlib.sha256()
            total_size = 0
            with open(file_path, 'rb') as src, open(tmp_vault_path, 'wb') as dst:
                while True:
                    chunk = src.read(1024 * 1024)
                    if not chunk:
                        break
                    hasher.update(chunk)
                    dst.write(xor_encrypt_decrypt(chunk))
                    total_size += len(chunk)
                    time.sleep(0)

            tmp_vault_path.replace(vault_path)
            logger.info("Quarantine vault ready: %s", vault_path)

            # Remove original only after the quarantine payload is fully written.
            file_path.unlink()
            logger.info("Original file removed after quarantine: %s", file_path)

            self.db.add_quarantine_record(
                original_path=str(file_path),
                vault_path=str(vault_path),
                threat_name=detection.threat_name,
                threat_score=detection.threat_score,
                file_hash=hasher.hexdigest(),
                file_size=total_size,
                status='quarantined',
                notes=f"XOR encrypted, original: {file_path.suffix}"
            )

            # Update the scan_logs DB record so action_taken shows 'quarantined' not 'pending'
            self.db.update_threat_action(str(file_path), 'quarantined')

            with self.stats_lock:
                self.current_scan_stats['files_quarantined'] += 1

            logger.warning(f"File quarantined: {vault_path}")
            return True

        except Exception as e:
            for partial_path in (tmp_vault_path, locals().get('vault_path')):
                try:
                    if partial_path and partial_path.exists():
                        partial_path.unlink()
                except Exception:
                    pass
            logger.error(f"Quarantine failed for {file_path}: {e}", exc_info=True)
            return False
    
    def restore_file(self, quarantine_id: int, restore_path: Optional[Path] = None) -> bool:
        """Restore file from quarantine."""
        try:
            records = self.db.get_quarantine_records(status='quarantined')
            record = next((r for r in records if r['id'] == quarantine_id), None)
            
            if not record:
                return False
            
            vault_path = Path(record['vault_path'])
            if not vault_path.exists():
                return False
            
            with open(vault_path, 'rb') as f:
                encrypted_data = f.read()
            
            decrypted_data = xor_encrypt_decrypt(encrypted_data)
            
            current_hash = hashlib.sha256(decrypted_data).hexdigest()
            if current_hash != record['file_hash']:
                logger.error("Integrity check failed!")
                return False
            
            if restore_path is None:
                restore_path = Path(record['original_path'])
            
            restore_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(restore_path, 'wb') as f:
                f.write(decrypted_data)
            
            self.db.update_quarantine_status(
                quarantine_id,
                status='restored',
                notes=f"Restored to {restore_path}"
            )
            
            logger.info(f"File restored: {restore_path}")
            return True
            
        except Exception as e:
            logger.error(f"Restore failed: {e}")
            return False
    
    def delete_quarantined_file(self, quarantine_id: int) -> bool:
        """Delete quarantined file."""
        try:
            records = self.db.get_quarantine_records(status='quarantined')
            record = next((r for r in records if r['id'] == quarantine_id), None)
            
            if not record:
                return False
            
            vault_path = Path(record['vault_path'])
            if vault_path.exists():
                vault_path.unlink()
            
            self.db.update_quarantine_status(quarantine_id, status='deleted')
            return True
            
        except Exception as e:
            logger.error(f"Delete failed: {e}")
            return False
    
    # ==================== DYNAMIC REAL-TIME PROTECTION ====================

    def start_dynamic_protection(self, watch_paths: Optional[List[Path]] = None) -> Dict[str, bool]:
        """
        Start all real-time monitors: filesystem watcher, process monitor,
        memory scanner, and (Windows) registry monitor.

        watch_paths — list of Path objects to watch for new/modified files.
                      Defaults to the user's home directory if not supplied.

        Returns a dict of {component: started_ok} for status display.
        """
        if not DYNAMIC_ENGINE_AVAILABLE or self.dynamic_engine is None:
            logger.warning("DynamicEngine not available — cannot start real-time protection")
            return {}

        if self._dynamic_protection_active:
            logger.info("Dynamic protection already running")
            return {}

        # Register watch paths
        paths = watch_paths or [Path.home()]
        for p in paths:
            if p.exists():
                self.dynamic_engine.add_watch_path(str(p))

        result = self.dynamic_engine.start()
        self._dynamic_protection_active = True
        logger.info("Dynamic protection started: %s", result)
        return result

    def stop_dynamic_protection(self) -> None:
        """Stop all real-time monitors."""
        if self.dynamic_engine:
            self.dynamic_engine.stop()
        self._dynamic_protection_active = False
        logger.info("Dynamic protection stopped")

    def get_dynamic_alerts(self, max_items: int = 50) -> List:
        """
        Non-blocking drain of the dynamic alert queue.
        Safe to call from any thread; designed for GUI heartbeat polling.
        Also persists each alert to the database as a process alert record.
        """
        if not self.dynamic_engine:
            return []
        alerts = self.dynamic_engine.drain_alerts(max_items)
        for alert in alerts:
            try:
                self.db.add_process_alert(
                    process_name  = alert.alert_type,
                    process_id    = alert.details.get("pid", 0),
                    parent_process= alert.source,
                    alert_type    = alert.alert_type,
                    severity      = alert.severity,
                    description   = alert.description,
                    action_taken  = "detected"
                )
            except Exception:
                pass
        return alerts

    def get_dynamic_status(self) -> Dict:
        """Return current status of all real-time monitors."""
        if not self.dynamic_engine:
            return {"available": False, "running": False}
        status = self.dynamic_engine.get_status()
        status["available"] = True
        return status

    def is_dynamic_protection_active(self) -> bool:
        return self._dynamic_protection_active

    # ==================== LEGACY PROCESS MONITORING (compatibility shim) ====================

    def start_process_monitoring(self) -> bool:
        """
        Compatibility shim — now delegates to start_dynamic_protection().
        The old implementation was disabled due to GUI deadlocks; the new
        DynamicEngine uses a safe queue-based design instead.
        """
        result = self.start_dynamic_protection()
        return bool(result)
    
    def _process_monitor_worker(self):
        """Process monitoring worker."""
        while not self.monitor_stop_event.is_set():
            try:
                alerts = self.process_engine.scan_all_processes()
                
                for alert in alerts:
                    self.db.add_process_alert(
                        process_name=alert.process_name,
                        process_id=alert.process_id,
                        parent_process=alert.parent_process,
                        alert_type=alert.alert_type,
                        severity=alert.severity,
                        description=alert.description,
                        action_taken=alert.recommended_action
                    )
                    
                    if self.alert_callback:
                        try:
                            self.alert_callback(alert)
                        except Exception as e:
                            logger.error(f"Alert callback error: {e}")
                
                for _ in range(30):
                    if self.monitor_stop_event.is_set():
                        break
                    time.sleep(0.1)
                    
            except Exception as e:
                logger.error(f"Process monitor error: {e}")
                time.sleep(5)
    
    def stop_process_monitoring(self) -> bool:
        """Stop process monitoring."""
        if not self.monitoring_active:
            return False
        
        self.monitor_stop_event.set()
        self.monitoring_active = False
        
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=2.0)
        
        logger.info("Process monitoring stopped")
        return True
    
    # ==================== REPORTING ====================
    
    # ==================== NETWORK MONITORING ====================

    def _on_network_alert(self, alert) -> None:
        """Callback invoked by NetworkMonitor for each detected attack."""
        logger.warning(f"[NetworkAlert] {alert.severity} | {alert.category} | {alert.src_ip} -> {alert.dst_ip}")
        if self.alert_callback:
            try:
                self.alert_callback(alert)
            except Exception as e:
                logger.error(f"Network alert callback error: {e}")

    def start_network_monitoring(self, interface: Optional[str] = None) -> bool:
        """Start live packet capture on the given interface (or default)."""
        if self.network_monitor is None:
            logger.warning("NetworkMonitor not available (Scapy not installed?)")
            return False
        return self.network_monitor.start(interface=interface)

    def stop_network_monitoring(self) -> None:
        """Stop packet capture."""
        if self.network_monitor:
            self.network_monitor.stop()

    def get_network_stats(self) -> dict:
        """Return live network monitor stats."""
        if self.network_monitor:
            return self.network_monitor.get_stats()
        return {}

    def get_threat_intel_stats(self) -> dict:
        """Return ThreatIntel cache stats (record counts, last update times)."""
        ti = None
        # Prefer the TI instance on the network monitor (it's shared)
        if self.network_monitor and hasattr(self.network_monitor, "_ti"):
            ti = self.network_monitor._ti
        # Fallback to DetectionEngine's singleton
        if ti is None:
            try:
                from .detectors import get_threat_intel
                ti = get_threat_intel()
            except Exception:
                pass
        if ti is None:
            return {"available": False}
        try:
            stats = ti.get_stats()
            stats["available"] = True
            return stats
        except Exception:
            return {"available": False}

    def force_threat_intel_update(self) -> dict:
        """Trigger an immediate refresh of all TI feeds in the background."""
        import threading as _t
        ti = None
        if self.network_monitor and hasattr(self.network_monitor, "_ti"):
            ti = self.network_monitor._ti
        if ti is None:
            try:
                from .detectors import get_threat_intel
                ti = get_threat_intel()
            except Exception:
                pass
        if ti is None:
            return {}
        _t.Thread(target=ti.update_now, daemon=True).start()
        return {"status": "update_started"}

    def list_network_interfaces(self):
        """Return available network interfaces."""
        if self.network_monitor:
            return self.network_monitor.list_interfaces()
        return []

    # ==================== REPORTING ====================

    def generate_report(self, output_path: Optional[Path] = None) -> Optional[Path]:
        """Generate forensic PDF report scoped to the most recent scan session."""
        try:
            return self.reporter.generate_report(
                output_path=output_path,
                scan_session_id=self.scan_session_id,
            )
        except Exception as e:
            logger.error(f"Report generation failed: {e}")
            return None
    
    # ==================== CLEANUP ====================
    
    def shutdown(self):
        """Clean shutdown."""
        logger.info("Shutting down Sentinel Hub...")
        
        if self.scan_status == ScanStatus.SCANNING:
            self.stop_scan()
        
        if self.monitoring_active:
            self.stop_process_monitoring()
        
        self.stop_dynamic_protection()
        
        # Shutdown threat writer
        self.threat_writer.shutdown()
        
        logger.info("Sentinel Hub shutdown complete")
