#!/usr/bin/env python3
"""
Sentinel Defender - Planning Agent
Receives an InvestigationReport and produces a prioritised,
sequenced remediation plan ready for human review.
"""

import logging
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
#  Data classes
# ─────────────────────────────────────────────

@dataclass
class PlannedAction:
    action_id: str
    step: int
    action_type: str          # "quarantine" | "delete" | "network_isolate" | "report" | "rescan" | "alert"
    target: str               # file path, IP, "system", "user", etc.
    description: str
    rationale: str
    priority: str             # "IMMEDIATE" | "HIGH" | "MEDIUM" | "LOW"
    risk_level: str           # "SAFE" | "MODERATE" | "DESTRUCTIVE"
    requires_human: bool      # always True in this system
    estimated_duration: str   # e.g. "< 1 second"
    reversible: bool


@dataclass
class RemediationPlan:
    plan_id: str
    created_at: str
    source_report_id: str
    severity: str
    total_actions: int
    actions: list             # list[PlannedAction] serialised as dicts
    execution_order: list     # ordered list of action_ids
    warnings: list            # human-readable caution notes
    summary: str


# ─────────────────────────────────────────────
#  Agent
# ─────────────────────────────────────────────

class PlanningAgent:
    """
    Converts an InvestigationReport into an ordered, human-reviewable
    RemediationPlan without executing any actions itself.
    """

    def __init__(self):
        self._plan_counter = 0

    # ── Public API ────────────────────────────────────────────────────────────

    def plan(self, investigation_report) -> RemediationPlan:
        """
        investigation_report: InvestigationReport dataclass (or dict).
        Returns a RemediationPlan ready for human review.
        """
        self._plan_counter += 1
        # Accept both dataclass and dict
        if hasattr(investigation_report, "__dataclass_fields__"):
            rep = investigation_report
            threats    = rep.threats
            severity   = rep.severity
            indicators = rep.indicators
            rec_actions = rep.recommended_actions
            report_id  = rep.report_id
        else:
            rep = investigation_report
            threats    = rep.get("threats", [])
            severity   = rep.get("severity", "LOW")
            indicators = rep.get("indicators", [])
            rec_actions = rep.get("recommended_actions", [])
            report_id  = rep.get("report_id", "UNKNOWN")

        plan_id = f"PLAN-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{self._plan_counter:04d}"

        actions = []
        step    = 1

        # ── Step 1: Quarantine all un-quarantined threats ─────────────────────
        for threat in threats:
            fp = threat.get("file_path") or threat.get("path") or ""
            already = threat.get("quarantined") or threat.get("action") == "quarantine"
            if fp and not already:
                actions.append(PlannedAction(
                    action_id=f"{plan_id}-A{step:03d}",
                    step=step,
                    action_type="quarantine",
                    target=fp,
                    description=f"Move '{fp}' to encrypted quarantine vault",
                    rationale="Quarantining isolates the threat without permanent deletion, allowing recovery if needed.",
                    priority="IMMEDIATE",
                    risk_level="SAFE",
                    requires_human=True,
                    estimated_duration="< 1 second",
                    reversible=True,
                ))
                step += 1

        # ── Step 2: Network isolation for critical/high severity ──────────────
        if severity in ("CRITICAL", "HIGH"):
            actions.append(PlannedAction(
                action_id=f"{plan_id}-A{step:03d}",
                step=step,
                action_type="network_isolate",
                target="system",
                description="Disable network adapters to prevent C2 communication or lateral movement",
                rationale="High-severity threats often include backdoors or worms that communicate outbound.",
                priority="IMMEDIATE",
                risk_level="MODERATE",
                requires_human=True,
                estimated_duration="~5 seconds",
                reversible=True,
            ))
            step += 1

        # ── Step 3: Alert / notify ────────────────────────────────────────────
        actions.append(PlannedAction(
            action_id=f"{plan_id}-A{step:03d}",
            step=step,
            action_type="alert",
            target="user",
            description="Display a full-screen threat alert to the active user",
            rationale="Ensures the operator is aware of the incident and can take further manual action.",
            priority="HIGH",
            risk_level="SAFE",
            requires_human=True,
            estimated_duration="instant",
            reversible=True,
        ))
        step += 1

        # ── Step 4: Generate PDF report ───────────────────────────────────────
        actions.append(PlannedAction(
            action_id=f"{plan_id}-A{step:03d}",
            step=step,
            action_type="report",
            target="pdf",
            description="Generate a forensic PDF report of this incident",
            rationale="Provides auditable evidence for compliance, insurance, or law-enforcement purposes.",
            priority="HIGH",
            risk_level="SAFE",
            requires_human=True,
            estimated_duration="~2 seconds",
            reversible=True,
        ))
        step += 1

        # ── Step 5: Re-scan ───────────────────────────────────────────────────
        actions.append(PlannedAction(
            action_id=f"{plan_id}-A{step:03d}",
            step=step,
            action_type="rescan",
            target="original_scan_path",
            description="Run a follow-up full scan to confirm threats are resolved",
            rationale="Ensures no residual payloads remain after quarantine.",
            priority="MEDIUM",
            risk_level="SAFE",
            requires_human=True,
            estimated_duration="varies (same as original scan)",
            reversible=True,
        ))
        step += 1

        # ── Step 6: Permanent delete for critical threats ─────────────────────
        critical_threats = [
            t for t in threats
            if any(k in (t.get("threat_name") or t.get("threat_type") or "").lower()
                   for k in ("ransomware", "rootkit", "worm", "backdoor"))
        ]
        for threat in critical_threats:
            fp = threat.get("file_path") or threat.get("path") or ""
            if fp:
                actions.append(PlannedAction(
                    action_id=f"{plan_id}-A{step:03d}",
                    step=step,
                    action_type="delete",
                    target=fp,
                    description=f"Permanently delete '{fp}' from quarantine vault after confirmation",
                    rationale="Ransomware, rootkits, and worms pose ongoing risk even in quarantine.",
                    priority="HIGH",
                    risk_level="DESTRUCTIVE",
                    requires_human=True,
                    estimated_duration="< 1 second",
                    reversible=False,
                ))
                step += 1

        warnings = self._build_warnings(actions, severity)
        summary  = self._build_summary(plan_id, actions, severity, threats)

        plan = RemediationPlan(
            plan_id=plan_id,
            created_at=datetime.now().isoformat(timespec="seconds"),
            source_report_id=report_id,
            severity=severity,
            total_actions=len(actions),
            actions=[asdict(a) for a in actions],
            execution_order=[a.action_id for a in actions],
            warnings=warnings,
            summary=summary,
        )

        logger.info(
            "[PlanningAgent] Plan %s created: %d actions for severity %s",
            plan_id, len(actions), severity,
        )
        return plan

    # ── "Fix it for me" helpers ───────────────────────────────────────────────

    def get_safe_actions(self, plan) -> list:
        """
        Return only the SAFE-risk actions from a RemediationPlan.
        Used by the "Fix it for me" one-click mode — these run automatically
        without asking the user.  MODERATE and DESTRUCTIVE actions are
        excluded and must be approved separately.
        """
        if hasattr(plan, "actions"):
            actions = plan.actions
        else:
            actions = plan.get("actions", [])
        return [a for a in actions if a.get("risk_level") == "SAFE"]

    def get_destructive_actions(self, plan) -> list:
        """Return only DESTRUCTIVE actions (permanent delete, etc.)."""
        if hasattr(plan, "actions"):
            actions = plan.actions
        else:
            actions = plan.get("actions", [])
        return [a for a in actions if a.get("risk_level") == "DESTRUCTIVE"]

    def plain_english_summary(self, plan) -> str:
        """
        One-sentence plain-English summary of the plan for non-technical users.
        e.g. "Sentinel will move 2 suspicious files to quarantine and create a
              safety report — no files will be deleted."
        """
        if hasattr(plan, "actions"):
            actions = plan.actions
        else:
            actions = plan.get("actions", [])

        quarantine_count = sum(1 for a in actions if a.get("action_type") == "quarantine")
        delete_count     = sum(1 for a in actions if a.get("action_type") == "delete")
        has_network_iso  = any(a.get("action_type") == "network_isolate" for a in actions)

        parts = []
        if quarantine_count:
            parts.append(
                f"move {quarantine_count} "
                f"suspicious file{'s' if quarantine_count > 1 else ''} to quarantine"
            )
        if has_network_iso:
            parts.append("temporarily disconnect from the internet")
        if delete_count:
            parts.append(
                f"permanently delete {delete_count} "
                f"dangerous file{'s' if delete_count > 1 else ''} (your approval required)"
            )

        if not parts:
            return "Run a follow-up scan to confirm your computer is clean."

        action_str = ", and ".join(parts)
        return f"Sentinel will {action_str}."

    # ── Private helpers ───────────────────────────────────────────────────────

    def _build_warnings(self, actions: list, severity: str) -> list:
        warnings = []
        has_destructive = any(a.risk_level == "DESTRUCTIVE" for a in actions)
        has_network     = any(a.action_type == "network_isolate" for a in actions)

        warnings.append(
            "⚠️  All actions require your explicit approval before execution — review carefully."
        )
        if has_destructive:
            warnings.append(
                "🔴 DESTRUCTIVE actions are included — deleted files CANNOT be recovered."
            )
        if has_network:
            warnings.append(
                "🟡 Network isolation will disconnect this machine — save all work first."
            )
        if severity in ("CRITICAL", "HIGH"):
            warnings.append(
                "🔴 High severity incident — consider engaging your IT security team."
            )
        return warnings

    def _build_summary(
        self, plan_id: str, actions: list, severity: str, threats: list
    ) -> str:
        destructive = sum(1 for a in actions if a.risk_level == "DESTRUCTIVE")
        safe        = sum(1 for a in actions if a.risk_level == "SAFE")
        moderate    = sum(1 for a in actions if a.risk_level == "MODERATE")

        return (
            f"Remediation plan {plan_id} contains {len(actions)} action(s) for a "
            f"{severity}-severity incident involving {len(threats)} detected threat(s). "
            f"Action breakdown: {safe} safe, {moderate} moderate, {destructive} destructive. "
            f"Each action requires your explicit approval before execution."
        )