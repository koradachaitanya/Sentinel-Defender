"""
Sentinel Defender - Network Forensics Module (UNIQUE FEATURE)
Captures and analyzes network traffic for C2 communications.
Visualizes network connections and suspicious traffic patterns.

THIS IS UNIQUE: Combines endpoint + network forensics!
"""

import logging
import socket
import struct
from typing import List, Dict, Optional
from datetime import datetime, timedelta
from collections import defaultdict
from dataclasses import dataclass

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

logger = logging.getLogger(__name__)


@dataclass
class NetworkConnection:
    """Represents a network connection."""
    local_ip: str
    local_port: int
    remote_ip: str
    remote_port: int
    protocol: str
    status: str
    process_name: str
    process_id: int
    timestamp: datetime
    suspicious_score: int = 0
    threat_indicators: List[str] = None
    
    def __post_init__(self):
        if self.threat_indicators is None:
            self.threat_indicators = []


class NetworkForensics:
    """
    Network forensics and traffic analysis.
    Detects C2 communications, port scanning, data exfiltration.
    """
    
    # Known malicious ports
    SUSPICIOUS_PORTS = {
        4444: 'Metasploit default',
        5555: 'Backdoor/Trojan',
        6666: 'IRC Bot',
        6667: 'IRC Bot',
        8080: 'HTTP Proxy (often malicious)',
        8888: 'Alternate HTTP (often malicious)',
        9999: 'Backdoor',
        31337: 'Elite/Leet backdoor',
        12345: 'NetBus Trojan'
    }
    
    # Suspicious IP ranges (example - update with threat intel)
    SUSPICIOUS_IP_PATTERNS = [
        '192.0.2.',     # TEST-NET (often used by malware samples)
        '198.51.100.',  # TEST-NET
        '203.0.113.'    # TEST-NET
    ]
    
    def __init__(self):
        self.connections = []
        self.connection_history = defaultdict(list)
        self.alerts = []
    
    def capture_connections(self) -> List[NetworkConnection]:
        """Capture current network connections."""
        if not PSUTIL_AVAILABLE:
            logger.warning("psutil not available - network capture disabled")
            return []
        
        self.connections.clear()
        
        try:
            for conn in psutil.net_connections(kind='inet'):
                # Skip listening sockets with no remote address
                if conn.status == 'LISTEN' or not conn.raddr:
                    continue
                
                # Get process info
                try:
                    proc = psutil.Process(conn.pid) if conn.pid else None
                    proc_name = proc.name() if proc else 'Unknown'
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    proc_name = 'Unknown'
                
                # Create connection object
                connection = NetworkConnection(
                    local_ip=conn.laddr.ip,
                    local_port=conn.laddr.port,
                    remote_ip=conn.raddr.ip,
                    remote_port=conn.raddr.port,
                    protocol='TCP' if conn.type == socket.SOCK_STREAM else 'UDP',
                    status=conn.status,
                    process_name=proc_name,
                    process_id=conn.pid or 0,
                    timestamp=datetime.now()
                )
                
                # Analyze for threats
                connection.suspicious_score = self._analyze_connection(connection)
                
                self.connections.append(connection)
                
                # Track history
                key = f"{connection.remote_ip}:{connection.remote_port}"
                self.connection_history[key].append(connection.timestamp)
        
        except Exception as e:
            logger.error(f"Network capture error: {e}")
        
        return self.connections
    
    def _analyze_connection(self, conn: NetworkConnection) -> int:
        """Analyze connection for suspicious indicators."""
        score = 0
        
        # Check port
        if conn.remote_port in self.SUSPICIOUS_PORTS:
            score += 60
            conn.threat_indicators.append(f"Suspicious port: {conn.remote_port} ({self.SUSPICIOUS_PORTS[conn.remote_port]})")
        
        # Check IP patterns
        for pattern in self.SUSPICIOUS_IP_PATTERNS:
            if conn.remote_ip.startswith(pattern):
                score += 50
                conn.threat_indicators.append(f"Suspicious IP range: {pattern}*")
        
        # Check process
        suspicious_procs = ['cmd.exe', 'powershell.exe', 'wscript.exe', 'mshta.exe', 'rundll32.exe']
        if conn.process_name.lower() in suspicious_procs:
            score += 40
            conn.threat_indicators.append(f"Suspicious process: {conn.process_name}")
        
        # Check for non-standard web ports
        web_ports = [80, 443, 8080, 8443]
        if conn.remote_port not in web_ports and conn.remote_port < 1024:
            score += 20
            conn.threat_indicators.append(f"Non-standard port: {conn.remote_port}")
        
        # Check for external connections from system processes
        system_procs = ['svchost.exe', 'lsass.exe', 'csrss.exe']
        if conn.process_name.lower() in system_procs:
            if not self._is_local_ip(conn.remote_ip):
                score += 70
                conn.threat_indicators.append(f"System process connecting externally: {conn.process_name}")
        
        return min(score, 100)
    
    def detect_c2_beaconing(self, time_window_minutes: int = 10) -> List[Dict]:
        """
        Detect C2 beaconing (periodic connections to same host).
        Returns list of suspected C2 servers.
        """
        c2_candidates = []
        cutoff_time = datetime.now() - timedelta(minutes=time_window_minutes)
        
        for key, timestamps in self.connection_history.items():
            # Filter recent connections
            recent = [t for t in timestamps if t > cutoff_time]
            
            if len(recent) < 3:
                continue
            
            # Calculate intervals
            intervals = []
            for i in range(len(recent) - 1):
                interval = (recent[i+1] - recent[i]).total_seconds()
                intervals.append(interval)
            
            if not intervals:
                continue
            
            # Check for regularity (low variance = beaconing)
            avg_interval = sum(intervals) / len(intervals)
            variance = sum((i - avg_interval) ** 2 for i in intervals) / len(intervals)
            std_dev = variance ** 0.5
            
            # If intervals are regular (low variance), it's likely C2
            if std_dev < avg_interval * 0.3:  # 30% variance threshold
                remote_ip, remote_port = key.rsplit(':', 1)
                c2_candidates.append({
                    'remote_ip': remote_ip,
                    'remote_port': int(remote_port),
                    'connection_count': len(recent),
                    'avg_interval': avg_interval,
                    'confidence': 1.0 - (std_dev / avg_interval) if avg_interval > 0 else 0,
                    'threat_type': 'C2 Beaconing',
                    'severity': 'critical'
                })
        
        return c2_candidates
    
    def detect_port_scanning(self, time_window_seconds: int = 10) -> List[Dict]:
        """Detect port scanning (many connections to different ports)."""
        recent_connections = [c for c in self.connections 
                            if (datetime.now() - c.timestamp).total_seconds() < time_window_seconds]
        
        # Group by remote IP
        by_ip = defaultdict(list)
        for conn in recent_connections:
            by_ip[conn.remote_ip].append(conn.remote_port)
        
        # Detect scanning (many ports from same IP)
        scanners = []
        for ip, ports in by_ip.items():
            unique_ports = set(ports)
            if len(unique_ports) >= 5:  # 5+ different ports in 10 seconds
                scanners.append({
                    'remote_ip': ip,
                    'ports_scanned': list(unique_ports),
                    'scan_count': len(unique_ports),
                    'threat_type': 'Port Scanning',
                    'severity': 'high'
                })
        
        return scanners
    
    def detect_data_exfiltration(self) -> List[Dict]:
        """Detect potential data exfiltration (large outbound transfers)."""
        # This is simplified - real implementation would track bytes sent
        exfil_candidates = []
        
        suspicious_connections = [c for c in self.connections if c.suspicious_score > 60]
        
        for conn in suspicious_connections:
            # Check if it's a long-lived connection (potential data transfer)
            if conn.status == 'ESTABLISHED':
                exfil_candidates.append({
                    'remote_ip': conn.remote_ip,
                    'remote_port': conn.remote_port,
                    'process': conn.process_name,
                    'threat_type': 'Potential Data Exfiltration',
                    'severity': 'high',
                    'indicators': conn.threat_indicators
                })
        
        return exfil_candidates
    
    def generate_network_map(self) -> Dict:
        """Generate network map data for visualization."""
        nodes = []
        edges = []
        
        # Add local system as central node
        nodes.append({
            'id': 'local',
            'label': 'Your System',
            'type': 'local',
            'ip': socket.gethostname()
        })
        
        # Add remote hosts as nodes
        seen_ips = set()
        for conn in self.connections:
            if conn.remote_ip not in seen_ips:
                nodes.append({
                    'id': conn.remote_ip,
                    'label': conn.remote_ip,
                    'type': 'remote',
                    'suspicious': conn.suspicious_score > 50
                })
                seen_ips.add(conn.remote_ip)
            
            # Add edge
            edges.append({
                'source': 'local',
                'target': conn.remote_ip,
                'port': conn.remote_port,
                'protocol': conn.protocol,
                'process': conn.process_name,
                'suspicious': conn.suspicious_score > 50
            })
        
        return {
            'nodes': nodes,
            'edges': edges,
            'timestamp': datetime.now().isoformat()
        }
    
    @staticmethod
    def _is_local_ip(ip: str) -> bool:
        """Check if IP is local/private."""
        return (ip.startswith('127.') or 
                ip.startswith('192.168.') or
                ip.startswith('10.') or
                ip.startswith('172.'))
    
    def get_summary(self) -> Dict:
        """Get network forensics summary."""
        total = len(self.connections)
        suspicious = len([c for c in self.connections if c.suspicious_score > 50])
        
        c2_detected = self.detect_c2_beaconing()
        port_scans = self.detect_port_scanning()
        
        return {
            'total_connections': total,
            'suspicious_connections': suspicious,
            'c2_servers_detected': len(c2_detected),
            'port_scans_detected': len(port_scans),
            'threat_level': 'high' if suspicious > 5 else 'medium' if suspicious > 0 else 'low'
        }
