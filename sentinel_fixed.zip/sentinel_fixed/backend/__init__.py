"""
Sentinel Defender - Research-Grade Antivirus Backend
Purpose: University Final Year Project

Backend modules for threat detection, analysis, and quarantine management.
"""

__version__ = "2.0.0"
__author__ = "Sentinel Security Research Team"

# Expose the new dynamic engine for convenience imports
try:
    from .dynamic_engine import DynamicEngine, DynamicAlert
except ImportError:
    pass