"""
Sentinel Defender - Optimized Database Manager
Phase 1: Threat-only logging with async batch writes for performance.
"""

import sqlite3
import logging
import os
import platform
from pathlib import Path
from typing import List, Dict, Optional, Any
from contextlib import contextmanager
from datetime import datetime

# Configure logging
logger = logging.getLogger(__name__)


# ==================== STORAGE PATH CONFIGURATION ====================

def get_app_data_dir() -> Path:
    """Get platform-appropriate application data directory."""
    system = platform.system()
    
    if system == "Windows":
        base = os.getenv('LOCALAPPDATA')
        if not base:
            base = os.path.expanduser('~\\AppData\\Local')
        app_dir = Path(base) / 'SentinelDefender'
        
    elif system == "Darwin":  # macOS
        app_dir = Path.home() / 'Library' / 'Application Support' / 'SentinelDefender'
        
    elif system == "Linux":
        xdg_data = os.getenv('XDG_DATA_HOME')
        if xdg_data:
            app_dir = Path(xdg_data) / 'SentinelDefender'
        else:
            app_dir = Path.home() / '.local' / 'share' / 'SentinelDefender'
    
    else:
        app_dir = Path.home() / '.SentinelDefender'
    
    # Create directory structure
    app_dir.mkdir(parents=True, exist_ok=True)
    (app_dir / 'logs').mkdir(exist_ok=True)
    (app_dir / 'quarantine').mkdir(exist_ok=True)
    
    return app_dir


# Global paths
APP_DATA_DIR = get_app_data_dir()
DATABASE_PATH = APP_DATA_DIR / 'sentinel.db'
LOG_DIR = APP_DATA_DIR / 'logs'
QUARANTINE_DIR = APP_DATA_DIR / 'quarantine'

logger.info(f"Application data directory: {APP_DATA_DIR}")


# ==================== DATABASE MANAGER ====================

class DatabaseManager:
    """
    High-performance database manager with threat-only logging.
    Phase 1: Only threats and errors are saved to disk (not clean files).
    """
    
    def __init__(self, db_path: Path = DATABASE_PATH):
        """Initialize database manager."""
        self.db_path = db_path
        
        # Initialize database and enable optimizations
        self.initialize_database()
        self._enable_wal_mode()
        self._optimize_pragmas()
        
        logger.info(f"Database initialized at {self.db_path}")
    
    @contextmanager
    def get_connection(self):
        """Context manager for database connections."""
        conn = sqlite3.connect(str(self.db_path), timeout=10.0)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Database transaction failed: {e}")
            raise
        finally:
            conn.close()
    
    def _enable_wal_mode(self):
        """Enable Write-Ahead Logging (WAL) mode for better concurrency."""
        try:
            with self.get_connection() as conn:
                result = conn.execute("PRAGMA journal_mode=WAL").fetchone()
                logger.info(f"WAL mode enabled: {result[0]}")
                conn.execute("PRAGMA wal_autocheckpoint=1000")
        except Exception as e:
            logger.error(f"Failed to enable WAL mode: {e}")
    
    def _optimize_pragmas(self):
        """Configure SQLite PRAGMAs for optimal performance."""
        try:
            with self.get_connection() as conn:
                conn.execute("PRAGMA synchronous=NORMAL")
                conn.execute("PRAGMA cache_size=-20000")  # 20 MB
                conn.execute("PRAGMA temp_store=MEMORY")
                conn.execute("PRAGMA foreign_keys=ON")
                logger.info("Database PRAGMAs optimized")
        except Exception as e:
            logger.error(f"Failed to optimize PRAGMAs: {e}")
    
    def initialize_database(self):
        """Create database tables if they don't exist."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # PHASE 1: Threat-only scan logs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS scan_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    file_path TEXT NOT NULL,
                    file_size INTEGER,
                    scan_status TEXT NOT NULL,
                    threat_name TEXT,
                    threat_type TEXT,
                    threat_score INTEGER,
                    detection_method TEXT,
                    action_taken TEXT,
                    scan_duration_ms INTEGER
                )
            """)
            
            # Indexes for fast queries
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_scan_logs_timestamp 
                ON scan_logs(timestamp DESC)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_scan_logs_threat_type 
                ON scan_logs(threat_type)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_scan_logs_status 
                ON scan_logs(scan_status)
            """)
            
            # Scan sessions table (metadata for graphs)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS scan_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    start_time DATETIME NOT NULL,
                    end_time DATETIME,
                    total_files INTEGER DEFAULT 0,
                    threats_found INTEGER DEFAULT 0,
                    files_quarantined INTEGER DEFAULT 0,
                    avg_files_per_sec REAL,
                    scan_path TEXT
                )
            """)
            
            # Quarantine table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS quarantine (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    original_path TEXT NOT NULL,
                    vault_path TEXT NOT NULL,
                    threat_name TEXT,
                    threat_score INTEGER,
                    file_hash TEXT,
                    file_size INTEGER,
                    quarantine_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    restore_date DATETIME,
                    status TEXT DEFAULT 'quarantined',
                    notes TEXT
                )
            """)
            
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_quarantine_status 
                ON quarantine(status)
            """)
            
            # Process alerts table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS process_alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    process_name TEXT NOT NULL,
                    process_id INTEGER,
                    parent_process TEXT,
                    alert_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    description TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    action_taken TEXT,
                    status TEXT DEFAULT 'active'
                )
            """)
    
    # ==================== PHASE 1: BATCH THREAT OPERATIONS ====================
    
    def batch_insert_threats(self, threats: List[Dict[str, Any]]):
        """
        PHASE 1: Batch insert threat records (NOT clean files).
        This is called asynchronously from the DB writer daemon.
        """
        if not threats:
            return
        
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Prepare data
                columns = [
                    'timestamp', 'file_path', 'file_size', 'scan_status',
                    'threat_name', 'threat_type', 'threat_score',
                    'detection_method', 'action_taken', 'scan_duration_ms'
                ]
                
                values = []
                for threat in threats:
                    values.append((
                        threat.get('timestamp', datetime.now()),
                        threat.get('file_path'),
                        threat.get('file_size'),
                        threat.get('scan_status', 'threat'),
                        threat.get('threat_name'),
                        threat.get('threat_type'),
                        threat.get('threat_score'),
                        threat.get('detection_method'),
                        threat.get('action_taken'),
                        threat.get('scan_duration_ms')
                    ))
                
                cursor.executemany(f"""
                    INSERT INTO scan_logs ({','.join(columns)})
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, values)
                
                logger.info(f"Batch inserted {len(threats)} threat records")
                
        except Exception as e:
            logger.error(f"Batch threat insert failed: {e}")
    
    def add_scan_session(self, **kwargs) -> int:
        """Start a new scan session."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO scan_sessions (start_time, scan_path)
                    VALUES (?, ?)
                """, (kwargs.get('start_time', datetime.now()), kwargs.get('scan_path')))
                return cursor.lastrowid
        except Exception as e:
            logger.error(f"Failed to add scan session: {e}")
            return 0
    
    def update_scan_session(self, session_id: int, **kwargs):
        """Update scan session with results."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE scan_sessions
                    SET end_time = ?,
                        total_files = ?,
                        threats_found = ?,
                        files_quarantined = ?,
                        avg_files_per_sec = ?
                    WHERE id = ?
                """, (
                    kwargs.get('end_time', datetime.now()),
                    kwargs.get('total_files', 0),
                    kwargs.get('threats_found', 0),
                    kwargs.get('files_quarantined', 0),
                    kwargs.get('avg_files_per_sec', 0.0),
                    session_id
                ))
        except Exception as e:
            logger.error(f"Failed to update scan session: {e}")
    
    # ==================== PHASE 2: QUERY METHODS FOR GRAPHS ====================
    
    def get_recent_threats(self, limit: int = 100) -> List[Dict]:
        """Get recent threats for dashboard display."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT * FROM scan_logs
                    WHERE scan_status = 'threat'
                    ORDER BY timestamp DESC
                    LIMIT ?
                """, (limit,))
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Failed to get recent threats: {e}")
            return []
    
    def get_threat_statistics(self) -> Dict[str, Any]:
        """Get threat statistics for dashboard."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                # Total threats
                cursor.execute("SELECT COUNT(*) FROM scan_logs WHERE scan_status = 'threat'")
                total_threats = cursor.fetchone()[0]
                
                # Threats by type
                cursor.execute("""
                    SELECT threat_type, COUNT(*) as count
                    FROM scan_logs
                    WHERE threat_type IS NOT NULL
                    GROUP BY threat_type
                """)
                threats_by_type = {row[0]: row[1] for row in cursor.fetchall()}
                
                # Recent session stats
                cursor.execute("""
                    SELECT 
                        AVG(avg_files_per_sec) as avg_speed,
                        SUM(total_files) as total_files,
                        SUM(threats_found) as total_threats
                    FROM scan_sessions
                    WHERE start_time > datetime('now', '-7 days')
                """)
                session_stats = cursor.fetchone()
                
                return {
                    'total_threats': total_threats,
                    'threats_by_type': threats_by_type,
                    'avg_scan_speed': session_stats[0] or 0.0,
                    'total_files_scanned': session_stats[1] or 0,
                    'threats_last_7_days': session_stats[2] or 0
                }
                
        except Exception as e:
            logger.error(f"Failed to get threat statistics: {e}")
            return {
                'total_threats': 0,
                'threats_by_type': {},
                'avg_scan_speed': 0.0,
                'total_files_scanned': 0,
                'threats_last_7_days': 0
            }
    
    def get_scan_history(self, limit: int = 1000, threat_only: bool = True) -> List[Dict]:
        """
        Get scan history for reporting.
        
        Args:
            limit: Maximum number of records to return
            threat_only: If True, only return threat records (not clean files)
        
        Returns:
            List of scan log records as dictionaries
        """
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                if threat_only:
                    # Only threats (default for reports)
                    cursor.execute("""
                        SELECT * FROM scan_logs
                        WHERE scan_status = 'threat'
                        ORDER BY timestamp DESC
                        LIMIT ?
                    """, (limit,))
                else:
                    # All scan records
                    cursor.execute("""
                        SELECT * FROM scan_logs
                        ORDER BY timestamp DESC
                        LIMIT ?
                    """, (limit,))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except Exception as e:
            logger.error(f"Failed to get scan history: {e}")
            return []
    
    # ==================== SESSION-SCOPED QUERIES (for per-scan reports) ====================

    def get_session_info(self, session_id: int) -> Optional[Dict]:
        """Return the scan_sessions row for the given session_id."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT * FROM scan_sessions WHERE id = ?", (session_id,)
                )
                row = cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            logger.error(f"get_session_info failed: {e}")
            return None

    def get_scan_history_by_session(self, session_id: int) -> List[Dict]:
        """
        Return only the threat records that belong to a specific scan session,
        identified by matching timestamp to the session's start_time..end_time window.
        Falls back to all threats if the session window cannot be determined.
        """
        session = self.get_session_info(session_id)
        if not session:
            return self.get_scan_history(limit=2000, threat_only=True)
        start = session.get("start_time")
        end   = session.get("end_time")
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                if end:
                    cursor.execute("""
                        SELECT * FROM scan_logs
                        WHERE scan_status = 'threat'
                          AND timestamp >= ?
                          AND timestamp <= ?
                        ORDER BY timestamp DESC
                    """, (start, end))
                else:
                    # Session still running or end not recorded — use start onwards
                    cursor.execute("""
                        SELECT * FROM scan_logs
                        WHERE scan_status = 'threat'
                          AND timestamp >= ?
                        ORDER BY timestamp DESC
                    """, (start,))
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"get_scan_history_by_session failed: {e}")
            return []

    def get_threat_statistics_by_session(self, session_id: int) -> Dict:
        """
        Return threat statistics scoped to a single scan session.
        """
        session = self.get_session_info(session_id)
        if not session:
            return self.get_threat_statistics()
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                start = session.get("start_time")
                end   = session.get("end_time")
                time_filter = ("AND timestamp >= ? AND timestamp <= ?" if end
                               else "AND timestamp >= ?")
                params = (start, end) if end else (start,)

                cursor.execute(f"""
                    SELECT COUNT(*) FROM scan_logs
                    WHERE scan_status = 'threat' {time_filter}
                """, params)
                total_threats = cursor.fetchone()[0]

                cursor.execute(f"""
                    SELECT threat_type, COUNT(*) as count
                    FROM scan_logs
                    WHERE threat_type IS NOT NULL {time_filter}
                    GROUP BY threat_type
                """, params)
                threats_by_type = {row[0]: row[1] for row in cursor.fetchall()}

                return {
                    "total_threats":      total_threats,
                    "threats_by_type":    threats_by_type,
                    "avg_scan_speed":     session.get("avg_files_per_sec") or 0.0,
                    "total_files_scanned":session.get("total_files") or 0,
                    "threats_last_7_days":total_threats,
                    "scan_path":          session.get("scan_path", ""),
                    "start_time":         str(session.get("start_time", "")),
                    "end_time":           str(session.get("end_time", "")),
                    "session_id":         session_id,
                }
        except Exception as e:
            logger.error(f"get_threat_statistics_by_session failed: {e}")
            return self.get_threat_statistics()

    def get_quarantine_by_session(self, session_id: int) -> List[Dict]:
        """
        Return quarantine records created during the given scan session's time window.
        """
        session = self.get_session_info(session_id)
        if not session:
            return self.get_quarantine_records(status="quarantined")
        start = session.get("start_time")
        end   = session.get("end_time")
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                if end:
                    cursor.execute("""
                        SELECT * FROM quarantine
                        WHERE quarantine_date >= ?
                          AND quarantine_date <= ?
                        ORDER BY quarantine_date DESC
                    """, (start, end))
                else:
                    cursor.execute("""
                        SELECT * FROM quarantine
                        WHERE quarantine_date >= ?
                        ORDER BY quarantine_date DESC
                    """, (start,))
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"get_quarantine_by_session failed: {e}")
            return []

    # ==================== QUARANTINE OPERATIONS ====================
    
    def batch_add_quarantine_records(self, records: List[Dict[str, Any]]):
        """Batch insert quarantine records."""
        if not records:
            return
        
        try:
            columns = list(records[0].keys())
            placeholders = ','.join(['?'] * len(columns))
            column_names = ','.join(columns)
            
            query = f"INSERT INTO quarantine ({column_names}) VALUES ({placeholders})"
            values = [tuple(record.get(col) for col in columns) for record in records]
            
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.executemany(query, values)
            
            logger.debug(f"Batch inserted {len(records)} quarantine records")
            
        except Exception as e:
            logger.error(f"Batch quarantine record insert failed: {e}")
    
    def add_quarantine_record(self, **kwargs):
        """Add single quarantine record."""
        self.batch_add_quarantine_records([kwargs])

    def update_threat_action(self, file_path: str, action: str):
        """Update action_taken for a threat record by file path (called after quarantine)."""
        try:
            with self.get_connection() as conn:
                conn.execute(
                    "UPDATE scan_logs SET action_taken = ? WHERE file_path = ?",
                    (action, file_path)
                )
                logger.debug(f"Updated action_taken='{action}' for {file_path}")
        except Exception as e:
            logger.error(f"update_threat_action failed for {file_path}: {e}")
    
    def get_quarantine_records(self, status: str = 'quarantined') -> List[Dict]:
        """Get quarantine records."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT * FROM quarantine
                    WHERE status = ?
                    ORDER BY quarantine_date DESC
                """, (status,))
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Failed to get quarantine records: {e}")
            return []
    
    def update_quarantine_status(self, quarantine_id: int, status: str, notes: str = None):
        """Update quarantine record status."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                if status == 'restored':
                    cursor.execute("""
                        UPDATE quarantine
                        SET status = ?, restore_date = ?, notes = ?
                        WHERE id = ?
                    """, (status, datetime.now(), notes, quarantine_id))
                else:
                    cursor.execute("""
                        UPDATE quarantine
                        SET status = ?, notes = ?
                        WHERE id = ?
                    """, (status, notes, quarantine_id))
                    
        except Exception as e:
            logger.error(f"Failed to update quarantine status: {e}")
    
    def batch_update_quarantine_status(self, quarantine_ids: List[int], status: str):
        """PHASE 3: Bulk update quarantine status."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                
                placeholders = ','.join(['?'] * len(quarantine_ids))
                
                if status == 'restored':
                    cursor.execute(f"""
                        UPDATE quarantine
                        SET status = ?, restore_date = ?
                        WHERE id IN ({placeholders})
                    """, (status, datetime.now(), *quarantine_ids))
                else:
                    cursor.execute(f"""
                        UPDATE quarantine
                        SET status = ?
                        WHERE id IN ({placeholders})
                    """, (status, *quarantine_ids))
                    
                logger.info(f"Bulk updated {len(quarantine_ids)} quarantine records to '{status}'")
                
        except Exception as e:
            logger.error(f"Batch quarantine update failed: {e}")
    
    # ==================== PROCESS ALERTS ====================
    
    def add_process_alert(self, **kwargs):
        """Add process alert."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO process_alerts 
                    (process_name, process_id, parent_process, alert_type, 
                     severity, description, action_taken)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    kwargs.get('process_name'),
                    kwargs.get('process_id'),
                    kwargs.get('parent_process'),
                    kwargs.get('alert_type'),
                    kwargs.get('severity'),
                    kwargs.get('description'),
                    kwargs.get('action_taken')
                ))
        except Exception as e:
            logger.error(f"Failed to add process alert: {e}")
    
    def get_process_alerts(self, limit: int = 50) -> List[Dict]:
        """Get recent process alerts."""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT * FROM process_alerts
                    ORDER BY timestamp DESC
                    LIMIT ?
                """, (limit,))
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"Failed to get process alerts: {e}")
            return []
    
    # ==================== INCIDENT TIMELINE ====================

    def get_incident_timeline(self, hours_back: int = 24, limit: int = 200) -> list:
        """
        Return a unified chronological list of events from all tables
        (scan_logs threats + process_alerts + quarantine) within the last
        `hours_back` hours, sorted newest-first.

        Each entry is a dict with keys:
            timestamp, event_type, title, detail, severity, source_table
        """
        try:
            with self.get_connection() as conn:
                conn.row_factory = __import__('sqlite3').Row

                # ── File threats from scan_logs ────────────────────────────
                file_rows = conn.execute("""
                    SELECT
                        timestamp,
                        'file_threat'                   AS event_type,
                        COALESCE(threat_name, 'Suspicious file') AS title,
                        file_path                       AS detail,
                        COALESCE(threat_type, 'medium') AS severity,
                        'scan_logs'                     AS source_table
                    FROM scan_logs
                    WHERE scan_status = 'threat'
                      AND timestamp >= datetime('now', ? || ' hours')
                    ORDER BY timestamp DESC
                    LIMIT ?
                """, (f"-{hours_back}", limit // 2)).fetchall()

                # ── Process alerts ─────────────────────────────────────────
                proc_rows = conn.execute("""
                    SELECT
                        timestamp,
                        'process_alert'                 AS event_type,
                        COALESCE(alert_type, 'Suspicious process') AS title,
                        COALESCE(process_name, '') || ' (PID ' ||
                            COALESCE(process_id, '?') || ')'  AS detail,
                        severity,
                        'process_alerts'                AS source_table
                    FROM process_alerts
                    WHERE timestamp >= datetime('now', ? || ' hours')
                    ORDER BY timestamp DESC
                    LIMIT ?
                """, (f"-{hours_back}", limit // 4)).fetchall()

                # ── Quarantine events ──────────────────────────────────────
                quar_rows = conn.execute("""
                    SELECT
                        quarantine_date                 AS timestamp,
                        'quarantine'                    AS event_type,
                        'File quarantined'              AS title,
                        COALESCE(original_path, vault_path) AS detail,
                        'high'                          AS severity,
                        'quarantine'                    AS source_table
                    FROM quarantine
                    WHERE quarantine_date >= datetime('now', ? || ' hours')
                    ORDER BY quarantine_date DESC
                    LIMIT ?
                """, (f"-{hours_back}", limit // 4)).fetchall()

                # Merge and sort
                all_events = [dict(r) for r in (*file_rows, *proc_rows, *quar_rows)]
                all_events.sort(key=lambda e: e.get("timestamp", ""), reverse=True)
                return all_events[:limit]

        except Exception as e:
            logger.error(f"get_incident_timeline failed: {e}")
            return []

    # ==================== MAINTENANCE ====================
    
    def vacuum_database(self):
        """Optimize database (reclaim space)."""
        try:
            with self.get_connection() as conn:
                conn.execute("VACUUM")
            logger.info("Database vacuumed successfully")
        except Exception as e:
            logger.error(f"Database vacuum failed: {e}")
    
    def checkpoint_wal(self):
        """Force WAL checkpoint."""
        try:
            with self.get_connection() as conn:
                conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            logger.info("WAL checkpoint completed")
        except Exception as e:
            logger.error(f"WAL checkpoint failed: {e}")