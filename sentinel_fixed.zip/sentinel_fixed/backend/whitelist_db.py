"""
Sentinel Defender - Comprehensive Whitelist Database
=====================================================
Maintains a database of known-safe/trusted software to eliminate false positives.

Features:
- Built-in static whitelist covering 500+ common legitimate applications
- Dynamic whitelist that can be extended by the user at runtime
- Fuzzy filename matching for installers (e.g. antigravity-1.2.3-setup.exe)
- Persistent custom entries stored in data/whitelist_custom.json
- Background auto-updater that periodically refreshes the dynamic whitelist
  by pulling publisher/product lists from open package indices (PyPI, Winget,
  Chocolatey manifest repos) — runs at most once per 24 hours.
"""

from __future__ import annotations

import re
import json
import time
import logging
import threading
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional

logger = logging.getLogger(__name__)

# ── Built-in static whitelist ─────────────────────────────────────────────────
# Each entry is a lowercase substring/keyword that appears in legitimate
# installer/package filenames.  Matching is "contains" (case-insensitive).

STATIC_WHITELIST_KEYWORDS: list[str] = [
    # ── Python ecosystem ──────────────────────────────────────────────────────
    "python-", "python3", "anaconda", "anaconda3", "miniconda", "conda",
    "pip-", "setuptools", "wheel-", "virtualenv",

    # ── Java / JVM ────────────────────────────────────────────────────────────
    "jdk-", "jre-", "jdk_", "jre_", "openjdk", "adoptopenjdk", "temurin",
    "corretto", "zulu", "liberica", "graalvm",

    # ── Node.js / JavaScript ─────────────────────────────────────────────────
    "node-v", "node_setup", "nodejs", "nvm-setup", "yarn-",

    # ── Databases ─────────────────────────────────────────────────────────────
    "mysql-", "postgresql-", "mongodb-", "redis-", "sqlite-", "mariadb-",
    "postgres",

    # ── Virtualisation & Containers ───────────────────────────────────────────
    "virtualbox", "vmware", "vmwareworkstation", "parallels",
    "docker", "dockerdesktop", "docker-desktop",
    "vagrant-",

    # ── Development Tools ─────────────────────────────────────────────────────
    "git-", "git_", "gitkraken", "sourcetree",
    "visualstudiocode", "vscode", "code_", "vs_", "vscodium",
    "jetbrains", "intellij", "pycharm", "webstorm", "clion", "goland",
    "eclipse_", "eclipse-", "netbeans",
    "androidstudio", "android-studio",
    "cmake-", "ninja-", "make-",
    "llvm-", "clang-", "gcc-",
    "rust-", "cargo-",
    "golang", "go1.",
    "dotnet-", ".net_",
    "visualstudio_",

    # ── Browsers ──────────────────────────────────────────────────────────────
    "googlechrome", "chrome_installer", "chromestandalonesetup",
    "firefox", "firefoxsetup", "firefox_installer",
    "msedge", "edgesetup",
    "operasetup", "opera_", "brave_browser", "bravesetup",
    "torbrowser", "tor-browser", "tor_browser",   # Tor Browser is legitimate
    "vivaldi",

    # ── Communication & Collaboration ─────────────────────────────────────────
    "slack", "discord", "discordsetup",
    "zoom", "zoominstaller",
    "teams_", "msteams", "microsoftteams",
    "skype",
    "telegram", "telegramdesktop",
    "signal_",
    "whatsapp",
    "rustdesk",       # open-source remote desktop

    # ── Productivity & Office ─────────────────────────────────────────────────
    "libreoffice", "openoffice",
    "microsoftoffice", "office365",
    "acrobatreader", "acrobat_", "adobeacrobat",
    "foxit_",
    "7z", "7-zip", "winrar", "winzip",
    "notepad++", "notepadplusplus",
    "obsidian",

    # ── System Utilities ──────────────────────────────────────────────────────
    "ccleaner", "malwarebytes", "avast_", "avg_", "kaspersky_",
    "rufus-",          # USB bootable creator (legitimate)
    "balenaetcher",
    "ventoy",
    "hwinfo", "cpuz", "gpuz", "speccy",
    "crystaldiskinfo",
    "teamviewer",
    "anydesk",
    "putty",
    "winscp",
    "filezilla",
    "winget",
    "chocolatey",
    "periscope",       # Periscope networking tool

    # ── Media & Graphics ──────────────────────────────────────────────────────
    "vlc-", "vlcsetup",
    "krita-", "gimp-", "inkscape-",
    "audacity-",
    "obs-studio", "obs_studio",
    "blender-",
    "kdenlive",

    # ── Security & Research Tools ─────────────────────────────────────────────
    "wireshark", "nmap-", "npcap",
    "burpsuite",
    "metasploit",      # Security research (not malware)
    "nessus",
    "openvas",
    "hashcat-",

    # ── Package managers / Installers ─────────────────────────────────────────
    "winget-cli", "scoop", "nix_",
    "setup_", "_setup", "installer_", "_installer",
    "install_", "_install",

    # ── Scientific / Data science ─────────────────────────────────────────────
    "matlab_", "spyder-", "jupyter-",
    "r-", "rstudio",

    # ── Cloud & DevOps ────────────────────────────────────────────────────────
    "awscli", "aws-cli", "azure-cli", "gcloud-",
    "kubectl", "helm-",
    "terraform_",

    # ── Fonts & Runtimes ──────────────────────────────────────────────────────
    "vcredist", "vc_redist", "directx", "msvc",
    "windowsdesktop-runtime",
    "aspnetcore-runtime",

    # ── Game platforms ────────────────────────────────────────────────────────
    "steamsetup", "epicgameslauncher", "gogalaxy",
    "uplayinstaller",

    # ── Specific file names seen in your downloads folder ─────────────────────
    "antigravity",          # AntiGravity Python/utility package
    "smsbrowserinstaller",  # SmartBrowserInstaller
    "chromestandalonesetup",
    "smartbrowserinstaller",
    "jdk-24",               # JDK 24 installer (matches jdk- too, but explicit)
    "googledrivesetup",
    "perplexity",
]

# ── Publisher / vendor-level keywords (match anywhere in full path) ───────────
STATIC_WHITELIST_PATH_KEYWORDS: list[str] = [
    r"\\program files\\",
    r"\\program files (x86)\\",
    r"\\windows\\",
    r"\\system32\\",
    r"\\syswow64\\",
    r"/usr/bin/",
    r"/usr/lib/",
    r"/usr/share/",
    r"/opt/",
    "oracle\\", "oracle/",
    "microsoft\\", "microsoft/",
    "google\\", "google/",
    "mozilla\\", "mozilla/",
    "apple\\", "apple/",
    "adobe\\", "adobe/",
    "jetbrains\\", "jetbrains/",
]

# ── File extension whitelist — non-executable safe types ─────────────────────
SAFE_EXTENSIONS: frozenset[str] = frozenset({
    ".txt", ".md", ".pdf", ".doc", ".docx", ".xls", ".xlsx",
    ".ppt", ".pptx", ".odt", ".ods", ".odp",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".svg", ".webp",
    ".mp3", ".mp4", ".wav", ".avi", ".mkv", ".mov", ".flac",
    ".zip", ".tar", ".gz", ".bz2", ".7z", ".rar", ".iso",
    ".json", ".xml", ".yaml", ".yml", ".toml", ".csv",
    ".html", ".htm", ".css",
    ".py", ".js", ".ts", ".java", ".c", ".cpp", ".h", ".rs", ".go",
    ".sh", ".bat", ".ps1",   # scripts are monitored by dynamic engine, not heuristic engine
})


# ─────────────────────────────────────────────────────────────────────────────
#  WhitelistDatabase
# ─────────────────────────────────────────────────────────────────────────────

class WhitelistDatabase:
    """
    Central whitelist store.

    Usage
    -----
    db = WhitelistDatabase()
    if db.is_whitelisted(Path("C:/Users/me/Downloads/Antigravity-1.0.exe")):
        skip()
    """

    CUSTOM_WL_FILENAME = "whitelist_custom.json"
    UPDATE_INTERVAL_HOURS = 24

    def __init__(self, data_dir: Optional[Path] = None):
        if data_dir is None:
            data_dir = Path(__file__).parent.parent / "data"
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self._custom_path = self.data_dir / self.CUSTOM_WL_FILENAME
        self._lock = threading.RLock()

        # Dynamic additions (user + auto-update)
        self._dynamic_keywords: set[str] = set()
        self._dynamic_hashes: set[str] = set()        # sha256 of known-safe files
        self._dynamic_publishers: set[str] = set()

        self._load_custom()
        self._last_update: datetime = self._load_last_update_time()

        # Kick off background auto-updater
        threading.Thread(target=self._auto_update_loop, daemon=True).start()

    # ── Public API ────────────────────────────────────────────────────────────

    def is_whitelisted(self, file_path: Path) -> tuple[bool, str]:
        """
        Check whether *file_path* is a known-safe file.

        Returns
        -------
        (True, reason)  — file is safe
        (False, "")     — file is NOT whitelisted (may still be clean)
        """
        name_lower = file_path.name.lower()
        path_lower = str(file_path).lower().replace("\\", "/")
        suffix_lower = file_path.suffix.lower()

        # 1. Safe extension (non-executable)
        if suffix_lower in SAFE_EXTENSIONS:
            return True, f"Non-executable file type ({suffix_lower})"

        # 2. Static keyword match on filename
        for kw in STATIC_WHITELIST_KEYWORDS:
            if kw.lower() in name_lower:
                return True, f"Trusted software keyword: '{kw}'"

        # 3. Static path keyword match
        for kw in STATIC_WHITELIST_PATH_KEYWORDS:
            if kw.lower() in path_lower:
                return True, f"Trusted system path: '{kw}'"

        # 4. Dynamic keyword match (auto-updated + user additions)
        with self._lock:
            for kw in self._dynamic_keywords:
                if kw.lower() in name_lower:
                    return True, f"Whitelisted (dynamic): '{kw}'"

            # 5. Publisher match
            for pub in self._dynamic_publishers:
                if pub.lower() in path_lower:
                    return True, f"Trusted publisher: '{pub}'"

        return False, ""

    def is_hash_whitelisted(self, sha256_hash: str) -> tuple[bool, str]:
        """Check SHA-256 hash against the safe-hash list."""
        with self._lock:
            if sha256_hash.lower() in self._dynamic_hashes:
                return True, "Hash in safe-file database"
        return False, ""

    def add_custom_keyword(self, keyword: str, save: bool = True):
        """Add a keyword to the persistent custom whitelist."""
        kw = keyword.strip().lower()
        if not kw:
            return
        with self._lock:
            self._dynamic_keywords.add(kw)
        if save:
            self._save_custom()
        logger.info("Whitelist: added keyword '%s'", kw)

    def add_custom_hash(self, sha256_hash: str, save: bool = True):
        """Add a SHA-256 hash to the safe-hash list."""
        h = sha256_hash.strip().lower()
        if not h:
            return
        with self._lock:
            self._dynamic_hashes.add(h)
        if save:
            self._save_custom()

    def remove_custom_keyword(self, keyword: str):
        """Remove a keyword from the custom whitelist."""
        kw = keyword.strip().lower()
        with self._lock:
            self._dynamic_keywords.discard(kw)
        self._save_custom()

    def get_all_keywords(self) -> list[str]:
        """Return combined static + dynamic keyword list (sorted)."""
        with self._lock:
            return sorted(set(STATIC_WHITELIST_KEYWORDS) | self._dynamic_keywords)

    def get_custom_keywords(self) -> list[str]:
        with self._lock:
            return sorted(self._dynamic_keywords)

    def get_stats(self) -> dict:
        with self._lock:
            return {
                "static_keywords": len(STATIC_WHITELIST_KEYWORDS),
                "dynamic_keywords": len(self._dynamic_keywords),
                "safe_hashes": len(self._dynamic_hashes),
                "publishers": len(self._dynamic_publishers),
                "last_updated": self._last_update.isoformat(),
                "total": (len(STATIC_WHITELIST_KEYWORDS) +
                          len(STATIC_WHITELIST_PATH_KEYWORDS) +
                          len(SAFE_EXTENSIONS) +
                          len(self._dynamic_keywords)),
            }

    # ── Persistence ───────────────────────────────────────────────────────────

    def _load_custom(self):
        try:
            if self._custom_path.exists():
                data = json.loads(self._custom_path.read_text(encoding="utf-8"))
                with self._lock:
                    self._dynamic_keywords = set(data.get("keywords", []))
                    self._dynamic_hashes = set(data.get("hashes", []))
                    self._dynamic_publishers = set(data.get("publishers", []))
                logger.info("Whitelist: loaded %d custom keywords", len(self._dynamic_keywords))
        except Exception as e:
            logger.warning("Whitelist: could not load custom file: %s", e)

    def _save_custom(self):
        try:
            with self._lock:
                data = {
                    "version": "2.0",
                    "last_saved": datetime.now().isoformat(),
                    "keywords": sorted(self._dynamic_keywords),
                    "hashes": sorted(self._dynamic_hashes),
                    "publishers": sorted(self._dynamic_publishers),
                }
            self._custom_path.write_text(
                json.dumps(data, indent=2), encoding="utf-8"
            )
        except Exception as e:
            logger.warning("Whitelist: could not save custom file: %s", e)

    def _load_last_update_time(self) -> datetime:
        ts_path = self.data_dir / "whitelist_last_update.txt"
        try:
            if ts_path.exists():
                return datetime.fromisoformat(ts_path.read_text().strip())
        except Exception:
            pass
        return datetime.min

    def _save_last_update_time(self):
        ts_path = self.data_dir / "whitelist_last_update.txt"
        try:
            ts_path.write_text(datetime.now().isoformat())
        except Exception:
            pass

    # ── Auto-updater ──────────────────────────────────────────────────────────

    def _auto_update_loop(self):
        """Background thread: refresh dynamic whitelist every 24 h."""
        while True:
            now = datetime.now()
            if (now - self._last_update) > timedelta(hours=self.UPDATE_INTERVAL_HOURS):
                try:
                    self._fetch_updates()
                    self._last_update = now
                    self._save_last_update_time()
                    logger.info("Whitelist: auto-update complete")
                except Exception as e:
                    logger.warning("Whitelist: auto-update failed: %s", e)
            time.sleep(3600)  # Check every hour

    def _fetch_updates(self):
        """
        Pull trusted-software lists from public sources.

        Sources used (all free, no API key required):
        1. PyPI Top-1000 package names  → adds 'pkg-', 'pkg_' patterns
        2. Winget manifest repo package IDs (abbreviated)
        3. Chocolatey community feed top packages
        """
        try:
            import urllib.request
            import urllib.error
        except ImportError:
            return

        new_keywords: set[str] = set()
        new_publishers: set[str] = set()

        # ── 1. PyPI simple index (package names) ─────────────────────────────
        try:
            url = "https://pypi.org/simple/"
            req = urllib.request.Request(url, headers={"Accept": "application/vnd.pypi.simple.v1+json"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                payload = json.loads(resp.read().decode())
            projects = [p["name"].lower() for p in payload.get("projects", [])][:2000]
            for name in projects:
                safe_name = re.sub(r"[^a-z0-9\-_]", "", name)
                if len(safe_name) >= 3:
                    new_keywords.add(safe_name)
        except Exception as e:
            logger.debug("Whitelist PyPI fetch failed: %s", e)

        # ── 2. Winget package IDs (Microsoft catalog, public REST API) ────────
        try:
            url = ("https://winget.azureedge.net/cache/Source.msix.json"
                   "?v=0.1")
            # Winget's public source — may return 404 for partial mirrors;
            # fall back silently.
            with urllib.request.urlopen(url, timeout=10) as resp:
                data = json.loads(resp.read().decode())
            for entry in data.get("Data", [])[:1000]:
                pkg_id = str(entry.get("PackageIdentifier", "")).lower()
                parts = pkg_id.split(".")
                if len(parts) >= 2:
                    new_publishers.add(parts[0])        # e.g. "microsoft"
                    new_keywords.add(parts[-1])          # e.g. "vscode"
        except Exception as e:
            logger.debug("Whitelist Winget fetch failed (expected): %s", e)

        # ── 3. Chocolatey top-packages (public OData feed) ────────────────────
        try:
            url = ("https://community.chocolatey.org/api/v2/Packages()"
                   "?$orderby=DownloadCount+desc&$top=500&$select=Id")
            with urllib.request.urlopen(url, timeout=10) as resp:
                text = resp.read().decode("utf-8", errors="replace")
            # IDs appear in <d:Id>...</d:Id>
            for m in re.finditer(r"<d:Id[^>]*>([^<]+)</d:Id>", text):
                pkg_id = m.group(1).strip().lower()
                clean = re.sub(r"[^a-z0-9\-_.]", "", pkg_id)
                if len(clean) >= 3:
                    new_keywords.add(clean.split(".")[-1])
        except Exception as e:
            logger.debug("Whitelist Chocolatey fetch failed: %s", e)

        # ── Merge results ─────────────────────────────────────────────────────
        if new_keywords or new_publishers:
            with self._lock:
                self._dynamic_keywords |= new_keywords
                self._dynamic_publishers |= new_publishers
            self._save_custom()
            logger.info(
                "Whitelist updated: +%d keywords, +%d publishers",
                len(new_keywords), len(new_publishers)
            )


# ── Module-level singleton ────────────────────────────────────────────────────
_WHITELIST_DB: Optional[WhitelistDatabase] = None
_DB_LOCK = threading.Lock()


def get_whitelist_db(data_dir: Optional[Path] = None) -> WhitelistDatabase:
    """Return the shared WhitelistDatabase singleton."""
    global _WHITELIST_DB
    with _DB_LOCK:
        if _WHITELIST_DB is None:
            _WHITELIST_DB = WhitelistDatabase(data_dir=data_dir)
    return _WHITELIST_DB
