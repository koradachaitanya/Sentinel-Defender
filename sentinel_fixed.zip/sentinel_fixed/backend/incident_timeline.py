"""
Sentinel Defender - Incident Timeline Reconstructor
Correlates security events into chronological attack chains.
Builds "story" of what happened during an incident.
"""

import logging
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import defaultdict

logger = logging.getLogger(__name__)


# ==================== DATA STRUCTURES ====================

@dataclass
class TimelineEvent:
    """Single event in an incident timeline."""
    event_id: str
    timestamp: datetime
    event_type: str          # 'detection', 'artifact', 'memory', 'behavioral', 'network'
    category: str            # 'initial_access', 'execution', 'persistence', 'defense_evasion', etc.
    severity: str            # 'critical', 'high', 'medium', 'low', 'info'
    source: str              # Which module generated this event
    
    # Event details
    title: str               # Short description
    description: str         # Detailed description
    entity: str              # What was affected (file, process, registry key)
    action: str              # What happened (created, modified, deleted, executed)
    
    # Context
    related_entities: List[str] = field(default_factory=list)  # Parent process, network connection, etc.
    indicators: Dict = field(default_factory=dict)
    mitre_technique: str = ""
    
    def to_dict(self) -> Dict:
        return {
            'event_id': self.event_id,
            'timestamp': self.timestamp.isoformat(),
            'event_type': self.event_type,
            'category': self.category,
            'severity': self.severity,
            'source': self.source,
            'title': self.title,
            'description': self.description,
            'entity': self.entity,
            'action': self.action,
            'related_entities': self.related_entities,
            'indicators': self.indicators,
            'mitre_technique': self.mitre_technique
        }


@dataclass
class AttackChain:
    """Correlated sequence of events forming an attack."""
    chain_id: str
    start_time: datetime
    end_time: datetime
    severity: str            # Highest severity in chain
    attack_phase: str        # Primary MITRE phase
    
    events: List[TimelineEvent] = field(default_factory=list)
    summary: str = ""        # Auto-generated attack narrative
    
    def to_dict(self) -> Dict:
        return {
            'chain_id': self.chain_id,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat(),
            'duration_seconds': (self.end_time - self.start_time).total_seconds(),
            'severity': self.severity,
            'attack_phase': self.attack_phase,
            'event_count': len(self.events),
            'summary': self.summary,
            'events': [e.to_dict() for e in self.events]
        }


@dataclass
class IncidentTimeline:
    """Complete incident timeline with attack chains."""
    incident_id: str
    start_time: datetime
    end_time: datetime
    total_events: int
    
    events: List[TimelineEvent] = field(default_factory=list)
    attack_chains: List[AttackChain] = field(default_factory=list)
    
    # Incident summary
    narrative: str = ""      # Plain-English story of the incident
    key_findings: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return {
            'incident_id': self.incident_id,
            'start_time': self.start_time.isoformat(),
            'end_time': self.end_time.isoformat(),
            'duration_hours': (self.end_time - self.start_time).total_seconds() / 3600,
            'total_events': self.total_events,
            'attack_chain_count': len(self.attack_chains),
            'narrative': self.narrative,
            'key_findings': self.key_findings,
            'recommendations': self.recommendations,
            'events': [e.to_dict() for e in self.events],
            'attack_chains': [c.to_dict() for c in self.attack_chains]
        }


# ==================== TIMELINE RECONSTRUCTOR ====================

class TimelineReconstructor:
    """
    Correlate security events into incident timelines.
    Builds attack chains using temporal proximity and entity relationships.
    """
    
    # Time window for event correlation (events within this window may be related)
    CORRELATION_WINDOW = timedelta(minutes=5)
    
    # MITRE ATT&CK phase mapping
    MITRE_PHASES = {
        'initial_access': ['T1566', 'T1189', 'T1190', 'T1195', 'T1199'],       # Phishing, exploit, supply chain
        'execution': ['T1059', 'T1106', 'T1203', 'T1204', 'T1053'],            # Command execution, scripting
        'persistence': ['T1547', 'T1543', 'T1053', 'T1546', 'T1574'],          # Startup, services, hijacking
        'privilege_escalation': ['T1068', 'T1055', 'T1134'],                   # Exploits, injection
        'defense_evasion': ['T1027', 'T1036', 'T1055', 'T1070', 'T1112'],      # Obfuscation, masquerading
        'credential_access': ['T1003', 'T1110', 'T1111', 'T1056'],             # Credential dumping, keylogging
        'discovery': ['T1082', 'T1083', 'T1046', 'T1057', 'T1018'],            # System/file/network discovery
        'lateral_movement': ['T1021', 'T1091', 'T1080'],                       # Remote services, replication
        'collection': ['T1005', 'T1039', 'T1114', 'T1056'],                    # Data from local system
        'exfiltration': ['T1041', 'T1048', 'T1020', 'T1030'],                  # C2 channel, exfil
        'impact': ['T1486', 'T1489', 'T1490', 'T1491']                         # Ransomware, service stop
    }
    
    def __init__(self):
        self.events = []
        self.timeline = None
    
    # ── Public API ────────────────────────────────────────────────────
    
    def add_detection_event(self, detection: Dict):
        """Add a threat detection event to timeline."""
        event = TimelineEvent(
            event_id=f"DET_{len(self.events):04d}",
            timestamp=datetime.fromisoformat(detection['timestamp']) if isinstance(detection.get('timestamp'), str) else datetime.now(),
            event_type='detection',
            category=self._map_to_attack_phase(detection.get('detection_method', '')),
            severity=detection.get('severity', 'medium'),
            source='detection_engine',
            title=f"Threat Detected: {detection.get('threat_name', 'Unknown')}",
            description=f"Detected {detection.get('threat_type', 'malware')} via {detection.get('detection_method', 'unknown')}",
            entity=detection.get('file_path', 'Unknown file'),
            action='detected',
            indicators=detection,
            mitre_technique=detection.get('mitre_technique', '')
        )
        self.events.append(event)
    
    def add_memory_event(self, anomaly: Dict):
        """Add memory anomaly event to timeline."""
        event = TimelineEvent(
            event_id=f"MEM_{len(self.events):04d}",
            timestamp=datetime.fromisoformat(anomaly['timestamp']) if isinstance(anomaly.get('timestamp'), str) else datetime.now(),
            event_type='memory',
            category='defense_evasion',
            severity=anomaly.get('severity', 'high'),
            source='memory_inspector',
            title=f"Memory Anomaly: {anomaly.get('anomaly_type', 'Unknown')}",
            description=anomaly.get('description', 'Suspicious memory pattern detected'),
            entity=f"{anomaly.get('process_name', 'Unknown')} (PID {anomaly.get('process_id', '?')})",
            action='injected' if 'inject' in anomaly.get('anomaly_type', '') else 'suspicious',
            related_entities=[f"Memory Address: {anomaly.get('memory_address', 'N/A')}"],
            indicators=anomaly,
            mitre_technique=anomaly.get('mitre_technique', '')
        )
        self.events.append(event)
    
    def add_artifact_event(self, artifact: Dict):
        """Add forensic artifact event to timeline."""
        event = TimelineEvent(
            event_id=f"ART_{len(self.events):04d}",
            timestamp=datetime.fromisoformat(artifact['timestamp']) if isinstance(artifact.get('timestamp'), str) else datetime.now(),
            event_type='artifact',
            category=artifact.get('category', 'discovery'),
            severity='info' if artifact.get('suspicious_score', 0) < 30 else 'medium' if artifact.get('suspicious_score', 0) < 60 else 'high',
            source='forensics_collector',
            title=f"{artifact.get('artifact_type', 'Artifact').title()}: {artifact.get('name', 'Unknown')}",
            description=artifact.get('value', 'Artifact collected'),
            entity=artifact.get('path', 'Unknown location'),
            action='found',
            indicators={'suspicious_score': artifact.get('suspicious_score', 0)},
            mitre_technique=artifact.get('mitre_technique', '')
        )
        self.events.append(event)
    
    def add_network_event(self, connection: Dict):
        """Add network connection event."""
        event = TimelineEvent(
            event_id=f"NET_{len(self.events):04d}",
            timestamp=datetime.now(),
            event_type='network',
            category='command_and_control' if connection.get('suspicious', False) else 'discovery',
            severity=connection.get('severity', 'low'),
            source='network_monitor',
            title=f"Network Connection: {connection.get('remote_ip', 'Unknown')}",
            description=f"Connection to {connection.get('remote_ip', 'unknown')}:{connection.get('remote_port', '?')}",
            entity=connection.get('process_name', 'Unknown process'),
            action='connected',
            related_entities=[f"Local: {connection.get('local_ip', '?')}:{connection.get('local_port', '?')}"],
            indicators=connection
        )
        self.events.append(event)
    
    def build_timeline(self, incident_id: str = None) -> IncidentTimeline:
        """
        Reconstruct complete incident timeline from collected events.
        Correlates events into attack chains.
        """
        if not self.events:
            return self._empty_timeline(incident_id)
        
        # Sort events chronologically
        self.events.sort(key=lambda e: e.timestamp)
        
        # Create timeline
        self.timeline = IncidentTimeline(
            incident_id=incident_id or datetime.now().strftime('%Y%m%d_%H%M%S'),
            start_time=self.events[0].timestamp,
            end_time=self.events[-1].timestamp,
            total_events=len(self.events),
            events=self.events.copy()
        )
        
        # Correlate events into attack chains
        self.timeline.attack_chains = self._correlate_attack_chains()
        
        # Generate narrative
        self.timeline.narrative = self._generate_narrative()
        
        # Extract key findings
        self.timeline.key_findings = self._extract_key_findings()
        
        # Generate recommendations
        self.timeline.recommendations = self._generate_recommendations()
        
        return self.timeline
    
    # ── Attack Chain Correlation ──────────────────────────────────────
    
    def _correlate_attack_chains(self) -> List[AttackChain]:
        """
        Group related events into attack chains.
        Uses temporal proximity and entity relationships.
        """
        chains = []
        used_events = set()
        
        for i, event in enumerate(self.events):
            if event.event_id in used_events:
                continue
            
            # Start new chain
            chain_events = [event]
            used_events.add(event.event_id)
            
            # Find related events within correlation window
            for j in range(i + 1, len(self.events)):
                next_event = self.events[j]
                
                if next_event.event_id in used_events:
                    continue
                
                # Time proximity check
                if (next_event.timestamp - event.timestamp) > self.CORRELATION_WINDOW:
                    break
                
                # Correlation criteria
                if self._are_events_related(event, next_event):
                    chain_events.append(next_event)
                    used_events.add(next_event.event_id)
            
            # Create attack chain if multiple events or high severity
            if len(chain_events) > 1 or chain_events[0].severity in ['critical', 'high']:
                chain = AttackChain(
                    chain_id=f"CHAIN_{len(chains):03d}",
                    start_time=chain_events[0].timestamp,
                    end_time=chain_events[-1].timestamp,
                    severity=self._highest_severity(chain_events),
                    attack_phase=self._determine_attack_phase(chain_events),
                    events=chain_events
                )
                chain.summary = self._generate_chain_summary(chain)
                chains.append(chain)
        
        return chains
    
    def _are_events_related(self, event1: TimelineEvent, event2: TimelineEvent) -> bool:
        """Determine if two events are part of the same attack chain."""
        
        # Same entity (file, process, registry key)
        if event1.entity == event2.entity:
            return True
        
        # Entity mentioned in related_entities
        if event1.entity in event2.related_entities or event2.entity in event1.related_entities:
            return True
        
        # Same MITRE technique
        if event1.mitre_technique and event1.mitre_technique == event2.mitre_technique:
            return True
        
        # Same attack phase
        if event1.category == event2.category and event1.category != 'discovery':
            return True
        
        return False
    
    def _highest_severity(self, events: List[TimelineEvent]) -> str:
        """Get highest severity from event list."""
        severity_order = ['critical', 'high', 'medium', 'low', 'info']
        for severity in severity_order:
            if any(e.severity == severity for e in events):
                return severity
        return 'medium'
    
    def _determine_attack_phase(self, events: List[TimelineEvent]) -> str:
        """Determine primary attack phase from events."""
        phase_counts = defaultdict(int)
        
        for event in events:
            if event.category:
                phase_counts[event.category] += 1
        
        if not phase_counts:
            return 'unknown'
        
        return max(phase_counts.items(), key=lambda x: x[1])[0]
    
    # ── Narrative Generation ──────────────────────────────────────────
    
    def _generate_chain_summary(self, chain: AttackChain) -> str:
        """Generate plain-English summary of an attack chain."""
        
        if not chain.events:
            return "Empty attack chain"
        
        # Start with first event
        first_event = chain.events[0]
        summary = f"At {first_event.timestamp.strftime('%H:%M:%S')}, {first_event.description.lower()}. "
        
        # Add subsequent events
        if len(chain.events) > 1:
            summary += f"This was followed by {len(chain.events) - 1} related event(s): "
            
            event_summaries = []
            for event in chain.events[1:4]:  # First 3 follow-up events
                event_summaries.append(event.title.lower())
            
            summary += ', '.join(event_summaries)
            
            if len(chain.events) > 4:
                summary += f", and {len(chain.events) - 4} more."
        
        # Add attack phase context
        phase_descriptions = {
            'initial_access': 'This represents the initial compromise of the system',
            'execution': 'This shows malicious code being executed',
            'persistence': 'This indicates attempts to maintain access',
            'privilege_escalation': 'This shows attempts to gain higher privileges',
            'defense_evasion': 'This indicates attempts to avoid detection',
            'credential_access': 'This shows attempts to steal credentials',
            'lateral_movement': 'This indicates attempts to spread to other systems',
            'exfiltration': 'This shows data being stolen',
            'impact': 'This represents the destructive phase of the attack'
        }
        
        if chain.attack_phase in phase_descriptions:
            summary += f" {phase_descriptions[chain.attack_phase]}."
        
        return summary
    
    def _generate_narrative(self) -> str:
        """Generate overall incident narrative."""
        if not self.timeline or not self.timeline.attack_chains:
            return "No significant attack activity detected."
        
        narrative = f"Timeline of incident {self.timeline.incident_id}:\n\n"
        
        # Summarize attack chains
        for i, chain in enumerate(self.timeline.attack_chains, 1):
            narrative += f"**Attack Chain {i}** ({chain.severity.upper()} severity):\n"
            narrative += f"{chain.summary}\n\n"
        
        # Overall assessment
        critical_count = sum(1 for c in self.timeline.attack_chains if c.severity == 'critical')
        high_count = sum(1 for c in self.timeline.attack_chains if c.severity == 'high')
        
        narrative += f"\n**Overall Assessment:**\n"
        narrative += f"- {len(self.timeline.attack_chains)} distinct attack chain(s) identified\n"
        narrative += f"- {critical_count} critical and {high_count} high-severity chains\n"
        narrative += f"- Incident duration: {(self.timeline.end_time - self.timeline.start_time).total_seconds() / 60:.1f} minutes\n"
        
        return narrative
    
    def _extract_key_findings(self) -> List[str]:
        """Extract key findings from timeline."""
        findings = []
        
        # Check for specific attack patterns
        if any('inject' in e.entity.lower() for e in self.timeline.events):
            findings.append("Code injection detected — possible fileless malware")
        
        if any(e.event_type == 'memory' for e in self.timeline.events):
            findings.append("Memory-based threats detected — traditional antivirus may have missed these")
        
        if any('credential' in e.description.lower() for e in self.timeline.events):
            findings.append("Credential theft attempted — change passwords immediately")
        
        if any(e.category == 'persistence' for e in self.timeline.events):
            findings.append("Persistence mechanisms found — malware may survive reboot")
        
        if any(e.category == 'lateral_movement' for e in self.timeline.events):
            findings.append("Lateral movement detected — other systems may be compromised")
        
        # High-value artifacts
        high_risk_artifacts = [e for e in self.timeline.events 
                               if e.event_type == 'artifact' and e.indicators.get('suspicious_score', 0) > 70]
        if high_risk_artifacts:
            findings.append(f"{len(high_risk_artifacts)} high-risk forensic artifacts collected")
        
        return findings
    
    def _generate_recommendations(self) -> List[str]:
        """Generate remediation recommendations."""
        recommendations = []
        
        # Based on attack phases detected
        phases_detected = set(c.attack_phase for c in self.timeline.attack_chains)
        
        if 'credential_access' in phases_detected:
            recommendations.append("Change all passwords from a clean device — assume credentials compromised")
            recommendations.append("Enable two-factor authentication on all critical accounts")
        
        if 'persistence' in phases_detected:
            recommendations.append("Check startup items, scheduled tasks, and services for malicious entries")
            recommendations.append("Consider a clean OS reinstall if rootkit suspected")
        
        if 'lateral_movement' in phases_detected:
            recommendations.append("Scan all devices on the network — malware may have spread")
            recommendations.append("Isolate compromised systems from network")
        
        if any(e.event_type == 'memory' for e in self.timeline.events):
            recommendations.append("Restart affected systems to clear memory-resident threats")
            recommendations.append("Perform memory forensics if further investigation needed")
        
        # General recommendations
        recommendations.append("Run a full system scan with updated antivirus")
        recommendations.append("Review system and application logs for additional indicators")
        recommendations.append("Backup important data before remediation")
        
        return recommendations
    
    # ── Helpers ───────────────────────────────────────────────────────
    
    def _map_to_attack_phase(self, detection_method: str) -> str:
        """Map detection method to MITRE phase."""
        if 'signature' in detection_method.lower():
            return 'execution'
        elif 'heuristic' in detection_method.lower():
            return 'defense_evasion'
        elif 'behavioral' in detection_method.lower():
            return 'execution'
        else:
            return 'unknown'
    
    def _empty_timeline(self, incident_id: str) -> IncidentTimeline:
        """Create empty timeline when no events."""
        return IncidentTimeline(
            incident_id=incident_id or 'EMPTY',
            start_time=datetime.now(),
            end_time=datetime.now(),
            total_events=0,
            narrative="No security events recorded.",
            key_findings=["No threats detected"],
            recommendations=["Continue monitoring"]
        )
    
    # ── Export ────────────────────────────────────────────────────────
    
    def export_json(self) -> Dict:
        """Export timeline as JSON."""
        if self.timeline:
            return self.timeline.to_dict()
        return {}
    
    def clear(self):
        """Clear all events and timeline."""
        self.events.clear()
        self.timeline = None
