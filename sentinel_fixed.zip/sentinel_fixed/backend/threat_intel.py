"""
Sentinel Defender - Threat Intelligence Engine
===============================================
Connects to three live abuse.ch feeds and caches everything locally so
the scanner keeps working when offline.

Feeds integrated
----------------
  MalwareBazaar  — malware file hashes  (MD5 / SHA-1 / SHA-256)
  ThreatFox      — IOCs: IPs, domains, URLs, file hashes
  URLhaus        — malicious URLs and their associated domains/IPs

How it plugs in
---------------
  DetectionEngine  → call  ThreatIntel.lookup_hash(md5, sha256)
                     returns ThreatIntelMatch or None

  NetworkMonitor   → call  ThreatIntel.lookup_ip(ip)
                            ThreatIntel.lookup_domain(domain)
                     returns ThreatIntelMatch or None

  Auto-update      → background thread refreshes every UPDATE_INTERVAL_HOURS
                     First run fetches everything, subsequent runs are incremental.

Storage
-------
  Single SQLite database at  data/threat_intel.db
  No external dependencies — pure stdlib  (urllib, sqlite3, gzip, csv, json)

Usage
-----
    from backend.threat_intel import ThreatIntel

    ti = ThreatIntel()          # starts background updater automatically
    ti.update_now()             # optional: force an immediate refresh

    match = ti.lookup_hash(md5="44d88612fea8a8f36de82e1278abb02f")
    match = ti.lookup_ip("185.220.101.1")
    match = ti.lookup_domain("malware-c2.ru")
    match = ti.lookup_url("http://evil.com/payload.exe")

    stats = ti.get_stats()      # dict with record counts and last-update times
"""

from __future__ import annotations

import csv
import gzip
import io
import json
import logging
import sqlite3
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ── Constants ─────────────────────────────────────────────────────────────────

UPDATE_INTERVAL_HOURS = 6          # how often the background thread refreshes
REQUEST_TIMEOUT_SEC   = 20         # per HTTP request timeout
MAX_URLHAUS_ROWS      = 200_000    # cap URLhaus import (file has 2M+ rows)
DB_CACHE_PRAGMA       = "PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;"

# abuse.ch public endpoints — no API key required
_MALWAREBAZAAR_RECENT_URL = (
    "https://mb-api.abuse.ch/api/v1/"
)
_THREATFOX_EXPORT_URL = (
    "https://threatfox-api.abuse.ch/api/v1/"
)
_URLHAUS_CSV_URL = (
    "https://urlhaus.abuse.ch/downloads/csv/"
)
_MALWAREBAZAAR_FULL_URL = (
    "https://bazaar.abuse.ch/export/csv/full/"     # ~200 MB gz, used for first run
)
_MALWAREBAZAAR_RECENT_CSV = (
    "https://bazaar.abuse.ch/export/csv/recent/"   # last 1000 samples, ~150 KB gz
)

# ── Data class ────────────────────────────────────────────────────────────────

@dataclass
class ThreatIntelMatch:
    """Returned when a lookup hits the local cache."""
    ioc_type:    str           # "hash_md5" | "hash_sha256" | "hash_sha1" |
                               # "ip" | "domain" | "url"
    value:       str           # the matched IOC
    threat_name: str           # e.g. "Emotet", "RedLine Stealer"
    threat_type: str           # e.g. "malware_download", "botnet_cc"
    confidence:  str           # "HIGH" | "MEDIUM" | "LOW"
    severity:    str           # "critical" | "high" | "medium" | "low"
    source:      str           # "malwarebazaar" | "threatfox" | "urlhaus"
    first_seen:  str           # ISO date string
    tags:        List[str] = field(default_factory=list)
    reference:   str = ""

    @property
    def threat_score(self) -> int:
        return {"critical": 100, "high": 90, "medium": 70, "low": 50}.get(
            self.severity, 60
        )


# ── Database helper ───────────────────────────────────────────────────────────

class _ThreatIntelDB:
    """
    Thin wrapper around the local SQLite cache.
    All lookups are O(1) via indexed columns.
    """

    def __init__(self, db_path: Path):
        self._path = db_path
        self._local = threading.local()
        self._init_schema()

    # ── Connection (thread-local) ─────────────────────────────────────────────

    def _conn(self) -> sqlite3.Connection:
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(str(self._path), check_same_thread=False)
            conn.row_factory = sqlite3.Row
            conn.executescript(DB_CACHE_PRAGMA)
            self._local.conn = conn
        return self._local.conn

    # ── Schema ────────────────────────────────────────────────────────────────

    def _init_schema(self):
        with self._conn() as c:
            c.executescript("""
                CREATE TABLE IF NOT EXISTS hashes (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    md5         TEXT,
                    sha1        TEXT,
                    sha256      TEXT,
                    threat_name TEXT NOT NULL,
                    threat_type TEXT NOT NULL DEFAULT 'malware',
                    tags        TEXT DEFAULT '',
                    first_seen  TEXT DEFAULT '',
                    source      TEXT NOT NULL,
                    added_at    TEXT NOT NULL
                );
                CREATE UNIQUE INDEX IF NOT EXISTS idx_hashes_md5    ON hashes(md5)    WHERE md5    IS NOT NULL;
                CREATE UNIQUE INDEX IF NOT EXISTS idx_hashes_sha1   ON hashes(sha1)   WHERE sha1   IS NOT NULL;
                CREATE UNIQUE INDEX IF NOT EXISTS idx_hashes_sha256 ON hashes(sha256) WHERE sha256 IS NOT NULL;

                CREATE TABLE IF NOT EXISTS network_iocs (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    ioc_type    TEXT NOT NULL,   -- 'ip' | 'domain' | 'url'
                    value       TEXT NOT NULL,
                    threat_name TEXT NOT NULL DEFAULT 'Malicious IOC',
                    threat_type TEXT NOT NULL DEFAULT 'malware',
                    confidence  TEXT NOT NULL DEFAULT 'HIGH',
                    tags        TEXT DEFAULT '',
                    first_seen  TEXT DEFAULT '',
                    source      TEXT NOT NULL,
                    added_at    TEXT NOT NULL
                );
                CREATE UNIQUE INDEX IF NOT EXISTS idx_nioc_val ON network_iocs(ioc_type, value);

                CREATE TABLE IF NOT EXISTS feed_meta (
                    feed        TEXT PRIMARY KEY,
                    last_update TEXT NOT NULL,
                    record_count INTEGER NOT NULL DEFAULT 0
                );
            """)

    # ── Writes ────────────────────────────────────────────────────────────────

    def upsert_hashes(self, rows: List[Dict]) -> int:
        """Insert or ignore hash rows. Returns inserted count."""
        if not rows:
            return 0
        now = _now()
        inserted = 0
        with self._conn() as c:
            for r in rows:
                try:
                    c.execute("""
                        INSERT OR IGNORE INTO hashes
                            (md5, sha1, sha256, threat_name, threat_type,
                             tags, first_seen, source, added_at)
                        VALUES (?,?,?,?,?,?,?,?,?)
                    """, (
                        r.get("md5"),    r.get("sha1"),    r.get("sha256"),
                        r.get("threat_name", "Unknown Malware"),
                        r.get("threat_type", "malware"),
                        ",".join(r.get("tags", [])),
                        r.get("first_seen", ""),
                        r.get("source", "unknown"),
                        now,
                    ))
                    inserted += c.rowcount
                except Exception:
                    pass
        return inserted

    def upsert_network_iocs(self, rows: List[Dict]) -> int:
        """Insert or ignore network IOC rows. Returns inserted count."""
        if not rows:
            return 0
        now = _now()
        inserted = 0
        with self._conn() as c:
            for r in rows:
                try:
                    c.execute("""
                        INSERT OR IGNORE INTO network_iocs
                            (ioc_type, value, threat_name, threat_type,
                             confidence, tags, first_seen, source, added_at)
                        VALUES (?,?,?,?,?,?,?,?,?)
                    """, (
                        r["ioc_type"], r["value"],
                        r.get("threat_name", "Malicious IOC"),
                        r.get("threat_type", "malware"),
                        r.get("confidence", "HIGH"),
                        ",".join(r.get("tags", [])),
                        r.get("first_seen", ""),
                        r.get("source", "unknown"),
                        now,
                    ))
                    inserted += c.rowcount
                except Exception:
                    pass
        return inserted

    def set_feed_meta(self, feed: str, count: int):
        with self._conn() as c:
            c.execute("""
                INSERT INTO feed_meta (feed, last_update, record_count)
                VALUES (?, ?, ?)
                ON CONFLICT(feed) DO UPDATE
                SET last_update=excluded.last_update,
                    record_count=excluded.record_count
            """, (feed, _now(), count))

    # ── Reads ─────────────────────────────────────────────────────────────────

    def lookup_hash(self, md5: str = "", sha1: str = "",
                    sha256: str = "") -> Optional[sqlite3.Row]:
        c = self._conn()
        if md5:
            row = c.execute("SELECT * FROM hashes WHERE md5=?",    (md5.lower(),)).fetchone()
            if row: return row
        if sha256:
            row = c.execute("SELECT * FROM hashes WHERE sha256=?", (sha256.lower(),)).fetchone()
            if row: return row
        if sha1:
            row = c.execute("SELECT * FROM hashes WHERE sha1=?",   (sha1.lower(),)).fetchone()
            if row: return row
        return None

    def lookup_ip(self, ip: str) -> Optional[sqlite3.Row]:
        return self._conn().execute(
            "SELECT * FROM network_iocs WHERE ioc_type='ip' AND value=?", (ip,)
        ).fetchone()

    def lookup_domain(self, domain: str) -> Optional[sqlite3.Row]:
        d = domain.lower().rstrip(".")
        return self._conn().execute(
            "SELECT * FROM network_iocs WHERE ioc_type='domain' AND value=?", (d,)
        ).fetchone()

    def lookup_url(self, url: str) -> Optional[sqlite3.Row]:
        return self._conn().execute(
            "SELECT * FROM network_iocs WHERE ioc_type='url' AND value=?", (url,)
        ).fetchone()

    def get_counts(self) -> Dict[str, int]:
        c = self._conn()
        counts = {}
        counts["hashes"]       = c.execute("SELECT COUNT(*) FROM hashes").fetchone()[0]
        counts["network_iocs"] = c.execute("SELECT COUNT(*) FROM network_iocs").fetchone()[0]
        rows = c.execute("SELECT feed, last_update, record_count FROM feed_meta").fetchall()
        counts["feeds"] = {r["feed"]: {"last_update": r["last_update"],
                                        "records": r["record_count"]}
                           for r in rows}
        return counts


# ── Feed parsers ──────────────────────────────────────────────────────────────

def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def _fetch(url: str, post_data: Optional[bytes] = None,
           headers: Optional[Dict] = None) -> bytes:
    """HTTP GET or POST with timeout. Raises on failure."""
    req_headers = {"User-Agent": "SentinelDefender/5.0 ThreatIntelUpdater"}
    if headers:
        req_headers.update(headers)
    req = urllib.request.Request(url, data=post_data, headers=req_headers,
                                 method="POST" if post_data else "GET")
    with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT_SEC) as resp:
        raw = resp.read()
    # Decompress if gzip
    if raw[:2] == b"\x1f\x8b":
        raw = gzip.decompress(raw)
    return raw


# ─── MalwareBazaar ───────────────────────────────────────────────────────────

def _parse_bazaar_csv(raw_bytes: bytes) -> List[Dict]:
    """
    Parse MalwareBazaar CSV export.
    Columns (subset we care about):
        first_seen, sha256_hash, md5_hash, sha1_hash,
        file_name, file_type_guess, mime_type, signature, tags,
        reporter, anonymous, ...
    """
    rows = []
    text = raw_bytes.decode("utf-8", errors="replace")
    reader = csv.DictReader(
        (line for line in text.splitlines() if not line.startswith("#")),
        # Bazaar CSV has a header row — DictReader picks it up automatically
    )
    for r in reader:
        threat_name = (
            r.get("signature") or
            r.get("file_name", "Unknown") or
            "Unknown Malware"
        ).strip() or "Unknown Malware"

        tags_raw = r.get("tags", "") or ""
        tags = [t.strip() for t in tags_raw.split(",") if t.strip()]

        rows.append({
            "md5":          (r.get("md5_hash")    or "").strip().lower() or None,
            "sha1":         (r.get("sha1_hash")   or "").strip().lower() or None,
            "sha256":       (r.get("sha256_hash") or "").strip().lower() or None,
            "threat_name":  threat_name,
            "threat_type":  "malware",
            "tags":         tags,
            "first_seen":   (r.get("first_seen") or "").strip(),
            "source":       "malwarebazaar",
        })
    return rows


def _fetch_malwarebazaar_recent() -> List[Dict]:
    """Fetch the last 1000 samples via CSV export (~150 KB gzip)."""
    logger.info("[ThreatIntel] Fetching MalwareBazaar recent samples…")
    try:
        raw = _fetch(_MALWAREBAZAAR_RECENT_CSV)
        rows = _parse_bazaar_csv(raw)
        logger.info("[ThreatIntel] MalwareBazaar: %d recent hashes parsed", len(rows))
        return rows
    except Exception as e:
        logger.warning("[ThreatIntel] MalwareBazaar fetch failed: %s", e)
        return []


def _fetch_malwarebazaar_api_recent(limit: int = 100) -> List[Dict]:
    """
    Fetch recent samples via JSON API.
    Used as a lightweight supplement — returns metadata for last N samples.
    """
    logger.info("[ThreatIntel] Fetching MalwareBazaar API recent (%d)…", limit)
    try:
        post = f"query=get_recent&selector=time".encode()
        raw  = _fetch(_MALWAREBAZAAR_RECENT_URL,
                      post_data=post,
                      headers={"Content-Type": "application/x-www-form-urlencoded"})
        data = json.loads(raw)
        if data.get("query_status") != "ok":
            return []

        rows = []
        for sample in data.get("data", [])[:limit]:
            tags = sample.get("tags") or []
            if isinstance(tags, str):
                tags = [tags]
            rows.append({
                "md5":         (sample.get("md5_hash")    or "").lower() or None,
                "sha1":        (sample.get("sha1_hash")   or "").lower() or None,
                "sha256":      (sample.get("sha256_hash") or "").lower() or None,
                "threat_name": sample.get("signature") or sample.get("file_name") or "Unknown",
                "threat_type": "malware",
                "tags":        tags,
                "first_seen":  sample.get("first_seen", ""),
                "source":      "malwarebazaar",
            })
        logger.info("[ThreatIntel] MalwareBazaar API: %d samples", len(rows))
        return rows
    except Exception as e:
        logger.warning("[ThreatIntel] MalwareBazaar API fetch failed: %s", e)
        return []


# ─── ThreatFox ───────────────────────────────────────────────────────────────

_THREATFOX_TYPE_MAP = {
    "ip:port":  "ip",
    "domain":   "domain",
    "url":      "url",
    "md5_hash": "hash_md5",
    "sha256_hash": "hash_sha256",
}

_THREATFOX_SEVERITY = {
    "botnet_cc":       "critical",
    "malware_download":"high",
    "phishing":        "high",
    "exploit":         "critical",
    "c2":              "critical",
}


def _fetch_threatfox(days_back: int = 7) -> Tuple[List[Dict], List[Dict]]:
    """
    Pull IOCs from ThreatFox JSON export API.
    Returns (hash_rows, network_ioc_rows).
    days_back: how many days of IOCs to fetch (max 90).
    """
    logger.info("[ThreatIntel] Fetching ThreatFox IOCs (last %d days)…", days_back)
    hash_rows: List[Dict] = []
    net_rows:  List[Dict] = []
    try:
        post_data = json.dumps({"query": "get_iocs", "days": days_back}).encode()
        raw  = _fetch(_THREATFOX_EXPORT_URL,
                      post_data=post_data,
                      headers={"Content-Type": "application/json"})
        data = json.loads(raw)

        if data.get("query_status") != "ok":
            logger.warning("[ThreatIntel] ThreatFox status: %s", data.get("query_status"))
            return [], []

        for ioc in data.get("data", []):
            ioc_type_raw = ioc.get("ioc_type", "")
            ioc_value    = (ioc.get("ioc") or "").strip()
            threat_type  = (ioc.get("threat_type") or "malware").strip().lower()
            malware_name = (ioc.get("malware") or ioc.get("threat_type_desc") or "Unknown").strip()
            tags_raw     = ioc.get("tags") or []
            tags         = tags_raw if isinstance(tags_raw, list) else [tags_raw]
            first_seen   = (ioc.get("first_seen") or "")[:10]
            severity     = _THREATFOX_SEVERITY.get(threat_type, "high")
            confidence   = str(ioc.get("confidence_level", 75))

            if not ioc_value:
                continue

            mapped = _THREATFOX_TYPE_MAP.get(ioc_type_raw)
            if not mapped:
                continue

            if mapped in ("hash_md5", "hash_sha256"):
                row: Dict = {
                    "threat_name": malware_name,
                    "threat_type": threat_type,
                    "tags":        tags,
                    "first_seen":  first_seen,
                    "source":      "threatfox",
                }
                if mapped == "hash_md5":
                    row["md5"] = ioc_value.lower()
                else:
                    row["sha256"] = ioc_value.lower()
                hash_rows.append(row)

            else:  # ip, domain, url
                # For ip:port → extract just the IP
                if ioc_type_raw == "ip:port" and ":" in ioc_value:
                    ioc_value = ioc_value.rsplit(":", 1)[0]
                elif ioc_type_raw == "ip:port" and "," in ioc_value:
                    ioc_value = ioc_value.split(",")[0]

                net_rows.append({
                    "ioc_type":    mapped,
                    "value":       ioc_value.lower().rstrip("."),
                    "threat_name": malware_name,
                    "threat_type": threat_type,
                    "confidence":  "HIGH" if int(confidence) >= 75 else "MEDIUM",
                    "tags":        tags,
                    "first_seen":  first_seen,
                    "source":      "threatfox",
                })

        logger.info("[ThreatIntel] ThreatFox: %d hashes, %d network IOCs",
                    len(hash_rows), len(net_rows))
        return hash_rows, net_rows

    except Exception as e:
        logger.warning("[ThreatIntel] ThreatFox fetch failed: %s", e)
        return [], []


# ─── URLhaus ─────────────────────────────────────────────────────────────────

def _fetch_urlhaus(max_rows: int = MAX_URLHAUS_ROWS) -> List[Dict]:
    """
    Fetch URLhaus CSV export.  Extracts URLs, domains, and IPs.
    CSV columns: id, dateadded, url, url_status, last_online,
                 threat, tags, urlhaus_link, reporter
    Returns network_ioc rows only (url + domain/ip extracted from url).
    """
    logger.info("[ThreatIntel] Fetching URLhaus CSV…")
    net_rows: List[Dict] = []
    try:
        raw  = _fetch(_URLHAUS_CSV_URL)
        text = raw.decode("utf-8", errors="replace")

        reader = csv.DictReader(
            (line for line in text.splitlines() if not line.startswith("#")),
        )
        count = 0
        for r in reader:
            if count >= max_rows:
                break
            url_val = (r.get("url") or "").strip()
            if not url_val:
                continue

            threat     = (r.get("threat") or "malware_download").strip().lower()
            tags_raw   = r.get("tags") or ""
            tags       = [t.strip() for t in tags_raw.split(",") if t.strip()]
            first_seen = (r.get("dateadded") or "")[:10]
            status     = (r.get("url_status") or "").lower()

            # Only include active/unknown URLs — skip ones already taken down
            if status == "offline":
                continue

            severity = "high" if "exploit" in threat or "exe" in url_val else "medium"

            # Add the URL itself
            net_rows.append({
                "ioc_type":    "url",
                "value":       url_val,
                "threat_name": threat.replace("_", " ").title(),
                "threat_type": threat,
                "confidence":  "HIGH",
                "tags":        tags,
                "first_seen":  first_seen,
                "source":      "urlhaus",
            })

            # Also extract domain/IP for network-level checks
            host = _extract_host(url_val)
            if host:
                ioc_type = "ip" if _looks_like_ip(host) else "domain"
                net_rows.append({
                    "ioc_type":    ioc_type,
                    "value":       host.lower().rstrip("."),
                    "threat_name": threat.replace("_", " ").title(),
                    "threat_type": threat,
                    "confidence":  "MEDIUM",
                    "tags":        tags,
                    "first_seen":  first_seen,
                    "source":      "urlhaus",
                })
            count += 1

        logger.info("[ThreatIntel] URLhaus: %d IOC rows parsed", len(net_rows))
        return net_rows

    except Exception as e:
        logger.warning("[ThreatIntel] URLhaus fetch failed: %s", e)
        return []


def _extract_host(url: str) -> str:
    """Extract hostname/IP from a URL string without importing urllib.parse."""
    try:
        # Remove scheme
        s = url.split("://", 1)[-1]
        # Remove path
        host = s.split("/")[0]
        # Remove port
        if host.startswith("["):         # IPv6
            host = host.split("]")[0][1:]
        else:
            host = host.split(":")[0]
        return host.strip()
    except Exception:
        return ""


def _looks_like_ip(s: str) -> bool:
    parts = s.split(".")
    if len(parts) != 4:
        return False
    try:
        return all(0 <= int(p) <= 255 for p in parts)
    except ValueError:
        return False


# ─── Row → ThreatIntelMatch ──────────────────────────────────────────────────

def _severity_from_source_and_type(source: str, threat_type: str) -> str:
    if threat_type in ("botnet_cc", "c2", "exploit", "ransomware"):
        return "critical"
    if source == "malwarebazaar":
        return "high"
    if threat_type in ("malware_download", "phishing"):
        return "high"
    return "medium"


def _row_to_match(row: sqlite3.Row, ioc_type: str, value: str) -> ThreatIntelMatch:
    source     = row["source"]
    threat_type = row["threat_type"] or "malware"
    tags_str   = row["tags"] or ""
    tags       = [t for t in tags_str.split(",") if t]
    confidence = row["confidence"] if "confidence" in row.keys() else "HIGH"
    severity   = _severity_from_source_and_type(source, threat_type)

    return ThreatIntelMatch(
        ioc_type    = ioc_type,
        value       = value,
        threat_name = row["threat_name"] or "Unknown",
        threat_type = threat_type,
        confidence  = confidence,
        severity    = severity,
        source      = source,
        first_seen  = row["first_seen"] or "",
        tags        = tags,
    )


# ── Public API ────────────────────────────────────────────────────────────────

class ThreatIntel:
    """
    Main class — use one instance per application.

    On first construction:
      • Creates / opens  data/threat_intel.db
      • If the database is empty, triggers an immediate full update
      • Starts a background thread that refreshes every UPDATE_INTERVAL_HOURS

    All lookups are synchronous and safe to call from any thread.
    The background updater never blocks the caller.
    """

    def __init__(self, db_path: Optional[Path] = None, auto_update: bool = True):
        if db_path is None:
            # Resolve relative to the project data/ directory
            _here = Path(__file__).resolve().parent.parent
            db_path = _here / "data" / "threat_intel.db"

        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db           = _ThreatIntelDB(db_path)
        self._lock         = threading.Lock()
        self._updating     = False
        self._last_update  = 0.0   # epoch seconds
        self._update_thread: Optional[threading.Thread] = None
        self._stop_event   = threading.Event()

        counts = self._db.get_counts()
        total  = counts.get("hashes", 0) + counts.get("network_iocs", 0)
        logger.info(
            "[ThreatIntel] Initialised — %d hashes + %d network IOCs in cache",
            counts.get("hashes", 0), counts.get("network_iocs", 0),
        )

        if auto_update:
            # Start background updater
            self._update_thread = threading.Thread(
                target=self._updater_loop,
                name="ThreatIntelUpdater",
                daemon=True,
            )
            self._update_thread.start()

            # If cache is empty, trigger an immediate update
            if total == 0:
                logger.info("[ThreatIntel] Cache empty — triggering first-run update…")
                threading.Thread(target=self.update_now, daemon=True).start()

    # ── Lookup API ────────────────────────────────────────────────────────────

    def lookup_hash(self, md5: str = "", sha1: str = "",
                    sha256: str = "") -> Optional[ThreatIntelMatch]:
        """
        Look up a file hash. Pass any combination of md5/sha1/sha256.
        Returns ThreatIntelMatch or None.
        """
        try:
            row = self._db.lookup_hash(
                md5=md5.lower() if md5 else "",
                sha1=sha1.lower() if sha1 else "",
                sha256=sha256.lower() if sha256 else "",
            )
            if row is None:
                return None
            # Determine which hash matched
            value = md5 or sha256 or sha1
            ioc_type = ("hash_md5"    if md5    else
                        "hash_sha256" if sha256  else "hash_sha1")
            return _row_to_match(row, ioc_type, value)
        except Exception as e:
            logger.debug("[ThreatIntel] lookup_hash error: %s", e)
            return None

    def lookup_ip(self, ip: str) -> Optional[ThreatIntelMatch]:
        """Look up an IP address. Returns ThreatIntelMatch or None."""
        try:
            row = self._db.lookup_ip(ip.strip())
            if row is None:
                return None
            return _row_to_match(row, "ip", ip)
        except Exception as e:
            logger.debug("[ThreatIntel] lookup_ip error: %s", e)
            return None

    def lookup_domain(self, domain: str) -> Optional[ThreatIntelMatch]:
        """Look up a domain. Returns ThreatIntelMatch or None."""
        try:
            row = self._db.lookup_domain(domain)
            if row is None:
                return None
            return _row_to_match(row, "domain", domain)
        except Exception as e:
            logger.debug("[ThreatIntel] lookup_domain error: %s", e)
            return None

    def lookup_url(self, url: str) -> Optional[ThreatIntelMatch]:
        """Look up a full URL. Returns ThreatIntelMatch or None."""
        try:
            row = self._db.lookup_url(url.strip())
            if row is None:
                return None
            return _row_to_match(row, "url", url)
        except Exception as e:
            logger.debug("[ThreatIntel] lookup_url error: %s", e)
            return None

    def get_stats(self) -> Dict:
        """
        Return a dict with cache sizes and last-update timestamps per feed.
        Safe to call at any time — reads are non-blocking.
        """
        counts = self._db.get_counts()
        counts["is_updating"]  = self._updating
        counts["last_update"]  = (
            datetime.fromtimestamp(self._last_update).strftime("%Y-%m-%d %H:%M:%S")
            if self._last_update else "never"
        )
        return counts

    # ── Update ────────────────────────────────────────────────────────────────

    def update_now(self) -> Dict[str, int]:
        """
        Fetch all three feeds and insert new records into the local cache.
        Thread-safe — concurrent calls are ignored (one update at a time).

        Returns dict with counts of newly inserted records per feed.
        """
        with self._lock:
            if self._updating:
                logger.info("[ThreatIntel] Update already in progress — skipping")
                return {}
            self._updating = True

        inserted: Dict[str, int] = {}
        try:
            # ── 1. MalwareBazaar ─────────────────────────────────────────────
            mb_rows = _fetch_malwarebazaar_recent()
            if not mb_rows:
                # Fallback to JSON API
                mb_rows = _fetch_malwarebazaar_api_recent(limit=100)
            n_mb = self._db.upsert_hashes(mb_rows)
            self._db.set_feed_meta("malwarebazaar", len(mb_rows))
            inserted["malwarebazaar"] = n_mb
            logger.info("[ThreatIntel] MalwareBazaar: +%d new hashes", n_mb)

            # ── 2. ThreatFox ─────────────────────────────────────────────────
            tf_hashes, tf_net = _fetch_threatfox(days_back=7)
            n_tf_h = self._db.upsert_hashes(tf_hashes)
            n_tf_n = self._db.upsert_network_iocs(tf_net)
            self._db.set_feed_meta("threatfox", len(tf_hashes) + len(tf_net))
            inserted["threatfox_hashes"]  = n_tf_h
            inserted["threatfox_network"] = n_tf_n
            logger.info("[ThreatIntel] ThreatFox: +%d hashes, +%d network IOCs",
                        n_tf_h, n_tf_n)

            # ── 3. URLhaus ───────────────────────────────────────────────────
            uh_rows = _fetch_urlhaus()
            n_uh = self._db.upsert_network_iocs(uh_rows)
            self._db.set_feed_meta("urlhaus", len(uh_rows))
            inserted["urlhaus"] = n_uh
            logger.info("[ThreatIntel] URLhaus: +%d network IOCs", n_uh)

            self._last_update = time.time()
            totals = self._db.get_counts()
            logger.info(
                "[ThreatIntel] Update complete — total: %d hashes, %d network IOCs",
                totals.get("hashes", 0), totals.get("network_iocs", 0),
            )
        except Exception as e:
            logger.error("[ThreatIntel] update_now failed: %s", e)
        finally:
            self._updating = False

        return inserted

    def stop(self):
        """Signal the background updater thread to stop."""
        self._stop_event.set()

    # ── Background updater ────────────────────────────────────────────────────

    def _updater_loop(self):
        """Background thread: sleep → update → repeat."""
        interval = UPDATE_INTERVAL_HOURS * 3600
        while not self._stop_event.is_set():
            # Sleep in 60s chunks so stop() is responsive
            elapsed = 0
            while elapsed < interval and not self._stop_event.is_set():
                time.sleep(60)
                elapsed += 60
            if not self._stop_event.is_set():
                try:
                    self.update_now()
                except Exception as e:
                    logger.error("[ThreatIntel] Background update error: %s", e)