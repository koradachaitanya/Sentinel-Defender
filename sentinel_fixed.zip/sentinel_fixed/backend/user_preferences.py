"""
Sentinel Defender - User Preferences
=====================================
Stores user choices from the first-run wizard and any later settings changes.
All settings live in a single JSON file: data/user_preferences.json

Used by:
  sentinel_gui.py  — first-run wizard, "Fix it for me" mode toggle
  main.py          — DynamicEngine watch paths, scheduled scan targets
  scheduler.py     — scan schedule config
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

# ── Defaults ──────────────────────────────────────────────────────────────────

DEFAULT_PREFS: Dict[str, Any] = {
    # Whether the first-run wizard has been completed
    "setup_complete": False,

    # Folders to watch with real-time protection (DynamicEngine)
    "watch_paths": [],

    # Folders to scan on the nightly schedule
    "scheduled_scan_paths": [],

    # Whether real-time protection starts automatically on launch
    "auto_start_protection": True,

    # Whether nightly scheduled scans are enabled
    "scheduled_scans_enabled": True,

    # Time for nightly scan (24h format, "HH:MM")
    "scheduled_scan_time": "02:00",

    # "fix_it_for_me" vs "step_by_step" remediation mode
    "remediation_mode": "fix_it_for_me",

    # Whether to show plain-English summaries (True) or technical detail (False)
    "plain_english_mode": True,

    # Whether to show Windows toast notifications for threats
    "show_notifications": True,

    # User's name (optional, used in reports)
    "user_name": "",

    # Theme (for future use)
    "theme": "dark",
}


# ── Manager ───────────────────────────────────────────────────────────────────

class UserPreferences:
    """
    Read/write user preferences from data/user_preferences.json.

    Usage:
        prefs = UserPreferences()
        if not prefs.setup_complete:
            # show first-run wizard
        watch_paths = prefs.watch_paths
        prefs.set("remediation_mode", "step_by_step")
    """

    def __init__(self, prefs_path: Path | None = None):
        if prefs_path is None:
            _here = Path(__file__).resolve().parent.parent
            prefs_path = _here / "data" / "user_preferences.json"

        self._path = prefs_path
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._data: Dict[str, Any] = {}
        self._load()

    # ── Persistence ───────────────────────────────────────────────────────────

    def _load(self):
        """Load from disk, filling in any missing keys from defaults."""
        if self._path.exists():
            try:
                with open(self._path, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                # Merge: saved values override defaults, but new default keys are added
                self._data = {**DEFAULT_PREFS, **saved}
                return
            except Exception as e:
                logger.warning("UserPreferences: load failed (%s), using defaults", e)
        self._data = dict(DEFAULT_PREFS)
        self._save()

    def _save(self):
        """Persist current settings to disk."""
        try:
            with open(self._path, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2)
        except Exception as e:
            logger.error("UserPreferences: save failed: %s", e)

    # ── Public API ────────────────────────────────────────────────────────────

    def get(self, key: str, default=None):
        return self._data.get(key, default)

    def set(self, key: str, value) -> None:
        self._data[key] = value
        self._save()

    def update(self, mapping: Dict[str, Any]) -> None:
        """Update multiple keys at once and save once."""
        self._data.update(mapping)
        self._save()

    # ── Convenience properties ────────────────────────────────────────────────

    @property
    def setup_complete(self) -> bool:
        return bool(self._data.get("setup_complete", False))

    @setup_complete.setter
    def setup_complete(self, value: bool):
        self.set("setup_complete", value)

    @property
    def watch_paths(self) -> List[str]:
        return self._data.get("watch_paths", [])

    @property
    def scheduled_scan_paths(self) -> List[str]:
        return self._data.get("scheduled_scan_paths", [])

    @property
    def auto_start_protection(self) -> bool:
        return bool(self._data.get("auto_start_protection", True))

    @property
    def scheduled_scans_enabled(self) -> bool:
        return bool(self._data.get("scheduled_scans_enabled", True))

    @property
    def scheduled_scan_time(self) -> str:
        return self._data.get("scheduled_scan_time", "02:00")

    @property
    def remediation_mode(self) -> str:
        return self._data.get("remediation_mode", "fix_it_for_me")

    @property
    def plain_english_mode(self) -> bool:
        return bool(self._data.get("plain_english_mode", True))

    @property
    def show_notifications(self) -> bool:
        return bool(self._data.get("show_notifications", True))

    @property
    def user_name(self) -> str:
        return self._data.get("user_name", "")

    def mark_setup_complete(self, watch_paths: List[str],
                             scheduled_paths: List[str],
                             auto_protect: bool,
                             scheduled_enabled: bool,
                             show_notifications: bool,
                             user_name: str = "") -> None:
        """Called by the first-run wizard on completion."""
        self.update({
            "setup_complete":           True,
            "watch_paths":              watch_paths,
            "scheduled_scan_paths":     scheduled_paths,
            "auto_start_protection":    auto_protect,
            "scheduled_scans_enabled":  scheduled_enabled,
            "show_notifications":       show_notifications,
            "user_name":                user_name,
            "remediation_mode":         "fix_it_for_me",
            "plain_english_mode":       True,
        })
        logger.info("UserPreferences: setup complete. Watch paths: %s", watch_paths)