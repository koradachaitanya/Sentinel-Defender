"""
Sentinel Defender - Forensic Artifact Collector
Gathers system artifacts: registry keys, network connections, startup items,
browser history, scheduled tasks, and services for investigation.
"""

import logging
import psutil
import socket
import subprocess
import platform
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass, field
from datetime import datetime
import json

logger = logging.getLogger(__name__)

# ==================== WINDOWS REGISTRY (if available) ====================

try:
    import winreg
    WINREG_AVAILABLE = True
except ImportError:
    WINREG_AVAILABLE = False
    logger.warning("winreg not available - registry forensics disabled")


# ==================== DATA STRUCTURES ====================

@dataclass
class ForensicArtifact:
    """Represents a single forensic artifact."""
    artifact_type: str      # 'registry', 'network', 'startup', 'service', 'scheduled_task', 'browser'
    category: str           # 'persistence', 'network', 'execution', 'discovery'
    name: str
    value: str
    path: str
    timestamp: datetime
    suspicious_score: int   # 0-100
    notes: str = ""
    mitre_technique: str = ""
    
    def to_dict(self) -> Dict:
        return {
            'artifact_type': self.artifact_type,
            'category': self.category,
            'name': self.name,
            'value': self.value,
            'path': self.path,
            'timestamp': self.timestamp.isoformat(),
            'suspicious_score': self.suspicious_score,
            'notes': self.notes,
            'mitre_technique': self.mitre_technique
        }


@dataclass
class ForensicCollection:
    """Complete forensic artifact collection from a system."""
    collection_id: str
    hostname: str
    os_version: str
    collection_timestamp: datetime
    artifacts: List[ForensicArtifact] = field(default_factory=list)
    summary: Dict = field(default_factory=dict)
    
    def add_artifact(self, artifact: ForensicArtifact):
        self.artifacts.append(artifact)
    
    def to_dict(self) -> Dict:
        return {
            'collection_id': self.collection_id,
            'hostname': self.hostname,
            'os_version': self.os_version,
            'collection_timestamp': self.collection_timestamp.isoformat(),
            'total_artifacts': len(self.artifacts),
            'artifacts': [a.to_dict() for a in self.artifacts],
            'summary': self.summary
        }


# ==================== FORENSIC ARTIFACT COLLECTOR ====================

class ForensicsCollector:
    """
    Collect forensic artifacts from the local system.
    Focus: Persistence mechanisms, network activity, execution traces.
    """
    
    def __init__(self):
        self.collection = ForensicCollection(
            collection_id=datetime.now().strftime('%Y%m%d_%H%M%S'),
            hostname=platform.node(),
            os_version=platform.platform(),
            collection_timestamp=datetime.now()
        )
    
    # ── Public API ────────────────────────────────────────────────────
    
    def collect_all(self) -> ForensicCollection:
        """Run all collection modules and return complete collection."""
        logger.info("Starting forensic artifact collection")
        
        self.collect_registry_persistence()
        self.collect_network_connections()
        self.collect_startup_items()
        self.collect_services()
        self.collect_scheduled_tasks()
        self.collect_browser_artifacts()
        self.collect_process_list()
        
        self._generate_summary()
        
        logger.info(f"Collection complete: {len(self.collection.artifacts)} artifacts")
        return self.collection
    
    # ── Registry Persistence (Windows) ────────────────────────────────
    
    def collect_registry_persistence(self):
        """Collect common persistence registry keys."""
        if not WINREG_AVAILABLE:
            return
        
        # Common persistence locations
        persistence_keys = [
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "Run"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "RunOnce"),
            (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "Run (User)"),
            (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "RunOnce (User)"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders", "Shell Folders"),
            (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Services", "Services"),
        ]
        
        for root, key_path, category_name in persistence_keys:
            try:
                key = winreg.OpenKey(root, key_path, 0, winreg.KEY_READ)
                
                i = 0
                while True:
                    try:
                        name, value, value_type = winreg.EnumValue(key, i)
                        
                        # Calculate suspiciousness
                        score = self._score_registry_value(name, value, key_path)
                        
                        artifact = ForensicArtifact(
                            artifact_type='registry',
                            category='persistence',
                            name=name,
                            value=str(value)[:500],  # Truncate long values
                            path=f"{self._hkey_to_string(root)}\\{key_path}",
                            timestamp=datetime.now(),
                            suspicious_score=score,
                            mitre_technique='T1547.001 - Registry Run Keys / Startup Folder'
                        )
                        self.collection.add_artifact(artifact)
                        
                        i += 1
                    except OSError:
                        break
                
                winreg.CloseKey(key)
                
            except (FileNotFoundError, PermissionError) as e:
                logger.debug(f"Cannot access registry key {key_path}: {e}")
    
    def _score_registry_value(self, name: str, value: str, path: str) -> int:
        """Score registry value suspiciousness (0-100)."""
        score = 0
        value_lower = str(value).lower()
        
        # Suspicious paths
        if any(x in value_lower for x in ['temp\\', 'appdata\\local\\temp', '%temp%']):
            score += 40
        
        # Obfuscation indicators
        if any(x in value_lower for x in ['powershell', 'cmd /c', 'wscript', 'mshta']):
            score += 30
        
        # Base64 encoding
        if len(value) > 50 and value.replace('=', '').replace('+', '').replace('/', '').isalnum():
            score += 25
        
        # Unusual extensions
        if any(x in value_lower for x in ['.vbs', '.js', '.hta', '.bat']):
            score += 20
        
        return min(score, 100)
    
    @staticmethod
    def _hkey_to_string(hkey) -> str:
        mapping = {
            winreg.HKEY_LOCAL_MACHINE: 'HKLM',
            winreg.HKEY_CURRENT_USER: 'HKCU',
            winreg.HKEY_CLASSES_ROOT: 'HKCR',
            winreg.HKEY_USERS: 'HKU',
        }
        return mapping.get(hkey, 'HKEY_?')
    
    # ── Network Connections ───────────────────────────────────────────
    
    def collect_network_connections(self):
        """Collect active network connections."""
        try:
            connections = psutil.net_connections(kind='inet')
            
            for conn in connections:
                if conn.status == 'ESTABLISHED':
                    try:
                        proc = psutil.Process(conn.pid) if conn.pid else None
                        proc_name = proc.name() if proc else 'Unknown'
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        proc_name = 'Unknown'
                    
                    # Score suspiciousness
                    score = self._score_network_connection(conn, proc_name)
                    
                    artifact = ForensicArtifact(
                        artifact_type='network',
                        category='network',
                        name=f"{proc_name} → {conn.raddr.ip if conn.raddr else 'N/A'}",
                        value=f"{conn.laddr.ip}:{conn.laddr.port} → {conn.raddr.ip if conn.raddr else 'N/A'}:{conn.raddr.port if conn.raddr else 'N/A'}",
                        path=f"PID: {conn.pid}",
                        timestamp=datetime.now(),
                        suspicious_score=score,
                        mitre_technique='T1071 - Application Layer Protocol' if score > 50 else ''
                    )
                    self.collection.add_artifact(artifact)
        
        except Exception as e:
            logger.error(f"Network connection collection error: {e}")
    
    def _score_network_connection(self, conn, proc_name: str) -> int:
        """Score network connection suspiciousness."""
        score = 0
        
        if conn.raddr:
            # Non-standard ports
            if conn.raddr.port in [4444, 5555, 6666, 8080, 8888, 9999]:
                score += 50
            
            # Suspicious processes making network connections
            if proc_name.lower() in ['cmd.exe', 'powershell.exe', 'wscript.exe', 'mshta.exe']:
                score += 40
            
            # Private IP ranges (might be lateral movement)
            if conn.raddr.ip.startswith('10.') or conn.raddr.ip.startswith('192.168.'):
                pass  # Internal traffic, not inherently suspicious
            elif not conn.raddr.ip.startswith('127.'):
                score += 10  # External connection (baseline suspicious)
        
        return min(score, 100)
    
    # ── Startup Items ─────────────────────────────────────────────────
    
    def collect_startup_items(self):
        """Collect startup folder items (Windows)."""
        if platform.system() != 'Windows':
            return
        
        startup_paths = [
            Path.home() / 'AppData/Roaming/Microsoft/Windows/Start Menu/Programs/Startup',
            Path('C:/ProgramData/Microsoft/Windows/Start Menu/Programs/Startup')
        ]
        
        for startup_path in startup_paths:
            if not startup_path.exists():
                continue
            
            for item in startup_path.iterdir():
                artifact = ForensicArtifact(
                    artifact_type='startup',
                    category='persistence',
                    name=item.name,
                    value=str(item),
                    path=str(startup_path),
                    timestamp=datetime.fromtimestamp(item.stat().st_mtime),
                    suspicious_score=30,  # Startup items moderately suspicious
                    mitre_technique='T1547.001 - Registry Run Keys / Startup Folder'
                )
                self.collection.add_artifact(artifact)
    
    # ── Services ──────────────────────────────────────────────────────
    
    def collect_services(self):
        """Collect Windows services (running/stopped)."""
        if platform.system() != 'Windows':
            return
        
        try:
            result = subprocess.run(
                ['sc', 'query', 'state=', 'all'],
                capture_output=True, text=True, timeout=10
            )
            
            services = self._parse_sc_query(result.stdout)
            
            for svc in services:
                score = 20 if svc['state'] == 'RUNNING' else 10
                
                # Score based on service name
                if any(x in svc['name'].lower() for x in ['temp', 'update', 'service']):
                    score += 20
                
                artifact = ForensicArtifact(
                    artifact_type='service',
                    category='persistence',
                    name=svc['name'],
                    value=f"State: {svc['state']} | Display: {svc['display_name']}",
                    path='Services',
                    timestamp=datetime.now(),
                    suspicious_score=score,
                    mitre_technique='T1543.003 - Create or Modify System Process: Windows Service'
                )
                self.collection.add_artifact(artifact)
        
        except Exception as e:
            logger.error(f"Service collection error: {e}")
    
    @staticmethod
    def _parse_sc_query(output: str) -> List[Dict]:
        """Parse sc query output."""
        services = []
        current = {}
        
        for line in output.split('\n'):
            line = line.strip()
            if line.startswith('SERVICE_NAME:'):
                if current:
                    services.append(current)
                current = {'name': line.split(':', 1)[1].strip()}
            elif line.startswith('DISPLAY_NAME:'):
                current['display_name'] = line.split(':', 1)[1].strip()
            elif line.startswith('STATE'):
                parts = line.split()
                if len(parts) > 3:
                    current['state'] = parts[3]
        
        if current:
            services.append(current)
        
        return services
    
    # ── Scheduled Tasks ───────────────────────────────────────────────
    
    def collect_scheduled_tasks(self):
        """Collect scheduled tasks (Windows)."""
        if platform.system() != 'Windows':
            return
        
        try:
            result = subprocess.run(
                ['schtasks', '/query', '/fo', 'LIST', '/v'],
                capture_output=True, text=True, timeout=10
            )
            
            tasks = self._parse_schtasks(result.stdout)
            
            for task in tasks:
                score = 30 if task.get('status') == 'Ready' else 15
                
                # Score based on task action
                action = task.get('action', '').lower()
                if any(x in action for x in ['powershell', 'cmd', 'wscript']):
                    score += 35
                
                artifact = ForensicArtifact(
                    artifact_type='scheduled_task',
                    category='persistence',
                    name=task.get('name', 'Unknown'),
                    value=f"Action: {task.get('action', 'N/A')}",
                    path=task.get('path', '\\'),
                    timestamp=datetime.now(),
                    suspicious_score=score,
                    mitre_technique='T1053.005 - Scheduled Task/Job: Scheduled Task'
                )
                self.collection.add_artifact(artifact)
        
        except Exception as e:
            logger.error(f"Scheduled task collection error: {e}")
    
    @staticmethod
    def _parse_schtasks(output: str) -> List[Dict]:
        """Parse schtasks output (simple extraction)."""
        tasks = []
        current = {}
        
        for line in output.split('\n'):
            line = line.strip()
            if line.startswith('TaskName:'):
                if current:
                    tasks.append(current)
                current = {'name': line.split(':', 1)[1].strip()}
            elif line.startswith('Status:'):
                current['status'] = line.split(':', 1)[1].strip()
            elif line.startswith('Task To Run:'):
                current['action'] = line.split(':', 1)[1].strip()
        
        if current:
            tasks.append(current)
        
        return tasks[:50]  # Limit to first 50 tasks
    
    # ── Browser Artifacts ─────────────────────────────────────────────
    
    def collect_browser_artifacts(self):
        """Collect browser history (basic — just check paths exist)."""
        browser_paths = {
            'Chrome': Path.home() / 'AppData/Local/Google/Chrome/User Data/Default/History',
            'Firefox': Path.home() / 'AppData/Roaming/Mozilla/Firefox/Profiles',
            'Edge': Path.home() / 'AppData/Local/Microsoft/Edge/User Data/Default/History',
        }
        
        for browser, path in browser_paths.items():
            if path.exists():
                artifact = ForensicArtifact(
                    artifact_type='browser',
                    category='discovery',
                    name=f"{browser} History",
                    value=f"Found at {path}",
                    path=str(path),
                    timestamp=datetime.fromtimestamp(path.stat().st_mtime),
                    suspicious_score=0,  # Browser history not suspicious
                    notes="Parse SQLite database for detailed history"
                )
                self.collection.add_artifact(artifact)
    
    # ── Process List ──────────────────────────────────────────────────
    
    def collect_process_list(self):
        """Collect running process list snapshot."""
        for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline']):
            try:
                info = proc.info
                cmdline = ' '.join(info['cmdline']) if info['cmdline'] else ''
                
                # Score suspiciousness
                score = self._score_process(info['name'], cmdline, info.get('exe', ''))
                
                artifact = ForensicArtifact(
                    artifact_type='process',
                    category='execution',
                    name=info['name'],
                    value=f"PID: {info['pid']} | Cmdline: {cmdline[:200]}",
                    path=info.get('exe', 'Unknown'),
                    timestamp=datetime.now(),
                    suspicious_score=score
                )
                self.collection.add_artifact(artifact)
            
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
    
    def _score_process(self, name: str, cmdline: str, exe_path: str) -> int:
        """Score process suspiciousness."""
        score = 0
        name_lower = name.lower()
        cmdline_lower = cmdline.lower()
        
        # Suspicious process names
        if name_lower in ['cmd.exe', 'powershell.exe', 'wscript.exe', 'cscript.exe', 'mshta.exe']:
            score += 20
        
        # Running from temp
        if 'temp' in exe_path.lower() or 'tmp' in exe_path.lower():
            score += 35
        
        # Obfuscation indicators in cmdline
        if '-e' in cmdline_lower or '-encodedcommand' in cmdline_lower:
            score += 50  # Base64 PowerShell
        
        if 'downloadstring' in cmdline_lower or 'invoke-expression' in cmdline_lower:
            score += 45
        
        return min(score, 100)
    
    # ── Summary ───────────────────────────────────────────────────────
    
    def _generate_summary(self):
        """Generate collection summary statistics."""
        by_type = {}
        by_category = {}
        high_risk = []
        
        for artifact in self.collection.artifacts:
            by_type[artifact.artifact_type] = by_type.get(artifact.artifact_type, 0) + 1
            by_category[artifact.category] = by_category.get(artifact.category, 0) + 1
            
            if artifact.suspicious_score >= 60:
                high_risk.append(artifact.name)
        
        self.collection.summary = {
            'by_type': by_type,
            'by_category': by_category,
            'high_risk_count': len(high_risk),
            'high_risk_artifacts': high_risk[:20]  # Top 20
        }
