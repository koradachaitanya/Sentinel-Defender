#!/usr/bin/env python3
"""
Sentinel Defender - Investigative Agent
Analyzes detected threats and generates structured investigation reports.
"""

import hashlib
import os
import json
import logging
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Set

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
#  Data classes
# ─────────────────────────────────────────────

@dataclass
class ThreatIndicator:
    indicator_type: str          # "hash" | "filename" | "behavior" | "entropy"
    value: str
    confidence: str              # "HIGH" | "MEDIUM" | "LOW"
    description: str


@dataclass
class InvestigationReport:
    report_id: str
    generated_at: str
    threat_count: int
    severity: str                # "CRITICAL" | "HIGH" | "MEDIUM" | "LOW" | "CLEAN"
    executive_summary: str
    threats: list                # raw threat dicts
    indicators: list             # list of ThreatIndicator (as dicts)
    recommended_actions: list    # plain strings
    risk_score: int              # 0-100
    findings: list               # narrative findings


# ─────────────────────────────────────────────
#  Agent
# ─────────────────────────────────────────────

class InvestigativeAgent:
    """
    Analyses the list of threats collected by SentinelHub and produces
    a structured InvestigationReport without any external calls.
    """

    # Threat-name fragments → MITRE ATT&CK-style tag
    THREAT_FAMILY_MAP = {
        "eicar":        ("Test/EICAR",              "Test signature – not a real threat"),
        "ransomware":   ("Ransomware",              "File-encrypting malware"),
        "trojan":       ("Trojan",                  "Malicious code disguised as legitimate"),
        "keylogger":    ("Spyware/Keylogger",       "Captures user keystrokes"),
        "backdoor":     ("Backdoor/RAT",            "Allows unauthorised remote access"),
        "dropper":      ("Dropper",                 "Installs additional malware"),
        "miner":        ("Cryptominer",             "Hijacks CPU/GPU for cryptocurrency"),
        "adware":       ("Adware",                  "Displays unwanted advertisements"),
        "worm":         ("Worm",                    "Self-replicating across the network"),
        "rootkit":      ("Rootkit",                 "Hides malware presence from OS"),
    }

    def __init__(self):
        self._report_counter = 0

    # ── Public API ────────────────────────────────────────────────────────────

    def investigate(self, threats: List[Dict], scan_path: Optional[str] = None) -> InvestigationReport:
        """
        Main entry point.
        threats: list of threat dicts as stored by SentinelHub / DatabaseManager.
        """
        self._report_counter += 1
        report_id = f"INV-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{self._report_counter:04d}"

        if not threats:
            return self._clean_report(report_id)

        indicators  = self._extract_indicators(threats)
        risk_score  = self._calculate_risk(threats, indicators)
        severity    = self._severity_label(risk_score)
        findings    = self._build_findings(threats, indicators)
        actions     = self._recommend_actions(threats, indicators, severity)
        summary     = self._executive_summary(threats, risk_score, severity, scan_path)

        report = InvestigationReport(
            report_id=report_id,
            generated_at=datetime.now().isoformat(timespec="seconds"),
            threat_count=len(threats),
            severity=severity,
            executive_summary=summary,
            threats=threats,
            indicators=[asdict(i) for i in indicators],
            recommended_actions=actions,
            risk_score=risk_score,
            findings=findings,
        )

        logger.info(
            "[InvestigativeAgent] Report %s — %d threats, risk %d, severity %s",
            report_id, len(threats), risk_score, severity,
        )
        return report

    def to_dict(self, report: InvestigationReport) -> dict:
        return asdict(report)

    def to_json(self, report: InvestigationReport, indent: int = 2) -> str:
        return json.dumps(self.to_dict(report), indent=indent, default=str)

    # ── Private helpers ───────────────────────────────────────────────────────

    def _extract_indicators(self, threats: List[Dict]) -> List[ThreatIndicator]:
        indicators: List[ThreatIndicator] = []
        seen_hashes: Set[str] = set()

        for t in threats:
            # Hash indicator
            th = t.get("file_hash") or t.get("hash") or ""
            if th and th not in seen_hashes:
                seen_hashes.add(th)
                indicators.append(ThreatIndicator(
                    indicator_type="hash",
                    value=th,
                    confidence="HIGH",
                    description="File hash matched known malware signature",
                ))

            # Filename / path indicator
            fp = t.get("file_path") or t.get("path") or ""
            if fp:
                fname = Path(fp).name
                indicators.append(ThreatIndicator(
                    indicator_type="filename",
                    value=fname,
                    confidence="MEDIUM",
                    description=f"Suspicious file detected: {fname}",
                ))

            # Threat-name family indicator
            tname = (t.get("threat_name") or t.get("threat_type") or "").lower()
            for keyword, (family, desc) in self.THREAT_FAMILY_MAP.items():
                if keyword in tname:
                    indicators.append(ThreatIndicator(
                        indicator_type="behavior",
                        value=family,
                        confidence="HIGH",
                        description=desc,
                    ))
                    break

            # Entropy indicator
            entropy = t.get("entropy") or t.get("heuristic_score") or 0
            try:
                if float(entropy) > 7.0:
                    indicators.append(ThreatIndicator(
                        indicator_type="entropy",
                        value=f"{float(entropy):.2f}",
                        confidence="MEDIUM",
                        description="High entropy suggests encryption or packing (common in malware)",
                    ))
            except (ValueError, TypeError):
                pass

        return indicators

    def _calculate_risk(self, threats: List[Dict], indicators: List[ThreatIndicator]) -> int:
        score = 0

        # Base: 10 points per threat, capped at 40
        score += min(len(threats) * 10, 40)

        # High-confidence indicators
        high_conf = sum(1 for i in indicators if i.confidence == "HIGH")
        score += min(high_conf * 5, 30)

        # Threat family severity bonuses
        for t in threats:
            tname = (t.get("threat_name") or t.get("threat_type") or "").lower()
            if any(k in tname for k in ("ransomware", "rootkit", "backdoor")):
                score += 20
            elif any(k in tname for k in ("trojan", "worm", "dropper")):
                score += 10
            elif any(k in tname for k in ("miner", "keylogger")):
                score += 8

        # Entropy bonus
        for i in indicators:
            if i.indicator_type == "entropy":
                score += 5

        return min(score, 100)

    def _severity_label(self, risk_score: int) -> str:
        if risk_score >= 80:
            return "CRITICAL"
        if risk_score >= 60:
            return "HIGH"
        if risk_score >= 30:
            return "MEDIUM"
        if risk_score > 0:
            return "LOW"
        return "CLEAN"

    def _build_findings(self, threats: List[Dict], indicators: List[ThreatIndicator]) -> List[str]:
        findings = []

        findings.append(
            f"Total threats identified: {len(threats)}"
        )

        families: Dict[str, int] = {}
        for t in threats:
            tname = (t.get("threat_name") or t.get("threat_type") or "Unknown").strip()
            families[tname] = families.get(tname, 0) + 1

        for family, count in sorted(families.items(), key=lambda x: -x[1]):
            findings.append(f"Threat family '{family}' detected {count} time(s)")

        hash_count = sum(1 for i in indicators if i.indicator_type == "hash")
        if hash_count:
            findings.append(
                f"{hash_count} file hash(es) matched known malware signatures in the threat database"
            )

        entropy_count = sum(1 for i in indicators if i.indicator_type == "entropy")
        if entropy_count:
            findings.append(
                f"{entropy_count} file(s) exhibit abnormally high entropy — likely packed or encrypted payloads"
            )

        # Quarantine status
        quarantined = sum(1 for t in threats if t.get("quarantined") or t.get("action") == "quarantine")
        if quarantined:
            findings.append(f"{quarantined} threat(s) already moved to quarantine vault")

        active = len(threats) - quarantined
        if active:
            findings.append(f"{active} threat(s) still on disk — remediation required")

        return findings

    def _recommend_actions(self, threats: List[Dict], indicators: List[ThreatIndicator], severity: str) -> List[str]:
        actions = []

        # Universal recommendations
        actions.append("Quarantine all detected threats immediately via the Quarantine tab")
        actions.append("Run a full-system scan to ensure no additional threats remain")

        if severity in ("CRITICAL", "HIGH"):
            actions.append("Isolate the affected machine from the network until remediation is complete")
            actions.append("Change all credentials (passwords, API keys) that may have been accessible on this system")

        # Threat-specific
        for t in threats:
            tname = (t.get("threat_name") or t.get("threat_type") or "").lower()
            if "ransomware" in tname:
                actions.append("Restore encrypted files from offline/cloud backup — do NOT pay ransom")
                actions.append("Check shadow copies: vssadmin list shadows (Windows)")
            if "rootkit" in tname:
                actions.append("Boot from a clean live OS image to remove rootkit — OS-level removal is unreliable")
            if "keylogger" in tname or "spyware" in tname:
                actions.append("Assume all typed credentials are compromised — rotate immediately")
            if "backdoor" in tname or "rat" in tname:
                actions.append("Audit firewall logs for outbound C2 connections")

        # Entropy-based
        entropy_indicators = [i for i in indicators if i.indicator_type == "entropy"]
        if entropy_indicators:
            actions.append("Submit high-entropy files to a sandbox (e.g. any.run, Cuckoo) for dynamic analysis")

        actions.append("Update virus definitions and re-scan within 24 hours")
        actions.append("Review and patch OS and application vulnerabilities (run Windows Update / apt upgrade)")

        # Deduplicate while preserving order
        seen, unique = set(), []
        for a in actions:
            if a not in seen:
                seen.add(a)
                unique.append(a)

        return unique

    def _executive_summary(
        self, threats: List[Dict], risk_score: int, severity: str, scan_path: Optional[str]
    ) -> str:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        path_str = f" of '{scan_path}'" if scan_path else ""

        families: Set[str] = set()
        for t in threats:
            tname = (t.get("threat_name") or t.get("threat_type") or "").lower()
            for keyword, (family, _) in self.THREAT_FAMILY_MAP.items():
                if keyword in tname:
                    families.add(family)
                    break
            else:
                families.add(t.get("threat_name") or "Unknown")

        family_str = ", ".join(sorted(families)) if families else "unknown malware"

        return (
            f"Sentinel Defender investigation completed at {ts}{path_str}. "
            f"The scan identified {len(threats)} threat(s) with an overall risk score of "
            f"{risk_score}/100 (severity: {severity}). "
            f"Threat families detected include: {family_str}. "
            f"Immediate remediation is {'strongly ' if severity in ('CRITICAL','HIGH') else ''}recommended. "
            f"See the Findings and Recommended Actions sections for details."
        )

    def _clean_report(self, report_id: str) -> InvestigationReport:
        return InvestigationReport(
            report_id=report_id,
            generated_at=datetime.now().isoformat(timespec="seconds"),
            threat_count=0,
            severity="CLEAN",
            executive_summary=(
                "No threats were detected during this scan. "
                "The system appears clean. Continue regular scheduled scans to maintain protection."
            ),
            threats=[],
            indicators=[],
            recommended_actions=["Maintain regular scan schedule", "Keep threat definitions updated"],
            risk_score=0,
            findings=["No threats found — system appears clean"],
        )
