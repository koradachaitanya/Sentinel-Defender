#!/usr/bin/env python3
"""
Sentinel Defender - Optimized Hollywood Dashboard
STABILITY PATCH: Reduced polling frequencies for smooth GUI.
PROFESSOR REQUIREMENT: Professional tabular log view.
"""

import sys
import os
import subprocess
import threading
import time
import hashlib
import logging
from pathlib import Path
from typing import Optional
from datetime import datetime
from tkinter import filedialog, messagebox, ttk, simpledialog
import customtkinter as ctk

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent))

from backend.main import SentinelHub, ScanType
from backend.database import DatabaseManager
from backend.investigative_agent import InvestigativeAgent
from backend.planning_agent import PlanningAgent
from backend.action_agent import ActionAgent, ActionStatus
from backend.network_engine import NetworkMonitor, NetworkAlert, AttackCategory, Severity, SCAPY_AVAILABLE
try:
    from backend.dynamic_engine import DynamicAlert
    DYNAMIC_ENGINE_AVAILABLE = True
except ImportError:
    DYNAMIC_ENGINE_AVAILABLE = False


def _install_runtime_file_logging():
    """Mirror runtime logs to a local file so UI freezes can be diagnosed after the fact."""
    try:
        log_dir = Path(__file__).parent / "data" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "runtime_debug.log"
        root_logger = logging.getLogger()
        target = str(log_path.resolve())
        for handler in root_logger.handlers:
            if isinstance(handler, logging.FileHandler) and getattr(handler, "baseFilename", "") == target:
                return
        file_handler = logging.FileHandler(log_path, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        ))
        root_logger.addHandler(file_handler)

        diag_path = log_dir / "runtime_diag.log"
        diag_logger = logging.getLogger("sentinel.diag")
        diag_logger.setLevel(logging.DEBUG)
        diag_logger.propagate = False
        for handler in diag_logger.handlers:
            if isinstance(handler, logging.FileHandler) and getattr(handler, "baseFilename", "") == str(diag_path.resolve()):
                return
        diag_handler = logging.FileHandler(diag_path, encoding="utf-8")
        diag_handler.setLevel(logging.DEBUG)
        diag_handler.setFormatter(logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        ))
        diag_logger.addHandler(diag_handler)
    except Exception:
        pass


_install_runtime_file_logging()
logger = logging.getLogger(__name__)
diag_logger = logging.getLogger("sentinel.diag")

# Whitelist database
try:
    from backend.whitelist_db import get_whitelist_db, WhitelistDatabase
    WHITELIST_AVAILABLE = True
except ImportError:
    WHITELIST_AVAILABLE = False
    print("[WARNING] Whitelist database not available")

# Admin Privilege Monitor
try:
    from backend.admin_priv_monitor import AdminPrivilegeMonitor, PrivilegeEvent, EventSeverity as PrivSeverity
    ADMIN_PRIV_MONITOR_AVAILABLE = True
except ImportError:
    ADMIN_PRIV_MONITOR_AVAILABLE = False
    print("[WARNING] Admin Privilege Monitor not available")

# Hardware Gatekeeper (Windows-only, needs winrt)
try:
    import winsdk.windows.devices.radios as radios
    from winsdk.windows.devices.radios import Radio, RadioKind, RadioState
    WINSKD_AVAILABLE = True
except ImportError:
    WINSKD_AVAILABLE = False

if WINSKD_AVAILABLE:
    HARDWARE_GATEKEEPER_AVAILABLE = True
else:
    HARDWARE_GATEKEEPER_AVAILABLE = False
    print("[WARNING] Hardware Gatekeeper not available (Windows + winrt required)")

# ── GUI2 additional feature imports ──────────────────────────────────────────
try:
    from backend.network_forensics import NetworkForensics
    NETWORK_FORENSICS_AVAILABLE = True
except ImportError:
    NETWORK_FORENSICS_AVAILABLE = False
    print("[WARNING] Network Forensics not available")

import webbrowser

# Optional imports
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("[WARNING] psutil not available - process monitor disabled")

try:
    import matplotlib
    matplotlib.use('Agg')
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    import matplotlib.pyplot as plt
    from collections import deque
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    print("[WARNING] matplotlib not available - graphs disabled")

# Configure appearance
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Colors
COLORS = {
    'bg_primary': '#0a0e27',
    'bg_secondary': '#111633',
    'bg_card': '#1a1f3a',
    'accent_blue': '#3b82f6',
    'accent_purple': '#8b5cf6',
    'accent_red': '#ef4444',
    'accent_green': '#10b981',
    'accent_orange': '#f59e0b',
    'text_primary': '#ffffff',
    'text_secondary': '#9ca3af',
    'log_threat': '#ff4444',
    'log_info': '#4488ff',
    'log_system': '#44ff88',
    'log_clean': '#88ff44'
}


# ==================== INTEGRATED HARDWARE GATEKEEPER ====================

# PowerShell WinRT bridge script — works WITHOUT admin privileges
# Uses Windows.Devices.Radios API (same as Windows Settings app)
_PS_RADIO_SCRIPT = r"""
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Devices.Radios.Radio,Windows.System.Devices,ContentType=WindowsRuntime]
$null = [Windows.Devices.Radios.RadioAccessStatus,Windows.System.Devices,ContentType=WindowsRuntime]
$null = [Windows.Devices.Radios.RadioState,Windows.System.Devices,ContentType=WindowsRuntime]

# Helper to await WinRT IAsyncOperation
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() |
    Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
                   $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]

function Await($WinRtTask, $ResultType) {
    $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    $netTask.Result
}

function AwaitAction($WinRtTask) {
    $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() |
        Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
                       $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' })[0]
    $netTask = $asTask.Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
}

$radios = Await ([Windows.Devices.Radios.Radio]::GetRadiosAsync()) `
    ([System.Collections.Generic.IReadOnlyList[Windows.Devices.Radios.Radio]])

$ACTION = $env:RADIO_ACTION   # "GET_STATE" | "SET_OFF" | "SET_ON"
$TARGET = $env:RADIO_TARGET   # "WiFi" | "Bluetooth" | "All"

foreach ($radio in $radios) {
    $kind = $radio.Kind.ToString()
    $state = $radio.State.ToString()

    if ($ACTION -eq "GET_STATE") {
        Write-Output "$kind|$state"
        continue
    }

    $match = ($TARGET -eq "All") -or
             ($TARGET -eq "WiFi"      -and $kind -eq "WiFi") -or
             ($TARGET -eq "Bluetooth" -and $kind -eq "Bluetooth")

    if ($match) {
        if ($ACTION -eq "SET_OFF" -and $state -ne "Off") {
            AwaitAction ($radio.SetStateAsync([Windows.Devices.Radios.RadioState]::Off))
            Write-Output "SET_OFF|$kind|OK"
        } elseif ($ACTION -eq "SET_ON" -and $state -eq "Off") {
            AwaitAction ($radio.SetStateAsync([Windows.Devices.Radios.RadioState]::On))
            Write-Output "SET_ON|$kind|OK"
        } else {
            Write-Output "NOOP|$kind|$state"
        }
    }
}
"""

import tempfile, os as _os

_PS_SCRIPT_PATH = None

def _get_ps_script() -> str:
    """Write the PowerShell script to a temp file once, reuse it."""
    global _PS_SCRIPT_PATH
    if _PS_SCRIPT_PATH and _os.path.exists(_PS_SCRIPT_PATH):
        return _PS_SCRIPT_PATH
    fd, path = tempfile.mkstemp(suffix=".ps1", prefix="sentinel_radio_")
    with _os.fdopen(fd, 'w') as f:
        f.write(_PS_RADIO_SCRIPT)
    _PS_SCRIPT_PATH = path
    return path

 
class HardwareGatekeeper:
    """
    Hardware gatekeeper using the Windows.Devices.Radios WinRT API via PowerShell.
    Works WITHOUT administrator privileges — same API used by Windows Settings.
    Controls both Wi-Fi and Bluetooth.
    """

    POLL_INTERVAL = 2   # seconds between enforcement checks

    def __init__(self, alert_callback=None):
        self.monitor_switch = None
        self.net_monitor_switch = None
        self.alert_callback     = alert_callback
        self._lock              = threading.Lock()
        self._auth              = False
        self._auth_ts           = 0.0
        self._running           = True
        self._thread            = None
        self._password_hash     = None
        self._last_wifi_blocked = False
        self._last_bt_blocked   = False

    # ── Password API ──────────────────────────────────────────────────────────

    def set_password(self, password: str):
        self._password_hash = hashlib.sha256(password.encode()).hexdigest()

    def verify_password(self, password: str) -> bool:
        if not self._password_hash:
            return False
        return self._password_hash == hashlib.sha256(password.encode()).hexdigest()

    def has_password(self) -> bool:
        return self._password_hash is not None

    def is_password_set(self) -> bool:
        return self._password_hash is not None

    def clear_password(self):
        self._password_hash = None
        self.revoke()

    def authenticate(self, password: str = "") -> bool:
        """Pass empty string when vault already verified externally."""
        with self._lock:
            if password == "" or self.verify_password(password):
                self._auth    = True
                self._auth_ts = time.time()
                return True
            return False

    def revoke(self):
        with self._lock:
            self._auth    = False
            self._auth_ts = 0.0

    def is_authenticated(self) -> bool:
        with self._lock:
            return self._auth

    def session_remaining(self) -> int:
        with self._lock:
            if not self._auth:
                return 0
        # Permanent authenticated sessions unless manually revoked or open Wi-Fi connection.
        return -1

    def _is_connected_to_open_wifi(self) -> bool:
        """Return True when connected Wi-Fi is an open (no-password) network."""
        try:
            r = subprocess.run(
                ["netsh", "wlan", "show", "interfaces"],
                capture_output=True, text=True, timeout=5,
                creationflags=0x08000000
            )
            auth_mode = None
            for line in r.stdout.splitlines():
                if "Authentication" in line and "BSSID" not in line:
                    parts = line.split(":", 1)
                    if len(parts) == 2:
                        auth_mode = parts[1].strip().lower()
                        break
            return auth_mode in ("open", "none", "open")
        except Exception:
            return False

    # ── PowerShell radio helper ───────────────────────────────────────────────

    @staticmethod
    def _run_ps(action: str, target: str, timeout: int = 15) -> str:
        """
        Run the WinRT radio script with given action + target.
        Returns stdout string (empty on error).
        action : "GET_STATE" | "SET_OFF" | "SET_ON"
        target : "WiFi"     | "Bluetooth" | "All"
        """
        script = _get_ps_script()
        env = _os.environ.copy()
        env["RADIO_ACTION"] = action
        env["RADIO_TARGET"] = target
        try:
            CREATE_NO_WINDOW = 0x08000000
            r = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive",
                 "-ExecutionPolicy", "Bypass", "-File", script],
                capture_output=True, text=True, timeout=timeout,
                env=env, creationflags=CREATE_NO_WINDOW,
            )
            return r.stdout.strip()
        except Exception as e:
            print(f"[HWGate] PS error ({action}/{target}): {e}")
            return ""

    # ── State reading ─────────────────────────────────────────────────────────

    def _get_states(self) -> dict:
        """Return {'WiFi': 'On'/'Off'/'Missing', 'Bluetooth': ...}"""
        out = self._run_ps("GET_STATE", "All")
        states = {"WiFi": "Missing", "Bluetooth": "Missing"}
        for line in out.splitlines():
            parts = line.strip().split("|")
            if len(parts) == 2:
                kind, state = parts
                if "WiFi" in kind or "Wi" in kind:
                    states["WiFi"] = state
                elif "Bluetooth" in kind:
                    states["Bluetooth"] = state
        return states

    def get_stats(self) -> dict:
        """
        Returns current HW stats. Caches result in _cached_stats so the UI
        can read it without triggering a new PowerShell call every tick.
        """
        try:
            states = self._get_states()
            wifi_s = states.get("WiFi", "Missing")
            bt_s   = states.get("Bluetooth", "Missing")
            def _norm(s):
                s = s.lower()
                if s == "on":  return "ON"
                if s == "off": return "OFF"
                return "MISSING"
            result = {
                "bt_state":          _norm(bt_s),
                "wifi_state":        _norm(wifi_s),
                "authenticated":     self.is_authenticated(),
                "session_remaining": self.session_remaining(),
            }
        except Exception:
            result = {"bt_state": "MISSING", "wifi_state": "MISSING",
                      "authenticated": self.is_authenticated(), "session_remaining": 0}
        # Cache result so UI can read without re-calling PS
        self._cached_stats = result
        return result

    def get_cached_stats(self) -> dict:
        """Return last known stats without calling PowerShell (instant, safe for main thread)."""
        return getattr(self, '_cached_stats',
                       {"bt_state": "N/A", "wifi_state": "N/A",
                        "authenticated": self.is_authenticated(), "session_remaining": 0})

    # ── Hardware control ──────────────────────────────────────────────────────

    def _set_radio(self, target: str, on: bool):
        action = "SET_ON" if on else "SET_OFF"
        out = self._run_ps(action, target)
        print(f"[HWGate] {action} {target}: {out or '(no output)'}")

    # ── Enforcer ──────────────────────────────────────────────────────────────

    def start(self) -> bool:
        """Disable both radios immediately, then start the watchdog thread."""
        print("[HWGate] Startup lockdown — disabling Wi-Fi & Bluetooth...")
        # Run lockdown in a thread so GUI doesn't freeze during PS startup
        threading.Thread(target=self._startup_lockdown, daemon=True).start()
        self._thread = threading.Thread(
            target=self._monitor_loop, daemon=True, name="HWGatekeeper"
        )
        self._thread.start()
        return True

    def _startup_lockdown(self):
        self._set_radio("WiFi",      on=False)
        self._set_radio("Bluetooth", on=False)
        print("[HWGate] Startup lockdown complete")

    def _monitor_loop(self):
        time.sleep(5)   # let startup lockdown finish first
        while self._running:
            try:
                with self._lock:
                    is_auth = self._auth
                # Auto-lock if user is on an open (no-password) Wi-Fi network
                if is_auth and self._is_connected_to_open_wifi():
                    print("[HWGate] Open Wi-Fi detected — locking hardware")
                    self.revoke()
                    if self.alert_callback:
                        self.alert_callback("unauthorized_activation",
                                            "Open Wi-Fi network detected — lock enforced")
                    self._set_radio("WiFi", on=False)
                    self._set_radio("Bluetooth", on=False)
                    self._last_wifi_blocked = True
                    self._last_bt_blocked = True
                    time.sleep(self.POLL_INTERVAL)
                    continue

                if not is_auth:
                    states = self._get_states()

                    wifi_on = states.get("WiFi", "Off").lower() == "on"
                    bt_on   = states.get("Bluetooth", "Off").lower() == "on"

                    if wifi_on:
                        if not self._last_wifi_blocked:
                            print("[HWGate] Unauthorised Wi-Fi ON — blocking")
                            if self.alert_callback:
                                self.alert_callback("unauthorized_activation", "Wi-Fi blocked")
                            self._last_wifi_blocked = True
                        self._set_radio("WiFi", on=False)
                    else:
                        self._last_wifi_blocked = False

                    if bt_on:
                        if not self._last_bt_blocked:
                            print("[HWGate] Unauthorised Bluetooth ON — blocking")
                            if self.alert_callback:
                                self.alert_callback("unauthorized_activation", "Bluetooth blocked")
                            self._last_bt_blocked = True
                        self._set_radio("Bluetooth", on=False)
                    else:
                        self._last_bt_blocked = False

            except Exception as e:
                print(f"[HWGate] Monitor error: {e}")

            time.sleep(self.POLL_INTERVAL)

    def stop(self):
        self._running = False
# ==================== PERFORMANCE GRAPHS ====================

class PerformanceGraphs:
    """Real-time performance graphs with matplotlib."""
    def __init__(self, parent_frame):
        if not MATPLOTLIB_AVAILABLE:
            ctk.CTkLabel(
                parent_frame,
                text="[WARNING]️ Matplotlib not available\nInstall: pip install matplotlib",
                font=ctk.CTkFont(size=14)
            ).pack(pady=50)
            self.canvas = None
            return
        
        plt.style.use('dark_background')
        self.fig, (self.ax1, self.ax2) = plt.subplots(2, 1, figsize=(8, 6))
        self.fig.patch.set_facecolor(COLORS['bg_card'])
        
        self.scan_speed_data = deque(maxlen=60)
        self.threat_count_data = deque(maxlen=60)
        self.time_labels = deque(maxlen=60)
        
        for _ in range(60):
            self.scan_speed_data.append(0)
            self.threat_count_data.append(0)
            self.time_labels.append('')
        
        self.canvas = FigureCanvasTkAgg(self.fig, parent_frame)
        self.canvas.get_tk_widget().pack(fill='both', expand=True, padx=10, pady=10)
        
        self._draw_graphs()
    
    def update(self, files_per_sec: float, threat_count: int):
        """Update graphs on the Tk thread; snapshots avoid data races."""
        if not MATPLOTLIB_AVAILABLE or self.canvas is None:
            return

        try:
            current_time = datetime.now().strftime('%H:%M:%S')
            self.scan_speed_data.append(files_per_sec)
            self.threat_count_data.append(threat_count)
            self.time_labels.append(current_time)
        except Exception as e:
            print(f"Graph data error: {e}")
            return

        # Skip if a render is already in progress — avoids pileup
        if getattr(self, '_render_busy', False):
            return
        self._render_busy = True

        # Snapshot data so the render path uses stable inputs
        speed_snapshot  = list(self.scan_speed_data)
        threat_snapshot = list(self.threat_count_data)
        self.canvas.get_tk_widget().after(
            0, lambda: self._render_graphs(speed_snapshot, threat_snapshot)
        )

    def _render_graphs(self, speed_snapshot, threat_snapshot):
        """Render figure and draw canvas on the Tk thread."""
        try:
            self.ax1.clear()
            self.ax2.clear()

            self.ax1.plot(speed_snapshot, color=COLORS['accent_blue'],
                          linewidth=2, marker='o', markersize=3)
            self.ax1.set_title('Scan Speed (Files/Second)', color='white', fontsize=12)
            self.ax1.set_facecolor(COLORS['bg_primary'])
            self.ax1.tick_params(colors='white', labelsize=8)
            self.ax1.grid(True, alpha=0.2, color='white')
            self.ax1.set_ylim(bottom=0)

            self.ax2.plot(threat_snapshot, color=COLORS['accent_red'],
                          linewidth=2, marker='o', markersize=3)
            self.ax2.set_title('Cumulative Threats Found', color='white', fontsize=12)
            self.ax2.set_facecolor(COLORS['bg_primary'])
            self.ax2.tick_params(colors='white', labelsize=8)
            self.ax2.grid(True, alpha=0.2, color='white')
            self.ax2.set_ylim(bottom=0)

            self.fig.tight_layout()
            if self.canvas:
                self.canvas.draw_idle()
        except Exception as e:
            print(f"Graph render error: {e}")
        finally:
            self._render_busy = False

    def _draw_graphs(self):
        """Legacy stub — kept so nothing breaks if called directly."""
        pass


# ==================== RESOURCE MONITOR ====================

class ResourceMonitor:
    """Track scanner process CPU/RAM usage."""
    def __init__(self):
        if PSUTIL_AVAILABLE:
            self.process = psutil.Process()
            self.enabled = True
        else:
            self.enabled = False
    
    def get_current_usage(self) -> dict:
        """Get current CPU and RAM usage."""
        if not self.enabled:
            return {'cpu': 0.0, 'ram': 0.0}
        
        try:
            cpu_percent = self.process.cpu_percent(interval=0)
            ram_mb = self.process.memory_info().rss / 1024 / 1024
            return {'cpu': cpu_percent, 'ram': ram_mb}
        except Exception:
            return {'cpu': 0.0, 'ram': 0.0}


# ==================== MAIN GUI CLASS ====================

class SentinelDefenderGUI(ctk.CTk):
    monitor_switch: Optional[ctk.CTkSwitch]
    net_monitor_switch: Optional[ctk.CTkSwitch]
    """
    Optimized Hollywood Dashboard with tabular logs.
    
    STABILITY PATCH ACTIVE:
    - Poll interval: 100ms → 200ms (50% reduction)
    - Graph updates: 1s → 2s (50% reduction)
    - Stats updates: 500ms → 1s (50% reduction)
    - Batch size: 50 → 30 (40% reduction)
    """
    
    # UI FREEZE FIX: Aggressive polling reduction to keep UI smooth
    POLL_INTERVAL = 1000     # ms - Poll buffer every 1 second (was 500ms)
    BATCH_SIZE = 10          # Process max 10 logs per poll (was 20) — fewer insertions per tick
    GRAPH_UPDATE_INTERVAL = 8000  # ms - Update graphs every 8 seconds (was 5000)
    STATS_UPDATE_TICKS = 3   # Update stat cards every 3rd tick (~3 seconds)
    
    def __init__(self):
        super().__init__()
        # ===== SAFE DEFAULTS =====
        self.monitor_switch = None
        self.net_monitor_switch = None
        self.net_table = None

        self._iface_map = {}
        self._net_iid_map = {}
        self._log_cursor = 0

        self._bg_hw_tick = 0
        self._hg_alert_queue = []
                
        self.GRAPH_UPDATE_INTERVAL = 8000  # ms — 8 second graph refresh to avoid UI lag
        
        # Window configuration
        self.title("Sentinel Defender v5.0 - Deep Protection")

        # ── Fit window to screen, leaving room for the OS taskbar ──────────
        self.update_idletasks()
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        TASKBAR_RESERVE = 56
        # Fill 95% of screen so it looks great on every laptop size
        win_w = min(int(screen_w * 0.95), screen_w)
        win_h = min(int((screen_h - TASKBAR_RESERVE) * 0.95), screen_h - TASKBAR_RESERVE)
        pos_x = max(0, (screen_w - win_w) // 2)
        pos_y = max(0, (screen_h - TASKBAR_RESERVE - win_h) // 2)
        self.geometry(f"{win_w}x{win_h}+{pos_x}+{pos_y}")
        # Minimum size scales with screen — works on 13" and 17" alike
        self.minsize(max(900, min(1100, screen_w)), max(600, min(700, screen_h - TASKBAR_RESERVE)))
        self.maxsize(screen_w, screen_h - TASKBAR_RESERVE)
        self.configure(fg_color=COLORS['bg_primary'])
        
        # Initialize backend
        self.hub = SentinelHub(
            progress_callback=None,
            threat_callback=None,
            alert_callback=None
        )
        self.db = DatabaseManager()
        
        # AI Agents
        self.investigative_agent = InvestigativeAgent()
        self.planning_agent      = PlanningAgent()
        self.action_agent        = ActionAgent(hub=self.hub)
        self._current_inv_report = None
        self._current_plan       = None

        # Network Monitor
        self.network_monitor = NetworkMonitor(alert_callback=self._on_network_alert)
        self._net_alert_queue: list = []        # thread-safe via GIL for simple list ops
        self._net_alert_lock  = threading.Lock()

        # Wire the GUI's NetworkMonitor into the hub's reporter so the PDF
        # report reads real captured alerts instead of the hub's unstarted monitor
        try:
            self.hub.reporter.nm = self.network_monitor
        except Exception:
            pass

        # Network threat counters (for stat cards)
        self._net_threats_count   = 0   # total alerts detected
        self._net_mitigated_count = 0   # CRITICAL/HIGH alerts automatically blocked

        # Network Forensics (GUI2 feature)
        if NETWORK_FORENSICS_AVAILABLE:
            try:
                self.network_forensics = NetworkForensics()
            except Exception as e:
                print(f"[WARNING] Network Forensics init failed: {e}")
                self.network_forensics = None
        else:
            self.network_forensics = None

        # Admin Privilege Monitor — created now, started after first paint
        self.admin_priv_monitor = None
        if ADMIN_PRIV_MONITOR_AVAILABLE:
            try:
                self.admin_priv_monitor = AdminPrivilegeMonitor(
                    event_callback=self._on_priv_event
                )
                print("[OK] Admin Privilege Monitor created — will start after UI init")
            except Exception as e:
                print(f"[WARNING] Admin Privilege Monitor failed to start: {e}")

        # Hardware Gatekeeper — starts on Windows via netsh/PowerShell (no winsdk needed)
        self.hardware_gatekeeper = None
        # Shared vault paths used by both the Admin tab and Hardware Gatekeeper tab
        import pathlib as _pathlib
        self._vault_dir      = _pathlib.Path("data") / "admin"
        self._adm_vault_path = self._vault_dir / "vault.dat"
        self._hw_vault_path  = self._vault_dir / "hw_vault.dat"

        if sys.platform == "win32":
            try:
                self._hg_alert_queue: list = []
                self._hg_lock = threading.Lock()
                self.hardware_gatekeeper = HardwareGatekeeper(
                    alert_callback=self._on_hardware_event
                )
                # Startup is deferred — after UI loads we show the password popup
                # (Fix 3: first-time setup asks admin to set password before locking)
                print("[OK] Hardware Gatekeeper created — will start after UI init")
            except Exception as e:
                print(f"[WARNING] Hardware Gatekeeper failed to init: {e}")
        
        # Resource monitor
        self.resource_monitor = ResourceMonitor()
        
        # State
        self.monitoring_active = False
        self.selected_path: Path | None = None
        self.usb_monitor_active = False
        self.fim_monitor_active = False
        self.known_drives = set()
        self.file_baselines = {}

        # AI pipeline run state
        self._last_pipeline_session_id = None
        self._pipeline_ran_for_session = False
        
        # Quarantine selection
        self.selected_quarantine_ids = set()
        self.quarantine_checkboxes = {}
        
        # Animation state
        self.pulse_brightness = 0.0
        self.pulse_direction = 1
        self.is_scanning = False
        
        # Build UI
        self.create_ui()
        
        # Set default path
        self.set_default_scan_path()
        
        # Typewriter effect
        self.after(500, self.show_startup_animation)
        
        # Start unified heartbeat — background worker fetches data, main thread only applies it
        self._poll_running = True
        self._start_background_worker()   # single daemon thread does all I/O
        self.after(1200, self.poll_log_buffer)  # main thread: configure() only, zero blocking
        
        # Start status pulse
        self.animate_status_pulse()
        
        # Start monitoring
        if PSUTIL_AVAILABLE:
            self.start_usb_monitoring()
            self.start_fim_monitoring()
        
        # Auto-Enable Real-Time Protector after first paint so startup feels immediate
        if self.monitor_switch:
            self.monitor_switch.select()
        self.after(250, self._deferred_startup_services)

        # Auto-start network monitor in background (requirement 2)
        self.after(1500, self._auto_start_network_monitor)

        # Fix 3: After UI is up, start HW gatekeeper with password prompt flow
        self.after(800, self._hw_gatekeeper_startup_flow)

        # Fix 2: Wire admin tab password gate (first-time or recurring)
        # This patches the tab-click event so opening Admin tab always prompts
        self.after(1200, self._install_admin_tab_guard)

        # Handle close
        self.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        print("[OK] Sentinel Defender v5.0 initialized (Deep Protection Active)")
        print(f"  Poll Interval: {self.POLL_INTERVAL}ms")
        print(f"  Graph Updates: {self.GRAPH_UPDATE_INTERVAL}ms")
        print(f"  Batch Size: {self.BATCH_SIZE}")

    def _deferred_startup_services(self):
        """Start heavyweight background services only after the UI is already visible."""
        try:
            if self.admin_priv_monitor:
                self.admin_priv_monitor.start()
                print("[OK] Admin Privilege Monitor started")
        except Exception as e:
            print(f"[WARNING] Admin Privilege Monitor failed to start: {e}")

        try:
            self.toggle_monitoring()
        except Exception as e:
            print(f"[WARNING] Deferred real-time protection start failed: {e}")
    
    # ==================== TYPEWRITER EFFECT ====================
    
    # ==================== FIX 2: ADMIN TAB PASSWORD GATE ====================

    def _vault_hash(self, pw: str, magic: str = "SENTINEL_V2") -> str:
        """Consistent password hashing used across all vault files."""
        import hashlib
        raw = f"{magic}:{pw}:{magic[::-1]}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def _vault_is_set(self, vault_path) -> bool:
        """Return True if vault file exists and has content."""
        try:
            return vault_path.exists() and vault_path.stat().st_size > 10
        except Exception:
            return False

    def _vault_verify(self, vault_path, candidate: str) -> bool:
        """Verify candidate password against vault file."""
        try:
            if not self._vault_is_set(vault_path):
                return False
            return vault_path.read_text().strip() == self._vault_hash(candidate)
        except Exception:
            return False

    def _vault_set(self, vault_path, pw: str):
        """Write hashed password to vault file."""
        vault_path.parent.mkdir(parents=True, exist_ok=True)
        vault_path.write_text(self._vault_hash(pw))

    def _install_admin_tab_guard(self):
        """
        Intercept tab-change events for 'Admin Privilege Monitor':
          • First ever run (no vault)  → show one-time password setup.
          • Subsequent runs            → ask ONCE per app session, then stay
                                         unlocked until the app is closed.
          • Tab re-clicked after unlock → open freely, no repeated prompt.
        """
        ADMIN_TAB = "🔐 Admin Privilege Monitor"
        # Only initialise to False if not already set (avoids re-locking on
        # _install_admin_tab_guard being called a second time).
        if not hasattr(self, "_admin_tab_unlocked"):
            self._admin_tab_unlocked = False

        def _on_tab_change():
            try:
                current = self.tabview.get()
            except Exception:
                return
            if current != ADMIN_TAB:
                return
            # Already unlocked this session — let the tab open freely.
            if self._admin_tab_unlocked:
                return
            # Block the tab immediately by switching away
            try:
                self.tabview.set("🔍 Live Logs")
            except Exception:
                pass
            # First-ever run: no vault yet → one-time password setup.
            # All subsequent runs: single challenge per session.
            if not self._vault_is_set(self._adm_vault_path):
                self._admin_first_time_setup()
            else:
                self._admin_password_challenge()

        # Bind to the underlying tab button widget via trace on the CTkTabview
        try:
            self.tabview.configure(command=lambda: self.after(10, _on_tab_change))
        except Exception:
            # Fallback: bind to every tab button's click event
            try:
                for btn in self.tabview._segmented_button._buttons_dict.values():
                    btn.configure(command=lambda: self.after(10, _on_tab_change))
            except Exception:
                pass

    def _admin_first_time_setup(self):
        """
        Fix 2: First-time admin password setup popup.
        Shown when no password has been stored yet.
        """
        pop = ctk.CTkToplevel(self)
        pop.title("🔐 Set Admin Password — First Time Setup")
        pop.resizable(False, False)
        pop.attributes("-topmost", True)
        pop.grab_set()
        pop.focus_force()
        W, H = 480, 400
        self.update_idletasks()
        px = self.winfo_x() + (self.winfo_width()  - W) // 2
        py = self.winfo_y() + (self.winfo_height() - H) // 2
        pop.geometry(f"{W}x{H}+{max(0,px)}+{max(0,py)}")

        ctk.CTkFrame(pop, fg_color=COLORS["accent_blue"], height=5, corner_radius=0).pack(fill="x")
        bd = ctk.CTkFrame(pop, fg_color=COLORS["bg_card"], corner_radius=0)
        bd.pack(fill="both", expand=True)

        ctk.CTkLabel(bd, text="🔐  Admin Privilege Monitor",
                     font=ctk.CTkFont(size=16, weight="bold"),
                     text_color=COLORS["accent_blue"]).pack(pady=(20, 4))
        ctk.CTkLabel(bd,
                     text="First time setup — please create an admin password.\n"
                          "This password will be required to access this tab\n"
                          "and to approve privilege escalation events.",
                     font=ctk.CTkFont(size=12),
                     text_color=COLORS["text_secondary"], justify="center").pack(pady=(0, 16), padx=28)

        new_var  = ctk.StringVar()
        conf_var = ctk.StringVar()
        fb_lbl   = ctk.CTkLabel(bd, text="", font=ctk.CTkFont(size=11), text_color=COLORS["accent_red"])

        ctk.CTkLabel(bd, text="New Password:", anchor="w",
                     font=ctk.CTkFont(size=12), text_color=COLORS["text_secondary"]).pack(fill="x", padx=32)
        ne = ctk.CTkEntry(bd, textvariable=new_var, show="●", height=40, corner_radius=8,
                          border_color=COLORS["accent_blue"], font=ctk.CTkFont(size=13))
        ne.pack(fill="x", padx=32, pady=(2, 10))

        ctk.CTkLabel(bd, text="Confirm Password:", anchor="w",
                     font=ctk.CTkFont(size=12), text_color=COLORS["text_secondary"]).pack(fill="x", padx=32)
        ce = ctk.CTkEntry(bd, textvariable=conf_var, show="●", height=40, corner_radius=8,
                          border_color=COLORS["accent_blue"], font=ctk.CTkFont(size=13))
        ce.pack(fill="x", padx=32, pady=(2, 8))
        fb_lbl.pack()
        pop.after(150, lambda: ne.focus_set() if pop.winfo_exists() else None)

        def _save():
            pw = new_var.get()
            cf = conf_var.get()
            if not pw:
                fb_lbl.configure(text="❌ Password cannot be empty."); return
            if len(pw) < 6:
                fb_lbl.configure(text="❌ Minimum 6 characters."); return
            if pw != cf:
                fb_lbl.configure(text="❌ Passwords do not match."); return
            self._vault_set(self._adm_vault_path, pw)
            self._admin_tab_unlocked = True
            pop.grab_release(); pop.destroy()
            self.tabview.set("🔐 Admin Privilege Monitor")
            self._append_to_log("[ADMIN] Admin password set for the first time.", "system")

        ce.bind("<Return>", lambda e: _save())
        ne.bind("<Return>", lambda e: ce.focus_set())
        ctk.CTkButton(bd, text="✅  Set Password & Enter Tab", command=_save,
                      height=44, corner_radius=10, fg_color=COLORS["accent_blue"],
                      hover_color="#2563eb", font=ctk.CTkFont(size=13, weight="bold")
                      ).pack(fill="x", padx=32, pady=(10, 20))
        pop.protocol("WM_DELETE_WINDOW", lambda: (pop.grab_release(), pop.destroy()))

    def _admin_password_challenge(self):
        """
        Fix 2: Password challenge popup shown every time admin tab is accessed.
        """
        pop = ctk.CTkToplevel(self)
        pop.title("🔐 Admin Access — Enter Password")
        pop.resizable(False, False)
        pop.attributes("-topmost", True)
        pop.grab_set()
        pop.focus_force()
        W, H = 420, 310
        self.update_idletasks()
        px = self.winfo_x() + (self.winfo_width()  - W) // 2
        py = self.winfo_y() + (self.winfo_height() - H) // 2
        pop.geometry(f"{W}x{H}+{max(0,px)}+{max(0,py)}")

        ctk.CTkFrame(pop, fg_color=COLORS["accent_blue"], height=5, corner_radius=0).pack(fill="x")
        bd = ctk.CTkFrame(pop, fg_color=COLORS["bg_card"], corner_radius=0)
        bd.pack(fill="both", expand=True)

        ctk.CTkLabel(bd, text="🔐  Admin Privilege Monitor",
                     font=ctk.CTkFont(size=16, weight="bold"),
                     text_color=COLORS["accent_blue"]).pack(pady=(20, 4))
        ctk.CTkLabel(bd,
                     text="Enter the admin password to access this section.\n"
                          "This keeps your security settings protected.",
                     font=ctk.CTkFont(size=12),
                     text_color=COLORS["text_secondary"], justify="center").pack(pady=(0, 16), padx=28)

        pw_var = ctk.StringVar()
        fb_lbl = ctk.CTkLabel(bd, text="", font=ctk.CTkFont(size=11), text_color=COLORS["accent_red"])
        pe = ctk.CTkEntry(bd, textvariable=pw_var, show="●", height=42, corner_radius=10,
                          placeholder_text="Admin password…", border_color=COLORS["accent_blue"],
                          font=ctk.CTkFont(size=13))
        pe.pack(fill="x", padx=32, pady=(0, 6))
        fb_lbl.pack()
        pop.after(150, lambda: pe.focus_set() if pop.winfo_exists() else None)

        def _ok(*_):
            if self._vault_verify(self._adm_vault_path, pw_var.get()):
                self._admin_tab_unlocked = True
                pop.grab_release(); pop.destroy()
                self.tabview.set("🔐 Admin Privilege Monitor")
            else:
                fb_lbl.configure(text="❌ Incorrect password.")
                pw_var.set("")
                pe.focus_set()

        pe.bind("<Return>", _ok)
        br = ctk.CTkFrame(bd, fg_color="transparent")
        br.pack(fill="x", padx=32, pady=(12, 20))
        br.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkButton(br, text="✅  Enter", command=_ok, height=42, corner_radius=10,
                      fg_color=COLORS["accent_blue"], hover_color="#2563eb",
                      font=ctk.CTkFont(size=13, weight="bold")).grid(row=0, column=0, padx=(0,4), sticky="ew")
        ctk.CTkButton(br, text="Cancel", command=lambda: (pop.grab_release(), pop.destroy()),
                      height=42, corner_radius=10, fg_color=COLORS["bg_secondary"],
                      font=ctk.CTkFont(size=12)).grid(row=0, column=1, padx=(4,0), sticky="ew")
        pop.protocol("WM_DELETE_WINDOW", lambda: (pop.grab_release(), pop.destroy()))

    # ==================== FIX 3: HW GATEKEEPER STARTUP FLOW ====================

    def _hw_gatekeeper_startup_flow(self):
        """
        Fix 3: Called after UI is ready. If no HW password is set yet, show
        the first-time setup popup BEFORE locking WiFi/BT. Otherwise show a
        brief notice that hardware is being locked and ask for password to unlock.
        """
        if self.hardware_gatekeeper is None:
            return
        if not self._vault_is_set(self._hw_vault_path):
            self._hw_first_time_password_setup()
        else:
            # Password already set — just start gatekeeper silently
            self._start_hw_gatekeeper_locked()

    def _hw_first_time_password_setup(self):
        """
        Fix 3: First-time HW password setup. Admin must set a password before
        WiFi/BT are locked. Explains what is happening in plain language.
        """
        pop = ctk.CTkToplevel(self)
        pop.title("📡 Hardware Security — First Time Setup")
        pop.resizable(False, False)
        pop.attributes("-topmost", True)
        pop.grab_set()
        pop.focus_force()
        W, H = 500, 460
        self.update_idletasks()
        px = self.winfo_x() + (self.winfo_width()  - W) // 2
        py = self.winfo_y() + (self.winfo_height() - H) // 2
        pop.geometry(f"{W}x{H}+{max(0,px)}+{max(0,py)}")

        ctk.CTkFrame(pop, fg_color=COLORS["accent_purple"], height=5, corner_radius=0).pack(fill="x")
        bd = ctk.CTkFrame(pop, fg_color=COLORS["bg_card"], corner_radius=0)
        bd.pack(fill="both", expand=True)

        ctk.CTkLabel(bd, text="📡  Hardware Security Setup",
                     font=ctk.CTkFont(size=16, weight="bold"),
                     text_color=COLORS["accent_purple"]).pack(pady=(20, 4))
        ctk.CTkLabel(bd,
                     text="Sentinel will automatically turn OFF your WiFi and Bluetooth\n"
                          "to protect this computer from wireless attacks.\n\n"
                          "To use WiFi or Bluetooth, users will need to enter a password\n"
                          "that you set right now. Please choose a secure password.\n\n"
                          "⚠  Keep this password safe — share it only with trusted users.",
                     font=ctk.CTkFont(size=12),
                     text_color=COLORS["text_secondary"], justify="center").pack(pady=(0, 14), padx=24)

        new_var  = ctk.StringVar()
        conf_var = ctk.StringVar()
        fb_lbl   = ctk.CTkLabel(bd, text="", font=ctk.CTkFont(size=11), text_color=COLORS["accent_red"])

        ctk.CTkLabel(bd, text="Create Hardware Password:", anchor="w",
                     font=ctk.CTkFont(size=12), text_color=COLORS["text_secondary"]).pack(fill="x", padx=32)
        ne = ctk.CTkEntry(bd, textvariable=new_var, show="●", height=40, corner_radius=8,
                          border_color=COLORS["accent_purple"], font=ctk.CTkFont(size=13))
        ne.pack(fill="x", padx=32, pady=(2, 8))

        ctk.CTkLabel(bd, text="Confirm Password:", anchor="w",
                     font=ctk.CTkFont(size=12), text_color=COLORS["text_secondary"]).pack(fill="x", padx=32)
        ce = ctk.CTkEntry(bd, textvariable=conf_var, show="●", height=40, corner_radius=8,
                          border_color=COLORS["accent_purple"], font=ctk.CTkFont(size=13))
        ce.pack(fill="x", padx=32, pady=(2, 6))
        fb_lbl.pack()
        pop.after(150, lambda: ne.focus_set() if pop.winfo_exists() else None)

        def _save():
            pw  = new_var.get()
            cf  = conf_var.get()
            if not pw:
                fb_lbl.configure(text="❌ Password cannot be empty."); return
            if len(pw) < 6:
                fb_lbl.configure(text="❌ Minimum 6 characters."); return
            if pw != cf:
                fb_lbl.configure(text="❌ Passwords do not match."); return
            self._vault_set(self._hw_vault_path, pw)
            if self.hardware_gatekeeper:
                self.hardware_gatekeeper.set_password(pw)
            pop.grab_release(); pop.destroy()
            self._start_hw_gatekeeper_locked()
            self._append_to_log("[HW] Hardware password set. WiFi & Bluetooth are now protected.", "system")

        ce.bind("<Return>", lambda e: _save())
        ne.bind("<Return>", lambda e: ce.focus_set())
        ctk.CTkButton(bd, text="🔒  Set Password & Activate Protection", command=_save,
                      height=44, corner_radius=10, fg_color=COLORS["accent_purple"],
                      hover_color="#7c3aed", font=ctk.CTkFont(size=13, weight="bold")
                      ).pack(fill="x", padx=32, pady=(10, 20))
        pop.protocol("WM_DELETE_WINDOW", lambda: (pop.grab_release(), pop.destroy(),
                                                   self._start_hw_gatekeeper_locked()))

    def _start_hw_gatekeeper_locked(self):
        """Start the HW gatekeeper (locks WiFi+BT) then immediately prompt for password."""
        hw = getattr(self, "hardware_gatekeeper", None)
        if hw is None:
            return
        try:
            hw.start()
            print("[OK] Hardware Gatekeeper started — WiFi & Bluetooth locked")
            self._append_to_log(
                "[HW] 🔒 WiFi and Bluetooth have been automatically turned OFF for your protection.",
                "system"
            )
            # Prompt the user right away so they can re-enable hardware if needed
            self.after(600, self._hw_startup_unlock_prompt)
        except Exception as e:
            print(f"[WARNING] HW Gatekeeper start failed: {e}")

    def _hw_startup_unlock_prompt(self):
        """
        Shown immediately after startup lockdown.
        Explains that WiFi & BT are now blocked, and lets the user enter the
        hardware password to re-enable them — without having to navigate to the tab.
        """
        pop = ctk.CTkToplevel(self)
        pop.title("📡 Hardware Gatekeeper — Startup")
        pop.resizable(False, False)
        pop.attributes("-topmost", True)
        pop.grab_set()
        pop.lift()
        pop.focus_force()

        W, H = 460, 380
        self.update_idletasks()
        px = self.winfo_x() + (self.winfo_width()  - W) // 2
        py = self.winfo_y() + (self.winfo_height() - H) // 2
        pop.geometry(f"{W}x{H}+{max(0,px)}+{max(0,py)}")

        PURPLE = COLORS.get("accent_purple", "#8b5cf6")
        GREEN  = "#22c55e"
        DARK   = COLORS["bg_card"]
        SUBTEXT = COLORS["text_secondary"]

        ctk.CTkFrame(pop, fg_color=PURPLE, height=5, corner_radius=0).pack(fill="x")
        bd = ctk.CTkFrame(pop, fg_color=DARK, corner_radius=0)
        bd.pack(fill="both", expand=True)

        ctk.CTkLabel(bd, text="🔒  WiFi & Bluetooth are now OFF",
                     font=ctk.CTkFont(size=15, weight="bold"),
                     text_color=PURPLE).pack(pady=(20, 4))

        ctk.CTkLabel(bd,
                     text="Sentinel has locked your WiFi and Bluetooth to protect\n"
                          "this computer from wireless threats.\n\n"
                          "If you need to use WiFi or Bluetooth right now,\n"
                          "enter your hardware password below to unlock them.",
                     font=ctk.CTkFont(size=12),
                     text_color=SUBTEXT, justify="center").pack(pady=(0, 12), padx=24)

        pw_var = ctk.StringVar()
        fb_lbl = ctk.CTkLabel(bd, text="", font=ctk.CTkFont(size=11),
                               text_color=COLORS.get("accent_red", "#ef4444"))

        ctk.CTkLabel(bd, text="Hardware Password:", anchor="w",
                     font=ctk.CTkFont(size=12),
                     text_color=SUBTEXT).pack(fill="x", padx=32)
        pw_entry = ctk.CTkEntry(bd, textvariable=pw_var, show="●", height=40,
                                corner_radius=8, border_color=PURPLE,
                                font=ctk.CTkFont(size=13))
        pw_entry.pack(fill="x", padx=32, pady=(4, 4))
        fb_lbl.pack()
        pop.after(150, lambda: pw_entry.focus_set() if pop.winfo_exists() else None)

        def _unlock():
            pw = pw_var.get()
            hw = getattr(self, "hardware_gatekeeper", None)
            if not pw:
                fb_lbl.configure(text="❌ Please enter your password."); return
            if hw and self._vault_verify(self._hw_vault_path, pw):
                hw.authenticate()
                pop.grab_release(); pop.destroy()
                self._append_to_log(
                    "[HW] ✅ Password accepted — WiFi & Bluetooth unlocked.", "clean")
            else:
                fb_lbl.configure(text="❌ Incorrect password. Try again.")
                pw_var.set("")

        def _keep_locked():
            pop.grab_release(); pop.destroy()
            self._append_to_log(
                "[HW] Hardware remains locked. Use the Hardware Gatekeeper tab to unlock.", "info")

        pw_entry.bind("<Return>", lambda e: _unlock())

        btn_fr = ctk.CTkFrame(bd, fg_color="transparent")
        btn_fr.pack(pady=(8, 20))
        ctk.CTkButton(btn_fr, text="🔓  Unlock Hardware", command=_unlock,
                      width=150, height=36, corner_radius=8,
                      fg_color=PURPLE, hover_color="#7c3aed",
                      font=ctk.CTkFont(size=12, weight="bold")).pack(side="left", padx=6)
        ctk.CTkButton(btn_fr, text="Keep Locked", command=_keep_locked,
                      width=110, height=36, corner_radius=8,
                      fg_color=COLORS["bg_secondary"],
                      hover_color=COLORS["bg_primary"],
                      font=ctk.CTkFont(size=12)).pack(side="left", padx=6)

        pop.protocol("WM_DELETE_WINDOW", _keep_locked)

    def _hw_free_network_blocked_popup(self, network_type: str, network_name: str):
        """
        Fix 3: Popup shown when device auto-connects to an open/passwordless
        WiFi or Bluetooth. Hardware is turned off; user must enter password.
        Uses simple language for non-tech users.
        """
        if getattr(self, "_hw_free_net_popup_open", False):
            return
        self._hw_free_net_popup_open = True

        if network_type == "wifi":
            icon, colour = "📶", COLORS["accent_red"]
            title = "⚠  Unsafe WiFi Detected!"
            msg   = (f"Your computer just connected to an open WiFi network:\n\n"
                     f"  📡  \"{network_name}\"\n\n"
                     "This network has NO password — anyone nearby can see what\n"
                     "you do online. Sentinel has turned off WiFi for your safety.\n\n"
                     "To reconnect, enter the hardware security password below.\n"
                     "We recommend using a secure (password-protected) WiFi network.")
        else:
            icon, colour = "🔷", COLORS["accent_purple"]
            title = "⚠  Unsecured Bluetooth Detected!"
            msg   = (f"A device without any security tried to pair:\n\n"
                     f"  🔷  \"{network_name}\"\n\n"
                     "Sentinel has blocked this connection because open Bluetooth\n"
                     "pairing can let strangers access your computer.\n\n"
                     "To allow it, enter the hardware security password below.")

        pop = ctk.CTkToplevel(self)
        pop.title(title)
        pop.resizable(False, False)
        pop.attributes("-topmost", True)
        pop.grab_set()
        pop.focus_force()
        W, H = 480, 380
        self.update_idletasks()
        px = self.winfo_x() + (self.winfo_width()  - W) // 2
        py = self.winfo_y() + (self.winfo_height() - H) // 2
        pop.geometry(f"{W}x{H}+{max(0,px)}+{max(0,py)}")

        ctk.CTkFrame(pop, fg_color=colour, height=5, corner_radius=0).pack(fill="x")
        bd = ctk.CTkFrame(pop, fg_color=COLORS["bg_card"], corner_radius=0)
        bd.pack(fill="both", expand=True)

        ctk.CTkLabel(bd, text=f"{icon}  {title}",
                     font=ctk.CTkFont(size=15, weight="bold"),
                     text_color=colour).pack(pady=(18, 4))
        ctk.CTkLabel(bd, text=msg, font=ctk.CTkFont(size=11),
                     text_color=COLORS["text_secondary"], justify="center",
                     wraplength=420).pack(pady=(0, 12), padx=24)

        pw_var = ctk.StringVar()
        fb_lbl = ctk.CTkLabel(bd, text="", font=ctk.CTkFont(size=11), text_color=COLORS["accent_red"])
        pe = ctk.CTkEntry(bd, textvariable=pw_var, show="●", height=42, corner_radius=10,
                          placeholder_text="Hardware security password…",
                          border_color=colour, font=ctk.CTkFont(size=13))
        pe.pack(fill="x", padx=32, pady=(0, 4))
        fb_lbl.pack()
        pop.after(150, lambda: pe.focus_set() if pop.winfo_exists() else None)

        def _close():
            self._hw_free_net_popup_open = False
            pop.grab_release(); pop.destroy()

        def _allow(*_):
            if not self._vault_is_set(self._hw_vault_path) or self._vault_verify(self._hw_vault_path, pw_var.get()):
                hw = getattr(self, "hardware_gatekeeper", None)
                if hw:
                    try: hw.authenticate()
                    except Exception: pass
                self._append_to_log(f"[HW] User unlocked hardware to access {network_name}", "system")
                _close()
            else:
                fb_lbl.configure(text="❌ Incorrect password — access denied.")
                pw_var.set(""); pe.focus_set()

        pe.bind("<Return>", _allow)
        br = ctk.CTkFrame(bd, fg_color="transparent")
        br.pack(fill="x", padx=32, pady=(8, 20))
        br.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkButton(br, text="✅  Allow Connection", command=_allow,
                      height=42, corner_radius=10, fg_color=COLORS["accent_green"],
                      hover_color="#0d9668", font=ctk.CTkFont(size=13, weight="bold")
                      ).grid(row=0, column=0, padx=(0, 4), sticky="ew")
        ctk.CTkButton(br, text="🚫  Keep Blocked", command=_close,
                      height=42, corner_radius=10, fg_color=COLORS["accent_red"],
                      hover_color="#dc2626", font=ctk.CTkFont(size=13, weight="bold")
                      ).grid(row=0, column=1, padx=(4, 0), sticky="ew")
        pop.protocol("WM_DELETE_WINDOW", _close)

    # ==================== FIX 4: PLAIN-ENGLISH SECURITY ALERT POPUPS ====================

    def _show_security_alert_popup(self, alert_type: str, title: str, plain_msg: str,
                                   severity: str = "HIGH", log_text: str = ""):
        """
        Fix 4: Show a plain-English popup for ANY security event so non-tech
        users understand what happened and what to do. Thread-safe — call via self.after().
        """
        colour_map = {
            "CRITICAL": COLORS["accent_red"],
            "HIGH":     "#f59e0b",
            "MEDIUM":   COLORS["accent_blue"],
            "LOW":      COLORS["accent_green"],
        }
        icon_map = {
            "malicious_file":      "🦠",
            "file_transfer":       "📤",
            "unauthorized_access": "🔓",
            "malicious_attempt":   "⚠️",
            "network_attack":      "🌐",
            "dns_attack":          "🔀",
            "hardware":            "📡",
        }
        colour = colour_map.get(severity, COLORS["accent_red"])
        icon   = icon_map.get(alert_type, "🚨")

        if log_text:
            self._append_to_log(f"[{severity}] {log_text}", "threat" if severity in ("CRITICAL","HIGH") else "info")
            if severity in ("CRITICAL", "HIGH"):
                self._flash_window()

        # Rate-limit popups:
        #   • Only one open at a time per type  (_sec_popup_<type> flag)
        #   • Even after closing, enforce a minimum quiet period so that
        #     a flood of backend alerts doesn't immediately reopen the popup.
        #     Network alerts: 5-minute quiet window. Others: 60 seconds.
        import time as _time_rl
        _now_rl = _time_rl.time()
        _cooldown = 300.0 if alert_type in ("network_attack", "dns_attack") else 120.0
        attr       = f"_sec_popup_{alert_type}"
        attr_ts    = f"_sec_popup_ts_{alert_type}"
        _last_shown = getattr(self, attr_ts, 0.0)
        if getattr(self, attr, False):          # popup currently open
            return
        if _now_rl - _last_shown < _cooldown:   # still in quiet window
            return
        setattr(self, attr, True)
        setattr(self, attr_ts, _now_rl)
        logger.warning("Security alert popup opened: type=%s severity=%s title=%s", alert_type, severity, title)

        pop = ctk.CTkToplevel(self)
        pop.title(f"{icon} Security Alert")
        pop.resizable(False, False)
        pop.attributes("-topmost", True)
        try: pop.attributes("-toolwindow", True)
        except Exception: pass
        try:
            pop.transient(self)
        except Exception:
            pass
        pop.lift()
        pop.focus_force()
        msg_lines = max(8, len(plain_msg.splitlines()) + 2)
        W = 560
        max_h = max(360, self.winfo_screenheight() - 140)
        H = min(max_h, 220 + msg_lines * 18)
        self.update_idletasks()
        px = self.winfo_x() + (self.winfo_width()  - W) // 2
        py = self.winfo_y() + (self.winfo_height() - H) // 2
        pop.geometry(f"{W}x{H}+{max(0,px)}+{max(0,py)}")

        ctk.CTkFrame(pop, fg_color=colour, height=6, corner_radius=0).pack(fill="x")
        bd = ctk.CTkFrame(pop, fg_color=COLORS["bg_card"], corner_radius=0)
        bd.pack(fill="both", expand=True)

        ctk.CTkLabel(bd, text=f"{icon}  {title}",
                     font=ctk.CTkFont(size=15, weight="bold"),
                     text_color=colour).pack(pady=(18, 8))

        body_scroll = ctk.CTkScrollableFrame(
            bd, fg_color=COLORS["bg_secondary"], corner_radius=10
        )
        body_scroll.pack(fill="both", expand=True, padx=20, pady=(0, 14))
        ctk.CTkLabel(
            body_scroll, text=plain_msg,
            font=ctk.CTkFont(size=12), text_color=COLORS["text_secondary"],
            justify="left", wraplength=470, anchor="w"
        ).pack(fill="x", padx=12, pady=12)

        def _close():
            setattr(self, attr, False)
            logger.info("Security alert popup closed: type=%s title=%s", alert_type, title)
            try: pop.destroy()
            except Exception: pass

        btn_bar = ctk.CTkFrame(bd, fg_color="transparent")
        btn_bar.pack(fill="x", padx=28, pady=(0, 18))
        ctk.CTkButton(
            btn_bar, text="Open Live Logs", command=lambda: (self.tabview.set("🔍 Live Logs"), _close()),
            height=42, corner_radius=10, fg_color=COLORS["bg_secondary"],
            font=ctk.CTkFont(size=12, weight="bold")
        ).pack(side="left", fill="x", expand=True, padx=(0, 6))
        ctk.CTkButton(
            btn_bar, text="Dismiss", command=_close, height=42, corner_radius=10,
            fg_color=colour, font=ctk.CTkFont(size=13, weight="bold")
        ).pack(side="left", fill="x", expand=True, padx=(6, 0))
        pop.protocol("WM_DELETE_WINDOW", _close)

    def _on_malicious_file_found(self, file_path: str, threat_name: str):
        """Fix 4: Plain-English popup when a malicious file is found."""
        msg = (f"Sentinel found a harmful file on your computer:\n\n"
               f"  🗂  {file_path}\n"
               f"  ☠  Threat: {threat_name}\n\n"
               "This file could damage your computer or steal your data.\n"
               "It has been moved to Quarantine so it cannot cause harm.\n\n"
               "✅  No action needed — Sentinel handled it automatically.\n"
               "You can review it in the 🔒 Quarantine tab.")
        self.after(0, lambda: self._show_security_alert_popup(
            "malicious_file", "⚠  Harmful File Found!", msg, "HIGH",
            f"Malicious file quarantined: {file_path} [{threat_name}]"
        ))

    def _on_unauthorized_file_transfer(self, detail: str):
        """Fix 4: Plain-English popup for unauthorized file transfer."""
        msg = (f"Someone may be copying files without permission:\n\n"
               f"  {detail}\n\n"
               "This could mean a USB drive, email attachment, or app is\n"
               "trying to move files off your computer without you knowing.\n\n"
               "⚠  What to do:\n"
               "  1. Check if you recently plugged in a USB drive.\n"
               "  2. If not — contact your IT support immediately.\n"
               "  3. Check the 🔍 Live Logs tab for more details.")
        self.after(0, lambda: self._show_security_alert_popup(
            "file_transfer", "📤  Suspicious File Transfer!", msg, "HIGH",
            f"Unauthorized file transfer detected: {detail}"
        ))

    def _on_unauthorized_access(self, detail: str):
        """Fix 4: Plain-English popup for unauthorized access attempt."""
        msg = (f"Someone tried to access a restricted area:\n\n"
               f"  {detail}\n\n"
               "This means something on your computer tried to get\n"
               "permission it should not have — like a program trying\n"
               "to become an administrator without your knowledge.\n\n"
               "⚠  What to do:\n"
               "  1. Check the 🔐 Admin Privilege Monitor tab.\n"
               "  2. Do not approve anything you did not start yourself.\n"
               "  3. If unsure, call your IT support.")
        self.after(0, lambda: self._show_security_alert_popup(
            "unauthorized_access", "🔓  Unauthorized Access Attempt!", msg, "HIGH",
            f"Unauthorized access: {detail}"
        ))

    def _on_malicious_attempt(self, detail: str):
        """Fix 4: Generic malicious attempt popup."""
        msg = (f"Sentinel blocked a suspicious activity:\n\n"
               f"  {detail}\n\n"
               "Something tried to do something harmful on your computer.\n"
               "Sentinel has blocked it automatically.\n\n"
               "✅  You are protected — but please check the\n"
               "🔍 Live Logs tab for full details.")
        self.after(0, lambda: self._show_security_alert_popup(
            "malicious_attempt", "🚨  Malicious Activity Blocked!", msg, "HIGH",
            f"Malicious attempt blocked: {detail}"
        ))

    def _on_network_attack_plain(self, attack_type: str, src_ip: str, detail: str, severity: str = "HIGH"):
        """Fix 4: Plain-English popup for network/DNS attacks."""
        if "dns" in attack_type.lower() or "spoof" in attack_type.lower():
            icon  = "🔀"
            title = "🔀  Internet Misdirection Attack Detected!"
            msg   = (f"Someone is trying to trick your internet traffic:\n\n"
                     f"  🌐  Attack from: {src_ip}\n"
                     f"  Type: {attack_type}\n\n"
                     "A DNS attack means someone may be redirecting your\n"
                     "web browsing to fake websites — for example, sending\n"
                     "you to a fake bank site that looks real.\n\n"
                     "⚠  What to do NOW:\n"
                     "  1. Stop using internet banking or email temporarily.\n"
                     "  2. Disconnect from WiFi and reconnect.\n"
                     "  3. Call your internet provider or IT support.")
        elif "mitm" in attack_type.lower() or "arp" in attack_type.lower():
            icon  = "👁"
            title = "👁  Someone Is Spying on Your Network!"
            msg   = (f"A 'man-in-the-middle' attack was detected:\n\n"
                     f"  🌐  Source: {src_ip}\n\n"
                     "This means someone on the same network may be watching\n"
                     "all your internet traffic — like a spy reading your messages.\n\n"
                     "⚠  What to do NOW:\n"
                     "  1. Disconnect from the current WiFi immediately.\n"
                     "  2. Do not enter any passwords or banking details.\n"
                     "  3. Contact your IT support.")
        elif "port scan" in attack_type.lower() or "scan" in attack_type.lower():
            icon  = "🔍"
            title = "🔍  Someone Is Probing Your Computer!"
            msg   = (f"A network scan was detected from:\n\n"
                     f"  🌐  {src_ip}\n\n"
                     "This means someone is looking for open 'doors' into your\n"
                     "computer — like a burglar checking which windows are unlocked.\n\n"
                     "Sentinel has blocked it. No action needed right now,\n"
                     "but tell your IT support if this keeps happening.")
        else:
            icon  = "🌐"
            title = "🌐  Network Attack Detected!"
            msg   = (f"A network attack was detected:\n\n"
                     f"  Type: {attack_type}\n"
                     f"  From: {src_ip}\n\n"
                     f"  Detail: {detail[:120]}\n\n"
                     "Sentinel has logged this event. Check the 📈 Performance\n"
                     "or 🔍 Live Logs tab for details. Contact IT support\n"
                     "if this keeps happening.")

        self.after(0, lambda: self._show_security_alert_popup(
            "network_attack", f"{icon}  Network Security Alert", msg, severity,
            f"[NET-{severity}] {attack_type} from {src_ip}: {detail[:80]}"
        ))

    def show_startup_animation(self):
        """Typewriter effect for startup message."""
        startup_text = "INITIALIZING SENTINEL CORE..."
        self.typewriter_text = ""
        self.typewriter_index = 0
        self.typewriter_target = startup_text
        self._typewriter_step()
    
    def _typewriter_step(self):
        """Animate one character."""
        if self.typewriter_index < len(self.typewriter_target):
            self.typewriter_text += self.typewriter_target[self.typewriter_index]
            self.typewriter_index += 1
            
            self.scan_log.delete("1.0", "end")
            self.scan_log.insert("1.0", self.typewriter_text)
            
            self.after(50, self._typewriter_step)
        else:
            self.after(500, self._finish_startup)
    
    def _finish_startup(self):
        """Finish startup animation — show auto-started monitors status."""
        self.scan_log.delete("1.0", "end")
        self._append_to_log("[SYSTEM] Sentinel Defender v5.0 Ready", "system")
        self._append_to_log("[INFO] Select folder and click 'Start Full Scan'", "info")
        self._append_to_log("=" * 80, "info")
        self._append_to_log("[AUTO] ✅ Real-Time Protection: ACTIVE (monitoring your files)", "system")
        self._append_to_log("[AUTO] ✅ Network Monitor: Starting (watching for network attacks)...", "system")
        self._append_to_log("[AUTO] ✅ Network Forensics: Running (scanning for hidden threats)...", "system")
        self._append_to_log("[AUTO] 🔒 WiFi & Bluetooth: Protected (password required to enable)", "system")
        self._append_to_log("=" * 80, "info")
    
    # ==================== UNIFIED UPDATER ====================
    # Replaces the old poll_log_buffer + update_statistics + update_graphs
    # trio that were all firing independently and stacking on the main thread.

    # ── Background worker thread ──────────────────────────────────────────────
    # ONE persistent thread does ALL data fetching. The main thread only calls
    # widget.configure() — never fetches, never sleeps, never blocks.

    def _start_background_worker(self):
        """
        Single daemon thread that collects ALL data that would otherwise block
        the main thread. Results are placed into self._bg_result (a plain dict)
        which is read by poll_log_buffer() on the main thread for fast configure() calls only.
        """
        import threading as _thr
        self._bg_result   = {}          # dict written by bg thread, read by main
        self._bg_lock     = _thr.Lock()
        self._bg_tick     = 0
        self._bg_running  = True

        def _worker():
            import time as _t
            while self._bg_running:
                _t.sleep(0.25 if self.is_scanning else 1.5)
                try:
                    data = {}
                    # 1. Scan stats (does I/O / DB query)
                    try:
                        data['status'] = self.hub.get_scan_status()
                    except Exception:
                        pass
                    # 2. Resource usage (syscall)
                    try:
                        if self.resource_monitor.enabled:
                            data['resource'] = self.resource_monitor.get_current_usage()
                    except Exception:
                        pass
                    # 3. Dynamic alerts (may iterate a queue)
                    try:
                        if self.monitoring_active:
                            data['dyn_alerts'] = self.hub.get_dynamic_alerts(max_items=10)
                    except Exception:
                        pass
                    # 4. Hardware alerts (drain the thread-safe queue — no PS calls here)
                    try:
                        with self._hg_lock:
                            hw_pending = self._hg_alert_queue[:]
                            self._hg_alert_queue.clear()
                        data['hw_alerts'] = hw_pending
                    except Exception:
                        data['hw_alerts'] = []
                    # 4b. HW stats — call PS every 6s (not every 1.5s) to reduce load
                    try:
                        self._bg_hw_tick = getattr(self, '_bg_hw_tick', 0) + 1
                        if self._bg_hw_tick >= 4:   # every 4 × 1.5s = 6s
                            self._bg_hw_tick = 0
                            hw = getattr(self, 'hardware_gatekeeper', None)
                            if hw:
                                hw.get_stats()      # populates hw._cached_stats as side effect
                    except Exception:
                        pass
                    # 5. Log buffer (reads shared list — no I/O)
                    try:
                        logs, cursor = self.hub.get_log_buffer_since(
                            self._log_cursor, count=self.BATCH_SIZE
                        )
                        data['logs'] = logs
                        data['log_cursor'] = cursor
                    except Exception:
                        pass

                    with self._bg_lock:
                        self._bg_result = data
                    if self.is_scanning:
                        diag_logger.debug(
                            "[QUEUE] bg_result status=%s logs=%d dyn=%d hw=%d net_pending=%d",
                            (data.get('status') or {}).get('status'),
                            len(data.get('logs') or []),
                            len(data.get('dyn_alerts') or []),
                            len(data.get('hw_alerts') or []),
                            len(getattr(self, '_net_alert_queue', []))
                        )
                except Exception as e:
                    print(f"[BG] worker error: {e}")

        _thr.Thread(target=_worker, daemon=True, name="SentinelBGWorker").start()

    def poll_log_buffer(self):
        """
        Main-thread heartbeat — reads pre-fetched data from _bg_result and
        calls configure(). Zero blocking I/O. Zero sleeps. Zero subprocess calls.
        Runs every 250 ms while scanning, otherwise 1200 ms.
        """
        poll_started = time.perf_counter()
        if not getattr(self, '_poll_running', True):
            return
        diag_logger.debug("[UI] poll start scanning=%s", self.is_scanning)

        # Grab a snapshot — hold lock as briefly as possible
        try:
            with self._bg_lock:
                data = dict(self._bg_result)
                self._bg_result = {}   # clear so we only process each batch once
        except Exception:
            data = {}

        # 1. Log lines — batch up to 5 per tick; single bulk insert reduces widget redraws
        try:
            logs = data.get('logs') or []
            if logs:
                self._log_cursor = data.get('log_cursor', self._log_cursor)
                for log in logs:
                    if not log:
                        continue
                    is_threat = ('Threat' in log or 'EICAR' in log or '[THREAT]' in log)
                    is_error  = 'Error' in log and not is_threat
                    tag = "threat" if (is_threat or is_error) else "clean"
                    self._append_to_log(log, tag)
                    if is_threat:
                        self._flash_window()
        except Exception as e:
            print(f"Log apply error: {e}")

        # 2. Stats cards — configure() calls only (instant, no I/O)
        try:
            status = data.get('status')
            if status:
                files_scanned = int(status.get('files_scanned', 0))
                threats_found = int(status.get('threats_found', 0))
                files_quarantined = int(status.get('files_quarantined', 0))
                clean = max(0, files_scanned - threats_found)

                status_snapshot = (files_scanned, threats_found, files_quarantined, clean)
                if status_snapshot != getattr(self, '_last_status_snapshot', None):
                    self.files_card.configure(text=str(files_scanned))
                    self.threats_card.configure(text=str(threats_found))
                    self.quarantine_card.configure(text=str(files_quarantined))
                    self.clean_card.configure(text=str(clean))
                    self._last_status_snapshot = status_snapshot

                resource = data.get('resource')
                if resource and hasattr(self, 'cpu_label') and hasattr(self, 'ram_label'):
                    resource_snapshot = (
                        round(float(resource.get('cpu', 0.0)), 1),
                        round(float(resource.get('ram', 0.0)), 1),
                    )
                    if resource_snapshot != getattr(self, '_last_resource_snapshot', None):
                        self.cpu_label.configure(text=f"CPU: {resource_snapshot[0]:.1f}%")
                        self.ram_label.configure(text=f"RAM: {resource_snapshot[1]:.1f} MB")
                        self._last_resource_snapshot = resource_snapshot

                current_file = status.get('current_file') or ''
                stalled_for = max(0.0, time.time() - float(status.get('last_progress_ts') or 0.0))
                st = status.get('status', '')
                if st == 'completed' and self.is_scanning:
                    self.is_scanning = False
                    self.start_scan_btn.configure(state="normal")
                    self.stop_scan_btn.configure(state="disabled")
                    self.pause_scan_btn.configure(state="disabled", text="⏸ Pause Scan")
                    self.last_scan_label.configure(
                        text=f"Last scan: {datetime.now().strftime('%H:%M:%S')} [OK]")
                    self.progress_bar.set(1.0)
                    self.progress_label.configure(text="Scan completed!")
                    self.status_label.configure(text="Scan Complete",
                                                text_color=COLORS['accent_green'])
                    self.after(800, self._on_scan_complete_trigger_agents)
                elif st == 'scanning':
                    self.is_scanning = True
                    now = time.time()
                    if now - getattr(self, '_last_progress_anim_ts', 0.0) >= 0.8:
                        cur = self.progress_bar.get()
                        nxt = 0.08 if cur >= 0.94 else (cur + 0.02)
                        self.progress_bar.set(nxt)
                        self._last_progress_anim_ts = now

                    current_name = Path(current_file).name if current_file else "current file"
                    if stalled_for >= 1.5 and current_file:
                        progress_text = (
                            f"Scanning large file... {current_name} "
                            f"({files_scanned} files | {status.get('files_per_sec', 0):.1f} files/sec)"
                        )
                    else:
                        progress_text = (
                            f"Scanning... ({files_scanned} files | "
                            f"{status.get('files_per_sec', 0):.1f} files/sec)"
                        )
                    if progress_text != getattr(self, '_last_progress_text', None):
                        self.progress_label.configure(text=progress_text)
                        self._last_progress_text = progress_text

                    status_text = "SCANNING ACTIVE - LARGE FILE" if stalled_for >= 1.5 and current_file else "SCANNING ACTIVE"
                    if status_text != getattr(self, '_last_status_text', None):
                        self.status_label.configure(text=status_text)
                        self._last_status_text = status_text
        except Exception as e:
            print(f"Stats apply error: {e}")

        # 3. Dynamic (real-time protection) alerts — already fetched by bg thread
        try:
            dyn = data.get('dyn_alerts') or []
            for alert in dyn:
                sev   = getattr(alert, "severity", "low").lower()
                title = getattr(alert, "title", str(alert))
                src   = getattr(alert, "source", "dynamic")
                score = getattr(alert, "threat_score", 0)
                path  = getattr(alert, "file_path", "") or getattr(alert, "path", "")
                self._append_to_log(
                    f"[RT/{sev.upper()}][{src.upper()}] {title} (score:{score})",
                    "threat" if sev in ("critical", "high") else "info"
                )
                if sev in ("critical", "high"):
                    self._flash_window()
                    tl = title.lower()
                    if any(k in tl for k in ("malware","virus","trojan","ransomware","eicar","threat")):
                        self._on_malicious_file_found(path or "unknown file", title)
                    elif any(k in tl for k in ("transfer","exfil","copy","usb")):
                        self._on_unauthorized_file_transfer(title)
                    elif any(k in tl for k in ("privilege","escalat","admin","uac")):
                        self._on_unauthorized_access(title)
                    else:
                        self._on_malicious_attempt(title)
        except Exception as e:
            print(f"Dyn alert apply error: {e}")

        # 4. Hardware alerts — already drained by bg thread, now just dispatch popups
        try:
            for event_type, detail in (data.get('hw_alerts') or []):
                self._append_to_log(f"[HARDWARE] {event_type}: {detail}", "threat")
                det_lower = detail.lower()
                if "wifi" in det_lower or "wi-fi" in det_lower:
                    ssid = detail.replace("Wi-Fi blocked", "").replace("wifi","").strip() or "open network"
                    self._hw_free_network_blocked_popup("wifi", ssid)
                elif "bluetooth" in det_lower or "bt" in det_lower:
                    dev = detail.replace("Bluetooth blocked","").strip() or "unknown device"
                    self._hw_free_network_blocked_popup("bluetooth", dev)
                else:
                    self._show_security_alert_popup(
                        "hardware", "📡  Hardware Access Blocked",
                        f"Sentinel blocked a hardware action:\n\n  {detail}\n\n"
                        "To allow hardware access, go to 📡 Hardware Gatekeeper tab\n"
                        "and enter your password.",
                        "HIGH", f"Hardware blocked: {detail}"
                    )
        except Exception as e:
            print(f"HW alert apply error: {e}")

        # 5. Graphs — only every 10 ticks (~15 s) — rendered off-thread already
        try:
            self._graph_tick = getattr(self, '_graph_tick', 0) + 1
            if self._graph_tick >= 10:
                self._graph_tick = 0
                if hasattr(self, 'performance_graphs') and self.performance_graphs:
                    st = data.get('status') or {}
                    self.performance_graphs.update(
                        files_per_sec=st.get('files_per_sec', 0),
                        threat_count=st.get('threats_found', 0))
        except Exception as e:
            print(f"Graph tick error: {e}")

        # 6. Network alerts — drain queue (all locking done here, no separate timer)
        try:
            self._poll_net_alerts_background()
        except Exception:
            pass

        poll_elapsed_ms = (time.perf_counter() - poll_started) * 1000.0
        diag_logger.debug(
            "[UI] poll end duration=%.2fms files=%s threats=%s logs=%d",
            poll_elapsed_ms,
            (data.get('status') or {}).get('files_scanned'),
            (data.get('status') or {}).get('threats_found'),
            len(data.get('logs') or [])
        )

        next_tick_ms = 250 if self.is_scanning else 1200
        self.after(next_tick_ms, self.poll_log_buffer)

        # 7. Admin uptime label (pure time arithmetic — instant)
        try:
            fn = getattr(self, '_adm_stat_tick_fn', None)
            if fn:
                fn()
        except Exception:
            pass

        # 7b. AdminPrivilegeMonitor — deliver pending events on main thread
        # (avoids "main thread is not in main loop" Tkinter errors)
        try:
            mon = getattr(self, 'admin_priv_monitor', None)
            if mon and hasattr(mon, 'drain_pending_callbacks'):
                mon.drain_pending_callbacks()
        except Exception:
            pass

        # 8. HW status badges — only every 5 ticks (~6s), reads cache only (PS runs in BG worker)
        try:
            self._hw_status_tick2 = getattr(self, '_hw_status_tick2', 0) + 1
            if self._hw_status_tick2 >= 5:
                self._hw_status_tick2 = 0
                hw = getattr(self, 'hardware_gatekeeper', None)
                if hw:
                    cached = hw.get_cached_stats()   # instant — reads _cached_stats dict
                    self._apply_hw_stats(cached)
        except Exception:
            pass

    # ==================== COLOR-CODED LOGGING ====================

    def _apply_hw_stats(self, stats: dict):
        """Apply pre-fetched HW stats to badges — main thread safe, zero I/O."""
        try:
            hw_upd = getattr(self, '_hw_status_upd_fn', None)
            if hw_upd:
                # Patch the gatekeeper's cached stats so _upd() reads them
                hw = getattr(self, 'hardware_gatekeeper', None)
                if hw and hasattr(hw, '_cached_stats'):
                    hw._cached_stats = stats
                hw_upd()
        except Exception:
            pass

        # Also update the badge labels directly
        try:
            def _bstyle(s):
                s = str(s).upper()
                if s == "ON":      return "🟢 ON",  "#10b981"
                if s == "OFF":     return "🔴 OFF", "#ef4444"
                return "⚠ N/A", COLORS["text_secondary"]
            bt_t, bt_c   = _bstyle(stats.get("bt_state",   "N/A"))
            wf_t, wf_c   = _bstyle(stats.get("wifi_state", "N/A"))
            auth = stats.get("authenticated", False)
            for attr, txt, col in [
                ("_hw_bt_badge",   bt_t, bt_c),
                ("_hw_wifi_badge", wf_t, wf_c),
            ]:
                lbl = getattr(self, attr, None)
                if lbl:
                    lbl.configure(text=txt, text_color=col)
            ab = getattr(self, "_hw_auth_badge", None)
            if ab:
                ab.configure(
                    text="🟢 Unlocked" if auth else "🔴 Locked",
                    text_color="#10b981" if auth else "#ef4444")
        except Exception:
            pass
            
    def _refresh_hw_status(self):
        """Legacy stub — HW status is now updated via _apply_hw_stats by the heartbeat."""
        pass
    
    def _refresh_admin_vault_badge(self):
        """Refresh admin vault badge — lightweight file existence check only."""
        try:
            if hasattr(self, '_adm_vault_badge'):
                is_set = self._vault_is_set(self._adm_vault_path)
                self._adm_vault_badge.configure(
                    text="🔑 Password Set" if is_set else "⚠  No Password",
                    text_color="#10b981" if is_set else "#f59e0b")
        except Exception:
            pass
    
    def _append_to_log(self, text: str, log_type: str = "info"):
        """Append colored log entry — optimised to minimise main-thread work.

        Key changes vs the original:
        - Tag config is done once at startup, not on every call.
        - Line-count trim is batched: we track an approximate counter and only
          query Tkinter (an O(n) operation) every 100 insertions, not every one.
        - Auto-scroll only queries yview when near the bottom threshold.
        """
        try:
            if not hasattr(self, '_tags_configured'):
                self.scan_log.tag_config("threat", foreground=COLORS['log_threat'])
                self.scan_log.tag_config("info",   foreground=COLORS['log_info'])
                self.scan_log.tag_config("system", foreground=COLORS['log_system'])
                self.scan_log.tag_config("clean",  foreground=COLORS['log_clean'])
                self._tags_configured = True

            self.scan_log.insert("end", text + "\n", log_type)

            # Throttled trim: only do the expensive index() query every 100 lines
            self._log_line_counter = getattr(self, '_log_line_counter', 0) + 1
            if self._log_line_counter >= 100:
                self._log_line_counter = 0
                total_lines = int(self.scan_log.index('end-1c').split('.')[0])
                if total_lines > 1200:
                    # Delete the oldest 400 lines in one operation
                    self.scan_log.delete('1.0', '400.0')

            if self._is_scrolled_to_bottom():
                self.scan_log.see("end")

        except Exception as e:
            print(f"Log append error: {e}")
    
    def _is_scrolled_to_bottom(self) -> bool:
        """Check if scrolled to bottom."""
        try:
            yview = self.scan_log.yview()
            if yview is None:
                return True
            return yview[1] >= 0.95
        except:
            return True
    
    # ==================== WINDOW FLASH ====================
    
    def _flash_window(self):
        """Flash window title on threat."""
        try:
            original_title = self.title()
            self.title("[WARNING]️ THREAT DETECTED [WARNING]️")
            self.after(500, lambda: self.title(original_title))
        except:
            pass
    
    # ==================== PULSING STATUS ====================
    
    def animate_status_pulse(self):
        """Animate status pulse — only reconfigures when colour actually changes (saves redraws)."""
        if self.is_scanning:
            self.pulse_brightness += 0.08 * self.pulse_direction
            if self.pulse_brightness >= 1.0:
                self.pulse_brightness = 1.0
                self.pulse_direction = -1
            elif self.pulse_brightness <= 0.3:
                self.pulse_brightness = 0.3
                self.pulse_direction = 1
            brightness = int(self.pulse_brightness * 255)
            new_color = f'#{brightness:02x}{brightness//2:02x}{brightness//4:02x}'
            if new_color != getattr(self, '_last_pulse_color', ''):
                self._last_pulse_color = new_color
                try:
                    self.status_label.configure(text_color=new_color)
                except Exception:
                    pass
        else:
            if getattr(self, '_last_pulse_color', '') != COLORS['accent_green']:
                self._last_pulse_color = COLORS['accent_green']
                try:
                    self.status_label.configure(text_color=COLORS['accent_green'])
                except Exception:
                    pass
        self.after(400, self.animate_status_pulse)  # 400ms — ~2.5fps, invisible
    
    # update_graphs — merged into poll_log_buffer unified heartbeat
    
    # update_statistics — merged into poll_log_buffer unified heartbeat
    
    # ==================== UI CONSTRUCTION ====================
    
    def create_ui(self):
        """Build UI."""
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        self.create_sidebar()
        self.create_main_area()
    
    def create_sidebar(self):
        """
        Compact sidebar — no scrollbar needed.
        Scan buttons are arranged in a single row (Start | Stop | Pause).
        Sidebar width scales with screen: 220px on small screens, 260px on large.
        """
        screen_w = self.winfo_screenwidth()
        sb_width = 220 if screen_w < 1400 else 260

        self._sidebar_outer = ctk.CTkFrame(
            self, width=sb_width, corner_radius=0, fg_color=COLORS['bg_secondary']
        )
        self._sidebar_outer.grid(row=0, column=0, sticky="nsew")
        self._sidebar_outer.grid_propagate(False)
        self._sidebar_outer.grid_rowconfigure(0, weight=1)
        self._sidebar_outer.grid_columnconfigure(0, weight=1)

        # Plain (non-scrollable) frame — everything fits without a scrollbar
        self.sidebar = ctk.CTkFrame(
            self._sidebar_outer,
            fg_color=COLORS['bg_secondary'],
            corner_radius=0,
        )
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_columnconfigure(0, weight=1)

        # ── Compact Logo ──────────────────────────────────────────────────────
        logo_frame = ctk.CTkFrame(
            self.sidebar, fg_color=COLORS['bg_card'], corner_radius=12
        )
        logo_frame.grid(row=0, column=0, padx=12, pady=(14, 8), sticky="ew")

        logo_inner = ctk.CTkFrame(logo_frame, fg_color="transparent")
        logo_inner.pack(pady=10)

        ctk.CTkLabel(
            logo_inner, text="🛡️", font=ctk.CTkFont(size=28)
        ).pack(side="left", padx=(8, 6))

        txt_frame = ctk.CTkFrame(logo_inner, fg_color="transparent")
        txt_frame.pack(side="left")
        ctk.CTkLabel(
            txt_frame, text="SENTINEL DEFENDER",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLORS['accent_blue']
        ).pack(anchor="w")
        ctk.CTkLabel(
            txt_frame, text="v5.0 • Deep Protection",
            font=ctk.CTkFont(size=10),
            text_color=COLORS['text_secondary']
        ).pack(anchor="w")

        # ── Folder selector ───────────────────────────────────────────────────
        ctk.CTkLabel(
            self.sidebar, text="SCAN CONTROLS",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=COLORS['text_secondary']
        ).grid(row=1, column=0, padx=14, pady=(10, 4), sticky="w")

        self.select_folder_btn = ctk.CTkButton(
            self.sidebar, text="📁 Select Folder",
            command=self.select_scan_folder,
            height=36, corner_radius=10,
            fg_color=COLORS['bg_card'],
            hover_color=COLORS['accent_blue'],
            border_width=2, border_color=COLORS['accent_blue'],
            font=ctk.CTkFont(size=12)
        )
        self.select_folder_btn.grid(row=2, column=0, padx=12, pady=(0, 6), sticky="ew")

        # ── Three scan buttons side-by-side ───────────────────────────────────
        btn_row = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        btn_row.grid(row=3, column=0, padx=12, pady=(0, 4), sticky="ew")
        btn_row.grid_columnconfigure((0, 1, 2), weight=1)

        self.start_scan_btn = ctk.CTkButton(
            btn_row, text="▶",
            command=self.start_scan,
            height=38, corner_radius=10,
            fg_color=COLORS['accent_green'], hover_color="#0d9668",
            font=ctk.CTkFont(size=14, weight="bold"),
            width=0
        )
        self.start_scan_btn.grid(row=0, column=0, padx=(0, 3), sticky="ew")

        self.stop_scan_btn = ctk.CTkButton(
            btn_row, text="⏹",
            command=self.stop_scan,
            height=38, corner_radius=10,
            fg_color=COLORS['accent_red'], hover_color="#dc2626",
            font=ctk.CTkFont(size=14), state="disabled",
            width=0
        )
        self.stop_scan_btn.grid(row=0, column=1, padx=3, sticky="ew")

        self.pause_scan_btn = ctk.CTkButton(
            btn_row, text="⏸",
            command=self.toggle_pause_scan,
            height=38, corner_radius=10,
            fg_color=COLORS.get('accent_orange', '#f59e0b'), hover_color="#d97706",
            font=ctk.CTkFont(size=14), state="disabled",
            width=0
        )
        self.pause_scan_btn.grid(row=0, column=2, padx=(3, 0), sticky="ew")

        # Button labels row
        lbl_row = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        lbl_row.grid(row=4, column=0, padx=12, pady=(0, 4), sticky="ew")
        lbl_row.grid_columnconfigure((0, 1, 2), weight=1)
        for col, txt in enumerate(["Start", "Stop", "Pause"]):
            ctk.CTkLabel(lbl_row, text=txt, font=ctk.CTkFont(size=9),
                         text_color=COLORS['text_secondary']).grid(row=0, column=col)

        self.last_scan_label = ctk.CTkLabel(
            self.sidebar, text="Last scan: Never run",
            font=ctk.CTkFont(size=10),
            text_color=COLORS['text_secondary'],
            wraplength=sb_width - 24, justify="center"
        )
        self.last_scan_label.grid(row=5, column=0, padx=12, pady=(0, 6), sticky="ew")

        # ── Resource usage ────────────────────────────────────────────────────
        resource_frame = ctk.CTkFrame(
            self.sidebar, fg_color=COLORS['bg_card'], corner_radius=10
        )
        resource_frame.grid(row=6, column=0, padx=12, pady=(4, 6), sticky="ew")
        resource_frame.grid_columnconfigure((0, 1), weight=1)

        ctk.CTkLabel(resource_frame, text="CPU", font=ctk.CTkFont(size=10),
                     text_color=COLORS['text_secondary']).grid(row=0, column=0, pady=(6, 0))
        ctk.CTkLabel(resource_frame, text="RAM", font=ctk.CTkFont(size=10),
                     text_color=COLORS['text_secondary']).grid(row=0, column=1, pady=(6, 0))
        self.cpu_label = ctk.CTkLabel(resource_frame, text="0.0%",
                                       font=ctk.CTkFont(size=12, weight="bold"),
                                       text_color=COLORS['accent_blue'])
        self.cpu_label.grid(row=1, column=0, pady=(0, 6))
        self.ram_label = ctk.CTkLabel(resource_frame, text="0 MB",
                                       font=ctk.CTkFont(size=12, weight="bold"),
                                       text_color=COLORS['accent_purple'])
        self.ram_label.grid(row=1, column=1, pady=(0, 6))

        # ── Protection toggles ────────────────────────────────────────────────
        ctk.CTkLabel(
            self.sidebar, text="PROTECTION",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=COLORS['text_secondary']
        ).grid(row=7, column=0, padx=14, pady=(10, 4), sticky="w")

        for row_idx, (label, attr, cmd) in enumerate([
            ("Real-time Monitor", "monitor_switch",     "toggle_monitoring"),
            ("Network Monitor",   "net_monitor_switch", "_toggle_net_monitor_switch"),
        ], start=8):
            f = ctk.CTkFrame(self.sidebar, fg_color=COLORS['bg_card'], corner_radius=10)
            f.grid(row=row_idx, column=0, padx=12, pady=3, sticky="ew")
            ctk.CTkLabel(f, text=label, font=ctk.CTkFont(size=12)).pack(side="left", padx=12, pady=10)
            sw = ctk.CTkSwitch(f, text="", command=getattr(self, cmd),
                               progress_color=COLORS['accent_green'])
            sw.pack(side="right", padx=12, pady=10)
            setattr(self, attr, sw)

        # ── AI Report button ──────────────────────────────────────────────────
        self.report_btn = ctk.CTkButton(
            self.sidebar, text="📄 Generate AI Report",
            command=self.generate_report,
            height=36, corner_radius=10,
            fg_color=COLORS['accent_purple'], hover_color="#7c3aed",
            font=ctk.CTkFont(size=12)
        )
        self.report_btn.grid(row=10, column=0, padx=12, pady=(10, 4), sticky="ew")

        # ── Power control buttons ─────────────────────────────────────────────
        power_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        power_frame.grid(row=11, column=0, padx=12, pady=(2, 4), sticky="ew")
        power_frame.grid_columnconfigure((0, 1), weight=1)

        self.btn_power_on = ctk.CTkButton(
            power_frame, text="⏻ ON",
            command=self.power_on_system,
            height=32, corner_radius=8,
            fg_color="#27ae60", hover_color="#1e8449",
            font=ctk.CTkFont(size=11, weight="bold"),
            state="disabled"   # starts ON, so ON btn is disabled
        )
        self.btn_power_on.grid(row=0, column=0, padx=(0, 3), sticky="ew")

        self.btn_power_off = ctk.CTkButton(
            power_frame, text="⏻ OFF",
            command=self.power_off_system,
            height=32, corner_radius=8,
            fg_color="#c0392b", hover_color="#922b21",
            font=ctk.CTkFont(size=11, weight="bold")
        )
        self.btn_power_off.grid(row=0, column=1, padx=(3, 0), sticky="ew")

        # ── Status indicator ──────────────────────────────────────────────────
        self.sidebar.grid_rowconfigure(13, weight=1)

        self.status_frame = ctk.CTkFrame(
            self.sidebar, fg_color=COLORS['bg_card'], corner_radius=10
        )
        self.status_frame.grid(row=13, column=0, padx=12, pady=(6, 12), sticky="ew")

        self.status_indicator = ctk.CTkLabel(
            self.status_frame, text="🟢", font=ctk.CTkFont(size=14)
        )
        self.status_indicator.pack(side="left", padx=8, pady=8)

        self.status_label = ctk.CTkLabel(
            self.status_frame, text="System Protected",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=COLORS['accent_green']
        )
        self.status_label.pack(side="left", pady=8)

    def create_main_area(self):
        """Main content area — no horizontal scrollbar, fills available space."""
        self.main_container = ctk.CTkFrame(
            self,
            fg_color=COLORS['bg_primary'],
            corner_radius=0,
        )
        self.main_container.grid(row=0, column=1, sticky="nsew", padx=14, pady=14)
        self.main_container.grid_rowconfigure(2, weight=1)
        self.main_container.grid_columnconfigure(0, weight=1)

        self.create_stat_cards()
        self.create_tabview()
        self.create_progress_section()
    
    def create_stat_cards(self):
        """Create stat cards."""
        cards_frame = ctk.CTkFrame(self.main_container, fg_color="transparent")
        cards_frame.grid(row=0, column=0, sticky="ew", pady=(0, 20))
        cards_frame.grid_columnconfigure((0, 1, 2, 3, 4, 5), weight=1)

        self.files_card = self.create_stat_card(
            cards_frame, 0, "📂 Files Scanned", "0", COLORS['accent_blue']
        )
        self.threats_card = self.create_stat_card(
            cards_frame, 1, "[WARNING]️ Threats Found", "0", COLORS['accent_red']
        )
        self.quarantine_card = self.create_stat_card(
            cards_frame, 2, "🔒 Quarantined", "0", COLORS['accent_orange']
        )
        self.clean_card = self.create_stat_card(
            cards_frame, 3, "[OK] Clean Files", "0", COLORS['accent_green']
        )
        self.net_threats_card = self.create_stat_card(
            cards_frame, 4, "🌐 Net Threats Found", "0", "#e74c3c"
        )
        self.net_mitigated_card = self.create_stat_card(
            cards_frame, 5, "🛡 Net Mitigated", "0", "#1abc9c"
        )
    
    def create_stat_card(self, parent, column, title, value, color):
        """Create stat card."""
        card = ctk.CTkFrame(
            parent,
            fg_color=COLORS['bg_card'],
            corner_radius=15,
            border_width=2,
            border_color=color
        )
        card.grid(row=0, column=column, padx=10, sticky="ew")
        
        ctk.CTkLabel(
            card,
            text=title,
            font=ctk.CTkFont(size=13),
            text_color=COLORS['text_secondary']
        ).pack(pady=(15, 5))
        
        value_label = ctk.CTkLabel(
            card,
            text=value,
            font=ctk.CTkFont(size=36, weight="bold"),
            text_color=color
        )
        value_label.pack(pady=(0, 15))
        
        return value_label
    
    def create_tabview(self):
        """Create tabview."""
        self.tabview = ctk.CTkTabview(
            self.main_container,
            corner_radius=15,
            fg_color=COLORS['bg_card']
        )
        self.tabview.grid(row=2, column=0, sticky="nsew", pady=(0, 20))
        
        # PROFESSOR REQUIREMENT: Database table view first
        self.tabview.add("📈 Performance")
        self.tabview.add("🔍 Live Logs")
        self.tabview.add("🔒 Quarantine")
        if PSUTIL_AVAILABLE:
            self.tabview.add("⚙️ Process Monitor")
        self.tabview.add("🔐 Admin Privilege Monitor")
        self.tabview.add("📡 Hardware Gatekeeper")
        self.tabview.add("🤖 AI Agents")

        # Create tabs
        self.create_performance_tab()
        self.create_live_logs_tab()
        self.create_quarantine_tab()
        if PSUTIL_AVAILABLE:
            self.create_process_monitor_tab()
        self.create_admin_privilege_tab()
        self.create_hardware_gatekeeper_tab()
        self.create_ai_agents_tab()
    
    # ==================== PROFESSOR REQUIREMENT: TABULAR DATABASE LOGS ====================
    
    def create_performance_tab(self):
        """Create performance graphs tab."""
        tab = self.tabview.tab("📈 Performance")
        
        if MATPLOTLIB_AVAILABLE:
            self.performance_graphs = PerformanceGraphs(tab)
        else:
            self.performance_graphs = None
            ctk.CTkLabel(
                tab,
                text="[WARNING]️ Install matplotlib for graphs:\npip install matplotlib",
                font=ctk.CTkFont(size=14),
                text_color=COLORS['text_secondary']
            ).pack(pady=50)
    
    def create_live_logs_tab(self):
        """Create live logs tab with color coding."""
        tab = self.tabview.tab("🔍 Live Logs")
        
        self.scan_log = ctk.CTkTextbox(
            tab,
            font=ctk.CTkFont(family="Consolas", size=12),
            fg_color=COLORS['bg_secondary'],
            corner_radius=10,
            wrap="word"
        )
        self.scan_log.pack(fill="both", expand=True, padx=10, pady=10)
    
    def create_quarantine_tab(self):
        """Create quarantine tab with checkboxes."""
        tab = self.tabview.tab("🔒 Quarantine")
        
        # Toolbar
        toolbar = ctk.CTkFrame(tab, fg_color="transparent")
        toolbar.pack(fill="x", padx=10, pady=10)
        
        ctk.CTkButton(
            toolbar,
            text="🔄 Refresh",
            command=self.refresh_quarantine,
            width=100,
            height=35,
            corner_radius=10,
            fg_color=COLORS['accent_blue']
        ).pack(side="left", padx=5)
        
        ctk.CTkButton(
            toolbar,
            text="☑ Select All",
            command=self.select_all_quarantine,
            width=100,
            height=35,
            corner_radius=10,
            fg_color=COLORS['accent_purple']
        ).pack(side="left", padx=5)
        
        ctk.CTkButton(
            toolbar,
            text="☐ Deselect All",
            command=self.deselect_all_quarantine,
            width=100,
            height=35,
            corner_radius=10,
            fg_color=COLORS['bg_card']
        ).pack(side="left", padx=5)
        
        self.restore_selected_btn = ctk.CTkButton(
            toolbar,
            text="↩️ Restore Selected",
            command=self.restore_selected_quarantine,
            width=130,
            height=35,
            corner_radius=10,
            fg_color=COLORS['accent_green'],
            state="disabled"
        )
        self.restore_selected_btn.pack(side="left", padx=5)
        
        self.delete_selected_btn = ctk.CTkButton(
            toolbar,
            text="🗑️ Delete Selected",
            command=self.delete_selected_quarantine,
            width=130,
            height=35,
            corner_radius=10,
            fg_color=COLORS['accent_red'],
            state="disabled"
        )
        self.delete_selected_btn.pack(side="left", padx=5)
        
        # List
        list_frame = ctk.CTkFrame(tab, fg_color=COLORS['bg_secondary'], corner_radius=10)
        list_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        self.quarantine_scroll = ctk.CTkScrollableFrame(list_frame, fg_color="transparent")
        self.quarantine_scroll.pack(fill="both", expand=True, padx=5, pady=5)
        
        self.refresh_quarantine()
    
    def create_process_monitor_tab(self):
        """Create process monitor tab."""
        tab = self.tabview.tab("⚙️ Process Monitor")
        
        ctk.CTkLabel(
            tab,
            text="System Process Monitor",
            font=ctk.CTkFont(size=18, weight="bold")
        ).pack(pady=10)
        
        ctk.CTkLabel(
            tab,
            text="Real-time CPU and RAM usage of running processes",
            font=ctk.CTkFont(size=12),
            text_color=COLORS['text_secondary']
        ).pack(pady=5)
        
        self.process_frame = ctk.CTkScrollableFrame(
            tab,
            fg_color=COLORS['bg_secondary'],
            corner_radius=10
        )
        self.process_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        ctk.CTkButton(
            tab,
            text="🔄 Refresh Processes",
            command=self.refresh_processes,
            height=40,
            corner_radius=10,
            fg_color=COLORS['accent_blue']
        ).pack(pady=10)
        
        self.refresh_processes()
    
    def create_progress_section(self):
        """Create progress section."""
        progress_frame = ctk.CTkFrame(
            self.main_container,
            fg_color=COLORS['bg_card'],
            corner_radius=15,
            height=100
        )
        progress_frame.grid(row=3, column=0, sticky="ew")
        progress_frame.grid_propagate(False)
        
        self.progress_label = ctk.CTkLabel(
            progress_frame,
            text="Ready to scan",
            font=ctk.CTkFont(size=14),
            text_color=COLORS['text_secondary']
        )
        self.progress_label.pack(pady=(15, 5))
        
        self.progress_bar = ctk.CTkProgressBar(
            progress_frame,
            height=22,
            corner_radius=10,
            progress_color=COLORS['accent_blue']
        )
        self.progress_bar.pack(fill="x", padx=20, pady=(5, 15))
        self.progress_bar.set(0)
    
    # ==================== COMMAND METHODS ====================
    
    def set_default_scan_path(self) -> Path:
        """Set default scan path."""
        try:
            downloads = Path.home() / "Downloads"
            if downloads.exists():
                self.selected_path = downloads
                self.select_folder_btn.configure(text=f"📁 {downloads.name}")
                return downloads
            
            home = Path.home()
            self.selected_path = home
            self.select_folder_btn.configure(text=f"📁 Home")
            return home
        except Exception as e:
            print(f"Error setting default path: {e}")
            default = Path.home()
            self.selected_path = default
            return default
    
    def select_scan_folder(self):
        """Select folder."""
        folder = filedialog.askdirectory(title="Select Folder to Scan")
        if folder:
            self.selected_path = Path(folder)
            self.select_folder_btn.configure(text=f"📁 {Path(folder).name}")
            self._append_to_log(f"[SYSTEM] Selected: {folder}", "system")
    
    def start_scan(self):
        """Start scan."""
        if self.selected_path is None:
            target = self.set_default_scan_path()
        else:
            target = self.selected_path
        
        if not isinstance(target, Path):
            target = Path(target)
        
        self.progress_bar.set(0)
        self.progress_label.configure(text="Initializing scan...")
        
        self.start_scan_btn.configure(state="disabled")
        self.stop_scan_btn.configure(state="normal")
        self.pause_scan_btn.configure(state="normal", text="⏸ Pause Scan",
                                       fg_color=COLORS.get('accent_orange', '#f59e0b'))
        
        self.scan_log.delete("1.0", "end")
        
        self._append_to_log("=" * 80, "system")
        self._append_to_log("[SYSTEM] STARTING FULL SCAN", "system")
        self._append_to_log(f"[INFO] Target: {target}", "info")
        self._append_to_log("[INFO] Engine: Throttled Mode (1ms pause/10 files)", "info")
        self._append_to_log("[INFO] GUI: Optimized polling (200ms intervals)", "info")
        self._append_to_log("=" * 80, "system")
        
        self.hub.start_scan(
            target_path=target,
            scan_type=ScanType.FULL,
            recursive=True
        )
        self.is_scanning = True
        self._last_status_snapshot = None
        self._last_resource_snapshot = None
        self._last_progress_text = None
        self._last_status_text = None
        self._last_progress_anim_ts = 0.0

        # Reset AI-pipeline run gate for new scan.
        self._pipeline_ran_for_session = False
        self._last_pipeline_session_id = None
    
    def stop_scan(self):
        """Stop scan."""
        self.hub.stop_scan()
        self.is_scanning = False
        self._last_progress_text = None
        self._last_status_text = None
        self.progress_label.configure(text="Scan stopped by user")
        self.start_scan_btn.configure(state="normal")
        self.stop_scan_btn.configure(state="disabled")
        self.pause_scan_btn.configure(state="disabled", text="⏸ Pause Scan")
        self.last_scan_label.configure(
            text=f"Last scan: {datetime.now().strftime('%H:%M:%S')} (stopped)"
        )
        
        self._append_to_log("\n" + "=" * 80, "system")
        self._append_to_log("[SYSTEM] SCAN STOPPED", "system")
        self._append_to_log("=" * 80, "system")

    def toggle_pause_scan(self):
        """Toggle between Pause and Resume during an active scan (GUI2 feature)."""
        try:
            status = self.hub.get_scan_status()
            if status.get('is_paused'):
                self.hub.resume_scan()
                self.pause_scan_btn.configure(
                    text="⏸ Pause Scan",
                    fg_color=COLORS.get('accent_orange', '#f59e0b')
                )
                self._append_to_log("[INFO] Scan resumed", "info")
            else:
                self.hub.pause_scan()
                self.pause_scan_btn.configure(
                    text="▶ Resume Scan",
                    fg_color=COLORS.get('accent_green', '#10b981')
                )
                self._append_to_log("[INFO] Scan paused — click Resume to continue", "info")
        except Exception as e:
            self._append_to_log(f"[INFO] Pause/Resume not supported: {e}", "info")
    
    def toggle_monitoring(self):
        """Toggle real-time dynamic protection on/off."""
        if self.monitor_switch and self.monitor_switch.get():
            # Determine the watch path — use selected scan path or home
            watch = [self.selected_path] if self.selected_path else [Path.home()]
            result = self.hub.start_dynamic_protection(watch_paths=watch)
            self.monitoring_active = True
            self.status_label.configure(
                text="🛡️ Protected", text_color=COLORS['accent_green']
            )
            components = ", ".join(k for k, v in result.items() if v) or "none"
            self._append_to_log(
                f"[SYSTEM] Real-time protection STARTED — active monitors: {components}",
                "system"
            )
            # Real-Time Protection tab removed — runs in background
            self._update_rt_badges()
        else:
            self.hub.stop_dynamic_protection()
            self.monitoring_active = False
            self.status_label.configure(
                text="System Protected", text_color=COLORS['accent_green']
            )
            self._append_to_log("[SYSTEM] Real-time protection STOPPED", "system")
            self._update_rt_badges()
    
    def _auto_start_network_monitor(self):
        """Auto-start network monitoring + forensics on GUI launch — Fix 4: auto-running on startup."""
        if not SCAPY_AVAILABLE:
            self._append_to_log(
                "[NET] Network monitor disabled — install scapy: pip install scapy", "info"
            )
        else:
            try:
                ok = self.network_monitor.start(interface=None)
                if ok:
                    try:
                        if self.net_monitor_switch:
                            self.net_monitor_switch.select()
                    except Exception:
                        pass
                    self._append_to_log(
                        "[NET] ✅ Network Monitor running — watching ALL network traffic for attacks",
                        "system"
                    )
                    if not hasattr(self, '_net_alerts_store'):
                        self._net_alerts_store = []
                    if not hasattr(self, '_net_iid_map'):
                        self._net_iid_map = {}
                    # No separate timer — poll_log_buffer heartbeat calls _poll_net_alerts_background
                else:
                    self._append_to_log(
                        "[NET] Network monitor could not start — try running as Administrator", "info"
                    )
            except Exception as e:
                self._append_to_log(f"[NET] Network monitor error: {e}", "info")

        # Fix 4: Always auto-start forensics scan regardless of scapy status
        if self.network_forensics:
            self.after(3000, self._background_forensics_scan)
            self._append_to_log(
                "[FORENSICS] ✅ Network Forensics running — scanning for hidden remote-control threats",
                "system"
            )
        else:
            self._append_to_log("[FORENSICS] Network Forensics not available", "info")

    def _toggle_net_monitor_switch(self):
        """Handle manual toggle of the Network Monitor switch."""
        if self.net_monitor_switch.get():
            self._auto_start_network_monitor()
        else:
            self.network_monitor.stop()
            self._append_to_log("[NET] Network monitor stopped by user.", "info")

    # ── Power On / Off ────────────────────────────────────────────────────────

    def power_off_system(self):
        """
        Stop all monitoring and scanning without erasing any logs.
        The Live Logs tab retains all entries made up to this point.
        A new log entry explains the powered-off state.
        """
        if getattr(self, '_system_powered_off', False):
            return   # already off — do nothing
        self._system_powered_off = True

        # ── Stop real-time dynamic protection ────────────────────────────────
        try:
            if self.monitoring_active:
                self.hub.stop_dynamic_protection()
                self.monitoring_active = False
                if self.net_monitor_switch:
                    self.net_monitor_switch.deselect()
        except Exception:
            pass

        # ── Stop network monitor ──────────────────────────────────────────────
        try:
            self.network_monitor.stop()
            self.net_monitor_switch.deselect()
        except Exception:
            pass

        # ── Stop active file scan (if running) ───────────────────────────────
        try:
            if self.is_scanning:
                self.hub.stop_scan()
                self.is_scanning = False
                self.start_scan_btn.configure(state="disabled")
                self.stop_scan_btn.configure(state="disabled")
                self.pause_scan_btn.configure(state="disabled", text="⏸ Pause Scan")
        except Exception:
            pass

        # ── Update sidebar buttons ────────────────────────────────────────────
        self.btn_power_off.configure(state="disabled", fg_color="#555555")
        self.btn_power_on.configure(state="normal",   fg_color="#27ae60")

        # ── Update status indicator ───────────────────────────────────────────
        self.status_indicator.configure(text="🔴")
        self.status_label.configure(
            text="System OFF", text_color=COLORS['accent_red']
        )

        # ── Append log without clearing any previous entries ──────────────────
        self._append_to_log(
            "[POWER] ⛔ System is currently in power-off state. "
            "All real-time monitoring and network monitoring have been suspended. "
            "Click ⏻ ON to resume protection.",
            "system"
        )

    def power_on_system(self):
        """
        Resume all monitoring from power-off state.
        All previous log entries (including the power-off notice) are preserved;
        a new entry confirms that monitoring has resumed.
        """
        if not getattr(self, '_system_powered_off', False):
            return   # already on — do nothing
        self._system_powered_off = False

        # ── Resume real-time dynamic protection ──────────────────────────────
        try:
            watch = [self.selected_path] if self.selected_path else [Path.home()]
            result = self.hub.start_dynamic_protection(watch_paths=watch)
            self.monitoring_active = True
            self.monitor_switch.select()
        except Exception:
            pass

        # ── Resume network monitor ────────────────────────────────────────────
        try:
            self._auto_start_network_monitor()
        except Exception:
            pass

        # ── Re-enable scan controls ───────────────────────────────────────────
        try:
            self.start_scan_btn.configure(state="normal")
        except Exception:
            pass

        # ── Update sidebar buttons ────────────────────────────────────────────
        self.btn_power_on.configure(state="disabled",  fg_color="#555555")
        self.btn_power_off.configure(state="normal",   fg_color="#c0392b")

        # ── Update status indicator ───────────────────────────────────────────
        self.status_indicator.configure(text="🟢")
        self.status_label.configure(
            text="System Protected", text_color=COLORS['accent_green']
        )

        # ── Append log — all previous entries including power-off msg preserved
        self._append_to_log(
            "[POWER] ✅ System powered ON. "
            "Real-time monitoring and network monitoring have resumed successfully.",
            "system"
        )

    def _poll_net_alerts_background(self):
        """
        Drain network alert queue and dispatch to log + plain-English popups.
        Called from poll_log_buffer (main heartbeat) — no independent timer.
        """
        try:
            with self._net_alert_lock:
                pending = self._net_alert_queue[:]
                self._net_alert_queue.clear()

            for alert in pending:
                if not hasattr(self, '_net_alerts_store'):
                    self._net_alerts_store = []
                self._net_alerts_store.append(alert)
                sev_str = alert.severity.value if hasattr(alert.severity, "value") else str(alert.severity)
                cat_str = alert.category.value if hasattr(alert.category, "value") else str(alert.category)

                # ── Increment network threat counters ─────────────────────────
                self._net_threats_count += 1
                if sev_str in ("CRITICAL", "HIGH"):
                    # Sentinel automatically blocks/logs CRITICAL & HIGH — counted as mitigated
                    self._net_mitigated_count += 1

                # ── Refresh network stat cards immediately ────────────────────
                try:
                    self.net_threats_card.configure(text=str(self._net_threats_count))
                    self.net_mitigated_card.configure(text=str(self._net_mitigated_count))
                except Exception:
                    pass

                self._append_to_log(
                    f"[NET-{sev_str}] {cat_str}: {alert.src_ip} → {alert.dst_ip}",
                    "threat" if sev_str in ("CRITICAL", "HIGH") else "info"
                )
                if sev_str in ("CRITICAL", "HIGH"):
                    self.after(50, lambda a=alert, s=sev_str, c=cat_str: self._on_network_attack_plain(
                        c, a.src_ip, a.description, s
                    ))
        except Exception:
            pass

    def _background_forensics_scan(self):
        """
        Continuously run Network Forensics + C2 detection in the background.
        Results are sent to the Live Log. A popup fires only when C2 servers
        are confirmed. Repeats every 5 minutes.
        """
        if not self.network_forensics:
            return

        def _worker():
            try:
                connections = self.network_forensics.capture_connections()
                c2_servers  = self.network_forensics.detect_c2_beaconing()
                summary     = self.network_forensics.get_summary()

                total   = summary.get("total_connections", 0)
                susp    = summary.get("suspicious_connections", 0)
                threat  = summary.get("threat_level", "unknown").upper()

                self.after(0, lambda: self._append_to_log(
                    f"[FORENSICS] Scan complete — {total} connections, "
                    f"{susp} suspicious, threat level: {threat}", "system"
                ))

                if c2_servers:
                    lines_out = [
                        "⚠️  YOUR COMPUTER MAY BE UNDER REMOTE CONTROL",
                        "",
                        "Sentinel has detected that your computer is secretly",
                        "communicating with a remote server. This is often a",
                        "sign of malware (harmful software) on your device.",
                        "",
                        "Suspicious remote address(es) found:",
                    ]
                    for i, c2 in enumerate(c2_servers[:3], 1):
                        ip   = c2.get("remote_ip", "?")
                        conf = int(c2.get("confidence", 0) * 100)
                        lines_out.append("  " + str(i) + ". " + str(ip) + "  (" + str(conf) + "% suspicious)")
                    lines_out += [
                        "",
                        "WHAT TO DO RIGHT NOW:",
                        "1. Disconnect from the internet immediately",
                        "   (unplug the cable or turn off Wi-Fi).",
                        "2. Do NOT open any new files or emails.",
                        "3. Call your IT support or a trusted technician.",
                        "4. Leave the computer ON so it can be inspected.",
                        "",
                        "Sentinel has logged all details for your technician.",
                    ]
                    msg = "\n".join(lines_out)
                    # Fix 4: Use plain-English styled popup instead of raw messagebox
                    self.after(0, lambda m=msg: self._show_security_alert_popup(
                        "malicious_attempt",
                        "🚨  Your Computer May Be Remotely Controlled!",
                        m, "CRITICAL",
                        f"[FORENSICS] ⚠️  {len(c2_servers)} C2 server(s) detected!"
                    ))
                    self.after(0, self._flash_window)

                if susp > 0:
                    self.after(0, lambda: self._append_to_log(
                        f"[FORENSICS] {susp} suspicious connection(s) — check Live Logs",
                        "threat" if susp > 5 else "info"
                    ))
            except Exception as e:
                err = str(e)
                self.after(0, lambda: self._append_to_log(
                    f"[FORENSICS] Background scan error: {err}", "info"
                ))
            finally:
                # Re-schedule every 5 minutes while monitoring is active
                if self._poll_running:
                    self.after(300_000, self._background_forensics_scan)

        threading.Thread(target=_worker, daemon=True).start()

    def generate_report(self):
        """Generate AI-powered PDF report in background thread."""
        self.report_btn.configure(state="disabled", text="AI Analyzing...")
        # Show a status update so user knows it's working
        try:
            self.status_label.configure(text="Generating AI Report...", text_color=COLORS["accent_blue"])
        except Exception:
            pass

        def report_thread():
            try:
                report_path = self.hub.generate_report()
                self.after(0, lambda: self.report_complete(report_path))
            except Exception as e:
                self.after(0, lambda: self.report_failed(str(e)))

        threading.Thread(target=report_thread, daemon=True).start()

    def report_complete(self, report_path):
        """Handle report completion."""
        self.report_btn.configure(state="normal", text="Generate AI Report")
        try:
            self.status_label.configure(text="Report Ready", text_color=COLORS["accent_green"])
        except Exception:
            pass
        if report_path:
            messagebox.showinfo(
                "AI Report Generated",
                f"Report with AI analysis saved to:\n{report_path}"
            )

    def report_failed(self, error):
        """Handle report failure."""
        self.report_btn.configure(state="normal", text="Generate AI Report")
        try:
            self.status_label.configure(text="Report Failed", text_color=COLORS["accent_red"])
        except Exception:
            pass
        messagebox.showerror("Report Error", f"Failed to generate report:\n{error}")
    
    # ==================== QUARANTINE OPERATIONS ====================
    
    def refresh_quarantine(self):
        """Refresh quarantine list."""
        for widget in self.quarantine_scroll.winfo_children():
            widget.destroy()
        
        self.selected_quarantine_ids.clear()
        self.quarantine_checkboxes.clear()
        
        records = self.db.get_quarantine_records(status='quarantined')
        
        if not records:
            ctk.CTkLabel(
                self.quarantine_scroll,
                text="No files in quarantine",
                font=ctk.CTkFont(size=14),
                text_color=COLORS['text_secondary']
            ).pack(pady=50)
            return
        
        for record in records:
            self.create_quarantine_item(record)
    
    def create_quarantine_item(self, record: dict):
        """Create quarantine item with checkbox."""
        item_frame = ctk.CTkFrame(
            self.quarantine_scroll,
            fg_color=COLORS['bg_card'],
            corner_radius=10,
            border_width=2,
            border_color=COLORS['accent_red']
        )
        item_frame.pack(fill="x", padx=5, pady=5)
        
        content = ctk.CTkFrame(item_frame, fg_color="transparent")
        content.pack(fill="x", padx=10, pady=10)
        
        checkbox = ctk.CTkCheckBox(
            content,
            text="",
            width=30,
            command=lambda: self.toggle_quarantine_selection(record['id'])
        )
        checkbox.pack(side="left", padx=(0, 10))
        self.quarantine_checkboxes[record['id']] = checkbox
        
        info_frame = ctk.CTkFrame(content, fg_color="transparent")
        info_frame.pack(side="left", fill="x", expand=True)
        
        ctk.CTkLabel(
            info_frame,
            text=f"🦠 {record['threat_name']}",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLORS['accent_red'],
            anchor="w"
        ).pack(anchor="w")
        
        size_text = self.format_size(record.get('file_size'))
        
        ctk.CTkLabel(
            info_frame,
            text=f"Original: {record['original_path']} ({size_text})",
            font=ctk.CTkFont(size=11),
            text_color=COLORS['text_secondary'],
            anchor="w"
        ).pack(anchor="w", pady=(5, 0))
    
    def format_size(self, size_bytes) -> str:
        """Format file size."""
        if size_bytes is None:
            size_bytes = 0
        
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        
        return f"{size_bytes:.1f} TB"
    
    def toggle_quarantine_selection(self, qid: int):
        """Toggle selection."""
        if qid in self.selected_quarantine_ids:
            self.selected_quarantine_ids.remove(qid)
        else:
            self.selected_quarantine_ids.add(qid)
        
        has_selection = len(self.selected_quarantine_ids) > 0
        state = "normal" if has_selection else "disabled"
        self.restore_selected_btn.configure(state=state)
        self.delete_selected_btn.configure(state=state)
    
    def select_all_quarantine(self):
        """Select all."""
        for qid, checkbox in self.quarantine_checkboxes.items():
            checkbox.select()
            self.selected_quarantine_ids.add(qid)
        
        self.restore_selected_btn.configure(state="normal")
        self.delete_selected_btn.configure(state="normal")
    
    def deselect_all_quarantine(self):
        """Deselect all."""
        for checkbox in self.quarantine_checkboxes.values():
            checkbox.deselect()
        
        self.selected_quarantine_ids.clear()
        self.restore_selected_btn.configure(state="disabled")
        self.delete_selected_btn.configure(state="disabled")
    
    def restore_selected_quarantine(self):
        """Restore selected."""
        if not self.selected_quarantine_ids:
            return
        
        count = len(self.selected_quarantine_ids)
        response = messagebox.askyesno(
            "Restore Files",
            f"Restore {count} selected file(s)?"
        )
        
        if response:
            success_count = 0
            failed_count = 0
            for qid in list(self.selected_quarantine_ids):
                if self.hub.restore_file(qid):
                    success_count += 1
                else:
                    failed_count += 1

            message = f"Restored {success_count} file(s)"
            if failed_count:
                message += f"; failed to restore {failed_count} file(s). See log for details."
            messagebox.showinfo("Success", message)
    def delete_selected_quarantine(self):
        """Delete selected."""
        if not self.selected_quarantine_ids:
            return
        
        count = len(self.selected_quarantine_ids)
        response = messagebox.askyesno(
            "Delete Files",
            f"PERMANENTLY delete {count} selected file(s)?\nThis cannot be undone."
        )
        
        if response:
            success_count = 0
            for qid in list(self.selected_quarantine_ids):
                if self.hub.delete_quarantined_file(qid):
                    success_count += 1
            
            messagebox.showinfo("Success", f"Deleted {success_count} file(s)")
            self.refresh_quarantine()
    
    # ==================== NETWORK MONITOR TAB ====================

    def create_network_monitor_tab(self):
        """Network Monitor tab removed — network monitoring runs automatically in background.
        Status is shown via the sidebar icon. This method is kept to avoid crashes."""
        pass
    # ── Interface name resolver ───────────────────────────────────────────────

    def _open_iface_picker(self):
        """
        Opens a compact scrollable interface picker popup.
        Shows max 10 items at a time with a search box to filter.
        Replaces the giant CTkOptionMenu that dumps all 40+ items at once.
        """
        import tkinter as tk

        friendly_names = list(self._iface_map.keys())

        dlg = ctk.CTkToplevel(self)
        dlg.title("Select Network Interface")
        dlg.resizable(False, False)
        dlg.grab_set()
        dlg.lift()
        dlg.focus_force()

        DLG_W, DLG_H = 460, 380
        self.update_idletasks()
        # Position just below the interface button
        px = self.winfo_x() + (self.winfo_width() - DLG_W) // 2
        py = self.winfo_y() + 120
        dlg.geometry(f"{DLG_W}x{DLG_H}+{max(0,px)}+{max(0,py)}")

        DARK  = COLORS['bg_card']
        DARK2 = COLORS['bg_secondary']
        TEXT  = COLORS['text_primary']
        SUB   = COLORS['text_secondary']

        outer = ctk.CTkFrame(dlg, fg_color=DARK, corner_radius=0)
        outer.pack(fill="both", expand=True)

        # ── Header ─────────────────────────────────────────────────────────
        ctk.CTkLabel(outer, text="🌐  Select Network Interface",
                     font=ctk.CTkFont(size=13, weight="bold"),
                     text_color=COLORS['accent_blue']).pack(pady=(12,6), padx=16, anchor="w")

        # ── Search box ──────────────────────────────────────────────────────
        search_var = ctk.StringVar()
        search_box = ctk.CTkEntry(
            outer, textvariable=search_var,
            placeholder_text="🔍  Type to filter...",
            height=30, corner_radius=8,
            fg_color=DARK2, border_color=COLORS['accent_blue'],
            font=ctk.CTkFont(size=11)
        )
        search_box.pack(fill="x", padx=16, pady=(0,6))
        search_box.focus()

        # ── Scrollable list ─────────────────────────────────────────────────
        list_frame = ctk.CTkScrollableFrame(
            outer, fg_color=DARK2, corner_radius=8,
            height=260
        )
        list_frame.pack(fill="both", expand=True, padx=16, pady=(0,8))
        list_frame.columnconfigure(0, weight=1)

        # Track highlighted row
        _rows: list = []

        def _populate(filter_text=""):
            for w in list_frame.winfo_children():
                w.destroy()
            _rows.clear()
            ft = filter_text.strip().lower()

            for name in friendly_names:
                if ft and ft not in name.lower():
                    continue

                is_selected = (name == self._net_iface_var.get())
                row_bg = COLORS['accent_blue'] if is_selected else DARK

                row = ctk.CTkFrame(list_frame, fg_color=row_bg, corner_radius=6,
                                   height=32, cursor="hand2")
                row.pack(fill="x", pady=2, padx=2)
                row.pack_propagate(False)

                ctk.CTkLabel(row, text=name,
                             font=ctk.CTkFont(size=10),
                             text_color=TEXT if is_selected else SUB,
                             anchor="w").pack(fill="x", padx=10, pady=6)

                def _select(n=name, d=dlg):
                    self._net_iface_var.set(n)
                    d.destroy()

                row.bind("<Button-1>", lambda e, fn=_select: fn())
                for child in row.winfo_children():
                    child.bind("<Button-1>", lambda e, fn=_select: fn())

                _rows.append(row)

        _populate()

        def _on_search(*_):
            _populate(search_var.get())

        search_var.trace_add("write", _on_search)

        # ── Footer count ────────────────────────────────────────────────────
        count_lbl = ctk.CTkLabel(outer,
                                  text=f"{len(friendly_names)} interface(s) found",
                                  font=ctk.CTkFont(size=9), text_color=SUB)
        count_lbl.pack(pady=(0,8))

        def _update_count(*_):
            ft = search_var.get().strip().lower()
            n = sum(1 for nm in friendly_names if not ft or ft in nm.lower())
            count_lbl.configure(text=f"{n} of {len(friendly_names)} interface(s)")

        search_var.trace_add("write", _update_count)

    def _build_iface_map(self) -> dict:
        """
        Returns an OrderedDict of  { friendly_label : raw_npf_path }
        so the dropdown shows human-readable names while Scapy still gets
        the raw Device/NPF_{...} string it needs.

        Resolution priority:
          1. scapy.arch.windows.get_windows_if_list()  (name + description)
          2. psutil.net_if_stats()                     (fallback on Linux/Mac)
          3. Raw NPF paths with cleaned-up labels      (last resort)
        """
        from collections import OrderedDict
        result: dict = OrderedDict()

        # ── Windows: use Scapy's own Windows interface list ─────────────────
        try:
            from scapy.arch.windows import get_windows_if_list
            win_ifaces = get_windows_if_list()
            TYPE_ICONS = {
                "Wi-Fi":      "📶",
                "Wireless":   "📶",
                "Ethernet":   "🔌",
                "Local Area": "🔌",
                "Loopback":   "🔁",
                "Bluetooth":  "🔷",
                "VirtualBox": "📦",
                "VMware":     "📦",
                "vEthernet":  "📦",
                "Hyper-V":    "📦",
                "TAP":        "🔧",
                "WAN":        "🌐",
            }

            def _icon(name: str, desc: str) -> str:
                combined = name + " " + desc
                for kw, ico in TYPE_ICONS.items():
                    if kw.lower() in combined.lower():
                        return ico
                return "🌐"

            for ifc in win_ifaces:
                name  = (ifc.get("name")        or "").strip()
                desc  = (ifc.get("description") or "").strip()
                guid  = (ifc.get("guid")        or "").strip()
                npf   = (ifc.get("win_index")   or ifc.get("name") or "").strip()

                # Build the \Device\NPF_{GUID} path Scapy sniff() wants
                if guid and not guid.startswith("\\"):
                    raw_path = f"\\Device\\NPF_{{{guid}}}"
                else:
                    raw_path = npf  # already a full path or interface name

                if not raw_path:
                    continue

                ico   = _icon(name, desc)
                label = f"{ico}  {name}" if name else f"{ico}  {desc}"
                if desc and desc != name:
                    label += f"  —  {desc[:45]}"

                # Deduplicate labels
                base_label, n = label, 1
                while label in result:
                    n += 1
                    label = f"{base_label} ({n})"

                result[label] = raw_path

            if result:
                result["🔁  Default (auto-select)"] = "__default__"
                return result
        except Exception:
            pass

        # ── Cross-platform fallback: psutil ──────────────────────────────────
        try:
            import psutil
            stats = psutil.net_if_stats()
            addrs = psutil.net_if_addrs()
            raw_ifaces = NetworkMonitor.list_interfaces() or []

            # Map psutil name → raw NPF path heuristically
            for raw in raw_ifaces:
                matched_name = None
                for ps_name in stats:
                    if ps_name.lower() in raw.lower() or raw.lower().endswith(ps_name.lower()):
                        matched_name = ps_name
                        break

                if matched_name:
                    is_up  = stats[matched_name].isup
                    speed  = stats[matched_name].speed
                    up_str = "▲ UP" if is_up else "▼ DOWN"
                    spd_str = f" {speed}Mbps" if speed > 0 else ""
                    label  = f"🌐  {matched_name}  [{up_str}{spd_str}]"
                else:
                    # Last resort: trim the GUID to something shorter
                    short = raw.replace("\\Device\\NPF_", "NPF_")
                    label = f"🌐  {short}"

                result[label] = raw

            if result:
                result["🔁  Default (auto-select)"] = "__default__"
                return result
        except Exception:
            pass

        # ── Absolute fallback: raw list with shortened labels ────────────────
        for raw in (NetworkMonitor.list_interfaces() or []):
            short = raw.replace("\\Device\\NPF_", "").strip("{}")[:20]
            label = f"🌐  {short}" if short else raw
            result[label] = raw

        result["🔁  Default (auto-select)"] = "__default__"
        return result

    def start_network_monitor(self):
        """Manual start — delegates to auto-start logic."""
        self._auto_start_network_monitor()

    def stop_network_monitor(self):
        """Stop the background network monitor."""
        self.network_monitor.stop()
        try:
            self.net_monitor_switch.deselect()
        except Exception:
            pass
        self._append_to_log("[NET] Network capture stopped.", "info")

    def clear_network_alerts(self):
        """Clear all captured network alerts."""
        self.network_monitor.clear_alerts()
        with self._net_alert_lock:
            self._net_alert_queue.clear()
        if hasattr(self, '_net_alerts_store'):
            self._net_alerts_store.clear()
        if hasattr(self, '_net_iid_map'):
            self._net_iid_map.clear()
        self._append_to_log("[NET] Network alerts cleared.", "info")

    # ── Network alert callback (worker thread) ────────────────────────────────

    def _on_network_alert(self, alert: NetworkAlert):
        """Called from network capture thread — only enqueue, never touch GUI."""
        with self._net_alert_lock:
            self._net_alert_queue.append(alert)

    # ── Network alert GUI poll (main thread) ─────────────────────────────────

    def _poll_net_alerts(self):
        """Legacy stub — network alert polling is now handled by _poll_net_alerts_background."""
        # This method is kept as a no-op so any existing after() calls don't crash
        pass

    def _add_net_alert_row(self, alert: NetworkAlert):
        """Insert one alert row into the network treeview."""
        try:
            t = alert.timestamp.split("T")[-1] if "T" in alert.timestamp else alert.timestamp[-8:]
            sev_icons = {
                "CRITICAL": "🔴 CRITICAL",
                "HIGH":     "🟠 HIGH",
                "MEDIUM":   "🟡 MEDIUM",
                "LOW":      "🔵 LOW",
                "INFO":     "⚪ INFO",
            }
            # category is an enum — get its plain string value for display
            cat_str   = alert.category.value if hasattr(alert.category, "value") else str(alert.category)
            sev_str   = alert.severity.value if hasattr(alert.severity, "value") else str(alert.severity)
            desc_short = alert.description[:100] + "…" if len(alert.description) > 100 else alert.description

            iid = self.net_table.insert(
                "", "end",
                values=(t, sev_icons.get(sev_str, sev_str),
                        cat_str, alert.src_ip, alert.dst_ip, desc_short),
                tags=(sev_str,)
            )
            # ── KEY FIX: store alert object keyed by iid so selection always works ──
            self._net_iid_map[iid] = alert

            # Auto-scroll to latest
            self.net_table.see(iid)
            # Flash log
            self._append_to_log(
                f"[NET-{sev_str}] {cat_str}: {alert.src_ip} → {alert.dst_ip}",
                "threat" if sev_str in ("CRITICAL", "HIGH") else "info"
            )
        except Exception as e:
            print(f"Row insert error: {e}")

    def _on_net_alert_select(self, event):
        """Show full alert detail when user clicks a row — uses iid map for O(1) lookup."""
        selection = self.net_table.selection()
        if not selection:
            return
        iid   = selection[0]
        found = self._net_iid_map.get(iid)
        if not found:
            return

        # Safely extract enum values for display
        sev_str = found.severity.value if hasattr(found.severity, "value") else str(found.severity)
        cat_str = found.category.value if hasattr(found.category, "value") else str(found.category)

        SEV_COLORS = {
            "CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵", "INFO": "⚪"
        }
        icon = SEV_COLORS.get(sev_str, "⚪")

        detail = (
            f"{icon} {sev_str}  —  {cat_str}\n"
            f"{'─'*50}\n"
            f"Alert ID    : {found.alert_id}\n"
            f"Timestamp   : {found.timestamp}\n"
            f"Protocol    : {found.protocol}\n"
            f"Source IP   : {found.src_ip}  (port {found.src_port})\n"
            f"Source MAC  : {found.src_mac or 'n/a'}\n"
            f"Dest IP     : {found.dst_ip}  (port {found.dst_port})\n"
            f"Dest MAC    : {found.dst_mac or 'n/a'}\n"
            f"\nDESCRIPTION\n{'─'*40}\n{found.description}\n"
            f"\nMITRE ATT&CK\n{'─'*40}\n{found.mitre_tactic}\n"
            f"\nRECOMMENDED ACTION\n{'─'*40}\n{found.recommendation}\n"
            f"\nRAW PACKET SUMMARY\n{'─'*40}\n{found.raw_summary}\n"
        )
        self.net_detail_box.configure(state="normal")
        self.net_detail_box.delete("1.0", "end")
        self.net_detail_box.insert("end", detail)
        self.net_detail_box.configure(state="disabled")

    def _show_critical_net_popup(self, alert: NetworkAlert):
        """Modal popup for CRITICAL network alerts with MITRE info."""
        short_desc = alert.description[:300]
        msg = (
            f"🔴  CRITICAL NETWORK ATTACK DETECTED\n"
            f"{'─'*50}\n"
            f"Attack Type : {alert.category}\n"
            f"Source      : {alert.src_ip}  [{alert.src_mac}]\n"
            f"Destination : {alert.dst_ip}\n"
            f"Protocol    : {alert.protocol}\n\n"
            f"DESCRIPTION:\n{short_desc}\n\n"
            f"MITRE ATT&CK: {alert.mitre_tactic}\n\n"
            f"IMMEDIATE ACTION:\n{alert.recommendation}\n\n"
            f"Switch to the 🌐 Network Monitor tab for full details."
        )
        self.title("🔴 CRITICAL NETWORK ATTACK [WARNING]️")
        self.after(3000, lambda: self.title("Sentinel Defender v5.0 - Deep Protection"))
        messagebox.showwarning("[WARNING]️  Critical Network Attack!", msg)

    # ==================== HARDWARE MONITOR TAB ====================

    def create_admin_privilege_tab(self):
        tab = self.tabview.tab("\U0001f510 Admin Privilege Monitor")
        tab.grid_rowconfigure(0, weight=1)
        tab.grid_columnconfigure(0, weight=1)

        import tkinter.ttk as ttk
        import hashlib, os, time
        from pathlib import Path

        _VAULT_DIR = Path("data") / "admin"
        _ADM_VAULT = _VAULT_DIR / "adm_vault.dat"
        _MAGIC     = "SENTINEL_V2"

        def _hash_pw(pw):
            raw = f"{_MAGIC}:{pw}:{_MAGIC[::-1]}"
            return hashlib.sha256(raw.encode()).hexdigest()
        def _vis(): return _ADM_VAULT.exists() and _ADM_VAULT.stat().st_size > 10
        def _vset(pw):
            _VAULT_DIR.mkdir(parents=True, exist_ok=True)
            _ADM_VAULT.write_text(_hash_pw(pw))
        def _vok(candidate):
            if not _vis(): return False
            return _ADM_VAULT.read_text().strip() == _hash_pw(candidate)
        def _vclr():
            if _ADM_VAULT.exists(): _ADM_VAULT.unlink()
        def _pw_str(pw):
            s = 0
            if len(pw) >= 8:  s += 0.25
            if len(pw) >= 12: s += 0.15
            if any(c.isupper() for c in pw): s += 0.2
            if any(c.isdigit() for c in pw): s += 0.2
            if any(c in "!@#$%^&*()-_=+" for c in pw): s += 0.2
            s = min(s, 1.0)
            if s < 0.4: return s, "Weak",        "#ef4444"
            if s < 0.7: return s, "Fair",        "#f59e0b"
            if s < 0.9: return s, "Strong",      "#10b981"
            return s,   "Very Strong", "#3b82f6"

        self._adm_counts     = {"detected": 0, "blocked": 0, "approved": 0}
        self._adm_start_ts   = time.time()
        self._adm_popup_open = False

        scroll = ctk.CTkScrollableFrame(tab, fg_color="transparent", corner_radius=0)
        scroll.grid(row=0, column=0, sticky="nsew")
        scroll.grid_columnconfigure(0, weight=1)

        # HEADER
        banner = ctk.CTkFrame(scroll, fg_color=COLORS["bg_card"], corner_radius=14)
        banner.pack(fill="x", padx=18, pady=(18, 0))
        ctk.CTkLabel(banner, text="\U0001f6e1\ufe0f  Admin Privilege Monitor",
            font=ctk.CTkFont(size=20, weight="bold"), text_color=COLORS["accent_blue"],
        ).pack(side="left", padx=22, pady=16)
        self._adm_vault_badge = ctk.CTkLabel(banner, text="",
            font=ctk.CTkFont(size=11, weight="bold"), corner_radius=8, width=150)
        self._adm_vault_badge.pack(side="right", padx=22)
        def _rbadge():
            self._adm_vault_badge.configure(
                text="\U0001f511 Password Set" if _vis() else "\u26a0  No Password",
                text_color="#10b981" if _vis() else "#f59e0b")
        _rbadge()
        ctk.CTkLabel(banner,
            text="Every privilege escalation triggers a password challenge.\n"
                 "Deny or close X = process terminated + escalated window destroyed.",
            font=ctk.CTkFont(size=12), text_color=COLORS["text_secondary"], justify="left",
        ).pack(side="left", padx=(0, 22), pady=16)

        # STATS ROW
        sf = ctk.CTkFrame(scroll, fg_color=COLORS["bg_secondary"], corner_radius=12)
        sf.pack(fill="x", padx=18, pady=(12, 0))
        sf.grid_columnconfigure((0, 1, 2, 3), weight=1)
        def _scell(col, label, attr, color):
            f = ctk.CTkFrame(sf, fg_color="transparent")
            f.grid(row=0, column=col, padx=10, pady=14)
            lbl = ctk.CTkLabel(f, text="0", font=ctk.CTkFont(size=24, weight="bold"), text_color=color)
            lbl.pack()
            ctk.CTkLabel(f, text=label, font=ctk.CTkFont(size=10), text_color=COLORS["text_secondary"]).pack()
            setattr(self, attr, lbl)
        _scell(0, "Detected",   "_adm_stat_detected",  COLORS["accent_blue"])
        _scell(1, "Blocked",    "_adm_stat_blocked",   COLORS["accent_red"])
        _scell(2, "Approved",   "_adm_stat_approved",  COLORS["accent_green"])
        _scell(3, "Uptime (s)", "_adm_stat_uptime",    COLORS["text_secondary"])
        def _stat_tick():
            # Uptime label updated lazily — no independent timer needed;
            # the main poll_log_buffer heartbeat will call _upd_adm_uptime() every cycle
            if hasattr(self, "_adm_stat_uptime"):
                self._adm_stat_uptime.configure(text=str(int(time.time() - self._adm_start_ts)))
        self._adm_stat_tick_fn = _stat_tick   # stored so heartbeat can call it
        def _upd_stats():
            c = self._adm_counts
            for k, a in [("detected","_adm_stat_detected"),("blocked","_adm_stat_blocked"),("approved","_adm_stat_approved")]:
                if hasattr(self, a): getattr(self, a).configure(text=str(c.get(k, 0)))

        # MONITOR CONTROLS
        ctrl = ctk.CTkFrame(scroll, fg_color=COLORS["bg_card"], corner_radius=14)
        ctrl.pack(fill="x", padx=18, pady=(10, 0))
        ctk.CTkLabel(ctrl, text="\U0001f6e1\ufe0f  Monitor Controls",
            font=ctk.CTkFont(size=14, weight="bold"), text_color=COLORS["text_primary"],
        ).pack(side="left", padx=20, pady=14)
        self._adm_mon_running = False
        def _toggle_mon():
            mon = getattr(self, "admin_priv_monitor", None)
            if mon is None:
                self._adm_tog_btn.configure(text="\u26a0 Monitor N/A"); return
            if not self._adm_mon_running:
                try:
                    mon.start()
                    self._adm_mon_running = True
                    self._adm_start_ts = time.time()
                    self._adm_tog_btn.configure(text="\u23f9  Stop Monitor",
                        fg_color=COLORS["accent_red"], hover_color="#dc2626")
                    _alog("INFO","sentinel","system","Monitor started","RUNNING")
                except Exception as e:
                    _alog("INFO","sentinel","system",f"Start err: {e}","ERROR")
            else:
                try: mon.stop()
                except Exception: pass
                self._adm_mon_running = False
                self._adm_tog_btn.configure(text="\u25b6  Start Monitor",
                    fg_color=COLORS["accent_green"], hover_color="#0d9668")
                _alog("INFO","sentinel","system","Monitor stopped","STOPPED")
        self._adm_tog_btn = ctk.CTkButton(ctrl, text="\u23f9  Stop Monitor",
            command=_toggle_mon, height=38, corner_radius=10, width=160,
            fg_color=COLORS["accent_red"], hover_color="#dc2626",
            font=ctk.CTkFont(size=12, weight="bold"))
        self._adm_tog_btn.pack(side="right", padx=(8, 8), pady=14)
        # Auto-start monitor when tab is created
        self.after(500, _toggle_mon)
        def _fire_test():
            mon = getattr(self, "admin_priv_monitor", None)
            if mon:
                try: mon.inject_test_event(); return
                except Exception: pass
            class _Fake:
                class severity:
                    value = "HIGH"
                process_name = "sentinel_test.exe"
                process_id   = os.getpid()
                user         = os.environ.get("USERNAME", os.environ.get("USER","testuser"))
                description  = "\U0001f9ea TEST: Simulated privilege escalation"
            _adm_handle(_Fake(), getattr(_Fake, "process_id", 0))
        ctk.CTkButton(ctrl, text="\U0001f9ea  Fire Test Event",
            command=_fire_test, height=38, corner_radius=10, width=160,
            fg_color=COLORS["accent_orange"], hover_color="#d97706",
            font=ctk.CTkFont(size=12, weight="bold"),
        ).pack(side="right", padx=(0, 8), pady=14)

        # SET / CHANGE PASSWORD
        pc = ctk.CTkFrame(scroll, fg_color=COLORS["bg_card"], corner_radius=14)
        pc.pack(fill="x", padx=18, pady=(12, 0))
        pc.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(pc, text="\U0001f4be  Set / Change Admin Challenge Password",
            font=ctk.CTkFont(size=14, weight="bold"), text_color=COLORS["text_primary"],
        ).grid(row=0, column=0, columnspan=3, sticky="w", padx=20, pady=(16, 8))
        self._adm_cur_var  = ctk.StringVar()
        self._adm_new_var  = ctk.StringVar()
        self._adm_conf_var = ctk.StringVar()
        def _fld(ri, label, var, border):
            ctk.CTkLabel(pc, text=label, anchor="e", width=255,
                font=ctk.CTkFont(size=12), text_color=COLORS["text_secondary"],
            ).grid(row=ri, column=0, padx=(20, 8), pady=4)
            e = ctk.CTkEntry(pc, textvariable=var, show="\u25cf",
                height=38, corner_radius=8, border_color=border, font=ctk.CTkFont(size=13))
            e.grid(row=ri, column=1, padx=(0, 20), pady=4, sticky="ew")
            return e
        _fld(1, "Current Password (leave empty to force reset):", self._adm_cur_var,  COLORS["text_secondary"])
        _fld(2, "New Password:",                                   self._adm_new_var,  COLORS["accent_blue"])
        _fld(3, "Confirm New Password:",                           self._adm_conf_var, COLORS["accent_blue"])
        self._adm_conf_match = ctk.CTkLabel(pc, text="", width=28, font=ctk.CTkFont(size=16))
        self._adm_conf_match.grid(row=3, column=2, padx=(4, 18), pady=4)
        ctk.CTkLabel(pc, text="Strength:", anchor="e", width=255,
            font=ctk.CTkFont(size=11), text_color=COLORS["text_secondary"],
        ).grid(row=4, column=0, padx=(20, 8), pady=(2, 4))
        self._adm_strength_bar = ctk.CTkProgressBar(pc, height=10, corner_radius=5)
        self._adm_strength_bar.grid(row=4, column=1, sticky="ew", padx=(0, 8), pady=(2, 4))
        self._adm_strength_bar.set(0)
        self._adm_strength_lbl = ctk.CTkLabel(pc, text="", width=80, font=ctk.CTkFont(size=11))
        self._adm_strength_lbl.grid(row=4, column=2, padx=(0, 18), pady=(2, 4))
        self._adm_pw_feedback = ctk.CTkLabel(pc, text="", font=ctk.CTkFont(size=11), text_color=COLORS["accent_red"])
        self._adm_pw_feedback.grid(row=5, column=0, columnspan=3, pady=(4, 0))
        psr = ctk.CTkFrame(pc, fg_color="transparent")
        psr.grid(row=6, column=0, columnspan=3, sticky="ew", padx=20, pady=(8, 16))
        psr.grid_columnconfigure(0, weight=1)
        def _save_pw():
            cur, new, conf = self._adm_cur_var.get(), self._adm_new_var.get(), self._adm_conf_var.get()
            fb = self._adm_pw_feedback
            if _vis() and cur and not _vok(cur):
                fb.configure(text="\u274c Current password incorrect.", text_color=COLORS["accent_red"]); return
            if not new:
                fb.configure(text="\u274c Password cannot be empty.", text_color=COLORS["accent_red"]); return
            if new != conf:
                fb.configure(text="\u274c Passwords do not match.", text_color=COLORS["accent_red"]); return
            if len(new) < 6:
                fb.configure(text="\u274c Minimum 6 characters.", text_color=COLORS["accent_red"]); return
            _vset(new)
            fb.configure(text="\u2705 Password saved.", text_color=COLORS["accent_green"])
            for v in (self._adm_cur_var, self._adm_new_var, self._adm_conf_var): v.set("")
            _rbadge()
            _alog("INFO","sentinel","sentinel","Admin password updated","SET")
        def _upd_str(*_):
            sc, lb, co = _pw_str(self._adm_new_var.get())
            self._adm_strength_bar.set(sc)
            self._adm_strength_bar.configure(progress_color=co)
            self._adm_strength_lbl.configure(text=lb, text_color=co)
        def _upd_mtch(*_):
            n, c = self._adm_new_var.get(), self._adm_conf_var.get()
            if not c: self._adm_conf_match.configure(text="")
            elif n == c: self._adm_conf_match.configure(text="\u2705", text_color="#10b981")
            else: self._adm_conf_match.configure(text="\u274c", text_color="#ef4444")
        self._adm_new_var.trace_add("write",  _upd_str)
        self._adm_conf_var.trace_add("write", _upd_mtch)
        self._adm_new_var.trace_add("write",  _upd_mtch)
        psr.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkButton(psr, text="\U0001f4be  Save Password", command=_save_pw,
            height=44, corner_radius=10, fg_color=COLORS["accent_blue"], hover_color="#2563eb",
            font=ctk.CTkFont(size=13, weight="bold"),
        ).grid(row=0, column=0, padx=(0, 4), sticky="ew")

        # Fix 2: Reset / Clear password button
        def _reset_pw():
            cur = self._adm_cur_var.get()
            fb  = self._adm_pw_feedback
            if not _vis():
                fb.configure(text="\u274c No password is currently set.", text_color=COLORS["accent_red"]); return
            if not cur:
                fb.configure(text="\u274c Enter current password to reset.", text_color=COLORS["accent_red"]); return
            if not _vok(cur):
                fb.configure(text="\u274c Incorrect current password.", text_color=COLORS["accent_red"]); return
            _vclr()
            fb.configure(text="\u2705 Password removed. Tab is now unprotected.", text_color=COLORS["accent_green"])
            for v in (self._adm_cur_var, self._adm_new_var, self._adm_conf_var): v.set("")
            _rbadge()
            _alog("INFO", "sentinel", "sentinel", "Admin password reset/removed", "RESET")
        ctk.CTkButton(psr, text="\U0001f504  Reset Password", command=_reset_pw,
            height=44, corner_radius=10, fg_color=COLORS["accent_red"], hover_color="#dc2626",
            font=ctk.CTkFont(size=13, weight="bold"),
        ).grid(row=0, column=1, padx=(4, 0), sticky="ew")

        # EVENT LOG
        lh = ctk.CTkFrame(scroll, fg_color=COLORS["bg_card"], corner_radius=12)
        lh.pack(fill="x", padx=18, pady=(14, 0))
        ctk.CTkLabel(lh, text="\U0001f4cb  Privilege Escalation Event Log",
            font=ctk.CTkFont(size=14, weight="bold"), text_color=COLORS["text_primary"],
        ).pack(side="left", padx=18, pady=12)
        def _clr():
            for i in self._adm_tree.get_children(): self._adm_tree.delete(i)
        ctk.CTkButton(lh, text="\U0001f5d1 Clear", command=_clr,
            width=90, height=32, corner_radius=8,
            fg_color=COLORS["bg_secondary"], hover_color=COLORS["accent_red"],
            font=ctk.CTkFont(size=11),
        ).pack(side="right", padx=18, pady=12)
        lw = ctk.CTkFrame(scroll, fg_color=COLORS["bg_secondary"], corner_radius=12)
        lw.pack(fill="x", padx=18, pady=(0, 18))
        sty = ttk.Style()
        sty.theme_use("default")
        sty.configure("ADM.Treeview",
            background=COLORS["bg_secondary"], foreground=COLORS["text_primary"],
            fieldbackground=COLORS["bg_secondary"], rowheight=26, font=("Consolas", 11))
        sty.configure("ADM.Treeview.Heading",
            background=COLORS["bg_card"], foreground=COLORS["text_secondary"],
            font=("Segoe UI", 10, "bold"))
        sty.map("ADM.Treeview", background=[("selected", COLORS["accent_blue"])])
        cols = ("timestamp","severity","process","user","description","status")
        self._adm_tree = ttk.Treeview(lw, columns=cols, show="headings", height=12, style="ADM.Treeview")
        for col, w, head in [
            ("timestamp",160,"Timestamp"),("severity",90,"Severity"),
            ("process",130,"Process"),("user",90,"User"),
            ("description",320,"Description"),("status",90,"Status"),
        ]:
            self._adm_tree.heading(col, text=head)
            self._adm_tree.column(col, width=w, anchor="w")
        vsb = ttk.Scrollbar(lw, orient="vertical", command=self._adm_tree.yview)
        self._adm_tree.configure(yscrollcommand=vsb.set)
        self._adm_tree.pack(side="left", fill="x", expand=True, padx=(10, 0), pady=10)
        vsb.pack(side="right", fill="y", pady=10, padx=(0, 10))
        self._adm_tree.tag_configure("critical", foreground="#ef4444")
        self._adm_tree.tag_configure("high",     foreground="#f59e0b")
        self._adm_tree.tag_configure("medium",   foreground="#3b82f6")
        self._adm_tree.tag_configure("approved", foreground="#10b981")
        self._adm_tree.tag_configure("blocked",  foreground="#ef4444")
        self._adm_tree.tag_configure("info",     foreground=COLORS["text_secondary"])

        def _alog(severity, process, user, desc, status):
            ts  = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            sev = str(severity).upper()
            tag = {"CRITICAL":"critical","HIGH":"high","MEDIUM":"medium",
                   "APPROVED":"approved","BLOCKED":"blocked"}.get(sev,"info")
            if status == "APPROVED": tag = "approved"
            if status in ("BLOCKED","DENIED"): tag = "blocked"
            if hasattr(self, "_adm_tree"):
                self._adm_tree.insert("", "end",
                    values=(ts, sev, process, user, desc[:80], status), tags=(tag,))
                self._adm_tree.yview_moveto(1.0)

        def _upd_last(new_status):
            children = self._adm_tree.get_children()
            if children:
                last = children[-1]
                vals = list(self._adm_tree.item(last, "values"))
                if len(vals) >= 6:
                    vals[5] = new_status
                    tag = "approved" if new_status == "APPROVED" else "blocked"
                    self._adm_tree.item(last, values=vals, tags=(tag,))

        def _kill_proc(pid, proc_name="", target_pids=None):
            """
            Kill ONLY the specific processes that triggered the UAC escalation.
            target_pids: set of PIDs identified at event time as the requestor chain.
            """
            import threading as _thr

            def _do_kill():
                _SENTINEL_PIDS = {os.getpid()}
                # Also protect parent of sentinel (the terminal/launcher)
                try:
                    import psutil as _ps
                    _me = _ps.Process(os.getpid())
                    _pp = _me.parent()
                    if _pp: _SENTINEL_PIDS.add(_pp.pid)
                except Exception:
                    pass

                # Kill only the targeted PIDs
                if target_pids:
                    for _tpid in target_pids:
                        if _tpid in _SENTINEL_PIDS:
                            continue
                        try:
                            subprocess.run(
                                ["taskkill", "/F", "/T", "/PID", str(_tpid)],
                                capture_output=True, timeout=5,
                                creationflags=0x08000000)
                        except Exception:
                            pass

                # Always kill consent.exe (the UAC dialog)
                try:
                    subprocess.run(
                        ["taskkill", "/F", "/IM", "consent.exe"],
                        capture_output=True, timeout=3,
                        creationflags=0x08000000)
                except Exception:
                    pass

                # Kill by name only if it's a specific reported process name
                # and NOT a generic or system name
                _SKIP_NAMES = {
                    "", "unknown", "unknown process",
                    "system", "smss.exe", "csrss.exe", "wininit.exe",
                    "services.exe", "lsass.exe", "winlogon.exe",
                    "explorer.exe", "svchost.exe", "taskmgr.exe",
                    "consent.exe", "taskkill.exe",
                    "python.exe", "pythonw.exe", "python3.exe",
                    "sentinel_gui.py",
                }
                _pn = (proc_name or "").strip().lower()
                if _pn and _pn not in _SKIP_NAMES:
                    # Only kill if this exact name is in target_pids processes
                    # to avoid killing unrelated apps with the same name
                    _should_kill = False
                    if target_pids:
                        try:
                            import psutil as _ps2
                            for _tp in target_pids:
                                try:
                                    if _ps2.Process(_tp).name().lower() == _pn:
                                        _should_kill = True
                                        break
                                except Exception:
                                    pass
                        except ImportError:
                            _should_kill = True  # no psutil, kill by name
                    else:
                        _should_kill = True
                    if _should_kill:
                        try:
                            subprocess.run(
                                ["taskkill", "/F", "/T", "/IM",
                                 proc_name.strip()],
                                capture_output=True, timeout=5,
                                creationflags=0x08000000)
                        except Exception:
                            pass

                # Hide all windows of killed PIDs from taskbar
                import time as _t2
                _t2.sleep(0.2)
                if target_pids:
                    try:
                        import ctypes as _ct, ctypes.wintypes as _wt
                        _u32 = _ct.windll.user32
                        _CB  = _ct.WINFUNCTYPE(
                            _ct.c_bool, _wt.HWND, _wt.LPARAM)
                        def _hide(hwnd, _lp):
                            _p = _ct.c_ulong(0)
                            _u32.GetWindowThreadProcessId(
                                hwnd, _ct.byref(_p))
                            if _p.value in target_pids:
                                try: _u32.ShowWindow(hwnd, 0)
                                except Exception: pass
                            return True
                        _u32.EnumWindows(_CB(_hide), 0)
                    except Exception:
                        pass

            _thr.Thread(target=_do_kill, daemon=True,
                        name="KillEscalated").start()



        # ── Plain-English process name map ────────────────────────────────────
        _PROC_FRIENDLY = {
            "cmd.exe":         ("Command Prompt",      "A black command-line window"),
            "powershell.exe":  ("PowerShell",          "A powerful scripting terminal"),
            "pwsh.exe":        ("PowerShell Core",     "A powerful scripting terminal"),
            "regedit.exe":     ("Registry Editor",     "A tool that edits deep Windows settings"),
            "regedt32.exe":    ("Registry Editor",     "A tool that edits deep Windows settings"),
            "msiexec.exe":     ("Windows Installer",   "A software installation package"),
            "setup.exe":       ("Setup Program",       "A software installer"),
            "install.exe":     ("Installer",           "A software installer"),
            "taskmgr.exe":     ("Task Manager",        "A tool to view/stop running programs"),
            "services.msc":    ("Windows Services",    "A tool that controls background services"),
            "devmgmt.msc":     ("Device Manager",      "A tool that controls hardware drivers"),
            "diskmgmt.msc":    ("Disk Management",     "A tool that manages hard drives"),
            "eventvwr.exe":    ("Event Viewer",        "A tool that shows system logs"),
            "gpedit.msc":      ("Group Policy Editor", "A tool that changes security policies"),
            "netsh.exe":       ("Network Shell",       "A command-line network configuration tool"),
            "runas.exe":       ("Run As",              "A tool to run programs as another user"),
            "wscript.exe":     ("Windows Script",      "A script execution engine"),
            "cscript.exe":     ("Windows Script",      "A script execution engine"),
            "consent.exe":     ("Windows UAC Dialog",  "The Windows permission request dialog"),
        }

        def _show_challenge(event, pid, target_pids=None):
            if self._adm_popup_open: return
            self._adm_popup_open = True

            proc_name  = getattr(event, "process_name", "unknown process")
            user       = getattr(event, "user",         os.environ.get("USERNAME","unknown"))
            desc       = getattr(event, "description",  "Admin access requested")
            sev_str    = str(getattr(getattr(event,"severity",None),"value","HIGH"))
            source     = getattr(event, "source", "")
            accent     = "#ef4444" if sev_str in ("CRITICAL","HIGH") else "#f59e0b"

            # Friendly name and plain explanation
            pkey    = proc_name.lower().strip()
            fname, fexplain = _PROC_FRIENDLY.get(pkey, (
                proc_name,
                "A program is trying to make system-level changes"
            ))

            # Build a plain-English explanation of WHAT is happening
            if "runas" in desc.lower() or "run as administrator" in desc.lower():
                action_line = f"Someone clicked \"Run as Administrator\" on {fname}."
            elif pkey in ("cmd.exe", "powershell.exe", "pwsh.exe"):
                action_line = f"{fname} is trying to open with full Administrator access."
            elif pkey in ("regedit.exe", "regedt32.exe"):
                action_line = f"{fname} is trying to modify deep Windows registry settings."
            elif pkey in ("msiexec.exe", "setup.exe", "install.exe"):
                action_line = f"A software installer is trying to install or change a program."
            else:
                action_line = f"{fname} is requesting Administrator-level access."

            pop = ctk.CTkToplevel(self)
            pop.title("🔐 Admin Access Request — Sentinel Verification")
            pop.resizable(False, False)
            pop.attributes("-topmost", True)
            try: pop.attributes("-toolwindow", True)
            except Exception: pass
            pop.grab_set()
            pop.focus_force()

            W, H = 540, 490
            self.update_idletasks()
            px = self.winfo_x() + (self.winfo_width()  - W) // 2
            py = self.winfo_y() + (self.winfo_height() - H) // 2
            pop.geometry(f"{W}x{H}+{max(0,px)}+{max(0,py)}")

            # ── Colour stripe ──────────────────────────────────────────────
            ctk.CTkFrame(pop, fg_color=accent, height=6, corner_radius=0).pack(fill="x")
            bd = ctk.CTkFrame(pop, fg_color=COLORS["bg_card"], corner_radius=0)
            bd.pack(fill="both", expand=True)

            # ── Header ─────────────────────────────────────────────────────
            icon = "🔴" if sev_str in ("CRITICAL","HIGH") else "🟡"
            ctk.CTkLabel(bd,
                text=f"{icon}  Admin Access Request Intercepted",
                font=ctk.CTkFont(size=15, weight="bold"), text_color=accent,
            ).pack(pady=(18, 4))

            # ── Plain-language explanation ─────────────────────────────────
            ctk.CTkLabel(bd,
                text=action_line,
                font=ctk.CTkFont(size=13, weight="bold"),
                text_color=COLORS["text_primary"], justify="center",
                wraplength=480,
            ).pack(pady=(0, 4), padx=20)

            ctk.CTkLabel(bd,
                text=f"{fexplain}.\nThis was BLOCKED until you enter the admin password.",
                font=ctk.CTkFont(size=11),
                text_color=COLORS["text_secondary"], justify="center",
                wraplength=480,
            ).pack(pady=(0, 10), padx=20)

            # ── Detail card ────────────────────────────────────────────────
            dc = ctk.CTkFrame(bd, fg_color=COLORS["bg_secondary"], corner_radius=10)
            dc.pack(fill="x", padx=24, pady=(0, 10))
            dc.grid_columnconfigure(1, weight=1)

            rows = [
                ("🖥  Program",    fname),
                ("📋 File name",  proc_name),
                ("👤 User",       user),
                ("⚠  Risk level", sev_str),
            ]
            if pid:
                rows.append(("🔢 Process ID", str(pid)))
            if source:
                rows.append(("🔍 Detected by", source))

            for ri, (k, v) in enumerate(rows):
                ctk.CTkLabel(dc, text=k, anchor="e", width=120,
                    font=ctk.CTkFont(size=10), text_color=COLORS["text_secondary"],
                ).grid(row=ri, column=0, padx=(10, 6), pady=2)
                ctk.CTkLabel(dc, text=str(v)[:60], anchor="w",
                    font=ctk.CTkFont(size=10, weight="bold"),
                    text_color=COLORS["text_primary"],
                ).grid(row=ri, column=1, padx=(0, 10), pady=2, sticky="w")

            # ── Instruction ────────────────────────────────────────────────
            ctk.CTkLabel(bd,
                text="If YOU started this, enter the admin password to allow it.\n"
                     "If you did NOT — click Deny to stop it immediately.",
                font=ctk.CTkFont(size=11),
                text_color=COLORS["text_secondary"], justify="center",
            ).pack(pady=(6, 4))

            # ── Password entry ─────────────────────────────────────────────
            pv = ctk.StringVar()
            pe = ctk.CTkEntry(bd, textvariable=pv, show="●",
                height=44, corner_radius=10,
                placeholder_text="Enter admin password to allow…",
                border_color=accent, font=ctk.CTkFont(size=13))
            pe.pack(padx=28, fill="x")
            pop.after(120, lambda: (pe.focus_set(), pe.icursor("end"))
                      if pop.winfo_exists() else None)

            el = ctk.CTkLabel(bd, text="", font=ctk.CTkFont(size=11),
                              text_color="#ef4444")
            el.pack(pady=(4, 0))

            # ── Actions ────────────────────────────────────────────────────
            def _release():
                self._adm_popup_open = False
                try: pop.grab_release()
                except Exception: pass
                try: pop.destroy()
                except Exception: pass

            def _approve(*_):
                if not _vis():
                    # No password set — allow through but log it
                    self._adm_counts["approved"] = self._adm_counts.get("approved", 0) + 1
                    _upd_stats(); _upd_last("APPROVED")
                    _alog(sev_str, proc_name, user,
                          f"{fname} allowed (no password set)", "APPROVED")
                    _release()
                    return
                if _vok(pv.get()):
                    self._adm_counts["approved"] = self._adm_counts.get("approved", 0) + 1
                    _upd_stats(); _upd_last("APPROVED")
                    _alog(sev_str, proc_name, user,
                          f"{fname} — admin approved", "APPROVED")
                    _release()
                else:
                    el.configure(text="❌ Incorrect password — access denied. Try again.")
                    pv.set(""); pe.focus_set()

            def _deny():
                self._adm_counts["blocked"] = self._adm_counts.get("blocked", 0) + 1
                _upd_stats(); _upd_last("BLOCKED")
                _alog(sev_str, proc_name, user,
                      f"{fname} — DENIED and terminated", "BLOCKED")

                import threading as _thr2

                def _do_deny_kill():
                    _my_pid = os.getpid()

                    # Build the full kill set from target_pids + direct pid
                    _kill_set = set(target_pids) if target_pids else set()
                    if pid and pid != _my_pid:
                        _kill_set.add(pid)

                    # Protect Sentinel and its full ancestor chain
                    _safe = {_my_pid}
                    try:
                        import psutil as _ps3
                        _c = _ps3.Process(_my_pid)
                        while _c:
                            _safe.add(_c.pid)
                            _par = _c.parent()
                            if _par is None or _par.pid == _c.pid: break
                            _c = _par
                    except Exception: pass

                    # Also collect conhost.exe children (the console window itself).
                    # Without this the black cmd window stays open after the process dies.
                    try:
                        import psutil as _ps4
                        _extra = set()
                        for _kpid in list(_kill_set):
                            if _kpid in _safe: continue
                            try:
                                _kproc = _ps4.Process(_kpid)
                                for _child in _kproc.children(recursive=True):
                                    if _child.name().lower() in (
                                            "conhost.exe", "cmd.exe",
                                            "powershell.exe", "pwsh.exe"):
                                        if _child.pid not in _safe:
                                            _extra.add(_child.pid)
                            except Exception: pass
                        _kill_set |= _extra
                    except Exception: pass

                    # Step 1 — kill consent.exe
                    try:
                        subprocess.run(["taskkill", "/F", "/IM", "consent.exe"],
                            capture_output=True, timeout=3, creationflags=0x08000000)
                    except Exception: pass

                    # Step 2 — hide all windows immediately so they vanish at once
                    try:
                        import ctypes as _ct2, ctypes.wintypes as _wt2
                        _u32 = _ct2.windll.user32
                        _CB  = _ct2.WINFUNCTYPE(_ct2.c_bool, _wt2.HWND, _wt2.LPARAM)
                        def _hide_all(hwnd, _lp):
                            _p = _ct2.c_ulong(0)
                            _u32.GetWindowThreadProcessId(hwnd, _ct2.byref(_p))
                            if _p.value in _kill_set:
                                try: _u32.ShowWindow(hwnd, 0)
                                except Exception: pass
                            return True
                        _u32.EnumWindows(_CB(_hide_all), 0)
                    except Exception: pass

                    # Step 3 — taskkill /F /T on every PID
                    for _kpid in list(_kill_set):
                        if _kpid in _safe: continue
                        try:
                            subprocess.run(
                                ["taskkill", "/F", "/T", "/PID", str(_kpid)],
                                capture_output=True, timeout=4, creationflags=0x08000000)
                        except Exception: pass

                    # Step 4 — kill by image name for the exact reported process
                    _SAFE_NAMES = {
                        "", "unknown", "system", "explorer.exe", "svchost.exe",
                        "python.exe", "pythonw.exe", "python3.exe",
                        "sentinel_gui.py", "taskkill.exe", "consent.exe",
                    }
                    _pn = (proc_name or "").strip().lower()
                    if _pn and _pn not in _SAFE_NAMES:
                        try:
                            subprocess.run(
                                ["taskkill", "/F", "/IM", proc_name.strip()],
                                capture_output=True, timeout=4, creationflags=0x08000000)
                        except Exception: pass

                    # Step 5 — PowerShell Stop-Process fallback for elevated processes
                    # (taskkill can be denied on a higher-integrity process;
                    # PowerShell Stop-Process with -Force bypasses this in many cases)
                    if _kill_set:
                        _pid_list = ",".join(str(p) for p in _kill_set if p not in _safe)
                        if _pid_list:
                            _ps_cmd = (
                                f"$ids=@({_pid_list});"
                                f"foreach($id in $ids){{"
                                f"try{{Stop-Process -Id $id -Force -ErrorAction SilentlyContinue}}catch{{}}}}"
                            )
                            try:
                                subprocess.run(
                                    ["powershell", "-NoProfile", "-NonInteractive",
                                     "-ExecutionPolicy", "Bypass", "-Command", _ps_cmd],
                                    capture_output=True, timeout=6, creationflags=0x08000000)
                            except Exception: pass

                    # Step 6 — final hide sweep after kills complete
                    try:
                        import ctypes as _ct3, ctypes.wintypes as _wt3
                        _u32b = _ct3.windll.user32
                        _CB2  = _ct3.WINFUNCTYPE(_ct3.c_bool, _wt3.HWND, _wt3.LPARAM)
                        def _hide2(hwnd, _lp):
                            _p = _ct3.c_ulong(0)
                            _u32b.GetWindowThreadProcessId(hwnd, _ct3.byref(_p))
                            if _p.value in _kill_set:
                                try: _u32b.ShowWindow(hwnd, 0)
                                except Exception: pass
                            return True
                        _u32b.EnumWindows(_CB2(_hide2), 0)
                    except Exception: pass

                _thr2.Thread(target=_do_deny_kill, daemon=True, name="DenyKill").start()
                _release()

            pop.protocol("WM_DELETE_WINDOW", _deny)
            pe.bind("<Return>", _approve)

            br = ctk.CTkFrame(bd, fg_color="transparent")
            br.pack(fill="x", padx=28, pady=(8, 20))
            br.grid_columnconfigure((0, 1), weight=1)
            ctk.CTkButton(br, text="✅  Allow — I Started This",
                command=_approve, height=46, corner_radius=10,
                fg_color=COLORS["accent_green"], hover_color="#0d9668",
                font=ctk.CTkFont(size=13, weight="bold"),
            ).grid(row=0, column=0, padx=(0, 5), sticky="ew")
            ctk.CTkButton(br, text="🚫  Deny & Stop It",
                command=_deny, height=46, corner_radius=10,
                fg_color=COLORS["accent_red"], hover_color="#dc2626",
                font=ctk.CTkFont(size=13, weight="bold"),
            ).grid(row=0, column=1, padx=(5, 0), sticky="ew")

        def _adm_handle(event, pid):
            self._adm_counts["detected"] = self._adm_counts.get("detected", 0) + 1
            _upd_stats()
            sev  = getattr(getattr(event, "severity", None), "value", "HIGH")
            proc = getattr(event, "process_name", "unknown")
            user = getattr(event, "user",         "unknown")
            desc = getattr(event, "description",  "Privilege escalation detected")
            _alog(sev, proc, user, desc, "PENDING")
            if not _vis():
                _upd_last("LOGGED"); return

            # ── FIX: Only show the popup when Command Prompt (cmd.exe) or a
            # shell is explicitly launched as Administrator.  Events that are
            # merely "admin-capable process appeared" (e.g. taskmgr, ipconfig)
            # should be logged silently — not interrupt the user with a popup.
            _CMD_SHELLS = {"cmd.exe", "powershell.exe", "pwsh.exe"}
            _proc_lower  = (proc or "").lower().strip()
            _is_runas    = "runas" in desc.lower() or "run as administrator" in desc.lower()
            _is_elevated = "elevated token" in desc.lower()
            if _proc_lower in _CMD_SHELLS and not (_is_runas or _is_elevated):
                # cmd/powershell launched normally — log only, no popup
                _upd_last("LOGGED")
                return

            if not self._adm_popup_open:
                # Identify ONLY the specific PIDs to kill on deny.
                # We protect Sentinel and all its parent processes.
                _target_pids = set()
                _sentinel_pids = {os.getpid()}
                try:
                    import psutil as _ps_id
                    # Protect sentinel and its full ancestor chain
                    _cur = _ps_id.Process(os.getpid())
                    while _cur:
                        _sentinel_pids.add(_cur.pid)
                        _par = _cur.parent()
                        if _par is None or _par.pid == _cur.pid:
                            break
                        _cur = _par
                except Exception:
                    pass

                # Add the reported PID (consent.exe or the escalating process)
                if pid and pid not in _sentinel_pids:
                    _target_pids.add(pid)
                    # If it's consent.exe, find WHO requested the elevation.
                    # The requesting process is the one that HAD foreground focus
                    # just before consent.exe appeared. Use psutil to find all
                    # non-system processes that have a visible window and are
                    # NOT system/sentinel processes.
                    try:
                        import psutil as _ps_id2
                        import ctypes as _ct_id
                        _consent_proc = _ps_id2.Process(pid)
                        if _consent_proc.name().lower() == "consent.exe":
                            # Get the foreground window owner
                            _fg_hwnd = _ct_id.windll.user32.GetForegroundWindow()
                            _fg_pid = _ct_id.c_ulong(0)
                            _ct_id.windll.user32.GetWindowThreadProcessId(
                                _fg_hwnd, _ct_id.byref(_fg_pid))
                            if (_fg_pid.value
                                    and _fg_pid.value not in _sentinel_pids):
                                _target_pids.add(_fg_pid.value)
                            # Also check: any process with a visible window
                            # that appeared recently (within last 30s)
                            import time as _ts
                            _now = _ts.time()
                            for _p in _ps_id2.process_iter(["pid","name","create_time"]):
                                try:
                                    _pinfo = _p.info
                                    if _pinfo["pid"] in _sentinel_pids:
                                        continue
                                    _pname_l = (_pinfo["name"] or "").lower()
                                    _SKIP = {
                                        "system","smss.exe","csrss.exe",
                                        "wininit.exe","services.exe",
                                        "lsass.exe","winlogon.exe",
                                        "explorer.exe","svchost.exe",
                                        "taskmgr.exe","consent.exe",
                                        "dllhost.exe","conhost.exe",
                                        "taskkill.exe","python.exe",
                                        "pythonw.exe","python3.exe",
                                        "RuntimeBroker.exe".lower(),
                                        "sihost.exe","ctfmon.exe",
                                    }
                                    if _pname_l in _SKIP:
                                        continue
                                    _ct = _pinfo.get("create_time", 0)
                                    if _ct and (_now - _ct) < 30:
                                        _target_pids.add(_pinfo["pid"])
                                except Exception:
                                    pass
                    except Exception:
                        pass

                _show_challenge(event, pid, _target_pids)

        # Wire AdminPrivilegeMonitor
        mon = getattr(self, "admin_priv_monitor", None)
        if mon:
            orig = getattr(mon, "_callback", None)
            def _wrapped(ev):
                p = getattr(ev, "process_id", 0)
                self.after(0, lambda e=ev, pid=p: _adm_handle(e, pid))
                if orig:
                    try: orig(ev)
                    except Exception: pass
            mon._callback = _wrapped

        self._adm_handle_event_fn = lambda ev: _adm_handle(
            ev, getattr(ev, "process_id", 0))

        ctk.CTkFrame(scroll, fg_color="transparent", height=20).pack()


    def create_hardware_gatekeeper_tab(self):
        """Hardware Gatekeeper tab - redesigned layout."""
        tab = self.tabview.tab("\U0001f4e1 Hardware Gatekeeper")
        tab.grid_rowconfigure(0, weight=1)
        tab.grid_columnconfigure(0, weight=1)

        import tkinter.ttk as ttk
        import hashlib as _hl, time as _t
        from pathlib import Path as _P

        # ── Vault helpers ──────────────────────────────────────────────────
        _VAULT_DIR = _P("data") / "admin"
        _HW_VAULT  = _VAULT_DIR / "hw_vault.dat"
        _MAGIC     = "SENTINEL_V2"

        def _hash_pw(pw):
            raw = f"{_MAGIC}:{pw}:{_MAGIC[::-1]}"
            return _hl.sha256(raw.encode()).hexdigest()
        def _vis(): return _HW_VAULT.exists() and _HW_VAULT.stat().st_size > 10
        def _vset(pw):
            _VAULT_DIR.mkdir(parents=True, exist_ok=True)
            _HW_VAULT.write_text(_hash_pw(pw))
        def _vok(candidate):
            if not _vis(): return False
            return _HW_VAULT.read_text().strip() == _hash_pw(candidate)
        def _vclr():
            if _HW_VAULT.exists(): _HW_VAULT.unlink()
        def _pw_str(pw):
            s = 0
            if len(pw) >= 8:  s += 0.25
            if len(pw) >= 12: s += 0.15
            if any(c.isupper() for c in pw): s += 0.2
            if any(c.isdigit() for c in pw): s += 0.2
            if any(c in "!@#$%^&*()-_=+" for c in pw): s += 0.2
            s = min(s, 1.0)
            if s < 0.4: return s, "Weak",        "#ef4444"
            if s < 0.7: return s, "Fair",        "#f59e0b"
            if s < 0.9: return s, "Strong",      "#10b981"
            return s,   "Very Strong", "#3b82f6"

        # ── Persistent state ───────────────────────────────────────────────
        self._hw_auth_active  = False
        self._hw_popup_open   = False
        self._hw_last_ssid    = None
        self._hw_known_bt     = set()
        self._hw_watch_active = False

        scroll = ctk.CTkScrollableFrame(tab, fg_color="transparent", corner_radius=0)
        scroll.grid(row=0, column=0, sticky="nsew")
        scroll.grid_columnconfigure(0, weight=1)

        # ══ HEADER ══════════════════════════════════════════════════════════
        banner = ctk.CTkFrame(scroll, fg_color=COLORS["bg_card"], corner_radius=14)
        banner.pack(fill="x", padx=18, pady=(18, 0))
        ctk.CTkLabel(banner, text="\U0001f4e1  Hardware Gatekeeper",
            font=ctk.CTkFont(size=20, weight="bold"),
            text_color=COLORS["accent_purple"],
        ).pack(side="left", padx=22, pady=16)
        self._hw_vault_badge = ctk.CTkLabel(banner, text="",
            font=ctk.CTkFont(size=11, weight="bold"), corner_radius=8, width=150)
        self._hw_vault_badge.pack(side="right", padx=22)
        def _rbadge():
            self._hw_vault_badge.configure(
                text="\U0001f511 Password Set" if _vis() else "\u26a0  No Password",
                text_color="#10b981" if _vis() else "#f59e0b")
        _rbadge()
        ctk.CTkLabel(banner,
            text="Wi-Fi & Bluetooth locked at startup.\n"
                 "Password required to unlock, change network, or pair new BT device.",
            font=ctk.CTkFont(size=12),
            text_color=COLORS["text_secondary"], justify="left",
        ).pack(side="left", padx=(0, 22), pady=16)

        # ══ 1. LOCK / UNLOCK PANEL ══════════════════════════════════════════
        lk = ctk.CTkFrame(scroll, fg_color=COLORS["bg_card"], corner_radius=14)
        lk.pack(fill="x", padx=18, pady=(12, 0))
        lk.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(lk, text="\U0001f510  Lock / Unlock Hardware Access",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color=COLORS["text_primary"],
        ).grid(row=0, column=0, columnspan=3, sticky="w", padx=20, pady=(16, 8))
        ctk.CTkLabel(lk, text="Password:", anchor="e", width=110,
            font=ctk.CTkFont(size=12), text_color=COLORS["text_secondary"],
        ).grid(row=1, column=0, padx=(20, 8), pady=6)
        self._hw_ul_var = ctk.StringVar()
        _ul_entry = ctk.CTkEntry(lk, textvariable=self._hw_ul_var, show="\u25cf",
            height=42, corner_radius=10, font=ctk.CTkFont(size=13),
            border_color=COLORS["accent_purple"],
            placeholder_text="Enter gatekeeper password\u2026")
        _ul_entry.grid(row=1, column=1, padx=(0, 8), pady=6, sticky="ew")
        _lk_fb = ctk.CTkLabel(lk, text="",
            font=ctk.CTkFont(size=11), text_color=COLORS["accent_red"])
        _lk_fb.grid(row=2, column=0, columnspan=3, pady=(0, 4))
        lk_btns = ctk.CTkFrame(lk, fg_color="transparent")
        lk_btns.grid(row=3, column=0, columnspan=3,
            sticky="ew", padx=20, pady=(4, 16))
        lk_btns.grid_columnconfigure((0, 1), weight=1)

        def _do_unlock():
            pw = self._hw_ul_var.get()
            if not _vis():
                self._hw_auth_active = True
                hw = getattr(self, "hardware_gatekeeper", None)
                if hw:
                    try: hw.authenticate()
                    except Exception: pass
                _lk_fb.configure(text="\u2705 Unlocked (no password set).",
                    text_color=COLORS["accent_green"])
                self._hw_ul_var.set("")
                _hwlog("UNLOCKED", "Hardware unlocked — no password configured")
                _upd()
                return
            if not pw:
                _lk_fb.configure(text="\u274c Enter the password first.",
                    text_color=COLORS["accent_red"]); return
            if _vok(pw):
                self._hw_auth_active = True
                hw = getattr(self, "hardware_gatekeeper", None)
                if hw:
                    try: hw.authenticate()
                    except Exception: pass
                _lk_fb.configure(text="\u2705 Hardware unlocked.",
                    text_color=COLORS["accent_green"])
                self._hw_ul_var.set("")
                _hwlog("UNLOCKED", "Hardware access granted via panel")
                _upd()
            else:
                _lk_fb.configure(text="\u274c Incorrect password.",
                    text_color=COLORS["accent_red"])
                self._hw_ul_var.set("")

        def _do_relock():
            self._hw_auth_active = False
            self._hw_ul_var.set("")
            _lk_fb.configure(text="\U0001f512 Hardware locked.",
                text_color=COLORS["accent_red"])
            hw = getattr(self, "hardware_gatekeeper", None)
            if hw:
                try: hw.revoke()
                except Exception: pass
            _hwlog("LOCKED", "Hardware manually re-locked")
            _upd()

        _ul_entry.bind("<Return>", lambda e: _do_unlock())
        ctk.CTkButton(lk_btns, text="\U0001f513  Unlock",
            command=_do_unlock, height=44, corner_radius=10,
            fg_color=COLORS["accent_green"], hover_color="#0d9668",
            font=ctk.CTkFont(size=13, weight="bold"),
        ).grid(row=0, column=0, padx=(0, 6), sticky="ew")
        ctk.CTkButton(lk_btns, text="\U0001f512  Re-lock Now",
            command=_do_relock, height=44, corner_radius=10,
            fg_color=COLORS["accent_red"], hover_color="#dc2626",
            font=ctk.CTkFont(size=13, weight="bold"),
        ).grid(row=0, column=1, padx=(6, 0), sticky="ew")

        # ══ 2. LIVE STATUS ROW ══════════════════════════════════════════════
        sc = ctk.CTkFrame(scroll, fg_color=COLORS["bg_card"], corner_radius=14)
        sc.pack(fill="x", padx=18, pady=(10, 0))
        sc.grid_columnconfigure((1, 3, 5), weight=1)
        def _sbadge(parent, col, attr, label):
            ctk.CTkLabel(parent, text=label, anchor="e", width=90,
                font=ctk.CTkFont(size=12),
                text_color=COLORS["text_secondary"],
            ).grid(row=0, column=col, padx=(18, 4), pady=14)
            b = ctk.CTkLabel(parent, text="\u2014",
                font=ctk.CTkFont(size=13, weight="bold"),
                text_color=COLORS["text_secondary"])
            b.grid(row=0, column=col+1, sticky="w", pady=14)
            setattr(self, attr, b)
        _sbadge(sc, 0, "_hw_bt_badge",   "Bluetooth:")
        _sbadge(sc, 2, "_hw_wifi_badge",  "Wi-Fi:")
        _sbadge(sc, 4, "_hw_auth_badge",  "Auth:")
        self._hw_ssid_lbl = ctk.CTkLabel(sc, text="Network: \u2014",
            font=ctk.CTkFont(size=11), text_color=COLORS["text_secondary"])
        self._hw_ssid_lbl.grid(row=0, column=6, padx=(12, 18), pady=14)
        def _bstyle(state):
            s = str(state).upper()
            if s == "ON":      return "\U0001f7e2 ON",  "#10b981"
            if s == "OFF":     return "\U0001f534 OFF", "#ef4444"
            if s == "MISSING": return "\u26a0  N/A",    "#f59e0b"
            return state or "\u2014", COLORS["text_secondary"]
        def _upd():
            auth = self._hw_auth_active
            self._hw_auth_badge.configure(
                text="\U0001f7e2 Unlocked" if auth else "\U0001f534 Locked",
                text_color="#10b981" if auth else "#ef4444")
            # Use cached stats populated by BG worker — no PowerShell call here
            hw = getattr(self, "hardware_gatekeeper", None)
            try:
                stats = getattr(hw, '_cached_stats', {}) if hw else {}
                if not stats:
                    stats = {"bt_state": "N/A", "wifi_state": "N/A"}
            except Exception:
                stats = {}
            t, c = _bstyle(stats.get("bt_state",   "N/A"))
            self._hw_bt_badge.configure(text=t, text_color=c)
            t, c = _bstyle(stats.get("wifi_state", "N/A"))
            self._hw_wifi_badge.configure(text=t, text_color=c)
        _upd()
        # Store _upd so the main heartbeat can call it — no independent after() timer needed
        self._hw_status_upd_fn = _upd

        # ══ 3. NETWORK & BLUETOOTH WATCH ════════════════════════════════════
        wc = ctk.CTkFrame(scroll, fg_color=COLORS["bg_card"], corner_radius=14)
        wc.pack(fill="x", padx=18, pady=(10, 0))
        wh = ctk.CTkFrame(wc, fg_color="transparent")
        wh.pack(fill="x", padx=20, pady=(14, 4))
        ctk.CTkLabel(wh, text="\U0001f4f6  Network & Bluetooth Connection Watch",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLORS["accent_blue"],
        ).pack(side="left")
        self._hw_wst = ctk.CTkLabel(wh, text="\u23f8 Inactive",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color=COLORS["text_secondary"])
        self._hw_wst.pack(side="right")
        ctk.CTkLabel(wc,
            text="Monitors Wi-Fi network changes and new Bluetooth device connections.\n"
                 "Password popup fires automatically on network switch or new BT pairing.",
            font=ctk.CTkFont(size=11),
            text_color=COLORS["text_secondary"], justify="left",
        ).pack(anchor="w", padx=20, pady=(0, 8))
        wb = ctk.CTkFrame(wc, fg_color="transparent")
        wb.pack(fill="x", padx=20, pady=(0, 14))
        wb.grid_columnconfigure((0, 1), weight=1)

        def _get_ssid():
            try:
                r = subprocess.run(
                    ["netsh", "wlan", "show", "interfaces"],
                    capture_output=True, text=True, timeout=5,
                    creationflags=0x08000000)
                for line in r.stdout.splitlines():
                    if "SSID" in line and "BSSID" not in line:
                        parts = line.split(":", 1)
                        if len(parts) == 2:
                            s = parts[1].strip()
                            if s: return s
            except Exception: pass
            return None

        def _get_bt():
            try:
                ps = ("Get-PnpDevice -Class Bluetooth -ErrorAction SilentlyContinue"
                      " | Where-Object {$_.Status -eq 'OK'}"
                      " | Select-Object -ExpandProperty InstanceId")
                r = subprocess.run(
                    ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                    capture_output=True, text=True, timeout=8,
                    creationflags=0x08000000)
                devs = set()
                for line in r.stdout.splitlines():
                    line = line.strip()
                    if line and len(line) > 4: devs.add(line)
                return devs
            except Exception: return set()

        def _watch_loop():
            self._hw_last_ssid = _get_ssid()
            self._hw_known_bt  = _get_bt()
            if self._hw_last_ssid:
                self.after(0, lambda s=self._hw_last_ssid:
                    self._hw_ssid_lbl.configure(text=f"Network: {s}"))
            while getattr(self, "_hw_watch_active", False):
                _t.sleep(3)
                try:
                    # ── Wi-Fi network change ──────────────────────────────
                    cur_ssid = _get_ssid()
                    if cur_ssid:
                        self.after(0, lambda s=cur_ssid:
                            self._hw_ssid_lbl.configure(text=f"Network: {s}"))
                    if (cur_ssid and
                            self._hw_last_ssid is not None and
                            cur_ssid != self._hw_last_ssid):
                        old = self._hw_last_ssid
                        det = f"'{old}' \u2192 '{cur_ssid}'"
                        if not self._hw_auth_active and not self._hw_popup_open:
                            self.after(0, lambda d=det, ns=cur_ssid:
                                _popup("wifi_change", d,
                                    on_approve=lambda: setattr(
                                        self, "_hw_last_ssid", ns),
                                    on_deny=_block_wifi))
                        else:
                            self._hw_last_ssid = cur_ssid
                            self.after(0, lambda d=det:
                                _hwlog("NETWORK_CHANGE", f"Network changed: {d}"))
                    elif cur_ssid and self._hw_last_ssid is None:
                        self._hw_last_ssid = cur_ssid
                    elif cur_ssid is None and self._hw_last_ssid is not None:
                        self._hw_last_ssid = None
                        self.after(0, lambda:
                            self._hw_ssid_lbl.configure(
                                text="Network: disconnected"))
                    # ── Bluetooth new device ──────────────────────────────
                    cur_bt   = _get_bt()
                    new_devs = cur_bt - self._hw_known_bt
                    if new_devs:
                        ds = ", ".join(list(new_devs)[:2])[:80]
                        det = f"New BT device(s): {ds}"
                        if not self._hw_auth_active and not self._hw_popup_open:
                            self.after(0, lambda d=det, nd=frozenset(new_devs):
                                _popup("bt_new_device", d,
                                    on_approve=lambda:
                                        self._hw_known_bt.update(nd),
                                    on_deny=None))
                        else:
                            self._hw_known_bt = cur_bt
                            self.after(0, lambda d=ds:
                                _hwlog("BT_DEVICE",
                                    f"New BT device allowed: {d}"))
                except Exception as e:
                    print(f"[HWWatch] {e}")

        def _block_wifi():
            try:
                subprocess.run(["netsh", "wlan", "disconnect"],
                    capture_output=True, timeout=5,
                    creationflags=0x08000000)
                _hwlog("BLOCKED",
                    "Wi-Fi network change denied — disconnected")
            except Exception as e:
                _hwlog("BLOCKED", f"Wi-Fi change denied ({e})")

        def _start_watch():
            if getattr(self, "_hw_watch_active", False): return
            self._hw_watch_active = True
            self._hw_wst.configure(text="\U0001f7e2 Active",
                text_color=COLORS["accent_green"])
            import threading as _thr
            _thr.Thread(target=_watch_loop, daemon=True,
                name="HWNetWatch").start()
            _hwlog("INFO", "Network & Bluetooth watch started")

        def _stop_watch():
            self._hw_watch_active = False
            self._hw_wst.configure(text="\u23f8 Inactive",
                text_color=COLORS["text_secondary"])
            _hwlog("INFO", "Network & Bluetooth watch stopped")

        ctk.CTkButton(wb, text="\u25b6  Start Watch",
            command=_start_watch, height=38, corner_radius=10,
            fg_color=COLORS["accent_green"], hover_color="#0d9668",
            font=ctk.CTkFont(size=12, weight="bold"),
        ).grid(row=0, column=0, padx=(0, 5), sticky="ew")
        ctk.CTkButton(wb, text="\u23f9  Stop Watch",
            command=_stop_watch, height=38, corner_radius=10,
            fg_color=COLORS["bg_secondary"], hover_color=COLORS["accent_red"],
            font=ctk.CTkFont(size=12),
        ).grid(row=0, column=1, padx=(5, 0), sticky="ew")
        self.after(4000, _start_watch)

        # ══ 4. SET / CHANGE PASSWORD ════════════════════════════════════════
        pc = ctk.CTkFrame(scroll, fg_color=COLORS["bg_card"], corner_radius=14)
        pc.pack(fill="x", padx=18, pady=(12, 0))
        pc.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(pc, text="\U0001f4be  Set / Change Gatekeeper Password",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLORS["text_primary"],
        ).grid(row=0, column=0, columnspan=3, sticky="w",
            padx=20, pady=(16, 8))
        self._hw_cur_var  = ctk.StringVar()
        self._hw_new_var  = ctk.StringVar()
        self._hw_conf_var = ctk.StringVar()
        def _fld(row_idx, label, var, border):
            ctk.CTkLabel(pc, text=label, anchor="e", width=255,
                font=ctk.CTkFont(size=12),
                text_color=COLORS["text_secondary"],
            ).grid(row=row_idx, column=0, padx=(20, 8), pady=4)
            e = ctk.CTkEntry(pc, textvariable=var, show="\u25cf",
                height=38, corner_radius=8, border_color=border,
                font=ctk.CTkFont(size=13))
            e.grid(row=row_idx, column=1, padx=(0, 20), pady=4,
                sticky="ew")
            return e
        _fld(1, "Current Password (leave empty to force reset):",
            self._hw_cur_var,  COLORS["text_secondary"])
        _fld(2, "New Password:", self._hw_new_var,  COLORS["accent_purple"])
        _fld(3, "Confirm New Password:", self._hw_conf_var,
            COLORS["accent_purple"])
        self._hw_conf_match = ctk.CTkLabel(pc, text="", width=28,
            font=ctk.CTkFont(size=16))
        self._hw_conf_match.grid(row=3, column=2, padx=(4, 18), pady=4)
        ctk.CTkLabel(pc, text="Strength:", anchor="e", width=255,
            font=ctk.CTkFont(size=11),
            text_color=COLORS["text_secondary"],
        ).grid(row=4, column=0, padx=(20, 8), pady=(2, 4))
        self._hw_strength_bar = ctk.CTkProgressBar(pc, height=10,
            corner_radius=5)
        self._hw_strength_bar.grid(row=4, column=1, sticky="ew",
            padx=(0, 8), pady=(2, 4))
        self._hw_strength_bar.set(0)
        self._hw_strength_lbl = ctk.CTkLabel(pc, text="", width=80,
            font=ctk.CTkFont(size=11))
        self._hw_strength_lbl.grid(row=4, column=2,
            padx=(0, 18), pady=(2, 4))
        self._hw_pw_feedback = ctk.CTkLabel(pc, text="",
            font=ctk.CTkFont(size=11), text_color=COLORS["accent_red"])
        self._hw_pw_feedback.grid(row=5, column=0, columnspan=3,
            pady=(4, 0))
        psr = ctk.CTkFrame(pc, fg_color="transparent")
        psr.grid(row=6, column=0, columnspan=3, sticky="ew",
            padx=20, pady=(8, 16))
        psr.grid_columnconfigure(0, weight=1)
        def _save_pw():
            cur = self._hw_cur_var.get()
            new = self._hw_new_var.get()
            conf = self._hw_conf_var.get()
            fb = self._hw_pw_feedback
            if _vis() and cur and not _vok(cur):
                fb.configure(text="\u274c Current password incorrect.",
                    text_color=COLORS["accent_red"]); return
            if not new:
                fb.configure(text="\u274c New password cannot be empty.",
                    text_color=COLORS["accent_red"]); return
            if new != conf:
                fb.configure(text="\u274c Passwords do not match.",
                    text_color=COLORS["accent_red"]); return
            if len(new) < 6:
                fb.configure(text="\u274c Minimum 6 characters.",
                    text_color=COLORS["accent_red"]); return
            _vset(new)
            fb.configure(text="\u2705 Password saved.",
                text_color=COLORS["accent_green"])
            for v in (self._hw_cur_var, self._hw_new_var,
                      self._hw_conf_var): v.set("")
            _rbadge()
            _hwlog("PASSWORD_SET", "Gatekeeper password updated")
        def _upd_str(*_):
            s, lbl, col = _pw_str(self._hw_new_var.get())
            self._hw_strength_bar.set(s)
            self._hw_strength_bar.configure(progress_color=col)
            self._hw_strength_lbl.configure(text=lbl, text_color=col)
        def _upd_mtch(*_):
            n = self._hw_new_var.get()
            c = self._hw_conf_var.get()
            if not c:
                self._hw_conf_match.configure(text="")
            elif n == c:
                self._hw_conf_match.configure(text="\u2705",
                    text_color="#10b981")
            else:
                self._hw_conf_match.configure(text="\u274c",
                    text_color="#ef4444")
        self._hw_new_var.trace_add("write",  _upd_str)
        self._hw_conf_var.trace_add("write", _upd_mtch)
        self._hw_new_var.trace_add("write",  _upd_mtch)
        ctk.CTkButton(psr, text="\U0001f4be  Save Password",
            command=_save_pw, height=44, corner_radius=10,
            fg_color=COLORS["accent_purple"], hover_color="#7c3aed",
            font=ctk.CTkFont(size=13, weight="bold"),
        ).grid(row=0, column=0, sticky="ew")

        # ══ 5. EVENT LOG ════════════════════════════════════════════════════
        lh = ctk.CTkFrame(scroll, fg_color=COLORS["bg_card"],
            corner_radius=12)
        lh.pack(fill="x", padx=18, pady=(14, 0))
        ctk.CTkLabel(lh, text="\U0001f4cb  Hardware Event Log",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLORS["text_primary"],
        ).pack(side="left", padx=18, pady=12)
        def _clr_log():
            for i in self._hw_tree.get_children():
                self._hw_tree.delete(i)
        ctk.CTkButton(lh, text="\U0001f5d1 Clear", command=_clr_log,
            width=90, height=32, corner_radius=8,
            fg_color=COLORS["bg_secondary"],
            hover_color=COLORS["accent_red"],
            font=ctk.CTkFont(size=11),
        ).pack(side="right", padx=18, pady=12)
        lw = ctk.CTkFrame(scroll, fg_color=COLORS["bg_secondary"],
            corner_radius=12)
        lw.pack(fill="x", padx=18, pady=(0, 18))
        sty = ttk.Style()
        sty.theme_use("default")
        sty.configure("HW.Treeview",
            background=COLORS["bg_secondary"],
            foreground=COLORS["text_primary"],
            fieldbackground=COLORS["bg_secondary"],
            rowheight=26, font=("Consolas", 11))
        sty.configure("HW.Treeview.Heading",
            background=COLORS["bg_card"],
            foreground=COLORS["text_secondary"],
            font=("Segoe UI", 10, "bold"))
        sty.map("HW.Treeview",
            background=[("selected", COLORS["accent_purple"])])
        cols = ("timestamp", "event", "detail")
        self._hw_tree = ttk.Treeview(lw, columns=cols,
            show="headings", height=10, style="HW.Treeview")
        self._hw_tree.heading("timestamp", text="Timestamp")
        self._hw_tree.heading("event",     text="Event")
        self._hw_tree.heading("detail",    text="Detail")
        self._hw_tree.column("timestamp", width=165, anchor="w")
        self._hw_tree.column("event",     width=160, anchor="w")
        self._hw_tree.column("detail",    width=540, anchor="w")
        vsb = ttk.Scrollbar(lw, orient="vertical",
            command=self._hw_tree.yview)
        self._hw_tree.configure(yscrollcommand=vsb.set)
        self._hw_tree.pack(side="left", fill="x", expand=True,
            padx=(10, 0), pady=10)
        vsb.pack(side="right", fill="y", pady=10, padx=(0, 10))
        self._hw_tree.tag_configure("locked",         foreground="#ef4444")
        self._hw_tree.tag_configure("unlocked",       foreground="#10b981")
        self._hw_tree.tag_configure("blocked",        foreground="#f59e0b")
        self._hw_tree.tag_configure("network_change", foreground="#3b82f6")
        self._hw_tree.tag_configure("bt_device",      foreground="#8b5cf6")
        self._hw_tree.tag_configure("info",
            foreground=COLORS["text_secondary"])

        # ── Log helper ────────────────────────────────────────────────────
        def _hwlog(etype, detail):
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            tag = {
                "LOCKED":          "locked",
                "UNLOCKED":        "unlocked",
                "BLOCKED":         "blocked",
                "STARTUP":         "locked",
                "NETWORK_CHANGE":  "network_change",
                "BT_DEVICE":       "bt_device",
                "PASSWORD_SET":    "info",
                "INFO":            "info",
            }.get(etype, "info")
            if hasattr(self, "_hw_tree"):
                self._hw_tree.insert("", "end",
                    values=(ts, etype, detail), tags=(tag,))
                self._hw_tree.yview_moveto(1.0)

        # ── Popup (used by enforcer + watch thread) ───────────────────────
        def _popup(reason="", detail="", on_approve=None, on_deny=None):
            if self._hw_popup_open: return
            self._hw_popup_open = True
            if reason == "wifi_change":
                ttl = "Wi-Fi Network Change Detected"
                icn = "\U0001f4f6"
                acc = "#3b82f6"
                msg = (f"Wi-Fi is switching to a new network.\n\n"
                       f"{detail}\n\n"
                       "Enter the gatekeeper password to allow this connection.")
            elif reason == "bt_new_device":
                ttl = "New Bluetooth Device Detected"
                icn = "\U0001f4f2"
                acc = "#8b5cf6"
                msg = (f"A new Bluetooth device is attempting to connect.\n\n"
                       f"{detail}\n\n"
                       "Enter the gatekeeper password to allow pairing.")
            else:
                ttl = "Hardware Access Restricted"
                icn = "\U0001f510"
                acc = "#ef4444"
                msg = ("An attempt to enable Bluetooth or Wi-Fi was blocked.\n"
                       "Enter the gatekeeper password to allow hardware access.")
                if detail and detail != "manual":
                    msg = f"Intercepted: {detail}\n\n" + msg
            pop = ctk.CTkToplevel(self)
            pop.title(f"{icn} {ttl}")
            pop.resizable(False, False)
            pop.attributes("-topmost", True)
            try: pop.attributes("-toolwindow", True)
            except Exception: pass
            pop.grab_set()
            W, H = 480, 340
            self.update_idletasks()
            px = self.winfo_x() + (self.winfo_width()  - W) // 2
            py = self.winfo_y() + (self.winfo_height() - H) // 2
            pop.geometry(f"{W}x{H}+{max(0,px)}+{max(0,py)}")
            ctk.CTkFrame(pop, fg_color=acc, height=5,
                corner_radius=0).pack(fill="x")
            bd = ctk.CTkFrame(pop, fg_color=COLORS["bg_card"],
                corner_radius=0)
            bd.pack(fill="both", expand=True)
            ctk.CTkLabel(bd, text=f"{icn}  {ttl}",
                font=ctk.CTkFont(size=15, weight="bold"),
                text_color=acc,
            ).pack(pady=(20, 8))
            ctk.CTkLabel(bd, text=msg,
                font=ctk.CTkFont(size=12),
                text_color=COLORS["text_secondary"], justify="center",
            ).pack(pady=(0, 12), padx=28)
            pv = ctk.StringVar()
            pe = ctk.CTkEntry(bd, textvariable=pv, show="\u25cf",
                height=42, corner_radius=10,
                placeholder_text="Gatekeeper password\u2026",
                font=ctk.CTkFont(size=13))
            pe.pack(padx=36, fill="x")
            # Give Tk time to render before setting focus — fixes unclickable entry
            pop.after(150, lambda: (pe.focus_set(), pe.icursor("end"))
                      if pop.winfo_exists() else None)
            el = ctk.CTkLabel(bd, text="",
                font=ctk.CTkFont(size=11), text_color="#ef4444")
            el.pack(pady=(5, 0))
            def _cls():
                self._hw_popup_open = False
                try: self.unbind_all("<FocusOut>")
                except Exception: pass
                pop.grab_release()
                pop.destroy()
            def _ok(*_):
                entered = pv.get()
                if not _vis() or _vok(entered):
                    self._hw_auth_active = True
                    hw = getattr(self, "hardware_gatekeeper", None)
                    if hw:
                        try: hw.authenticate()
                        except Exception: pass
                    if on_approve:
                        try: on_approve()
                        except Exception: pass
                    _hwlog("UNLOCKED",
                        f"Access granted ({reason or 'hardware'})")
                    _upd()
                    _cls()
                else:
                    el.configure(text="\u274c Incorrect password.")
                    pv.set("")
                    pe.focus_set()
            def _no():
                _hwlog("BLOCKED",
                    f"Access denied ({reason or 'hardware'})")
                if on_deny:
                    try: on_deny()
                    except Exception: pass
                _cls()
            pe.bind("<Return>", _ok)
            br = ctk.CTkFrame(bd, fg_color="transparent")
            br.pack(fill="x", padx=36, pady=(10, 20))
            br.grid_columnconfigure((0, 1), weight=1)
            ctk.CTkButton(br, text="\u2705  Allow",
                command=_ok, height=42, corner_radius=10,
                fg_color=COLORS["accent_green"], hover_color="#0d9668",
                font=ctk.CTkFont(size=13, weight="bold"),
            ).grid(row=0, column=0, padx=(0, 5), sticky="ew")
            ctk.CTkButton(br, text="\u274c  Deny & Block",
                command=_no, height=42, corner_radius=10,
                fg_color=COLORS["accent_red"], hover_color="#dc2626",
                font=ctk.CTkFont(size=13, weight="bold"),
            ).grid(row=0, column=1, padx=(5, 0), sticky="ew")
            pop.protocol("WM_DELETE_WINDOW", _no)

        # ── Wire gatekeeper alert callback ────────────────────────────────
        hw = getattr(self, "hardware_gatekeeper", None)
        if hw:
            def _hw_alert_cb(alert_type, detail):
                if (not self._hw_auth_active
                        and not self._hw_popup_open):
                    _hwlog("BLOCKED", f"{alert_type}: {detail}")
                    self.after(0, lambda d=detail:
                        _popup("radio_on", d))
            try: hw.alert_callback = _hw_alert_cb
            except Exception: pass

        _hwlog("STARTUP", "BT & Wi-Fi locked at application start")
        ctk.CTkFrame(scroll, fg_color="transparent", height=20).pack()


    # ==================== REAL-TIME PROTECTION TAB ====================

    def create_ai_agents_tab(self):
        """Three-panel AI Agents tab: Investigate → Plan → Act."""
        tab = self.tabview.tab("🤖 AI Agents")
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(1, weight=1)

        # ── Header ──────────────────────────────────────────────────────────
        header = ctk.CTkFrame(tab, fg_color=COLORS['bg_card'], corner_radius=12)
        header.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))

        ctk.CTkLabel(
            header,
            text="🤖  AI Agent Pipeline",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=COLORS['accent_purple']
        ).pack(side="left", padx=20, pady=12)

        ctk.CTkLabel(
            header,
            text="Investigate  →  Plan  →  Act (with your approval)",
            font=ctk.CTkFont(size=13),
            text_color=COLORS['text_secondary']
        ).pack(side="left", padx=10, pady=12)

        # Run-all button
        self.run_pipeline_btn = ctk.CTkButton(
            header,
            text="▶  Run Full Pipeline",
            command=self.run_full_agent_pipeline,
            height=38,
            width=180,
            corner_radius=10,
            fg_color=COLORS['accent_purple'],
            hover_color="#7c3aed",
            font=ctk.CTkFont(size=13, weight="bold")
        )
        self.run_pipeline_btn.pack(side="right", padx=20, pady=12)

        # ── Three columns ────────────────────────────────────────────────────
        columns_frame = ctk.CTkFrame(tab, fg_color="transparent")
        columns_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        columns_frame.grid_columnconfigure((0, 1, 2), weight=1)
        columns_frame.grid_rowconfigure(0, weight=1)

        # ── Column 1: Investigative Agent ────────────────────────────────────
        inv_frame = ctk.CTkFrame(
            columns_frame, fg_color=COLORS['bg_card'],
            corner_radius=12, border_width=2, border_color=COLORS['accent_blue']
        )
        inv_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        inv_frame.grid_rowconfigure(2, weight=1)
        inv_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            inv_frame, text="🔬  Investigative Agent",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLORS['accent_blue']
        ).grid(row=0, column=0, sticky="w", padx=15, pady=(12, 4))

        ctk.CTkLabel(
            inv_frame, text="Analyses threats & builds an incident report",
            font=ctk.CTkFont(size=11), text_color=COLORS['text_secondary']
        ).grid(row=1, column=0, sticky="w", padx=15, pady=(0, 8))

        self.inv_report_text = ctk.CTkTextbox(
            inv_frame, fg_color=COLORS['bg_primary'],
            corner_radius=8, font=ctk.CTkFont(family="Consolas", size=11),
            wrap="word"
        )
        self.inv_report_text.grid(row=2, column=0, sticky="nsew", padx=10, pady=(0, 8))
        self.inv_report_text.insert("end", "Click '▶ Run Full Pipeline' or 'Investigate' to analyse detected threats.\n")
        self.inv_report_text.configure(state="disabled")

        self.investigate_btn = ctk.CTkButton(
            inv_frame, text="🔬 Investigate Now",
            command=self.run_investigative_agent,
            height=38, corner_radius=10,
            fg_color=COLORS['accent_blue'], hover_color="#2563eb"
        )
        self.investigate_btn.grid(row=3, column=0, padx=10, pady=(0, 12), sticky="ew")

        # ── Column 2: Planning Agent ──────────────────────────────────────────
        plan_frame = ctk.CTkFrame(
            columns_frame, fg_color=COLORS['bg_card'],
            corner_radius=12, border_width=2, border_color=COLORS['accent_orange']
        )
        plan_frame.grid(row=0, column=1, sticky="nsew", padx=5)
        plan_frame.grid_rowconfigure(2, weight=1)
        plan_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            plan_frame, text="📋  Planning Agent",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLORS['accent_orange']
        ).grid(row=0, column=0, sticky="w", padx=15, pady=(12, 4))

        ctk.CTkLabel(
            plan_frame, text="Creates a step-by-step remediation plan",
            font=ctk.CTkFont(size=11), text_color=COLORS['text_secondary']
        ).grid(row=1, column=0, sticky="w", padx=15, pady=(0, 8))

        self.plan_text = ctk.CTkTextbox(
            plan_frame, fg_color=COLORS['bg_primary'],
            corner_radius=8, font=ctk.CTkFont(family="Consolas", size=11),
            wrap="word"
        )
        self.plan_text.grid(row=2, column=0, sticky="nsew", padx=10, pady=(0, 8))
        self.plan_text.insert("end", "Run Investigate first, then click 'Plan' to create a remediation plan.\n")
        self.plan_text.configure(state="disabled")

        self.plan_btn = ctk.CTkButton(
            plan_frame, text="📋 Create Plan",
            command=self.run_planning_agent,
            height=38, corner_radius=10,
            fg_color=COLORS['accent_orange'], hover_color="#d97706",
            state="disabled"
        )
        self.plan_btn.grid(row=3, column=0, padx=10, pady=(0, 12), sticky="ew")

        # ── Column 3: Action Agent ────────────────────────────────────────────
        act_frame = ctk.CTkFrame(
            columns_frame, fg_color=COLORS['bg_card'],
            corner_radius=12, border_width=2, border_color=COLORS['accent_red']
        )
        act_frame.grid(row=0, column=2, sticky="nsew", padx=(5, 0))
        act_frame.grid_rowconfigure(2, weight=1)
        act_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            act_frame, text="⚡  Action Agent",
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=COLORS['accent_red']
        ).grid(row=0, column=0, sticky="w", padx=15, pady=(12, 4))

        ctk.CTkLabel(
            act_frame, text="Executes each step — asks your permission first",
            font=ctk.CTkFont(size=11), text_color=COLORS['text_secondary']
        ).grid(row=1, column=0, sticky="w", padx=15, pady=(0, 8))

        self.action_log_text = ctk.CTkTextbox(
            act_frame, fg_color=COLORS['bg_primary'],
            corner_radius=8, font=ctk.CTkFont(family="Consolas", size=11),
            wrap="word"
        )
        self.action_log_text.grid(row=2, column=0, sticky="nsew", padx=10, pady=(0, 8))
        self.action_log_text.insert("end", "Plan will be executed here, one step at a time.\nYou will approve or deny each action before it runs.\n")
        self.action_log_text.configure(state="disabled")

        # Stop button
        self.stop_agents_btn = ctk.CTkButton(
            act_frame, text="⏹ Stop Agent",
            command=self._stop_action_agent,
            height=38, corner_radius=10,
            fg_color="#374151", hover_color="#4b5563",
            state="disabled"
        )
        self.stop_agents_btn.grid(row=3, column=0, padx=10, pady=(0, 5), sticky="ew")

        self.execute_plan_btn = ctk.CTkButton(
            act_frame, text="⚡ Execute Plan",
            command=self.run_action_agent,
            height=38, corner_radius=10,
            fg_color=COLORS['accent_red'], hover_color="#dc2626",
            state="disabled"
        )
        self.execute_plan_btn.grid(row=4, column=0, padx=10, pady=(0, 12), sticky="ew")

    # ── Agent logic ──────────────────────────────────────────────────────────

    def _on_scan_complete_trigger_agents(self):
        """
        Called automatically 800ms after a scan finishes.
        Shows a compact popup summary, then — if the user agrees — runs the
        Investigate → Plan → Act pipeline.
        """
        try:
            status = self.hub.get_scan_status()
            files   = status.get('files_scanned', 0)
            threats = status.get('threats_found', 0)
            self._current_scan_session_id = getattr(self.hub, 'scan_session_id', None)
        except Exception:
            files, threats = 0, 0
            self._current_scan_session_id = None

        try:
            self.tabview.set("🤖 AI Agents")
        except Exception:
            pass

        net_stats    = self.network_monitor.get_stats()
        net_alerts   = net_stats.get("total_alerts", 0)
        net_critical = net_stats.get("alerts_by_severity", {}).get("CRITICAL", 0)
        severity_hint = (
            "CRITICAL" if (threats >= 5 or net_critical > 0) else
            "HIGH"     if threats >= 2                        else
            "MEDIUM"   if threats  > 0                        else "CLEAN"
        )

        clean = max(0, files - threats)
        self._append_to_log(
            f"[AI] Scan finished — {threats} threat(s). Launching agent pipeline...", "system"
        )
        self._show_scan_summary_dialog(files, threats, clean, net_alerts, net_critical, severity_hint)

    def _show_scan_summary_dialog(self, files, threats, clean, net_alerts, net_critical, severity_hint):
        """Compact fixed-size scan-complete dialog (replaces the huge messagebox)."""
        import tkinter as tk

        dlg = ctk.CTkToplevel(self)
        dlg.title("Scan Complete")
        dlg.resizable(False, False)
        dlg.grab_set()
        dlg.lift()
        dlg.focus_force()

        # Size: compact 420 × auto — centred on parent
        DLG_W = 420
        self.update_idletasks()
        px = self.winfo_x() + (self.winfo_width()  - DLG_W) // 2
        py = self.winfo_y() + (self.winfo_height() - 260)   // 2
        dlg.geometry(f"{DLG_W}+{max(0,px)}+{max(0,py)}")

        DARK   = COLORS['bg_card']
        ACCENT = "#ef4444" if threats > 0 else "#22c55e"
        TEXT   = COLORS['text_primary']
        SUBTEXT= COLORS['text_secondary']

        # ── Header strip ────────────────────────────────────────────────────
        hdr = ctk.CTkFrame(dlg, fg_color=ACCENT, corner_radius=0, height=6)
        hdr.pack(fill="x")

        body_frame = ctk.CTkFrame(dlg, fg_color=DARK, corner_radius=0)
        body_frame.pack(fill="both", expand=True, padx=0, pady=0)
        body_frame.columnconfigure(0, weight=1)

        icon_char = "[WARNING]️" if threats > 0 else "✅"
        heading   = (f"Scan Complete — {threats} Threat(s) Found"
                     if threats > 0 else "Scan Complete — System Clean")

        ctk.CTkLabel(body_frame, text=f"{icon_char}  {heading}",
                     font=ctk.CTkFont(size=14, weight="bold"),
                     text_color=ACCENT).pack(pady=(16,4), padx=16)

        # ── Stats row ───────────────────────────────────────────────────────
        stats_fr = ctk.CTkFrame(body_frame, fg_color=COLORS['bg_secondary'], corner_radius=8)
        stats_fr.pack(fill="x", padx=16, pady=4)
        stats_fr.columnconfigure((0,1,2), weight=1)

        def stat_cell(parent, col, val, lbl, color=TEXT):
            ctk.CTkLabel(parent, text=str(val),
                         font=ctk.CTkFont(size=18, weight="bold"),
                         text_color=color).grid(row=0, column=col, padx=10, pady=(8,2))
            ctk.CTkLabel(parent, text=lbl,
                         font=ctk.CTkFont(size=10),
                         text_color=SUBTEXT).grid(row=1, column=col, padx=10, pady=(0,8))

        stat_cell(stats_fr, 0, f"{files:,}", "Files Scanned")
        stat_cell(stats_fr, 1, threats,      "Threats Found",   "#ef4444" if threats > 0 else "#22c55e")
        stat_cell(stats_fr, 2, net_alerts,   "Network Alerts",  "#f59e0b" if net_alerts > 0 else TEXT)

        # ── Clean stats ──────────────────────────────────────────────────────
        ctk.CTkLabel(body_frame,
                     text=f"Clean files: {clean}",
                     font=ctk.CTkFont(size=11),
                     text_color=SUBTEXT).pack(pady=(4,2))

        # ── Detail line ─────────────────────────────────────────────────────
        if threats > 0 or net_alerts > 0:
            details = []
            if threats > 0:
                details.append(f"Severity: {severity_hint}")
            if net_critical > 0:
                details.append(f"{net_critical} CRITICAL network alert(s)")
            ctk.CTkLabel(body_frame, text=" · ".join(details),
                         font=ctk.CTkFont(size=11),
                         text_color="#f59e0b").pack(pady=(4,2))

        # ── Buttons — threat vs clean path ──────────────────────────────────
        btn_fr = ctk.CTkFrame(body_frame, fg_color="transparent")
        btn_fr.pack(pady=(0,16))

        has_issues = threats > 0 or net_alerts > 0

        if has_issues:
            # Threats or network alerts found → offer pipeline
            ctk.CTkLabel(body_frame,
                         text="Run the AI Agent pipeline?\n(Investigate → Plan → approve actions)",
                         font=ctk.CTkFont(size=11),
                         text_color=SUBTEXT,
                         justify="center").pack(pady=(6,4))

            def _proceed():
                dlg.destroy()
                self._append_to_log("[AI] User approved — starting Investigative Agent.", "system")
                self.run_investigative_agent(then_plan=True)

            def _skip():
                dlg.destroy()
                self._append_to_log("[AI] User skipped agent pipeline — run manually via the AI Agents tab.", "info")

            ctk.CTkButton(btn_fr, text="▶  Run Pipeline", command=_proceed,
                          width=140, height=34, corner_radius=8,
                          fg_color=ACCENT, hover_color="#dc2626",
                          font=ctk.CTkFont(size=12, weight="bold")).pack(side="left", padx=6)
            ctk.CTkButton(btn_fr, text="Skip", command=_skip,
                          width=90, height=34, corner_radius=8,
                          fg_color=COLORS['bg_secondary'],
                          hover_color=COLORS['bg_primary']).pack(side="left", padx=6)
        else:
            # All clean → just an OK button, no pipeline needed
            ctk.CTkLabel(body_frame,
                         text="No threats detected. Your system is safe.",
                         font=ctk.CTkFont(size=11),
                         text_color=SUBTEXT,
                         justify="center").pack(pady=(6,4))

            def _ok():
                dlg.destroy()
                self._append_to_log("[AI] Scan complete — system clean. No action needed.", "clean")

            ctk.CTkButton(btn_fr, text="✅  OK", command=_ok,
                          width=120, height=34, corner_radius=8,
                          fg_color="#22c55e", hover_color="#16a34a",
                          font=ctk.CTkFont(size=12, weight="bold")).pack(side="left", padx=6)

    def run_full_agent_pipeline(self):
        """Run all three agents sequentially."""
        self.run_investigative_agent(then_plan=True)

    def run_investigative_agent(self, then_plan: bool = False):
        """Fetch threats from DB and run InvestigativeAgent."""
        session_id = getattr(self.hub, 'scan_session_id', None)
        if not session_id:
            messagebox.showwarning(
                "No scan data", "Please run a file scan before executing the AI agent pipeline.")
            return
        # FIX: Allow re-running the pipeline (e.g. clean-scan run requested by user).
        # Old code blocked ALL re-runs with no way to override — even when the user
        # explicitly clicked "Run Full Pipeline" or "Run Pipeline" in the scan dialog.
        # Now we just reset the guard so the pipeline always runs on demand.
        if self._last_pipeline_session_id == session_id:
            # Reset so _work() can proceed
            self._last_pipeline_session_id = None

        self.investigate_btn.configure(state="disabled", text="Investigating...")
        self._agent_log(self.inv_report_text, "🔬 Investigative Agent starting...\n", clear=True)

        def _work():
            try:
                # FIX: Use the session_id captured in the outer scope (no re-assignment).
                # The old code reassigned session_id inside _work(), causing an
                # UnboundLocalError because Python saw the later assignment and
                # treated the variable as local throughout the function.
                current_session_id = getattr(self.hub, 'scan_session_id', None) or session_id

                # Mark pipeline as having started for this scan session.
                self._last_pipeline_session_id = current_session_id

                # Get threats from current scan session
                if current_session_id:
                    scan_threats = self.db.get_scan_history_by_session(current_session_id) or []
                else:
                    scan_threats = self.db.get_recent_threats(limit=50) or []

                # Also include any recent real-time dynamic alerts
                if self.monitoring_active:
                    dynamic_alerts = self.db.get_process_alerts(limit=50) or []
                    for alert in dynamic_alerts:
                        scan_threats.append({
                            "threat_name": alert.get("alert_type"),
                            "threat_type": alert.get("severity"),
                            "action": alert.get("action_taken"),
                            "path": alert.get("process_name")
                        })

                threats = scan_threats
                scan_path = str(self.selected_path) if hasattr(self, 'selected_path') and self.selected_path else None
                report = self.investigative_agent.investigate(threats, scan_path)
                self._current_inv_report = report
                # FIX: capture report in lambda default arg to avoid late-binding closure issue
                self.after(0, lambda r=report, tp=then_plan: self._display_inv_report(r, tp))
            except Exception as e:
                # FIX: capture e in lambda default arg — when the except block exits,
                # Python clears the name 'e'; the lambda would then raise NameError.
                err_msg = str(e)
                self.after(0, lambda m=err_msg: self._agent_log(
                    self.inv_report_text, f"\u274c Error: {m}\n"
                ))
            finally:
                self.after(0, lambda: self.investigate_btn.configure(
                    state="normal", text="\U0001f52c Investigate Now"
                ))

        threading.Thread(target=_work, daemon=True).start()

    def _display_inv_report(self, report, then_plan: bool):
        """Render investigation report in the textbox."""
        lines = [
            f"{'='*55}",
            f"  INVESTIGATION REPORT  {report.report_id}",
            f"{'='*55}",
            f"Generated : {report.generated_at}",
            f"Severity  : {report.severity}",
            f"Risk Score: {report.risk_score}/100",
            f"Threats   : {report.threat_count}",
            "",
            "EXECUTIVE SUMMARY",
            "-"*40,
            report.executive_summary,
            "",
            "FINDINGS",
            "-"*40,
        ]
        for f in report.findings:
            lines.append(f"  • {f}")
        lines += [
            "",
            "RECOMMENDED ACTIONS",
            "-"*40,
        ]
        for i, a in enumerate(report.recommended_actions, 1):
            lines.append(f"  {i}. {a}")
        lines += [
            "",
            f"INDICATORS OF COMPROMISE ({len(report.indicators)})",
            "-"*40,
        ]
        for ind in report.indicators[:10]:
            lines.append(f"  [{ind['indicator_type'].upper()}] {ind['value']} — {ind['confidence']}")

        self._agent_log(self.inv_report_text, "\n".join(lines), clear=True)
        self.plan_btn.configure(state="normal")
        self._append_to_log(
            f"[AI] Investigation complete — severity: {report.severity}, risk: {report.risk_score}/100",
            "info"
        )
        if then_plan:
            self.after(300, lambda: self.run_planning_agent(then_execute=True))

    def run_planning_agent(self, then_execute: bool = False):
        """Run PlanningAgent on the current InvestigationReport."""
        if self._current_inv_report is None:
            messagebox.showwarning("No Report", "Run Investigate first.")
            return
        self.plan_btn.configure(state="disabled", text="Planning...")
        self._agent_log(self.plan_text, "📋 Planning Agent creating remediation plan...\n", clear=True)

        def _work():
            try:
                plan = self.planning_agent.plan(self._current_inv_report)
                self._current_plan = plan
                self.after(0, lambda: self._display_plan(plan, then_execute=then_execute))
            except Exception as e:
                self.after(0, lambda: self._agent_log(self.plan_text, f"❌ Error: {e}\n"))
            finally:
                self.after(0, lambda: self.plan_btn.configure(state="normal", text="📋 Create Plan"))

        threading.Thread(target=_work, daemon=True).start()

    def _display_plan(self, plan, then_execute: bool = False):
        """Render remediation plan."""
        lines = [
            f"{'='*55}",
            f"  REMEDIATION PLAN  {plan.plan_id}",
            f"{'='*55}",
            f"Created  : {plan.created_at}",
            f"Severity : {plan.severity}",
            f"Actions  : {plan.total_actions}",
            "",
            "WARNINGS",
            "-"*40,
        ]
        for w in plan.warnings:
            lines.append(f"  {w}")
        lines += ["", "ACTION SEQUENCE", "-"*40]

        for action in plan.actions:
            risk_icon = {"SAFE": "🟢", "MODERATE": "🟡", "DESTRUCTIVE": "🔴"}.get(
                action.get("risk_level", "SAFE"), "⚪"
            )
            lines.append(
                f"\n  Step {action['step']}: {action['action_type'].upper()} {risk_icon}"
            )
            lines.append(f"  Target  : {action['target']}")
            lines.append(f"  Action  : {action['description']}")
            lines.append(f"  Why     : {action['rationale']}")
            lines.append(f"  Risk    : {action.get('risk_level','?')}  |  Reversible: {action.get('reversible','?')}")

        lines += ["", "-"*55, plan.summary]
        self._agent_log(self.plan_text, "\n".join(lines), clear=True)
        self.execute_plan_btn.configure(state="normal")
        self._append_to_log(f"[AI] Remediation plan ready — {plan.total_actions} action(s).", "info")

        # Auto-pipeline: show popup asking to proceed to execution
        if then_execute:
            self.after(400, lambda: self._prompt_execute_plan(plan))

    def _prompt_execute_plan(self, plan):
        """
        Compact fixed-size plan-execution dialog.
        Replaces the oversized messagebox with a scrollable action list.
        """
        self._show_plan_approval_dialog(plan)

    def _show_plan_approval_dialog(self, plan):
        """
        Plan approval dialog.
        The action list is a FIXED-HEIGHT scrollable area — buttons are
        always visible at the bottom no matter how many steps there are.
        """
        safe        = sum(1 for a in plan.actions if a.get("risk_level") == "SAFE")
        moderate    = sum(1 for a in plan.actions if a.get("risk_level") == "MODERATE")
        destructive = sum(1 for a in plan.actions if a.get("risk_level") == "DESTRUCTIVE")

        dlg = ctk.CTkToplevel(self)
        dlg.title("Execute Remediation Plan?")
        dlg.resizable(False, False)
        dlg.grab_set()
        dlg.lift()
        dlg.focus_force()

        # Fixed dialog size — buttons always visible
        DLG_W = 500
        DLG_H = 480
        self.update_idletasks()
        screen_h = self.winfo_screenheight()
        DLG_H    = min(DLG_H, screen_h - 80)
        px = self.winfo_x() + (self.winfo_width()  - DLG_W) // 2
        py = max(20, self.winfo_y() + (self.winfo_height() - DLG_H) // 2)
        dlg.geometry(f"{DLG_W}x{DLG_H}+{max(0,px)}+{py}")

        DARK   = COLORS['bg_card']
        DARK2  = COLORS['bg_secondary']
        ACCENT = "#f59e0b" if destructive == 0 else "#ef4444"

        # ── colour strip at top ──────────────────────────────────────────────
        ctk.CTkFrame(dlg, fg_color=ACCENT, corner_radius=0, height=6).pack(fill="x")

        # ── title ────────────────────────────────────────────────────────────
        ctk.CTkLabel(dlg, text="⚡  Remediation Plan Ready",
                     font=ctk.CTkFont(size=15, weight="bold"),
                     fg_color=DARK, text_color=ACCENT,
                     corner_radius=0).pack(fill="x", pady=(10, 4))

        # ── stat badges ──────────────────────────────────────────────────────
        badge_fr = ctk.CTkFrame(dlg, fg_color=DARK2, corner_radius=8)
        badge_fr.pack(fill="x", padx=16, pady=(0, 6))
        badge_fr.columnconfigure((0,1,2,3), weight=1)

        def _badge(col, val, lbl, color):
            ctk.CTkLabel(badge_fr, text=str(val),
                         font=ctk.CTkFont(size=18, weight="bold"),
                         text_color=color).grid(row=0, column=col, padx=8, pady=(8,2))
            ctk.CTkLabel(badge_fr, text=lbl,
                         font=ctk.CTkFont(size=9),
                         text_color=COLORS['text_secondary']).grid(row=1, column=col, padx=8, pady=(0,8))

        _badge(0, plan.total_actions, "Total Steps",  COLORS['text_primary'])
        _badge(1, safe,               "🟢 Safe",      "#22c55e")
        _badge(2, moderate,           "🟡 Moderate",  "#f59e0b")
        _badge(3, destructive,        "🔴 Destruct",  "#ef4444")

        # ── scrollable action list — fixed height so buttons stay visible ────
        ctk.CTkLabel(dlg, text="Planned Actions:",
                     font=ctk.CTkFont(size=11, weight="bold"),
                     text_color=COLORS['text_secondary'],
                     fg_color=DARK).pack(anchor="w", padx=18, pady=(4, 2))

        # Action list takes a fixed 180px — leaves plenty of room for buttons
        scroll = ctk.CTkScrollableFrame(dlg, height=180,
                                        fg_color=DARK2, corner_radius=6)
        scroll.pack(fill="x", padx=16, pady=(0, 8))

        risk_icons = {"SAFE": "🟢", "MODERATE": "🟡", "DESTRUCTIVE": "🔴"}
        for a in plan.actions:
            icon    = risk_icons.get(a.get("risk_level", "SAFE"), "⚪")
            tgt     = str(a.get("target", ""))
            tgt_short = tgt if len(tgt) <= 45 else "…" + tgt[-42:]
            row_txt = f"{icon}  Step {a['step']}: {a['action_type'].upper()}  ·  {tgt_short}"
            ctk.CTkLabel(scroll, text=row_txt,
                         font=ctk.CTkFont(size=10),
                         text_color=COLORS['text_primary'],
                         anchor="w").pack(fill="x", padx=6, pady=2)

        # ── divider ──────────────────────────────────────────────────────────
        ctk.CTkFrame(dlg, fg_color=DARK2, height=1,
                     corner_radius=0).pack(fill="x", padx=16, pady=(4, 0))

        # ── note ─────────────────────────────────────────────────────────────
        ctk.CTkLabel(dlg,
                     text="Tick actions to approve in the next step.\nNo file is changed without your explicit YES.",
                     font=ctk.CTkFont(size=10),
                     text_color=COLORS['text_secondary'],
                     justify="center",
                     fg_color=DARK).pack(pady=(8, 6))

        # ── YES / NO buttons — always at the bottom, always visible ──────────
        btn_fr = ctk.CTkFrame(dlg, fg_color=DARK, corner_radius=0)
        btn_fr.pack(fill="x", side="bottom", pady=(0, 16))

        def _yes():
            dlg.destroy()
            self._append_to_log("[AI] User said YES — starting Action Agent.", "system")
            self.run_action_agent()

        def _no():
            dlg.destroy()
            self._append_to_log("[AI] User said NO — execution deferred.", "info")

        ctk.CTkButton(
            btn_fr, text="✅  YES — Proceed to Approve Actions",
            command=_yes,
            width=260, height=44, corner_radius=10,
            fg_color="#16a34a", hover_color="#15803d",
            font=ctk.CTkFont(size=13, weight="bold")
        ).pack(side="left", padx=(24, 8), pady=8)

        ctk.CTkButton(
            btn_fr, text="❌  NO — Cancel",
            command=_no,
            width=150, height=44, corner_radius=10,
            fg_color="#dc2626", hover_color="#b91c1c",
            font=ctk.CTkFont(size=13, weight="bold")
        ).pack(side="left", padx=8, pady=8)

    def run_action_agent(self):
        """
        Show ONE batch-approval dialog for all actions, then execute
        only the ones the user ticked — no more per-action interruptions.
        """
        if self._current_plan is None:
            messagebox.showwarning("No Plan", "Run the Planning Agent first.")
            return

        scan_path = str(self.selected_path) if hasattr(self, 'selected_path') and self.selected_path else None
        self._show_batch_approval_dialog(self._current_plan, scan_path)

    def _show_batch_approval_dialog(self, plan, scan_path):
        """
        Single popup with a checkbox per action.
        User checks/unchecks each action, then clicks Execute Once.
        All approved actions run in one background pass — no more interruptions.
        """
        import tkinter as tk

        dlg = ctk.CTkToplevel(self)
        dlg.title("Approve Actions")
        dlg.resizable(False, False)
        dlg.grab_set()
        dlg.lift()
        dlg.focus_force()

        DLG_W = 520
        DLG_H = min(520, max(320, 160 + len(plan.actions) * 54))
        self.update_idletasks()
        px = self.winfo_x() + (self.winfo_width()  - DLG_W) // 2
        py = self.winfo_y() + (self.winfo_height() - DLG_H) // 2
        dlg.geometry(f"{DLG_W}x{DLG_H}+{max(0,px)}+{max(0,py)}")

        DARK   = COLORS['bg_card']
        DARK2  = COLORS['bg_secondary']
        TEXT   = COLORS['text_primary']
        SUBTEXT= COLORS['text_secondary']
        RISK_C = {"SAFE": "#22c55e", "MODERATE": "#f59e0b", "DESTRUCTIVE": "#ef4444"}
        RISK_I = {"SAFE": "🟢",     "MODERATE": "🟡",      "DESTRUCTIVE": "🔴"}

        # Accent colour based on highest risk
        has_destr   = any(a.get("risk_level") == "DESTRUCTIVE" for a in plan.actions)
        has_mod     = any(a.get("risk_level") == "MODERATE"    for a in plan.actions)
        ACCENT      = "#ef4444" if has_destr else ("#f59e0b" if has_mod else "#22c55e")

        # ── Header ──────────────────────────────────────────────────────────
        hdr = ctk.CTkFrame(dlg, fg_color=ACCENT, corner_radius=0, height=5)
        hdr.pack(fill="x")

        outer = ctk.CTkFrame(dlg, fg_color=DARK, corner_radius=0)
        outer.pack(fill="both", expand=True)

        ctk.CTkLabel(outer, text="⚡  Select Actions to Execute",
                     font=ctk.CTkFont(size=14, weight="bold"),
                     text_color=ACCENT).pack(pady=(12, 2))
        ctk.CTkLabel(outer,
                     text="Tick the actions you approve. All selected actions run at once.",
                     font=ctk.CTkFont(size=10), text_color=SUBTEXT).pack(pady=(0, 8))

        # ── Bottom Controls (Packed first to guarantee visibility) ───────────
        bottom_frame = ctk.CTkFrame(outer, fg_color="transparent")
        bottom_frame.pack(side="bottom", fill="x")
        
        btn_fr = ctk.CTkFrame(bottom_frame, fg_color="transparent")
        btn_fr.pack(side="bottom", pady=(0,12))
        
        sel_fr = ctk.CTkFrame(bottom_frame, fg_color="transparent")
        sel_fr.pack(side="bottom", anchor="w", padx=20, pady=(0,6))

        # ── Scrollable action checklist ──────────────────────────────────────
        scroll = ctk.CTkScrollableFrame(outer, fg_color=DARK2, corner_radius=8)
        scroll.pack(side="top", fill="both", expand=True, padx=16, pady=(0, 6))
        scroll.columnconfigure(0, weight=1)

        check_vars = []  # list of (tk.BooleanVar, action_dict)
        for a in plan.actions:
            rl    = a.get("risk_level", "SAFE")
            icon  = RISK_I.get(rl, "⚪")
            color = RISK_C.get(rl, TEXT)
            rev   = "reversible" if a.get("reversible", True) else "PERMANENT"

            var = tk.BooleanVar(value=True)   # pre-ticked
            check_vars.append((var, a))

            row_fr = ctk.CTkFrame(scroll, fg_color=DARK, corner_radius=6)
            row_fr.pack(fill="x", pady=3, padx=4)
            row_fr.columnconfigure(1, weight=1)

            # Checkbox
            ctk.CTkCheckBox(row_fr, variable=var, text="",
                            width=24, height=24,
                            checkbox_width=18, checkbox_height=18,
                            fg_color=color, hover_color=color,
                            border_color=COLORS['bg_secondary']).grid(
                row=0, column=0, rowspan=2, padx=(8,4), pady=6)

            # Step label
            ctk.CTkLabel(row_fr,
                         text=f"{icon}  Step {a['step']}: {a['action_type'].upper()}  [{rl}]  ·  {rev}",
                         font=ctk.CTkFont(size=11, weight="bold"),
                         text_color=color, anchor="w").grid(
                row=0, column=1, sticky="ew", padx=4, pady=(6,0))

            # Target
            tgt = str(a.get("target",""))
            short_tgt = tgt if len(tgt) <= 55 else "…" + tgt[-52:]
            ctk.CTkLabel(row_fr, text=short_tgt,
                         font=ctk.CTkFont(size=9),
                         text_color=SUBTEXT, anchor="w").grid(
                row=1, column=1, sticky="ew", padx=4, pady=(0,6))

        # ── Select All / None ────────────────────────────────────────────────
        def _all():
            for v,_ in check_vars: v.set(True)
        def _none():
            for v,_ in check_vars: v.set(False)

        ctk.CTkButton(sel_fr, text="Select All",  command=_all,
                      width=90, height=26, corner_radius=6,
                      fg_color=DARK2).pack(side="left", padx=(0,4))
        ctk.CTkButton(sel_fr, text="Select None", command=_none,
                      width=90, height=26, corner_radius=6,
                      fg_color=DARK2).pack(side="left")

        # ── Execute / Cancel ────────────────────────────────────────────────
        def _execute():
            approved_actions = [a for v,a in check_vars if v.get()]
            dlg.destroy()
            if not approved_actions:
                self._append_to_log("[AI] No actions selected — execution skipped.", "info")
                return
            self._run_approved_actions(approved_actions, scan_path)

        def _cancel():
            dlg.destroy()
            self._append_to_log("[AI] Action execution cancelled by user.", "info")

        yes_btn = ctk.CTkButton(
            btn_fr,
            text=f"✅  YES — Execute {len(plan.actions)} Action(s)",
            command=_execute,
            width=230, height=40, corner_radius=10,
            fg_color="#16a34a", hover_color="#15803d",
            font=ctk.CTkFont(size=13, weight="bold")
        )
        yes_btn.pack(side="left", padx=8)

        ctk.CTkButton(
            btn_fr,
            text="❌  NO — Cancel",
            command=_cancel,
            width=140, height=40, corner_radius=10,
            fg_color="#dc2626", hover_color="#b91c1c",
            font=ctk.CTkFont(size=13, weight="bold")
        ).pack(side="left", padx=8)

        # Keep YES button label in sync with checkbox ticks
        def _update_btn_label(*_):
            n = sum(1 for v,_ in check_vars if v.get())
            yes_btn.configure(text=f"✅  YES — Execute {n} Action(s)")
        for v,_ in check_vars:
            v.trace_add("write", _update_btn_label)

    def _run_approved_actions(self, approved_actions: list, scan_path):
        """
        Execute pre-approved actions in a background thread — no per-action popups.
        The approval_callback always returns True because user already approved
        everything in the batch dialog.
        """
        # Build a lightweight plan-like object that ActionAgent understands
        class _BatchPlan:
            def __init__(self, actions):
                self.actions = actions

        batch_plan = _BatchPlan(approved_actions)

        self.execute_plan_btn.configure(state="disabled", text="Executing...")
        self.stop_agents_btn.configure(state="normal")
        self._agent_log(self.action_log_text, "⚡ Action Agent executing approved actions...\n", clear=True)

        def approval_callback(action: dict) -> bool:
            # Pre-approved in batch dialog — always True
            return True

        def result_callback(result):
            status_icon = {"COMPLETED": "✅", "FAILED": "❌", "DENIED": "🚫"}.get(result.status, "⚪")
            line = (
                f"{status_icon} [{result.status}] {result.action_type.upper()} — "
                f"{result.message}"
            )
            if result.error:
                line += f"\n   ↳ Error: {result.error}"
            self.after(0, lambda: self._agent_log(self.action_log_text, line + "\n"))
            self.after(0, lambda: self._append_to_log(
                f"[ACTION] {result.action_type}: {result.status}", "info"
            ))

        self.action_agent.approval_callback = approval_callback
        self.action_agent.result_callback   = result_callback

        def _on_done():
            summary = self.action_agent.get_results_summary()
            done_msg = (
                f"\n{'='*50}\n"
                f"Execution complete.\n"
                f"  Completed : {summary['completed']}\n"
                f"  Failed    : {summary['failed']}\n"
                f"  Denied    : {summary['denied']}\n"
                f"{'='*50}\n"
            )
            self.after(0, lambda: self._agent_log(self.action_log_text, done_msg))
            self.after(0, lambda: self.execute_plan_btn.configure(state="normal", text="⚡ Execute Plan"))
            self.after(0, lambda: self.stop_agents_btn.configure(state="disabled"))

        def _worker():
            self.action_agent.execute_plan(batch_plan, scan_path).join()
            _on_done()

        threading.Thread(target=_worker, daemon=True).start()

    def _stop_action_agent(self):
        self.action_agent.stop()
        self._agent_log(self.action_log_text, "\n🛑 Stop requested — will halt after current action.\n")
        self.stop_agents_btn.configure(state="disabled")

    def _agent_log(self, textbox, text: str, clear: bool = False):
        """Write text to an agent textbox (main thread safe)."""
        try:
            textbox.configure(state="normal")
            if clear:
                textbox.delete("1.0", "end")
            textbox.insert("end", text)
            textbox.see("end")
            textbox.configure(state="disabled")
        except Exception:
            pass

    # ==================== PROCESS MONITOR ====================
    
    def refresh_processes(self):
        """Refresh process list."""
        if not PSUTIL_AVAILABLE:
            return
        
        for widget in self.process_frame.winfo_children():
            widget.destroy()
        
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_info']):
                try:
                    info = proc.info
                    processes.append({
                        'pid': info['pid'],
                        'name': info['name'],
                        'cpu': info['cpu_percent'],
                        'memory': info['memory_info'].rss / 1024 / 1024
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            processes.sort(key=lambda x: x['memory'], reverse=True)
            
            for proc in processes[:20]:
                self.create_process_item(proc)
                
        except Exception as e:
            print(f"Process refresh error: {e}")
    
    def create_process_item(self, proc: dict):
        """Create process item."""
        is_high_risk = proc['memory'] > 500 or proc['cpu'] > 50
        border_color = COLORS['accent_red'] if is_high_risk else COLORS['accent_blue']
        
        item = ctk.CTkFrame(
            self.process_frame,
            fg_color=COLORS['bg_card'],
            corner_radius=10,
            border_width=2,
            border_color=border_color
        )
        item.pack(fill="x", padx=5, pady=5)
        
        content = ctk.CTkFrame(item, fg_color="transparent")
        content.pack(fill="x", padx=15, pady=10)
        
        name_label = ctk.CTkLabel(
            content,
            text=f"⚙️ {proc['name']} (PID: {proc['pid']})",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLORS['accent_red'] if is_high_risk else COLORS['text_primary'],
            anchor="w"
        )
        name_label.pack(anchor="w")
        
        stats_label = ctk.CTkLabel(
            content,
            text=f"CPU: {proc['cpu']:.1f}% | RAM: {proc['memory']:.1f} MB",
            font=ctk.CTkFont(size=11),
            text_color=COLORS['text_secondary'],
            anchor="w"
        )
        stats_label.pack(anchor="w", pady=(5, 0))
    
    # ==================== USB & FIM MONITORING ====================
    
    def start_usb_monitoring(self):
        """Start USB monitoring."""
        if not PSUTIL_AVAILABLE:
            return
        
        self.usb_monitor_active = True
        self.known_drives = set(p.device for p in psutil.disk_partitions())
        
        def usb_monitor_thread():
            while self.usb_monitor_active:
                try:
                    current_drives = set(p.device for p in psutil.disk_partitions())
                    new_drives = current_drives - self.known_drives
                    
                    for drive in new_drives:
                        self.after(0, lambda d=drive: self.on_new_drive_detected(d))
                    
                    self.known_drives = current_drives
                except Exception as e:
                    print(f"USB monitor error: {e}")
                
                time.sleep(2)
        
        threading.Thread(target=usb_monitor_thread, daemon=True).start()
    
    def on_new_drive_detected(self, drive: str):
        """Handle new drive."""
        response = messagebox.askyesno(
            "New Drive Detected!",
            f"Drive {drive} was just plugged in.\n\nScan for threats now?"
        )
        
        if response:
            self.selected_path = Path(drive)
            self.select_folder_btn.configure(text=f"📁 {drive}")
            self.start_scan()
    
    def start_fim_monitoring(self):
        """Start FIM monitoring."""
        if not PSUTIL_AVAILABLE:
            return
        
        self.fim_monitor_active = True
        
        critical_files = []
        if os.name == 'nt':
            critical_files = [
                r"C:\Windows\System32\drivers\etc\hosts",
                r"C:\Windows\System32\cmd.exe",
            ]
        else:
            critical_files = [
                "/etc/hosts",
                "/bin/bash",
            ]
        
        for file_path in critical_files:
            try:
                if os.path.exists(file_path):
                    with open(file_path, 'rb') as f:
                        file_hash = hashlib.sha256(f.read()).hexdigest()
                    self.file_baselines[file_path] = file_hash
            except:
                pass
        
        def fim_monitor_thread():
            while self.fim_monitor_active:
                try:
                    for file_path, baseline_hash in list(self.file_baselines.items()):
                        if os.path.exists(file_path):
                            with open(file_path, 'rb') as f:
                                current_hash = hashlib.sha256(f.read()).hexdigest()
                            
                            if current_hash != baseline_hash:
                                self.after(
                                    0,
                                    lambda fp=file_path: self.on_integrity_violation(fp)
                                )
                                self.file_baselines[file_path] = current_hash
                except:
                    pass
                
                time.sleep(10)
        
        threading.Thread(target=fim_monitor_thread, daemon=True).start()
    
    def on_integrity_violation(self, file_path: str):
        """Handle integrity violation."""
        messagebox.showwarning(
            "INTEGRITY VIOLATION",
            f"Critical system file modified:\n{file_path}\n\n"
            "This may indicate malware activity!"
        )
    
    # ==================== BACKGROUND-ONLY FEATURES (no tabs) ====================

    def create_realtime_protection_tab(self):
        """Real-Time Protection runs silently in background — no tab needed."""
        pass

    def create_network_forensics_tab(self):
        """Network Forensics runs silently in background — no tab needed."""
        pass

    def create_threat_hunting_tab(self):
        """Threat Hunting removed from UI."""
        pass

    def _drain_dynamic_alerts(self):
        """Legacy stub — dynamic alert draining is now handled by the BG worker + poll_log_buffer."""
        pass

    def _update_rt_badges(self):
        """No-op — Real-Time Protection badges removed with tab."""
        pass

    def _append_rt_alert(self, alert):
        """Redirect RT alerts to live log instead of removed tab feed."""
        try:
            sev   = getattr(alert, "severity", "low").lower()
            title = getattr(alert, "title", str(alert))
            src   = getattr(alert, "source", "rt")
            self._append_to_log(
                f"[RT/{sev.upper()}] {title}",
                "threat" if sev in ("critical", "high") else "info"
            )
        except Exception:
            pass

    # ──────────────────────────────────────────────────────────────────────────
    # ADMIN PRIVILEGE MONITOR TAB HELPERS
    # ──────────────────────────────────────────────────────────────────────────

    def _refresh_vault_badge(self):
        """Update the admin vault status badge."""
        if hasattr(self, '_vault_status_badge'):
            has_pw = self.admin_priv_monitor.has_password()
            self._vault_status_badge.configure(
                text="🔐 Admin Password Set" if has_pw else "🔓 No Admin Password",
                fg_color=COLORS['accent_green'] if has_pw else COLORS['accent_red']
            )

    def _confirm_passwords(self):
        """Confirm that new and confirm passwords match."""
        new = self._new_pw_var.get()
        conf = self._conf_pw_var.get()
        if new == conf and new:
            self._passwords_confirmed = True
            self._conf_btn_feedback.configure(
                text="✅ Passwords match — ready to save.",
                text_color=COLORS['accent_green']
            )
        else:
            self._passwords_confirmed = False
            self._conf_btn_feedback.configure(
                text="❌ Passwords do not match.",
                text_color=COLORS['accent_red']
            )

    def _save_admin_password(self):
        """Save or change admin password."""
        if not self._passwords_confirmed:
            self._set_pw_feedback.configure(text="Please confirm passwords match first.")
            return

        cur = self._cur_pw_var.get()
        new = self._new_pw_var.get()

        has_pw = self.admin_priv_monitor.has_password()
        if has_pw:
            if not self.admin_priv_monitor.verify_password(cur):
                self._set_pw_feedback.configure(text="Current password is incorrect.")
                return

        self.admin_priv_monitor.set_password(new)
        self._set_pw_feedback.configure(text="Admin password saved successfully.", text_color=COLORS['accent_green'])
        self._refresh_admin_vault_badge()
        self._cur_pw_var.set("")
        self._new_pw_var.set("")
        self._conf_pw_var.set("")
        self._passwords_confirmed = False
        self._conf_btn_feedback.configure(
            text="\u26a0  Click 'Confirm Passwords Match' before saving.",
            text_color=COLORS['accent_orange']
        )

    def _toggle_pw_visibility(self):
        """Toggle password field visibility."""
        self._pw_visible = not self._pw_visible
        show_char = "" if self._pw_visible else "\u25cf"
        self._cur_pw_entry.configure(show=show_char)
        self._new_pw_entry.configure(show=show_char)
        self._conf_pw_entry.configure(show=show_char)
        self._clr_pw_entry.configure(show=show_char)

    def _clear_admin_password(self):
        """Remove admin password."""
        if not self.admin_priv_monitor.has_password():
            self._clr_feedback.configure(text="No admin password is set.")
            return

        pw = self._clr_pw_var.get()
        if not pw:
            self._clr_feedback.configure(text="Enter current password to remove.")
            return

        if not self.admin_priv_monitor.verify_password(pw):
            self._clr_feedback.configure(text="Incorrect password.")
            return

        self.admin_priv_monitor.clear_password()
        self._clr_feedback.configure(text="Admin password removed successfully.", text_color=COLORS['accent_green'])
        self._refresh_admin_vault_badge()
        self._clr_pw_var.set("")

    def _fire_test_priv_event(self):
        """Fire a test privilege escalation event."""
        # Simulate a privilege escalation attempt
        test_process = {
            "pid": 12345,
            "name": "test_elevated_process.exe",
            "path": "C:\\Windows\\System32\\test_elevated_process.exe",
            "user": "Administrator",
            "command_line": "test_elevated_process.exe --elevate"
        }
        self.admin_priv_monitor._on_privilege_attempt(test_process)

    # ──────────────────────────────────────────────────────────────────────────
    # HARDWARE GATEKEEPER TAB HELPERS
    # ──────────────────────────────────────────────────────────────────────────

    def _refresh_hw_vault_badge(self):
        """Update the HW vault status badge using the file-based vault."""
        from pathlib import Path
        hw_vault = Path("data") / "admin" / "hw_vault.dat"
        is_set = hw_vault.exists() and hw_vault.stat().st_size > 10
        badge = getattr(self, "_hw_vault_badge", None)
        if badge:
            badge.configure(
                text="🔑 Password Set" if is_set else "⚠  No Password",
                text_color="#10b981" if is_set else "#f59e0b")

    def _refresh_hw_status(self):
        """Stub — HW status is now updated via _apply_hw_stats by the BG worker heartbeat."""
        pass

    def _update_hw_conf_match(self):
        """Update confirm password match indicator for HW."""
        new = self._hw_new_var.get()
        conf = self._hw_conf_var.get()
        if not new and not conf:
            self._hw_conf_match_lbl.configure(text="")
            return
        if new == conf:
            self._hw_conf_match_lbl.configure(text="✓", text_color=COLORS['accent_green'])
        else:
            self._hw_conf_match_lbl.configure(text="✗", text_color=COLORS['accent_red'])

    def _save_hw_password(self):
        """Save or change HW password."""
        cur = self._hw_cur_var.get()
        new = self._hw_new_var.get()
        conf = self._hw_conf_var.get()

        if not new:
            self._hw_pw_feedback.configure(text="New password cannot be empty.")
            return
        if new != conf:
            self._hw_pw_feedback.configure(text="New passwords do not match.")
            return

        from pathlib import Path as _P
        _v = _P('data') / 'admin' / 'hw_vault.dat'
        has_pw = _v.exists() and _v.stat().st_size > 10
        if has_pw:
            if not self._vault_verify(_v, cur):
                self._hw_pw_feedback.configure(text="Current password is incorrect.")
                return

        self._vault_set(_v, new)
        if self.hardware_gatekeeper:
            self.hardware_gatekeeper.set_password(new)
        self._hw_pw_feedback.configure(text="Hardware password saved successfully.", text_color=COLORS['accent_green'])
        self._refresh_hw_vault_badge()
        self._hw_cur_var.set("")
        self._hw_new_var.set("")
        self._hw_conf_var.set("")

    def _hw_unlock_prompt(self):
        """Delegate to the new tab unlock popup (vault-based, no admin needed)."""
        if hasattr(self, '_hw_popup_open'):
            # new tab handles it via _show_hw_unlock_popup closure
            pass

    def _clear_hw_password(self):
        """Remove HW password via vault."""
        from pathlib import Path
        import hashlib as _hl
        hw_vault = Path("data") / "admin" / "hw_vault.dat"

        if not (hw_vault.exists() and hw_vault.stat().st_size > 10):
            if hasattr(self, "_hw_clr_feedback"):
                self._hw_clr_feedback.configure(text="No hardware password is set.")
            return

        pw = getattr(self, "_hw_clr_var", None)
        pw = pw.get() if pw else ""
        if not pw:
            if hasattr(self, "_hw_clr_feedback"):
                self._hw_clr_feedback.configure(text="Enter current password to remove.")
            return

        # Verify
        magic = "SENTINEL_V2"
        raw = f"{magic}:{pw}:{magic[::-1]}"
        if hw_vault.read_text().strip() != _hl.sha256(raw.encode()).hexdigest():
            if hasattr(self, "_hw_clr_feedback"):
                self._hw_clr_feedback.configure(text="❌ Incorrect password.")
            return

        hw_vault.unlink()
        if hasattr(self, "_hw_clr_feedback"):
            self._hw_clr_feedback.configure(text="✅ Hardware password removed.")
        if hasattr(self, "_hw_clr_var"):
            self._hw_clr_var.set("")
        self._refresh_hw_vault_badge()

    def create_whitelist_tab(self):
        """
        Whitelist Manager tab — lets users view and manage the false-positive
        prevention database. Shows static built-ins and lets users add/remove
        custom keywords. Displays auto-update status.
        """
        tab = self.tabview.tab("✅ Whitelist Manager")
        tab.grid_columnconfigure(0, weight=1)
        tab.grid_rowconfigure(2, weight=1)

        # ── Header ─────────────────────────────────────────────────────────
        header = ctk.CTkFrame(tab, fg_color=COLORS['bg_card'], corner_radius=12)
        header.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 5))
        header.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(
            header,
            text="✅  Whitelist Database — Trusted Software Registry",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COLORS['accent_green']
        ).grid(row=0, column=0, padx=20, pady=(12, 2), sticky="w")

        ctk.CTkLabel(
            header,
            text="Known & trusted applications are automatically excluded from threat detection to eliminate false positives.",
            font=ctk.CTkFont(size=11),
            text_color=COLORS['text_secondary'],
            wraplength=800, justify="left"
        ).grid(row=1, column=0, padx=20, pady=(0, 12), sticky="w")

        # Stats badges
        stats_row = ctk.CTkFrame(tab, fg_color="transparent")
        stats_row.grid(row=1, column=0, sticky="ew", padx=10, pady=(0, 5))
        for i in range(5):
            stats_row.grid_columnconfigure(i, weight=1)

        def _wl_badge(col, label, color):
            f = ctk.CTkFrame(stats_row, fg_color=COLORS['bg_card'],
                             corner_radius=10, border_width=2, border_color=color)
            f.grid(row=0, column=col, padx=4, sticky="ew")
            ctk.CTkLabel(f, text=label, font=ctk.CTkFont(size=11),
                         text_color=COLORS['text_secondary']).pack(pady=(8, 2))
            val = ctk.CTkLabel(f, text="—", font=ctk.CTkFont(size=22, weight="bold"),
                               text_color=color)
            val.pack(pady=(0, 8))
            return val

        self._wl_badge_static   = _wl_badge(0, "📦 Built-in Rules",    COLORS['accent_blue'])
        self._wl_badge_dynamic  = _wl_badge(1, "🌐 Auto-updated",      COLORS['accent_green'])
        self._wl_badge_custom   = _wl_badge(2, "✏️  Custom",            COLORS['accent_purple'])
        self._wl_badge_total    = _wl_badge(3, "📊 Total Entries",     COLORS['accent_orange'])
        self._wl_badge_updated  = _wl_badge(4, "🕒 Last Updated",      COLORS['text_secondary'])

        # ── Main pane: split into list + controls ─────────────────────────
        main_pane = ctk.CTkFrame(tab, fg_color="transparent")
        main_pane.grid(row=2, column=0, sticky="nsew", padx=10, pady=(0, 10))
        main_pane.grid_columnconfigure(0, weight=2)
        main_pane.grid_columnconfigure(1, weight=1)
        main_pane.grid_rowconfigure(0, weight=1)

        # ── Left: keyword list ─────────────────────────────────────────────
        list_frame = ctk.CTkFrame(main_pane, fg_color=COLORS['bg_secondary'], corner_radius=10)
        list_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        list_frame.grid_rowconfigure(1, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)

        list_hdr = ctk.CTkFrame(list_frame, fg_color="transparent")
        list_hdr.grid(row=0, column=0, sticky="ew", padx=10, pady=8)
        list_hdr.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            list_hdr, text="Custom Whitelist Entries",
            font=ctk.CTkFont(size=13, weight="bold")
        ).grid(row=0, column=0, sticky="w")

        ctk.CTkButton(
            list_hdr, text="🔄 Refresh",
            command=self._refresh_whitelist_tab,
            width=90, height=28, corner_radius=8,
            fg_color=COLORS['accent_blue'], hover_color="#1d4ed8",
            font=ctk.CTkFont(size=11)
        ).grid(row=0, column=1, sticky="e")

        # Treeview for custom entries
        from tkinter import ttk as _ttk
        style = _ttk.Style()
        style.configure("WL.Treeview",
                        background=COLORS['bg_card'],
                        foreground=COLORS['text_primary'],
                        fieldbackground=COLORS['bg_card'],
                        borderwidth=0, font=("Consolas", 10), rowheight=24)
        style.configure("WL.Treeview.Heading",
                        background=COLORS['bg_secondary'],
                        foreground=COLORS['accent_green'],
                        font=("Consolas", 10, "bold"))
        style.map("WL.Treeview", background=[("selected", COLORS['accent_green'])])

        self._wl_tree = _ttk.Treeview(
            list_frame, columns=("keyword", "source"),
            show="headings", style="WL.Treeview", selectmode="browse"
        )
        self._wl_tree.heading("keyword", text="Keyword / Pattern")
        self._wl_tree.heading("source", text="Source")
        self._wl_tree.column("keyword", width=320, stretch=True)
        self._wl_tree.column("source", width=100, stretch=False)

        vsb_wl = _ttk.Scrollbar(list_frame, orient="vertical", command=self._wl_tree.yview)
        self._wl_tree.configure(yscrollcommand=vsb_wl.set)
        self._wl_tree.grid(row=1, column=0, sticky="nsew", padx=(8, 0), pady=(0, 8))
        vsb_wl.grid(row=1, column=1, sticky="ns", pady=(0, 8))

        # ── Right: add / remove controls ──────────────────────────────────
        ctrl_frame = ctk.CTkFrame(main_pane, fg_color=COLORS['bg_card'], corner_radius=10)
        ctrl_frame.grid(row=0, column=1, sticky="nsew", padx=(5, 0))
        ctrl_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            ctrl_frame, text="Add Custom Entry",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLORS['accent_green']
        ).grid(row=0, column=0, padx=15, pady=(15, 5), sticky="w")

        ctk.CTkLabel(
            ctrl_frame,
            text="Enter a keyword that appears in the\nfilename of a trusted application\n(e.g. 'antigravity', 'myvpn-setup'):",
            font=ctk.CTkFont(size=11),
            text_color=COLORS['text_secondary'],
            justify="left"
        ).grid(row=1, column=0, padx=15, pady=(0, 6), sticky="w")

        self._wl_entry = ctk.CTkEntry(
            ctrl_frame,
            placeholder_text="e.g. antigravity",
            height=34, corner_radius=8,
            fg_color=COLORS['bg_secondary'],
            border_color=COLORS['accent_green'],
            font=ctk.CTkFont(size=12)
        )
        self._wl_entry.grid(row=2, column=0, padx=15, pady=(0, 6), sticky="ew")

        ctk.CTkButton(
            ctrl_frame, text="➕  Add to Whitelist",
            command=self._add_whitelist_keyword,
            height=36, corner_radius=8,
            fg_color=COLORS['accent_green'], hover_color="#0d9668",
            font=ctk.CTkFont(size=12, weight="bold")
        ).grid(row=3, column=0, padx=15, pady=(0, 15), sticky="ew")

        # Divider
        ctk.CTkFrame(ctrl_frame, fg_color=COLORS['bg_secondary'],
                     height=1, corner_radius=0).grid(
            row=4, column=0, padx=15, pady=5, sticky="ew")

        ctk.CTkLabel(
            ctrl_frame, text="Remove Selected Entry",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLORS['accent_red']
        ).grid(row=5, column=0, padx=15, pady=(10, 5), sticky="w")

        ctk.CTkLabel(
            ctrl_frame,
            text="Select a custom entry in the list\nthen click Remove:",
            font=ctk.CTkFont(size=11),
            text_color=COLORS['text_secondary'],
            justify="left"
        ).grid(row=6, column=0, padx=15, pady=(0, 6), sticky="w")

        ctk.CTkButton(
            ctrl_frame, text="➖  Remove Selected",
            command=self._remove_whitelist_keyword,
            height=36, corner_radius=8,
            fg_color=COLORS['accent_red'], hover_color="#dc2626",
            font=ctk.CTkFont(size=12, weight="bold")
        ).grid(row=7, column=0, padx=15, pady=(0, 15), sticky="ew")

        # Divider
        ctk.CTkFrame(ctrl_frame, fg_color=COLORS['bg_secondary'],
                     height=1, corner_radius=0).grid(
            row=8, column=0, padx=15, pady=5, sticky="ew")

        ctk.CTkLabel(
            ctrl_frame, text="Auto-Update Status",
            font=ctk.CTkFont(size=13, weight="bold"),
            text_color=COLORS['accent_blue']
        ).grid(row=9, column=0, padx=15, pady=(10, 5), sticky="w")

        self._wl_update_status = ctk.CTkLabel(
            ctrl_frame,
            text="🔄 Checking...",
            font=ctk.CTkFont(size=11),
            text_color=COLORS['text_secondary'],
            justify="left", wraplength=180
        )
        self._wl_update_status.grid(row=10, column=0, padx=15, pady=(0, 8), sticky="w")

        ctk.CTkButton(
            ctrl_frame, text="🌐  Force Update Now",
            command=self._force_whitelist_update,
            height=34, corner_radius=8,
            fg_color=COLORS['accent_blue'], hover_color="#1d4ed8",
            font=ctk.CTkFont(size=11)
        ).grid(row=11, column=0, padx=15, pady=(0, 15), sticky="ew")

        # Initial data load
        self.after(200, self._refresh_whitelist_tab)

    def _refresh_whitelist_tab(self):
        """Reload whitelist stats and custom entries into the tab."""
        if not WHITELIST_AVAILABLE:
            return
        try:
            wl = get_whitelist_db()
            stats = wl.get_stats()

            self._wl_badge_static.configure(text=str(stats["static_keywords"]))
            self._wl_badge_dynamic.configure(text=str(stats["dynamic_keywords"]))
            self._wl_badge_custom.configure(text=str(len(wl.get_custom_keywords())))
            self._wl_badge_total.configure(text=str(stats["total"]))

            try:
                dt = datetime.fromisoformat(stats["last_updated"])
                age = datetime.now() - dt
                if age.days > 0:
                    age_str = f"{age.days}d ago"
                elif age.seconds > 3600:
                    age_str = f"{age.seconds//3600}h ago"
                else:
                    age_str = "Recent"
                self._wl_badge_updated.configure(text=age_str)
                self._wl_update_status.configure(
                    text=f"Last updated:\n{dt.strftime('%Y-%m-%d %H:%M')}",
                    text_color=COLORS['accent_green']
                )
            except Exception:
                self._wl_badge_updated.configure(text="—")

            # Populate treeview with custom keywords
            for item in self._wl_tree.get_children():
                self._wl_tree.delete(item)

            for kw in wl.get_custom_keywords():
                self._wl_tree.insert("", "end", values=(kw, "Custom"))

        except Exception as e:
            print(f"Whitelist refresh error: {e}")

    def _add_whitelist_keyword(self):
        """Add a keyword from the entry box to the whitelist."""
        if not WHITELIST_AVAILABLE:
            return
        kw = self._wl_entry.get().strip()
        if not kw:
            from tkinter import messagebox
            messagebox.showwarning("Empty", "Please enter a keyword first.")
            return
        try:
            wl = get_whitelist_db()
            wl.add_custom_keyword(kw)
            self._wl_entry.delete(0, "end")
            self._refresh_whitelist_tab()
            self._append_to_log(f"[WHITELIST] Added: '{kw}'", "system")
        except Exception as e:
            self._append_to_log(f"[WHITELIST] Add failed: {e}", "info")

    def _remove_whitelist_keyword(self):
        """Remove the selected entry from the custom whitelist."""
        if not WHITELIST_AVAILABLE:
            return
        sel = self._wl_tree.selection()
        if not sel:
            from tkinter import messagebox
            messagebox.showwarning("No Selection", "Select a custom entry to remove.")
            return
        kw = self._wl_tree.item(sel[0])["values"][0]
        try:
            wl = get_whitelist_db()
            wl.remove_custom_keyword(kw)
            self._refresh_whitelist_tab()
            self._append_to_log(f"[WHITELIST] Removed: '{kw}'", "info")
        except Exception as e:
            self._append_to_log(f"[WHITELIST] Remove failed: {e}", "info")

    def _force_whitelist_update(self):
        """Trigger an immediate background whitelist update from the web."""
        if not WHITELIST_AVAILABLE:
            return
        self._wl_update_status.configure(
            text="🔄 Fetching from web...", text_color=COLORS['accent_orange']
        )
        def _worker():
            try:
                wl = get_whitelist_db()
                wl._fetch_updates()
                wl._last_update = datetime.now()
                wl._save_last_update_time()
                self.after(0, self._refresh_whitelist_tab)
                self.after(0, lambda: self._append_to_log(
                    "[WHITELIST] Auto-update complete — database refreshed from web", "system"
                ))
            except Exception as e:
                self.after(0, lambda: self._wl_update_status.configure(
                    text=f"❌ Update failed:\n{str(e)[:60]}",
                    text_color=COLORS['accent_red']
                ))
        threading.Thread(target=_worker, daemon=True).start()

    # ==================== ADMIN PRIVILEGE MONITOR ====================

    def _on_priv_event(self, event):
        """
        Called from background thread when a privilege escalation is detected.
        Schedules GUI update on main thread safely.
        """
        self.after(0, lambda e=event: self._handle_priv_event(e))

    def _handle_priv_event(self, event):
        """
        Route privilege escalation event to the Admin Privilege Monitor
        challenge popup. This replaces the old generic messagebox.
        """
        try:
            sev   = event.severity.value if hasattr(event.severity, "value") else str(event.severity)
            pname = getattr(event, "process_name", "unknown")
            user  = getattr(event, "user", "unknown")
            desc  = getattr(event, "description", "")

            # Log to Live Logs tab
            self._append_to_log(
                f"[PRIV-{sev}] {pname} (user: {user}) — {desc}",
                "threat" if sev in ("CRITICAL", "HIGH") else "info"
            )
            self._flash_window()

            # Route to Admin Privilege Monitor challenge popup
            fn = getattr(self, "_adm_handle_event_fn", None)
            if fn:
                try:
                    fn(event)
                except Exception as e:
                    print(f"[AdminPriv] challenge routing error: {e}")
        except Exception as e:
            print(f"Priv event handler error: {e}")

    # ==================== HARDWARE GATEKEEPER ====================

    def _on_hardware_event(self, event_type: str, detail: str = ""):
        """
        Called from HardwareGatekeeper background thread — just enqueue.
        BG worker drains this queue; main thread applies via poll_log_buffer.
        """
        with self._hg_lock:
            self._hg_alert_queue.append((event_type, detail))

    def _poll_hardware_alerts(self):
        """Legacy stub — hardware alert draining is handled by BG worker + poll_log_buffer."""
        pass

    # ==================== CLEANUP ====================

    def on_closing(self):
        """Handle close — stop all threads and BG worker."""
        self.usb_monitor_active = False
        self.fim_monitor_active = False
        self._poll_running = False
        self._admin_tab_unlocked = False
        # Stop BG worker
        try:
            self._bg_running = False
        except Exception:
            pass

        if self.hub.scan_status.value == 'scanning':
            self.hub.stop_scan()

        if self.monitoring_active:
            self.hub.stop_dynamic_protection()

        self.network_monitor.stop()
        if self.admin_priv_monitor:
            try:
                self.admin_priv_monitor.stop()
            except Exception:
                pass
        if self.hardware_gatekeeper:
            try:
                self.hardware_gatekeeper.stop()
            except Exception:
                pass
        self.hub.shutdown()
        self.destroy()

    # ==================== INCIDENT RESPONSE TAB ====================

def main():
    """Main entry point."""
    print("=" * 70)
    print("SENTINEL DEFENDER v5.0 - DEEP PROTECTION")
    print("=" * 70)
    print()
    print("STABILITY PATCH ACTIVE:")
    print("  [OK] Engine throttle (1ms pause/10 files)")
    print("  [OK] Reduced polling (200ms)")
    print("  [OK] Slower graph updates (2s)")
    print("  [OK] Professional tabular logs")
    print()
    
    try:
        import customtkinter
        print("[OK] customtkinter found")
    except ImportError:
        print("✗ customtkinter not found")
        print("  Install: pip install customtkinter")
        return
    
    if PSUTIL_AVAILABLE:
        print("[OK] psutil found")
    else:
        print("[WARNING] psutil not found (optional)")
    
    if MATPLOTLIB_AVAILABLE:
        print("[OK] matplotlib found")
    else:
        print("[WARNING] matplotlib not found (optional)")
    
    print("\n[LAUNCH] Launching Optimized Dashboard...")
    
    app = SentinelDefenderGUI()
    app.mainloop()


if __name__ == "__main__":
    main()
